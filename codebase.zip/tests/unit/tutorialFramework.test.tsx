import { act, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { scenarioTemplates } from "@/domain/scenarios/registry";
import {
  getTutorialForScenario,
  tutorialDefinitions
} from "@/domain/tutorials/registry";
import { tutorialDefinitionSchema } from "@/domain/tutorials/schema";
import { TutorialPanel } from "@/features/tutorials/TutorialPanel";
import { useProjectStore } from "@/stores/projectStore";
import { useTutorialStore } from "@/stores/tutorialStore";
import { useUiStore } from "@/stores/uiStore";
import { isTutorialBlockedShortcut } from "@/features/tutorials/keyboard";

const basicTutorial = getTutorialForScenario("basic-web-application")!;

function resetTutorialStore(): void {
  useTutorialStore.setState({ activeTutorialId: undefined, progressByTutorial: {} });
  localStorage.clear();
}

describe("tutorial registry", () => {
  it("defines one valid capability-gated tutorial for every scenario", () => {
    expect(tutorialDefinitions).toHaveLength(scenarioTemplates.length);
    expect(new Set(tutorialDefinitions.map((tutorial) => tutorial.scenarioId)).size).toBe(
      scenarioTemplates.length
    );

    for (const tutorial of tutorialDefinitions) {
      expect(tutorialDefinitionSchema.safeParse(tutorial).success).toBe(true);
      expect(tutorial.steps.every((step) =>
        ["acknowledge", "observe", "run", "open-metrics"].includes(step.action)
      )).toBe(true);
    }
  });

  it("uses a fuller pilot flow for Basic Web Application", () => {
    expect(basicTutorial.steps.map((step) => step.id)).toEqual([
      "load-scenario",
      "trace-request-path",
      "review-single-server",
      "run-default-simulation",
      "open-run-metrics",
      "finish-overview"
    ]);
  });
});

describe("tutorial progress store", () => {
  beforeEach(resetTutorialStore);
  afterEach(resetTutorialStore);

  it("supports acknowledgement, navigation, restart, exit, and completion", () => {
    const store = useTutorialStore.getState();
    store.start(basicTutorial.id);
    store.next();
    store.acknowledge("trace-request-path", true);

    let progress = useTutorialStore.getState().progressByTutorial[basicTutorial.id]!;
    expect(progress.currentStepIndex).toBe(1);
    expect(progress.acknowledgedStepIds).toContain("trace-request-path");

    useTutorialStore.getState().back();
    expect(useTutorialStore.getState().progressByTutorial[basicTutorial.id]!.currentStepIndex).toBe(0);

    useTutorialStore.getState().restart();
    progress = useTutorialStore.getState().progressByTutorial[basicTutorial.id]!;
    expect(progress).toEqual({
      currentStepIndex: 0,
      acknowledgedStepIds: [],
      completed: false,
      revealedHintCount: 0
    });

    for (let index = 0; index < basicTutorial.steps.length; index += 1) {
      useTutorialStore.getState().next();
    }
    expect(useTutorialStore.getState().activeTutorialId).toBeUndefined();
    expect(useTutorialStore.getState().progressByTutorial[basicTutorial.id]!.completed).toBe(true);

    useTutorialStore.getState().start(basicTutorial.id);
    useTutorialStore.getState().exit();
    expect(useTutorialStore.getState().activeTutorialId).toBeUndefined();
  });

  it("keeps progress in local storage rather than project data", () => {
    useTutorialStore.getState().start(basicTutorial.id);
    useTutorialStore.getState().next();

    const saved = JSON.parse(
      localStorage.getItem("system-design-simulator-tutorials") ?? "{}"
    ) as { state?: Record<string, unknown> };
    expect(saved.state).toHaveProperty("progressByTutorial");
    expect(saved.state).not.toHaveProperty("activeTutorialId");
    expect(useProjectStore.getState().document).not.toHaveProperty("tutorial");
    expect(useProjectStore.getState().isDirty).toBe(false);
  });
});

describe("tutorial keyboard isolation", () => {
  it.each([
    { key: "s", ctrlKey: true, metaKey: false, shiftKey: false },
    { key: "m", ctrlKey: false, metaKey: true, shiftKey: false },
    { key: "z", ctrlKey: true, metaKey: false, shiftKey: false },
    { key: "y", ctrlKey: true, metaKey: false, shiftKey: false },
    { key: "F10", ctrlKey: false, metaKey: false, shiftKey: true },
    { key: "Delete", ctrlKey: false, metaKey: false, shiftKey: false },
    { key: "Backspace", ctrlKey: false, metaKey: false, shiftKey: false },
    { key: "Enter", ctrlKey: false, metaKey: false, shiftKey: false }
  ])("blocks $key while a tutorial owns keyboard interaction", (event) => {
    expect(isTutorialBlockedShortcut(event)).toBe(true);
  });

  it("does not classify ordinary navigation keys as global shortcuts", () => {
    expect(
      isTutorialBlockedShortcut({
        key: "Tab",
        ctrlKey: false,
        metaKey: false,
        shiftKey: false
      })
    ).toBe(false);
  });
});

describe("TutorialPanel", () => {
  beforeEach(() => {
    resetTutorialStore();
    useUiStore.setState({
      activeScenarioId: "basic-web-application",
      metricsModalOpen: false,
      contextPanelOpen: true,
      contextPanelTab: "objectives"
    });
    useProjectStore.getState().newProject();
  });

  afterEach(() => {
    act(() => {
      resetTutorialStore();
      useUiStore.setState({ activeScenarioId: undefined });
    });
  });

  it("advances automatic and manually acknowledged steps accessibly", () => {
    act(() => useTutorialStore.getState().start(basicTutorial.id));
    render(<TutorialPanel />);

    expect(screen.getByRole("dialog", { name: basicTutorial.title })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Next" })).toBeEnabled();
    fireEvent.click(screen.getByRole("button", { name: "Next" }));

    expect(screen.getByRole("button", { name: "Next" })).toBeDisabled();
    fireEvent.click(screen.getByRole("checkbox", { name: "I traced the request path" }));
    expect(screen.getByRole("button", { name: "Next" })).toBeEnabled();
  });

  it("exits on Escape and prevents the key from reaching global bubble handlers", () => {
    let bubbled = false;
    const listener = (): void => {
      bubbled = true;
    };
    window.addEventListener("keydown", listener);
    act(() => useTutorialStore.getState().start(basicTutorial.id));
    render(<TutorialPanel />);

    fireEvent.keyDown(window, { key: "Escape" });

    expect(useTutorialStore.getState().activeTutorialId).toBeUndefined();
    expect(bubbled).toBe(false);
    window.removeEventListener("keydown", listener);
  });
});
