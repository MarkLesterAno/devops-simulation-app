import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const workspaceRoot = path.resolve(import.meta.dirname, "../..");

describe("release security boundaries", () => {
  it("uses a restrictive local-only CSP and permits blob images only for local PNG export", () => {
    const html = fs.readFileSync(path.join(workspaceRoot, "index.html"), "utf8");
    const policy = html.match(/Content-Security-Policy"\s+content="([^"]+)"/)?.[1];

    expect(policy).toBeDefined();
    expect(policy).toContain("default-src 'self'");
    expect(policy).toContain("script-src 'self'");
    expect(policy).toContain("connect-src 'self'");
    expect(policy).toContain("object-src 'none'");
    expect(policy).toContain("base-uri 'none'");
    expect(policy).toContain("img-src 'self' data: blob:");
  });

  it("keeps Electron renderer isolation and sandboxing enabled", () => {
    const main = fs.readFileSync(path.join(workspaceRoot, "electron/main/index.ts"), "utf8");
    const preload = fs.readFileSync(path.join(workspaceRoot, "electron/preload/index.cts"), "utf8");

    expect(main).toContain("contextIsolation: true");
    expect(main).toContain("nodeIntegration: false");
    expect(main).toContain("sandbox: true");
    expect(preload).not.toContain("contextBridge.exposeInMainWorld(\"ipcRenderer\"");
    expect(preload).not.toContain("contextBridge.exposeInMainWorld(\"require\"");
  });
});
