import { beforeEach, describe, expect, it } from "vitest";
import { useToastStore } from "@/stores/toastStore";

describe("application notifications", () => {
  beforeEach(() => {
    useToastStore.setState({ appNotifications: [] });
  });

  it("creates a persistent, dismissible error notification with the supplied detail", () => {
    useToastStore.getState().notify({
      severity: "error",
      title: "Could not save project",
      detail: "Permission denied"
    });

    const notification = useToastStore.getState().appNotifications[0];
    expect(notification).toMatchObject({
      severity: "error",
      title: "Could not save project",
      detail: "Permission denied"
    });

    useToastStore.getState().dismissAppNotification(notification!.id);
    expect(useToastStore.getState().appNotifications).toEqual([]);
  });

  it("keeps notifications out of the project document and finding history", () => {
    useToastStore.getState().notify({ severity: "info", title: "Export complete" });

    expect(useToastStore.getState().appNotifications).toHaveLength(1);
    expect(useToastStore.getState().history).toEqual([]);
  });
});
