import { describe, expect, it } from "vitest";
import {
  buildCatalog,
  filterTechnologies,
  getAdvisoriesForRole,
  getCapabilitiesForRole,
  getTechnologiesForComponentType,
  resolveTechnologyAssignment,
  technologyCatalog,
  toTechnologyAssignment
} from "@/domain/technology/registry";
import { GENERIC_TECHNOLOGY_ID, type TechnologyOptionInput } from "@/domain/technology/schema";
import { componentTypeSchema } from "@/domain/architecture/schema";
import { parseProjectDocument } from "@/domain/architecture/projectDocument";
import { useProjectStore } from "@/stores/projectStore";
import { runSimulation } from "@/simulation-engine/core/SimulationEngine";
import { defaultSimulationSettings, type SimulationInput } from "@/domain/simulation/simulationInput";
import { node, edge, project } from "./testFixtures";
import { diffPreset, buildPresetPatch } from "@/domain/technology/presets";

const componentTypes = new Set<string>(componentTypeSchema.options);

// Deliberately loosely typed: several cases below feed structurally invalid data
// to buildCatalog to prove the integrity checks reject it.
function baseEntry(overrides: Record<string, unknown> = {}): TechnologyOptionInput {
  return {
    id: "example-product",
    displayName: "Example Product",
    provider: "Example Corp",
    deploymentModel: ["open-source"],
    componentTypes: ["cache"],
    description: "An example technology entry used for catalog integrity tests.",
    capabilities: ["in-memory"],
    modelVersion: "1.0.0",
    ...overrides
  } as TechnologyOptionInput;
}

describe("technology catalog integrity", () => {
  it("loads a non-empty catalog", () => {
    expect(technologyCatalog.length).toBeGreaterThan(100);
  });

  it("gives every entry a stable, unique, kebab-case id", () => {
    const ids = technologyCatalog.map((option) => option.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const id of ids) {
      expect(id).toMatch(/^[a-z0-9]+(-[a-z0-9]+)*$/);
    }
  });

  it("never collides with the generic sentinel id", () => {
    expect(technologyCatalog.some((option) => option.id === GENERIC_TECHNOLOGY_ID)).toBe(false);
  });

  it("maps every entry to at least one valid component type", () => {
    for (const option of technologyCatalog) {
      expect(option.componentTypes.length).toBeGreaterThan(0);
      for (const componentType of option.componentTypes) {
        expect(componentTypes.has(componentType)).toBe(true);
      }
    }
  });

  it("never offers technologies for client nodes", () => {
    expect(getTechnologiesForComponentType("client")).toHaveLength(0);
  });

  it("offers technologies for every non-client component type", () => {
    for (const componentType of componentTypeSchema.options) {
      if (componentType === "client") continue;
      expect(getTechnologiesForComponentType(componentType).length).toBeGreaterThan(0);
    }
  });

  it("rejects duplicate ids", () => {
    expect(() => buildCatalog([baseEntry(), baseEntry({ displayName: "Other" })])).toThrow(
      /duplicate/i
    );
  });

  it("rejects duplicate provider/product pairs", () => {
    expect(() => buildCatalog([baseEntry(), baseEntry({ id: "example-product-two" })])).toThrow(
      /duplicate/i
    );
  });

  it("rejects structurally invalid entries", () => {
    expect(() => buildCatalog([baseEntry({ componentTypes: ["not-a-component"] })])).toThrow();
    expect(() => buildCatalog([baseEntry({ id: "Not Kebab Case" })])).toThrow();
  });

  it("scopes advisories and capabilities to the role being filled", () => {
    const redis = technologyCatalog.find((option) => option.id === "redis");
    expect(redis).toBeDefined();
    expect(redis!.componentTypes.length).toBeGreaterThan(1);
    const cacheCapabilities = getCapabilitiesForRole(redis!, "cache");
    const queueCapabilities = getCapabilitiesForRole(redis!, "message-queue");
    expect(cacheCapabilities).not.toEqual(queueCapabilities);
  });

  it("surfaces a warning-worthy status for legacy and deprecated entries", () => {
    const retired = technologyCatalog.filter((option) => option.status !== "current");
    expect(retired.length).toBeGreaterThan(0);
    for (const option of retired) {
      expect(["legacy", "deprecated"]).toContain(option.status);
    }
  });

  it("flags non-relational stores mapped onto the relational database component", () => {
    const mongo = technologyCatalog.find((option) => option.id === "mongodb");
    expect(mongo).toBeDefined();
    const advisories = getAdvisoriesForRole(mongo!, "relational-database");
    expect(advisories.some((advisory) => /non-relational/i.test(advisory.message))).toBe(true);
  });

  it("searches across names, providers, aliases, and capabilities", () => {
    const options = getTechnologiesForComponentType("cache");
    expect(filterTechnologies(options, { search: "redis" }).length).toBeGreaterThan(0);
    expect(filterTechnologies(options, { search: "zzzz-no-such-product" })).toHaveLength(0);
    const openSource = filterTechnologies(options, { deploymentModel: "open-source" });
    expect(openSource.every((option) => option.deploymentModel.includes("open-source"))).toBe(true);
  });
});

describe("technology assignment resolution", () => {
  it("treats a missing assignment as generic", () => {
    expect(resolveTechnologyAssignment(undefined, "cache").state).toBe("generic");
  });

  it("resolves a known, compatible assignment", () => {
    const redis = technologyCatalog.find((option) => option.id === "redis")!;
    const resolution = resolveTechnologyAssignment(toTechnologyAssignment(redis), "cache");
    expect(resolution.state).toBe("known");
    if (resolution.state === "known") {
      expect(resolution.compatible).toBe(true);
    }
  });

  it("preserves an unknown technology instead of discarding it", () => {
    const resolution = resolveTechnologyAssignment(
      { id: "some-retired-product", displayName: "Some Retired Product" },
      "cache"
    );
    expect(resolution.state).toBe("unknown");
    if (resolution.state === "unknown") {
      expect(resolution.assignment.displayName).toBe("Some Retired Product");
    }
  });

  it("marks a known but incompatible assignment", () => {
    const redis = technologyCatalog.find((option) => option.id === "redis")!;
    const resolution = resolveTechnologyAssignment(toTechnologyAssignment(redis), "cdn");
    expect(resolution.state).toBe("known");
    if (resolution.state === "known") {
      expect(resolution.compatible).toBe(false);
    }
  });
});

describe("simulation presets", () => {
  it("reports only the fields that would actually change", () => {
    const changes = diffPreset({ baseLatencyMs: 5 }, { baseLatencyMs: 5, timeoutMs: 1000 });
    expect(changes.map((change) => change.key)).toEqual(["timeoutMs"]);
  });

  it("supports selective application", () => {
    const patch = buildPresetPatch({ baseLatencyMs: 2, timeoutMs: 500 }, ["timeoutMs"]);
    expect(patch).toEqual({ timeoutMs: 500 });
  });
});

describe("technology assignments in the project document", () => {
  it("survives a save/load round trip", () => {
    const store = useProjectStore.getState();
    store.newProject();
    store.addNode("cache", { x: 0, y: 0 });
    const nodeId = useProjectStore.getState().document.nodes.at(-1)!.id;
    const redis = technologyCatalog.find((option) => option.id === "redis")!;
    useProjectStore.getState().setNodeTechnology(nodeId, toTechnologyAssignment(redis));

    const serialized = JSON.stringify(useProjectStore.getState().document);
    const parsed = parseProjectDocument(JSON.parse(serialized));
    expect(parsed.ok).toBe(true);
    const restored = parsed.document?.nodes.find((node) => node.id === nodeId);
    expect(restored?.config.technology).toEqual(toTechnologyAssignment(redis));
  });

  it("clears back to generic without touching tuned simulation values", () => {
    const store = useProjectStore.getState();
    store.newProject();
    store.addNode("cache", { x: 0, y: 0 });
    const nodeId = useProjectStore.getState().document.nodes.at(-1)!.id;
    useProjectStore.getState().updateNodeConfig(nodeId, { baseLatencyMs: 42 });
    const redis = technologyCatalog.find((option) => option.id === "redis")!;
    useProjectStore.getState().setNodeTechnology(nodeId, toTechnologyAssignment(redis));
    useProjectStore.getState().setNodeTechnology(nodeId, undefined);

    const node = useProjectStore.getState().document.nodes.find((entry) => entry.id === nodeId)!;
    expect(node.config.technology).toBeUndefined();
    expect(node.config.baseLatencyMs).toBe(42);
  });

  it("does not affect simulation results", () => {
    const redis = technologyCatalog.find((option) => option.id === "redis")!;
    const plainNodes = [
      node("client", "client"),
      node("app", "server", { perInstanceCapacityRps: 1000, baseLatencyMs: 5, jitterMs: 0 })
    ];
    const taggedNodes = plainNodes.map((entry) =>
      entry.id === "app"
        ? { ...entry, config: { ...entry.config, technology: toTechnologyAssignment(redis) } }
        : entry
    );
    const edges = [edge("e1", "client", "app")];

    const input = (nodes: typeof plainNodes): SimulationInput => ({
      projectSnapshot: project(nodes, edges),
      trafficProfileId: "profile-1",
      faultScenarioIds: [],
      durationMs: 1000,
      seed: 42,
      settings: defaultSimulationSettings()
    });

    const before = runSimulation(input(plainNodes));
    const after = runSimulation(input(taggedNodes));

    expect(after.status).toBe(before.status);
    expect(after.observedAvailability).toBe(before.observedAvailability);
    expect(after.systemMetrics.map((snapshot) => snapshot.requestCount)).toEqual(
      before.systemMetrics.map((snapshot) => snapshot.requestCount)
    );
  });
});
