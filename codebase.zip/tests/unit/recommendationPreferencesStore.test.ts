import { beforeEach, describe, expect, it } from "vitest";
import { useRecommendationPreferencesStore } from "@/stores/recommendationPreferencesStore";
import { useProjectStore } from "@/stores/projectStore";

function resetStore(): void {
  useRecommendationPreferencesStore.setState({
    preferOpenSource: false,
    preferManagedServices: false,
    preferredProviders: []
  });
  localStorage.clear();
}

describe("recommendation preferences store", () => {
  beforeEach(resetStore);

  it("starts with conservative defaults", () => {
    const state = useRecommendationPreferencesStore.getState();
    expect(state.preferOpenSource).toBe(false);
    expect(state.preferManagedServices).toBe(false);
    expect(state.preferredProviders).toEqual([]);
  });

  it("toggles preferences independently", () => {
    useRecommendationPreferencesStore.getState().setPreferOpenSource(true);
    expect(useRecommendationPreferencesStore.getState().preferManagedServices).toBe(false);
    expect(useRecommendationPreferencesStore.getState().preferOpenSource).toBe(true);
    useRecommendationPreferencesStore.getState().setPreferManagedServices(true);
    expect(useRecommendationPreferencesStore.getState().preferManagedServices).toBe(true);
  });

  it("adds and removes preferred providers without duplicates", () => {
    useRecommendationPreferencesStore.getState().addPreferredProvider("Amazon Web Services");
    useRecommendationPreferencesStore.getState().addPreferredProvider("Amazon Web Services");
    expect(useRecommendationPreferencesStore.getState().preferredProviders).toEqual([
      "Amazon Web Services"
    ]);
    useRecommendationPreferencesStore.getState().removePreferredProvider("Amazon Web Services");
    expect(useRecommendationPreferencesStore.getState().preferredProviders).toEqual([]);
  });

  it("persists preferences to local storage isolated from the project document", () => {
    useRecommendationPreferencesStore.getState().setPreferOpenSource(true);
    useRecommendationPreferencesStore.getState().addPreferredProvider("Redis");

    const saved = JSON.parse(
      localStorage.getItem("system-design-simulator-recommendation-preferences") ?? "{}"
    ) as { state?: Record<string, unknown> };
    expect(saved.state).toMatchObject({ preferOpenSource: true, preferredProviders: ["Redis"] });

    // Local UI preferences must never leak into the versioned project document.
    expect(useProjectStore.getState().document).not.toHaveProperty("recommendationPreferences");
    expect(useProjectStore.getState().isDirty).toBe(false);
  });

  it("resets to defaults", () => {
    useRecommendationPreferencesStore.getState().setPreferOpenSource(true);
    useRecommendationPreferencesStore.getState().addPreferredProvider("Redis");
    useRecommendationPreferencesStore.getState().reset();
    expect(useRecommendationPreferencesStore.getState()).toMatchObject({
      preferOpenSource: false,
      preferManagedServices: false,
      preferredProviders: []
    });
  });
});