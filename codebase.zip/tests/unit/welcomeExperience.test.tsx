import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { WelcomeExperience } from "@/features/onboarding/WelcomeExperience";
import { useProjectStore } from "@/stores/projectStore";
import { useTutorialStore } from "@/stores/tutorialStore";
import { useUiStore } from "@/stores/uiStore";
import { useWelcomeStore } from "@/stores/welcomeStore";

function resetStores(): void {
  localStorage.clear();
  useProjectStore.getState().newProject();
  useTutorialStore.setState({ activeTutorialId: undefined, progressByTutorial: {} });
  useUiStore.setState({ activeScenarioId: undefined, scenarioGalleryOpen: false });
  useWelcomeStore.setState({ hasSeenWelcome: false, isOpen: false });
}

describe("WelcomeExperience", () => {
  beforeEach(() => {
    act(resetStores);
  });

  afterEach(() => {
    cleanup();
    act(resetStores);
  });

  it("explains the local-model boundary and can be dismissed without changing a project", () => {
    render(<WelcomeExperience />);

    expect(
      screen.getByRole("dialog", { name: "Welcome to the System Design Simulator" })
    ).toBeInTheDocument();
    expect(screen.getByText(/never sends HTTP traffic/i)).toBeInTheDocument();

    act(() => {
      fireEvent.click(screen.getByRole("button", { name: "Build from scratch" }));
    });

    expect(useWelcomeStore.getState().hasSeenWelcome).toBe(true);
    expect(useProjectStore.getState().isDirty).toBe(false);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("opens the beginner guided scenario and starts its tutorial", () => {
    render(<WelcomeExperience />);

    act(() => {
      fireEvent.click(screen.getByRole("button", { name: "Start guided beginner scenario" }));
    });

    expect(useUiStore.getState().activeScenarioId).toBe("basic-web-application");
    expect(useUiStore.getState().activeScenarioMode).toBe("guided-tour");
    expect(useProjectStore.getState().document.nodes.length).toBeGreaterThan(0);
    expect(useTutorialStore.getState().activeTutorialId).toBe("basic-web-application-tutorial");
  });

  it("routes users to the scenario library without creating a project", () => {
    render(<WelcomeExperience />);

    act(() => {
      fireEvent.click(screen.getByRole("button", { name: "Browse scenarios" }));
    });

    expect(useUiStore.getState().scenarioGalleryOpen).toBe(true);
    expect(useProjectStore.getState().document.nodes).toHaveLength(0);
  });
});
