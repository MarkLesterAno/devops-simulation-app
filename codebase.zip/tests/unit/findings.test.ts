import { describe, expect, it } from "vitest";
import { deriveFindings } from "@/simulation-engine/core/findings";
import type { ComponentMetricSnapshot } from "@/domain/metrics/schema";

function metric(nodeId: string, utilization: number): ComponentMetricSnapshot {
  return {
    timestampMs: 1_000,
    nodeId,
    utilization,
    latencyMs: 25,
    errorRate: 0,
    activeWork: 1,
    queuedWork: 0,
    queueDepth: 0
  };
}

describe("deriveFindings", () => {
  it("connects low availability to saturated components when the run observed both", () => {
    const findings = deriveFindings([], [metric("app", 0.98)], 0.9);
    const availability = findings.find((finding) => finding.id === "observed-availability");
    expect(availability?.relatedNodeIds).toEqual(["app"]);
    expect(availability?.evidence).toContain("saturated-nodes=app");
    expect(availability?.suggestedAction).toMatch(/saturated/i);
  });

  it("points learners toward faults and timeouts when availability is low without saturation", () => {
    const findings = deriveFindings([], [metric("app", 0.4)], 0.97);
    const availability = findings.find((finding) => finding.id === "observed-availability");
    expect(availability?.relatedNodeIds).toEqual([]);
    expect(availability?.suggestedAction).toMatch(/faults disabled/i);
  });
});
