import { describe, expect, it } from "vitest";
import { EventQueue, EventPriority, type SimulationEventBase } from "@/simulation-engine/events/EventQueue";

interface TestEvent extends SimulationEventBase {
  label: string;
}

function makeEvent(
  timestampMs: number,
  priority: EventPriority,
  sequence: number,
  label: string
): TestEvent {
  return { timestampMs, priority, sequence, type: "test", label };
}

describe("EventQueue", () => {
  it("pops events strictly in ascending timestamp order", () => {
    const queue = new EventQueue<TestEvent>();
    queue.push(makeEvent(30, EventPriority.ArrivalForwardOrRetry, 1, "c"));
    queue.push(makeEvent(10, EventPriority.ArrivalForwardOrRetry, 2, "a"));
    queue.push(makeEvent(20, EventPriority.ArrivalForwardOrRetry, 3, "b"));

    const order = [queue.pop()?.label, queue.pop()?.label, queue.pop()?.label];
    expect(order).toEqual(["a", "b", "c"]);
  });

  it("breaks timestamp ties using priority class", () => {
    const queue = new EventQueue<TestEvent>();
    queue.push(makeEvent(10, EventPriority.MetricSnapshot, 1, "metric"));
    queue.push(makeEvent(10, EventPriority.FaultBoundary, 2, "fault"));
    queue.push(makeEvent(10, EventPriority.CompletionOrConsume, 3, "completion"));

    const order = [queue.pop()?.label, queue.pop()?.label, queue.pop()?.label];
    expect(order).toEqual(["fault", "completion", "metric"]);
  });

  it("breaks timestamp+priority ties using monotonic sequence", () => {
    const queue = new EventQueue<TestEvent>();
    queue.push(makeEvent(10, EventPriority.ArrivalForwardOrRetry, 5, "second"));
    queue.push(makeEvent(10, EventPriority.ArrivalForwardOrRetry, 2, "first"));

    const order = [queue.pop()?.label, queue.pop()?.label];
    expect(order).toEqual(["first", "second"]);
  });

  it("reports size and emptiness correctly", () => {
    const queue = new EventQueue<TestEvent>();
    expect(queue.isEmpty()).toBe(true);
    queue.push(makeEvent(1, EventPriority.ArrivalForwardOrRetry, 1, "only"));
    expect(queue.isEmpty()).toBe(false);
    expect(queue.size).toBe(1);
    queue.pop();
    expect(queue.isEmpty()).toBe(true);
  });

  it("maintains order under many randomized insertions (heap correctness)", () => {
    const queue = new EventQueue<TestEvent>();
    const timestamps: number[] = [];
    for (let i = 0; i < 500; i += 1) {
      const timestamp = Math.floor(Math.sin(i) * 1000 + 1000);
      timestamps.push(timestamp);
      queue.push(makeEvent(timestamp, EventPriority.ArrivalForwardOrRetry, i, String(i)));
    }
    const popped: number[] = [];
    while (!queue.isEmpty()) {
      popped.push(queue.pop()!.timestampMs);
    }
    const expected = [...timestamps].sort((a, b) => a - b);
    expect(popped).toEqual(expected);
  });
});
