import type {
  ArchitectureEdge,
  ArchitectureNode,
  BaseComponentConfig,
  ComponentType
} from "@/domain/architecture/schema";
import type { ProjectDocument } from "@/domain/architecture/projectDocument";
import { PROJECT_SCHEMA_VERSION } from "@/domain/architecture/projectDocument";
import type { TrafficProfile } from "@/domain/simulation/trafficProfile";
import type { FaultScenario } from "@/domain/simulation/faultScenario";

const baseConfig: BaseComponentConfig = {
  displayName: "node",
  region: "local",
  instanceCount: 1,
  perInstanceCapacityRps: 100,
  baseLatencyMs: 5,
  jitterMs: 0,
  timeoutMs: 2000,
  errorRate: 0,
  overflowBehavior: "queue",
  maxQueueDepth: 1000,
  estimatedCostPerHour: 0,
  maxRetries: 0,
  retryBackoffMs: 100
};

export function node(
  id: string,
  type: ComponentType,
  overrides: Partial<BaseComponentConfig & Record<string, unknown>> = {}
): ArchitectureNode {
  return {
    id,
    type,
    position: { x: 0, y: 0 },
    config: { ...baseConfig, displayName: id, ...overrides }
  };
}

export function edge(
  id: string,
  sourceNodeId: string,
  targetNodeId: string,
  overrides: Partial<ArchitectureEdge> = {}
): ArchitectureEdge {
  return {
    id,
    sourceNodeId,
    targetNodeId,
    kind: "request",
    latencyMs: 0,
    ...overrides
  };
}

export function trafficProfile(overrides: Partial<TrafficProfile> = {}): TrafficProfile {
  return {
    id: "profile-1",
    name: "Constant",
    durationMs: 1000,
    intervals: [{ kind: "constant", startMs: 0, endMs: 1000, startRps: 100, endRps: 100 }],
    readRatio: 0.8,
    concurrentUsers: 100,
    requestSizeBytes: 1024,
    responseSizeBytes: 4096,
    ...overrides
  };
}

export function project(
  nodes: ArchitectureNode[],
  edges: ArchitectureEdge[],
  profiles: TrafficProfile[] = [trafficProfile()],
  faultScenarios: FaultScenario[] = []
): ProjectDocument {
  const now = new Date().toISOString();
  return {
    schemaVersion: PROJECT_SCHEMA_VERSION,
    id: "project-1",
    name: "Test Project",
    createdAt: now,
    updatedAt: now,
    nodes,
    edges,
    trafficProfiles: profiles,
    faultScenarios
  };
}
