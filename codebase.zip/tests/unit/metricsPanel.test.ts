import { describe, expect, it } from "vitest";
import type { SystemMetricSnapshot } from "@/domain/metrics/schema";
import {
  downsampleSystemMetrics,
  MAX_METRICS_CHART_POINTS,
  utilizationState
} from "@/features/metrics/metricsChart";

function snapshot(timestampMs: number): SystemMetricSnapshot {
  return {
    timestampMs,
    requestCount: 0,
    successCount: 0,
    failureCount: 0,
    rps: 0,
    errorRate: 0,
    latency: { p50: 0, p95: 0, p99: 0 }
  };
}

describe("metrics chart presentation", () => {
  it("keeps the first and final measurement when downsampling a long run", () => {
    const source = Array.from({ length: MAX_METRICS_CHART_POINTS + 100 }, (_, index) =>
      snapshot(index * 1_000)
    );

    const sampled = downsampleSystemMetrics(source);

    expect(sampled.length).toBeLessThanOrEqual(MAX_METRICS_CHART_POINTS);
    expect(sampled[0]).toBe(source[0]);
    expect(sampled[sampled.length - 1]).toBe(source[source.length - 1]);
  });

  it("uses the documented utilization thresholds", () => {
    expect(utilizationState(0.69)).toBe("healthy");
    expect(utilizationState(0.7)).toBe("warning");
    expect(utilizationState(0.85)).toBe("degraded");
    expect(utilizationState(0.95)).toBe("degraded");
    expect(utilizationState(0.951)).toBe("failed");
  });
});
