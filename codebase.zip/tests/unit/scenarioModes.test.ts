import { describe, expect, it } from "vitest";
import {
  buildScenarioDocument,
  getScenarioStartingState
} from "@/domain/scenarios/builder";
import { getScenarioFaultPresets, scenarioTemplates } from "@/domain/scenarios/registry";

describe("scenario learning modes", () => {
  it("keeps the reference graph only for Guided Tour and gives Challenge a blank canvas", () => {
    for (const template of scenarioTemplates) {
      const reference = getScenarioStartingState(template, "guided-tour");
      const challenge = getScenarioStartingState(template, "challenge");
      expect(reference.kind).toBe("complete");
      expect(reference.nodes).toHaveLength(template.blueprint.nodes.length);
      expect(challenge.kind).toBe("empty");
      expect(challenge.nodes).toHaveLength(0);
      expect(challenge.edges).toHaveLength(0);
    }
  });

  it("provides a deliberate Build starting state with internally consistent retained connections", () => {
    for (const template of scenarioTemplates) {
      const state = getScenarioStartingState(template, "build");
      const document = buildScenarioDocument(template, { mode: "build", id: template.metadata.id });
      expect(state.rationale, template.metadata.id).not.toHaveLength(0);
      expect(document.nodes.map((node) => node.id)).toEqual(state.nodes.map((node) => node.id));
      const ids = new Set(document.nodes.map((node) => node.id));
      expect(
        document.edges.every((edge) => ids.has(edge.sourceNodeId) && ids.has(edge.targetNodeId))
      ).toBe(true);
    }
  });

  it("pairs every shipped fault with a valid sustained request preset and real node target", () => {
    for (const template of scenarioTemplates) {
      const nodeIds = new Set(template.blueprint.nodes.map((node) => node.id));
      for (const fault of getScenarioFaultPresets(template.metadata.id)) {
        expect(fault.pairedRequestPresetId).toBe(`${template.metadata.id}-sustained`);
        expect(fault.targetNodeIds.every((nodeId) => nodeIds.has(nodeId))).toBe(true);
      }
    }
  });
});
