import { afterEach, describe, expect, it } from "vitest";
import { useProjectStore } from "@/stores/projectStore";
import { buildScenarioDocument } from "@/domain/scenarios/builder";
import { scenarioTemplates } from "@/domain/scenarios/registry";
import { hasBlockingErrors } from "@/domain/validation/graphValidation";

/**
 * Integration tests for the scenario gallery's path through `projectStore`:
 * `ScenarioGallery.handleOpenTemplate` builds a document with
 * `buildScenarioDocument` and hands it to `loadTemplateDocument`. These tests
 * exercise that same path directly rather than mounting the React component.
 */
describe("scenario gallery integration", () => {
  afterEach(() => {
    // Zustand stores are module-level singletons shared across test files, so
    // leaving one dirty or mid-history would bleed into the next test.
    useProjectStore.getState().newProject();
  });

  it("opens a built scenario as unsaved work with a clean slate", () => {
    const template = scenarioTemplates[0]!;
    const document = buildScenarioDocument(template, {
      id: template.metadata.id,
      now: "2024-01-01T00:00:00.000Z"
    });

    // Leave some pre-existing state behind so we can confirm it's actually cleared.
    useProjectStore.getState().addNode("client", { x: 0, y: 0 });
    useProjectStore.getState().selectNode(useProjectStore.getState().document.nodes.at(-1)!.id);
    useProjectStore.getState().setFilePath("C:/projects/demo.json");
    useProjectStore.getState().setResult({
      totalRequests: 1,
      successfulRequests: 1,
      failedRequests: 0,
      averageLatencyMs: 1,
      p95LatencyMs: 1,
      p99LatencyMs: 1,
      throughputRps: 1,
      nodeMetrics: {},
      timeline: { events: [], durationMs: 0 }
    } as never);

    useProjectStore.getState().loadTemplateDocument(document);

    const state = useProjectStore.getState();
    expect(state.document).toBe(document);
    expect(state.isDirty).toBe(true);
    expect(state.filePath).toBeUndefined();
    expect(state.past).toHaveLength(0);
    expect(state.future).toHaveLength(0);
    expect(state.selectedNodeId).toBeUndefined();
    expect(state.selectedEdgeId).toBeUndefined();
    expect(state.lastResult).toBeUndefined();
    expect(state.lastResultSignature).toBeUndefined();
    expect(state.validationIssues.length).toBeGreaterThanOrEqual(0);
    // Validation ran against the newly loaded document, not the stale one.
    expect(hasBlockingErrors(state.validationIssues)).toBe(false);
  });

  it("opens every library template with no blocking validation errors", () => {
    for (const template of scenarioTemplates) {
      const document = buildScenarioDocument(template, { id: template.metadata.id });
      useProjectStore.getState().loadTemplateDocument(document);

      const state = useProjectStore.getState();
      expect(
        hasBlockingErrors(state.validationIssues),
        `${template.metadata.id} blocked Run: ${state.validationIssues
          .filter((issue) => issue.severity === "error")
          .map((issue) => issue.message)
          .join("; ")}`
      ).toBe(false);
      expect(state.isDirty).toBe(true);
      expect(state.filePath).toBeUndefined();
    }
  });

  it("gives a freshly opened template document the right name, nodes, traffic, and faults", () => {
    const template = scenarioTemplates[0]!;
    const document = buildScenarioDocument(template, {
      id: template.metadata.id,
      now: "2024-01-01T00:00:00.000Z"
    });

    useProjectStore.getState().loadTemplateDocument(document);

    const state = useProjectStore.getState();
    expect(state.document.name).toBe(template.blueprint.projectName);
    expect(state.document.nodes).toHaveLength(template.blueprint.nodes.length);
    expect(state.document.nodes.map((node) => node.id).sort()).toEqual(
      template.blueprint.nodes.map((node) => node.id).sort()
    );
    expect(state.document.trafficProfiles.length).toBe(template.blueprint.trafficProfiles.length);
    expect(
      state.document.trafficProfiles.some(
        (profile) => profile.id === template.metadata.defaultTrafficProfileId
      )
    ).toBe(true);
    expect(state.document.faultScenarios.length).toBe(template.blueprint.faultScenarios.length);
    for (const faultScenarioId of template.metadata.defaultFaultScenarioIds) {
      expect(
        state.document.faultScenarios.some((scenario) => scenario.id === faultScenarioId)
      ).toBe(true);
    }
  });
});
