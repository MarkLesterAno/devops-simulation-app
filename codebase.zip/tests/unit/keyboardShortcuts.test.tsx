import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { KeyboardShortcutsModal } from "@/features/shortcuts/KeyboardShortcutsModal";
import { isShortcutReferenceKey, KEYBOARD_SHORTCUTS } from "@/features/shortcuts/shortcuts";

describe("keyboard shortcut reference", () => {
  it("opens only for unmodified question-mark or F1 key presses", () => {
    expect(
      isShortcutReferenceKey({ key: "?", ctrlKey: false, metaKey: false, altKey: false })
    ).toBe(true);
    expect(
      isShortcutReferenceKey({ key: "F1", ctrlKey: false, metaKey: false, altKey: false })
    ).toBe(true);
    expect(
      isShortcutReferenceKey({ key: "?", ctrlKey: true, metaKey: false, altKey: false })
    ).toBe(false);
    expect(
      isShortcutReferenceKey({ key: "s", ctrlKey: false, metaKey: false, altKey: false })
    ).toBe(false);
  });

  it("renders every shared shortcut definition in an accessible dialog", () => {
    const onClose = vi.fn();
    render(<KeyboardShortcutsModal onClose={onClose} />);

    expect(screen.getByRole("dialog", { name: "Keyboard shortcuts" })).toBeInTheDocument();
    for (const shortcut of KEYBOARD_SHORTCUTS) {
      expect(screen.getAllByText(shortcut.action).length).toBeGreaterThan(0);
    }

    fireEvent.click(screen.getByRole("button", { name: "Close" }));
    expect(onClose).toHaveBeenCalledOnce();
  });
});
