import { describe, expect, it } from "vitest";
import { createDiagramSvg } from "@/features/canvas/diagramExport";
import { node, edge, project } from "./testFixtures";

describe("diagram export", () => {
  it("creates a self-contained SVG with component labels, technology, and edges", () => {
    const document = project(
      [
        node("client", "client", { displayName: "Web client" }),
        node("app", "server", {
          displayName: "API",
          technology: { id: "nodejs", displayName: "Node.js", componentTypes: ["server"] }
        })
      ],
      [edge("request", "client", "app")]
    );

    const svg = createDiagramSvg(document);

    expect(svg).toContain("<svg");
    expect(svg).toContain("Web client");
    expect(svg).toContain("Node.js");
    expect(svg).toContain("request");
    expect(svg).toContain("marker-end");
  });

  it("escapes architecture labels before embedding them in SVG", () => {
    const document = project([node("app", "server", { displayName: "<unsafe & label>" })], []);

    expect(createDiagramSvg(document)).toContain("&lt;unsafe &amp; label&gt;");
  });
});
