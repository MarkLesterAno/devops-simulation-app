import { beforeEach, describe, expect, it } from "vitest";
import {
  buildAutosaveRecord,
  clearAutosave,
  isRestorableDraft,
  readAutosave,
  writeAutosave
} from "@/persistence/autosave";
import { useProjectStore } from "@/stores/projectStore";
import { createEmptyProject } from "@/domain/architecture/projectDocument";

function currentDocument() {
  return useProjectStore.getState().document;
}

describe("autosave", () => {
  beforeEach(async () => {
    window.localStorage.clear();
    useProjectStore.getState().newProject();
    await clearAutosave();
  });

  it("treats an empty project as not worth recovering", () => {
    expect(isRestorableDraft(createEmptyProject("Empty"))).toBe(false);
  });

  it("treats a project with nodes as recoverable", () => {
    useProjectStore.getState().addNode("client", { x: 0, y: 0 });
    expect(isRestorableDraft(currentDocument())).toBe(true);
  });

  it("round-trips a draft through storage", async () => {
    useProjectStore.getState().addNode("client", { x: 10, y: 20 });
    useProjectStore.getState().addNode("server", { x: 200, y: 20 });
    const saved = currentDocument();

    expect(await writeAutosave(saved, "C:/projects/demo.json", true)).toBe(true);
    const draft = await readAutosave();

    expect(draft).toBeDefined();
    expect(draft!.filePath).toBe("C:/projects/demo.json");
    expect(draft!.isDirty).toBe(true);
    expect(draft!.document.nodes).toHaveLength(saved.nodes.length);
    expect(draft!.document.nodes.map((n) => n.type).sort()).toEqual(["client", "server"]);
  });

  it("preserves technology assignments in a recovered draft", async () => {
    useProjectStore.getState().addNode("cache", { x: 0, y: 0 });
    const nodeId = currentDocument().nodes.at(-1)!.id;
    useProjectStore
      .getState()
      .setNodeTechnology(nodeId, { id: "redis", displayName: "Redis", provider: "Redis" });

    await writeAutosave(currentDocument(), undefined, true);
    const draft = await readAutosave();

    const restored = draft?.document.nodes.find((node) => node.id === nodeId);
    expect(restored?.config.technology).toMatchObject({ id: "redis" });
  });

  it("records whether the work was unsaved", async () => {
    useProjectStore.getState().addNode("client", { x: 0, y: 0 });
    await writeAutosave(currentDocument(), "C:/projects/demo.json", false);
    const draft = await readAutosave();
    expect(draft!.isDirty).toBe(false);
  });

  it("returns nothing when no draft exists", async () => {
    expect(await readAutosave()).toBeUndefined();
  });

  it("discards a corrupt draft instead of throwing", async () => {
    window.localStorage.setItem("sds:autosave-draft", "{not-json");
    expect(await readAutosave()).toBeUndefined();
  });

  it("discards a draft with an unsupported envelope version", async () => {
    window.localStorage.setItem(
      "sds:autosave-draft",
      JSON.stringify({ version: 99, savedAt: new Date().toISOString(), document: {} })
    );
    expect(await readAutosave()).toBeUndefined();
  });

  it("discards a draft whose document fails schema validation", async () => {
    window.localStorage.setItem(
      "sds:autosave-draft",
      JSON.stringify({
        version: 1,
        savedAt: new Date().toISOString(),
        isDirty: true,
        document: { nodes: "not-an-array" }
      })
    );
    expect(await readAutosave()).toBeUndefined();
  });

  it("clears a stored draft", async () => {
    useProjectStore.getState().addNode("client", { x: 0, y: 0 });
    await writeAutosave(currentDocument(), undefined, true);
    expect(await readAutosave()).toBeDefined();
    await clearAutosave();
    expect(await readAutosave()).toBeUndefined();
  });

  it("stamps records with a version and timestamp", () => {
    const record = buildAutosaveRecord(createEmptyProject("X"), undefined, true);
    expect(record.version).toBe(1);
    expect(Number.isNaN(new Date(record.savedAt).getTime())).toBe(false);
  });

  it("omits filePath when the project has never been written to disk", () => {
    const record = buildAutosaveRecord(createEmptyProject("X"), undefined, true);
    expect(record.filePath).toBeUndefined();
  });
});

describe("restoreDocument", () => {
  beforeEach(() => {
    useProjectStore.getState().newProject();
  });

  it("restores a draft as unsaved work and revalidates it", () => {
    const draft = createEmptyProject("Recovered");
    useProjectStore.getState().restoreDocument(draft, undefined, true);

    const state = useProjectStore.getState();
    expect(state.document.name).toBe("Recovered");
    expect(state.isDirty).toBe(true);
    // An empty recovered graph must still block Run rather than leave it enabled.
    expect(state.validationIssues.some((issue) => issue.severity === "error")).toBe(true);
  });

  it("restores already-saved work without flagging it dirty", () => {
    const draft = createEmptyProject("Saved");
    useProjectStore.getState().restoreDocument(draft, "C:/projects/demo.json", false);

    const state = useProjectStore.getState();
    expect(state.isDirty).toBe(false);
    expect(state.filePath).toBe("C:/projects/demo.json");
  });

  it("clears undo history so recovered work cannot be undone into a stale graph", () => {
    useProjectStore.getState().addNode("client", { x: 0, y: 0 });
    useProjectStore.getState().restoreDocument(createEmptyProject("Recovered"), undefined, true);

    const state = useProjectStore.getState();
    expect(state.past).toHaveLength(0);
    expect(state.future).toHaveLength(0);
  });
});
