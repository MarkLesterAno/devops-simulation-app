import { describe, expect, it } from "vitest";
import { useProjectStore } from "@/stores/projectStore";
import { hasBlockingErrors } from "@/domain/validation/graphValidation";

describe("projectStore initial validation", () => {
  it("validates the seed document on creation so Run is blocked before any edit", () => {
    const { validationIssues } = useProjectStore.getState();

    expect(validationIssues.length).toBeGreaterThan(0);
    expect(hasBlockingErrors(validationIssues)).toBe(true);
    expect(validationIssues.some((issue) => issue.code === "no-request-origin")).toBe(true);
  });

  it("re-blocks after newProject() resets to an empty architecture", () => {
    const store = useProjectStore.getState();
    store.addNode("client", { x: 0, y: 0 });
    store.newProject();

    expect(hasBlockingErrors(useProjectStore.getState().validationIssues)).toBe(true);
  });
});
