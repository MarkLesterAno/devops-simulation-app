import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { createNodeFromDefinition } from "@/domain/components/registry";
import { NodeConfigForm } from "@/features/inspector/NodeConfigForm";
import { useProjectStore } from "@/stores/projectStore";

describe("NodeConfigForm", () => {
  it("keeps invalid numeric edits out of the project and exposes an inline error", () => {
    const node = createNodeFromDefinition("server", "server-test", { x: 0, y: 0 });
    const updateNodeConfig = vi.spyOn(useProjectStore.getState(), "updateNodeConfig");
    render(<NodeConfigForm node={node} includeTechnology={false} />);

    fireEvent.change(screen.getByLabelText("Error rate (0–1)"), { target: { value: "5" } });

    expect(screen.getByRole("alert")).toHaveTextContent("less than or equal to 1");
    expect(screen.getByLabelText("Error rate (0–1)")).toHaveAttribute("aria-invalid", "true");
    expect(updateNodeConfig).not.toHaveBeenCalled();
    updateNodeConfig.mockRestore();
  });

  it("does not coerce an empty required number to zero", () => {
    const node = createNodeFromDefinition("server", "server-test-empty", { x: 0, y: 0 });
    render(<NodeConfigForm node={node} includeTechnology={false} />);

    fireEvent.change(screen.getByLabelText("Instance count"), { target: { value: "" } });

    expect(screen.getByRole("alert")).toHaveTextContent("A value is required");
    expect(screen.getByLabelText("Instance count")).toHaveValue(null);
  });
});
