import { describe, expect, it } from "vitest";
import { validateGraph, hasBlockingErrors } from "@/domain/validation/graphValidation";
import { node, edge } from "./testFixtures";

describe("validateGraph", () => {
  it("AC-VA-01: blocks a graph with no client/request origin", () => {
    const issues = validateGraph([node("app", "server")], []);
    expect(issues.some((i) => i.code === "no-request-origin")).toBe(true);
    expect(hasBlockingErrors(issues)).toBe(true);
  });

  it("AC-VA-02: blocks a graph with no reachable terminal path", () => {
    const nodes = [node("client", "client"), node("lb", "load-balancer")];
    const edges = [edge("e1", "client", "lb")];
    const issues = validateGraph(nodes, edges);
    expect(issues.some((i) => i.code === "no-terminal-path")).toBe(true);
    expect(hasBlockingErrors(issues)).toBe(true);
  });

  it("AC-VA-03: blocks a load balancer with no eligible targets", () => {
    const nodes = [node("client", "client"), node("lb", "load-balancer")];
    const edges = [edge("e1", "client", "lb")];
    const issues = validateGraph(nodes, edges);
    expect(issues.some((i) => i.code === "load-balancer-no-targets")).toBe(true);
  });

  it("AC-VA-04: warns (not blocks) about a queue with no consumer", () => {
    const nodes = [node("client", "client"), node("app", "server"), node("q", "message-queue")];
    const edges = [edge("e1", "client", "app"), edge("e2", "app", "q", { kind: "event" })];
    const issues = validateGraph(nodes, edges);
    const queueWarning = issues.find((i) => i.code === "queue-no-consumer");
    expect(queueWarning?.severity).toBe("warning");
    expect(hasBlockingErrors(issues)).toBe(false);
  });

  it("accepts a fully valid client -> load balancer -> app -> database graph", () => {
    const nodes = [
      node("client", "client"),
      node("lb", "load-balancer"),
      node("app", "server"),
      node("db", "relational-database")
    ];
    const edges = [
      edge("e1", "client", "lb"),
      edge("e2", "lb", "app"),
      edge("e3", "app", "db")
    ];
    const issues = validateGraph(nodes, edges);
    expect(hasBlockingErrors(issues)).toBe(false);
  });

  it("warns about disconnected nodes", () => {
    const nodes = [node("client", "client"), node("app", "server"), node("orphan", "cache")];
    const edges = [edge("e1", "client", "app")];
    const issues = validateGraph(nodes, edges);
    expect(issues.some((i) => i.code === "disconnected-node" && i.nodeIds?.includes("orphan"))).toBe(
      true
    );
  });

  it("accepts a client -> server -> object storage graph with an observability side-edge", () => {
    const nodes = [
      node("client", "client"),
      node("app", "server"),
      node("store", "object-storage"),
      node("obs", "observability")
    ];
    const edges = [
      edge("e1", "client", "app"),
      edge("e2", "app", "store"),
      edge("e3", "app", "obs", { kind: "observability" })
    ];
    const issues = validateGraph(nodes, edges);
    expect(hasBlockingErrors(issues)).toBe(false);
  });

  it("blocks a request-routing cycle because it has no deterministic terminal path", () => {
    const nodes = [
      node("client", "client"),
      node("app-a", "server"),
      node("app-b", "server")
    ];
    const edges = [
      edge("e1", "client", "app-a"),
      edge("e2", "app-a", "app-b"),
      edge("e3", "app-b", "app-a")
    ];
    const issues = validateGraph(nodes, edges);
    expect(issues.some((issue) => issue.code === "request-routing-cycle")).toBe(true);
    expect(hasBlockingErrors(issues)).toBe(true);
  });

  it("blocks replication edges that do not connect data components", () => {
    const nodes = [
      node("client", "client"),
      node("app", "server"),
      node("db", "relational-database")
    ];
    const edges = [
      edge("e1", "client", "app"),
      edge("e2", "app", "db"),
      edge("replication", "app", "db", { kind: "replication" })
    ];
    const issues = validateGraph(nodes, edges);
    expect(issues.some((issue) => issue.code === "invalid-replication-path")).toBe(true);
  });

  it("warns when multi-region topology has no explicit failover route", () => {
    const nodes = [
      node("client", "client", { region: "us-east" }),
      node("app", "server", { region: "us-west" })
    ];
    const issues = validateGraph(nodes, [edge("e1", "client", "app")]);
    expect(issues.some((issue) => issue.code === "multi-region-no-failover")).toBe(true);
  });

  it("warns that multiple event consumers do not model consumer-group semantics", () => {
    const nodes = [
      node("client", "client"),
      node("app", "server"),
      node("topic", "event-topic"),
      node("worker-a", "worker"),
      node("worker-b", "worker")
    ];
    const edges = [
      edge("e1", "client", "app"),
      edge("e2", "app", "topic", { kind: "event" }),
      edge("e3", "topic", "worker-a", { kind: "event" }),
      edge("e4", "topic", "worker-b", { kind: "event" })
    ];
    const issues = validateGraph(nodes, edges);
    expect(issues.some((issue) => issue.code === "consumer-semantics-simplified")).toBe(true);
  });
});
