import { describe, expect, it } from "vitest";
import { rollupComponentMetrics } from "@/features/metrics/componentRollup";
import type { ComponentMetricSnapshot } from "@/domain/metrics/schema";

function snapshot(
  nodeId: string,
  timestampMs: number,
  utilization: number,
  latencyMs: number
): ComponentMetricSnapshot {
  return {
    nodeId,
    timestampMs,
    utilization,
    activeWork: 0,
    queuedWork: 0,
    latencyMs,
    errorRate: 0
  };
}

describe("rollupComponentMetrics", () => {
  it("retains peak utilization and latency instead of the final interval", () => {
    const [rollup] = rollupComponentMetrics([
      snapshot("app", 0, 0.92, 280),
      snapshot("app", 1_000, 0.1, 20)
    ]);

    expect(rollup).toMatchObject({
      nodeId: "app",
      peakUtilization: 0.92,
      peakLatencyMs: 280
    });
  });

  it("sorts components by their peak utilization", () => {
    const rollups = rollupComponentMetrics([
      snapshot("cache", 0, 0.4, 20),
      snapshot("server", 0, 0.9, 100)
    ]);

    expect(rollups.map((rollup) => rollup.nodeId)).toEqual(["server", "cache"]);
  });
});
