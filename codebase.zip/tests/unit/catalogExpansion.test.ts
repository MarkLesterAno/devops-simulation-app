﻿import { describe, expect, it } from "vitest";
import { runSimulation, COMPONENT_MODEL_VERSION } from "@/simulation-engine/core/SimulationEngine";
import { validateGraph } from "@/domain/validation/graphValidation";
import { parseProjectDocument, PROJECT_SCHEMA_VERSION } from "@/domain/architecture/projectDocument";
import { defaultSimulationSettings, type SimulationInput } from "@/domain/simulation/simulationInput";
import { getTechnologiesForComponentType } from "@/domain/technology/registry";
import type { ArchitectureEdge, ArchitectureNode } from "@/domain/architecture/schema";
import { node, edge, project, trafficProfile } from "./testFixtures";

function input(
  nodes: ArchitectureNode[],
  edges: ArchitectureEdge[],
  overrides: Partial<SimulationInput> = {}
): SimulationInput {
  return {
    projectSnapshot: project(nodes, edges, [
      trafficProfile({
        durationMs: 2000,
        intervals: [{ kind: "constant", startMs: 0, endMs: 2000, startRps: 100, endRps: 100 }]
      })
    ]),
    trafficProfileId: "profile-1",
    faultScenarioIds: [],
    durationMs: 2000,
    seed: 7,
    settings: defaultSimulationSettings(),
    ...overrides
  };
}

function workDoneAt(result: ReturnType<typeof runSimulation>, nodeId: string): number {
  const snapshots = result.componentMetrics.filter((snapshot) => snapshot.nodeId === nodeId);
  return Math.max(0, ...snapshots.map((snapshot) => snapshot.activeWork));
}

function metricFor(
  result: ReturnType<typeof runSimulation>,
  nodeId: string
): Record<string, number | undefined> {
  const snapshots = result.componentMetrics.filter((snapshot) => snapshot.nodeId === nodeId);
  expect(snapshots.length).toBeGreaterThan(0);
  const totals: Record<string, number | undefined> = {};
  for (const snapshot of snapshots) {
    for (const [key, value] of Object.entries(snapshot)) {
      if (typeof value !== "number") continue;
      totals[key] = (totals[key] ?? 0) + value;
    }
  }
  return totals;
}

describe("catalog expansion â€” API gateway", () => {
  it("AC-CO-10: quota rejections are counted and reported as failed requests", () => {
    const result = runSimulation(
      input(
        [
          node("client", "client"),
          node("gw", "api-gateway", {
            perInstanceCapacityRps: 10_000,
            baseLatencyMs: 0,
            policyLatencyMs: 0,
            rateLimitRps: 10,
            rateLimitBurst: 10
          }),
          node("app", "server", { perInstanceCapacityRps: 10_000, baseLatencyMs: 1 })
        ],
        [edge("e1", "client", "gw"), edge("e2", "gw", "app")]
      )
    );

    expect(result.status).toBe("completed");
    const gateway = metricFor(result, "gw");
    expect(gateway.quotaRejectionCount ?? 0).toBeGreaterThan(0);
    expect(result.observedAvailability).toBeLessThan(1);
  });

  it("AC-CO-11: a fail-closed identity service blocks requests when it is unavailable", () => {
    const nodes = [
      node("client", "client"),
      node("gw", "api-gateway", {
        perInstanceCapacityRps: 10_000,
        policyLatencyMs: 0,
        authMode: "delegate"
      }),
      node("idp", "identity-auth-service", {
        perInstanceCapacityRps: 10_000,
        cacheHitRatio: 0,
        verificationLatencyMs: 1,
        failMode: "fail-closed"
      }),
      node("app", "server", { perInstanceCapacityRps: 10_000, baseLatencyMs: 1 })
    ];
    const edges = [
      edge("e1", "client", "gw"),
      edge("e2", "gw", "idp", { kind: "request" }),
      edge("e3", "gw", "app")
    ];

    const healthy = runSimulation(input(nodes, edges));
    const faulted = runSimulation(
      input(nodes, edges, {
        faultScenarioIds: ["f1"],
        projectSnapshot: project(
          nodes,
          edges,
          [
            trafficProfile({
              durationMs: 2000,
              intervals: [{ kind: "constant", startMs: 0, endMs: 2000, startRps: 100, endRps: 100 }]
            })
          ],
          [
            {
              id: "f1",
              name: "IdP down",
              faults: [
                {
                  id: "fault-1",
                  type: "credential-store-unavailable",
                  target: { nodeIds: ["idp"], edgeIds: [] },
                  startMs: 0,
                  endMs: 2000
                }
              ]
            }
          ]
        )
      })
    );

    expect(healthy.observedAvailability ?? 0).toBeGreaterThan(faulted.observedAvailability ?? 0);
    expect(metricFor(faulted, "gw").authBlockedCount ?? 0).toBeGreaterThan(0);
  });
});

describe("catalog expansion â€” DNS traffic manager", () => {
  it("AC-CO-12: a long TTL keeps traffic pinned to a cached answer", () => {
    const nodes = [
      node("client", "client"),
      node("dns", "dns-traffic-manager", {
        perInstanceCapacityRps: 1000,
        baseLatencyMs: 2,
        resolutionLatencyMs: 1,
        ttlSeconds: 600
      }),
      node("primary", "server", { perInstanceCapacityRps: 200, baseLatencyMs: 20 }),
      node("secondary", "server", { perInstanceCapacityRps: 200, baseLatencyMs: 20 })
    ];
    const edges = [
      edge("e1", "client", "dns"),
      edge("e2", "dns", "primary"),
      edge("e3", "dns", "secondary")
    ];

    const result = runSimulation(input(nodes, edges));
    expect(result.status).toBe("completed");

    const dns = metricFor(result, "dns");
    expect(dns.dnsCacheHitRatio).toBeDefined();
    const primaryHits = workDoneAt(result, "primary");
    const secondaryHits = workDoneAt(result, "secondary");

    // A cached answer is reused for its TTL, so one target absorbs everything.
    expect(primaryHits).toBeGreaterThan(0);
    expect(secondaryHits).toBe(0);
  });
});

describe("catalog expansion â€” NoSQL database", () => {
  it("AC-CO-13: eventual consistency with replication lag produces stale reads", () => {
    const result = runSimulation(
      input(
        [
          node("client", "client"),
          node("app", "server", { perInstanceCapacityRps: 10_000, baseLatencyMs: 1 }),
          node("db", "nosql-database", {
            perInstanceCapacityRps: 10_000,
            baseLatencyMs: 1,
            consistency: "eventual",
            replicationLagMs: 500,
            partitionCount: 4
          })
        ],
        [edge("e1", "client", "app"), edge("e2", "app", "db")]
      )
    );

    expect(metricFor(result, "db").staleReadCount ?? 0).toBeGreaterThan(0);
  });

  it("AC-CO-14: partition skew throttles below aggregate capacity", () => {
    const build = (hotPartitionSkew: number) => {
      const nodes = [
        node("client", "client"),
        node("app", "server", { perInstanceCapacityRps: 10_000, baseLatencyMs: 1 }),
        node("db", "nosql-database", {
          // Aggregate capacity is ample; only the per-partition share is tight.
          perInstanceCapacityRps: 16,
          baseLatencyMs: 20,
          partitionCount: 8,
          hotPartitionSkew
        })
      ];
      const edges = [edge("e1", "client", "app"), edge("e2", "app", "db")];
      return runSimulation(
        input(nodes, edges, {
          projectSnapshot: project(nodes, edges, [
            trafficProfile({
              durationMs: 2000,
              intervals: [{ kind: "constant", startMs: 0, endMs: 2000, startRps: 200, endRps: 200 }]
            })
          ])
        })
      );
    };

    const uniform = build(0);
    const skewed = build(0.95);
    expect(metricFor(skewed, "db").hotPartitionThrottleCount ?? 0).toBeGreaterThan(
      metricFor(uniform, "db").hotPartitionThrottleCount ?? 0
    );
    expect(skewed.observedAvailability ?? 0).toBeLessThan(uniform.observedAvailability ?? 0);
  });
});

describe("catalog expansion â€” event topic", () => {
  it("AC-CO-15: each subscriber group receives an independent copy of every event", () => {
    const result = runSimulation(
      input(
        [
          node("client", "client"),
          node("app", "server", { perInstanceCapacityRps: 10_000, baseLatencyMs: 1 }),
          node("topic", "event-topic", { perInstanceCapacityRps: 10_000, baseLatencyMs: 0 }),
          node("w1", "worker", { perInstanceCapacityRps: 10_000, baseLatencyMs: 1 }),
          node("w2", "worker", { perInstanceCapacityRps: 10_000, baseLatencyMs: 1 })
        ],
        [
          edge("e1", "client", "app"),
          edge("e2", "app", "topic", { kind: "event" }),
          edge("e3", "topic", "w1", { kind: "event" }),
          edge("e4", "topic", "w2", { kind: "event" })
        ]
      )
    );

    const w1 = workDoneAt(result, "w1");
    const w2 = workDoneAt(result, "w2");

    expect(w1).toBeGreaterThan(0);
    expect(w1).toBe(w2);
  });
});

describe("catalog expansion â€” external service", () => {
  it("AC-CO-16: provider rate limits throttle regardless of local instance count", () => {
    const result = runSimulation(
      input(
        [
          node("client", "client"),
          node("app", "server", { perInstanceCapacityRps: 10_000, baseLatencyMs: 1 }),
          node("provider", "external-service", {
            instanceCount: 1,
            perInstanceCapacityRps: 10_000,
            baseLatencyMs: 1,
            slaLatencyMs: 1,
            providerRateLimitRps: 5
          })
        ],
        [edge("e1", "client", "app"), edge("e2", "app", "provider")]
      )
    );

    expect(metricFor(result, "provider").providerThrottleCount ?? 0).toBeGreaterThan(0);
  });
});

describe("catalog expansion â€” validation", () => {
  const base = (nodes: ArchitectureNode[], edges: ArchitectureEdge[]) => validateGraph(nodes, edges);

  it("AC-VA-05: an API gateway with no outgoing route is an error", () => {
    const issues = base(
      [node("client", "client"), node("gw", "api-gateway")],
      [edge("e1", "client", "gw")]
    );
    expect(issues.some((issue) => issue.code === "gateway-no-routes")).toBe(true);
  });

  it("AC-VA-06: delegated auth without an identity service is an error", () => {
    const issues = base(
      [
        node("client", "client"),
        node("gw", "api-gateway", { authMode: "delegate" }),
        node("app", "server")
      ],
      [edge("e1", "client", "gw"), edge("e2", "gw", "app")]
    );
    expect(issues.some((issue) => issue.code === "auth-delegation-missing")).toBe(true);
  });

  it("AC-VA-07: a DNS node with no targets is an error", () => {
    const issues = base(
      [node("client", "client"), node("dns", "dns-traffic-manager")],
      [edge("e1", "client", "dns")]
    );
    expect(issues.some((issue) => issue.code === "dns-no-targets")).toBe(true);
  });

  it("AC-VA-08: a topic with no subscribers is an error", () => {
    const issues = base(
      [node("client", "client"), node("app", "server"), node("topic", "event-topic")],
      [edge("e1", "client", "app"), edge("e2", "app", "topic", { kind: "event" })]
    );
    expect(issues.some((issue) => issue.code === "topic-no-subscribers")).toBe(true);
  });

  it("AC-VA-09: strong consistency with replication lag is an error", () => {
    const issues = base(
      [
        node("client", "client"),
        node("app", "server"),
        node("db", "nosql-database", { consistency: "strong", replicationLagMs: 100 })
      ],
      [edge("e1", "client", "app"), edge("e2", "app", "db")]
    );
    expect(issues.some((issue) => issue.code === "nosql-invalid-consistency")).toBe(true);
  });

  it("AC-VA-10: an external service cannot be scaled by adding an autoscaler", () => {
    const issues = base(
      [
        node("client", "client"),
        node("app", "server"),
        node("provider", "external-service"),
        node("scaler", "autoscaler")
      ],
      [
        edge("e1", "client", "app"),
        edge("e2", "app", "provider"),
        edge("e3", "provider", "scaler", { kind: "observability" })
      ]
    );
    expect(issues.some((issue) => issue.code === "external-service-not-scalable")).toBe(true);
  });
});

describe("catalog expansion â€” compatibility", () => {
  it("AC-PE-04: a v1 project document migrates forward and loads", () => {
    const current = project([node("client", "client"), node("app", "server")], [edge("e1", "client", "app")]);
    const legacy = { ...current, schemaVersion: 1 };

    const parsed = parseProjectDocument(legacy);
    expect(parsed.ok).toBe(true);
    expect(parsed.document?.schemaVersion).toBe(PROJECT_SCHEMA_VERSION);
    expect(parsed.document?.nodes).toHaveLength(2);
  });

  it("AC-SI-08: results are stamped with the component model version", () => {
    const result = runSimulation(
      input([node("client", "client"), node("app", "server")], [edge("e1", "client", "app")])
    );
    expect(result.componentModelVersion).toBe(COMPONENT_MODEL_VERSION);
  });

  it("every expansion component has at least one assignable technology", () => {
    for (const type of [
      "api-gateway",
      "dns-traffic-manager",
      "nosql-database",
      "event-topic",
      "identity-auth-service",
      "external-service"
    ] as const) {
      expect(getTechnologiesForComponentType(type).length).toBeGreaterThan(0);
    }
  });
});

