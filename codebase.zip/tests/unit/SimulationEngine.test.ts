import { describe, expect, it } from "vitest";
import { runSimulation } from "@/simulation-engine/core/SimulationEngine";
import { defaultSimulationSettings, type SimulationInput } from "@/domain/simulation/simulationInput";
import { node, edge, project, trafficProfile } from "./testFixtures";

function makeInput(overrides: Partial<SimulationInput> = {}): SimulationInput {
  return {
    projectSnapshot: project(
      [
        node("client", "client"),
        node("app", "server", { perInstanceCapacityRps: 1000, baseLatencyMs: 5, jitterMs: 0 })
      ],
      [edge("e1", "client", "app")]
    ),
    trafficProfileId: "profile-1",
    faultScenarioIds: [],
    durationMs: 1000,
    seed: 42,
    settings: defaultSimulationSettings(),
    ...overrides
  };
}

describe("SimulationEngine", () => {
  it("AC-SI-01: identical input and seed produce equivalent aggregated outcomes", () => {
    const input = makeInput();
    const resultA = runSimulation(input);
    const resultB = runSimulation(input);
    expect(resultA.status).toBe("completed");
    expect(resultA.observedAvailability).toBe(resultB.observedAvailability);
    expect(resultA.systemMetrics.map((m) => m.requestCount)).toEqual(
      resultB.systemMetrics.map((m) => m.requestCount)
    );
    expect(resultA.events.length).toEqual(resultB.events.length);
  });

  it("AC-SI-02: a constant 100 RPS profile over 1 logical second admits ~100 requests", () => {
    const input = makeInput({
      projectSnapshot: project(
        [
          node("client", "client"),
          node("app", "server", { perInstanceCapacityRps: 1000, baseLatencyMs: 1, jitterMs: 0 })
        ],
        [edge("e1", "client", "app")],
        [trafficProfile({ durationMs: 1000, intervals: [{ kind: "constant", startMs: 0, endMs: 1000, startRps: 100, endRps: 100 }] })]
      )
    });
    const result = runSimulation(input);
    const totalRequests = result.systemMetrics.reduce((sum, snap) => sum + snap.requestCount, 0);
    expect(totalRequests).toBeGreaterThanOrEqual(95);
    expect(totalRequests).toBeLessThanOrEqual(105);
  });

  it("AC-SI-03: work above configured capacity triggers overflow (reject) behavior", () => {
    const input = makeInput({
      projectSnapshot: project(
        [
          node("client", "client"),
          node("app", "server", {
            perInstanceCapacityRps: 1,
            baseLatencyMs: 500,
            overflowBehavior: "reject"
          })
        ],
        [edge("e1", "client", "app")],
        [trafficProfile({ durationMs: 500, intervals: [{ kind: "constant", startMs: 0, endMs: 500, startRps: 50, endRps: 50 }] })]
      )
    });
    const result = runSimulation(input);
    const totalFailures = result.systemMetrics.reduce((sum, snap) => sum + snap.failureCount, 0);
    expect(totalFailures).toBeGreaterThan(0);
  });

  it("AC-SI-04: a queued request's wait time is reflected in recorded latency", () => {
    const input = makeInput({
      projectSnapshot: project(
        [
          node("client", "client"),
          node("app", "server", {
            perInstanceCapacityRps: 1,
            baseLatencyMs: 50,
            overflowBehavior: "queue",
            maxQueueDepth: 1000
          })
        ],
        [edge("e1", "client", "app")],
        [trafficProfile({ durationMs: 200, intervals: [{ kind: "constant", startMs: 0, endMs: 200, startRps: 50, endRps: 50 }] })]
      )
    });
    const result = runSimulation(input);
    const maxP99 = Math.max(...result.systemMetrics.map((s) => s.latency.p99));
    // With 1 concurrent slot and 50ms service time under ~10 arrivals in 200ms,
    // later requests must wait in queue, so p99 latency exceeds a single service time.
    expect(maxP99).toBeGreaterThan(50);
  });

  it("AC-SI-05: a timed-out request is never later counted as successful", () => {
    const input = makeInput({
      projectSnapshot: project(
        [
          node("client", "client", { timeoutMs: 10 }),
          node("app", "server", {
            perInstanceCapacityRps: 1,
            baseLatencyMs: 200,
            overflowBehavior: "queue",
            maxQueueDepth: 1000
          })
        ],
        [edge("e1", "client", "app")],
        [trafficProfile({ durationMs: 200, intervals: [{ kind: "constant", startMs: 0, endMs: 200, startRps: 50, endRps: 50 }] })]
      )
    });
    const result = runSimulation(input);
    const totalFailures = result.systemMetrics.reduce((sum, snap) => sum + snap.failureCount, 0);
    expect(totalFailures).toBeGreaterThan(0);
    expect(result.events.some((e) => e.type === "timeout")).toBe(true);
  });

  it("AC-CO-01: round-robin distributes successive requests in stable target order", () => {
    const input = makeInput({
      projectSnapshot: project(
        [
          node("client", "client"),
          node("lb", "load-balancer"),
          node("a", "server", { perInstanceCapacityRps: 1000 }),
          node("b", "server", { perInstanceCapacityRps: 1000 })
        ],
        [
          edge("e1", "client", "lb"),
          edge("e2", "lb", "a", { routingStrategy: "round-robin" }),
          edge("e3", "lb", "b", { routingStrategy: "round-robin" })
        ],
        [trafficProfile({ durationMs: 100, intervals: [{ kind: "constant", startMs: 0, endMs: 100, startRps: 40, endRps: 40 }] })]
      )
    });
    const result = runSimulation(input);
    const aUtil = result.componentMetrics.filter((m) => m.nodeId === "a");
    const bUtil = result.componentMetrics.filter((m) => m.nodeId === "b");
    expect(aUtil.length).toBeGreaterThan(0);
    expect(bUtil.length).toBeGreaterThan(0);
  });

  it("AC-CO-02: an unavailable load-balancer target receives no traffic (no-healthy-target)", () => {
    const input = makeInput({
      projectSnapshot: project(
        [node("client", "client"), node("lb", "load-balancer"), node("a", "server")],
        [edge("e1", "client", "lb"), edge("e2", "lb", "a")],
        [trafficProfile({ durationMs: 100, intervals: [{ kind: "constant", startMs: 0, endMs: 100, startRps: 20, endRps: 20 }] })],
        [
          {
            id: "scenario-1",
            name: "Outage",
            faults: [
              {
                id: "fault-1",
                type: "node-outage",
                target: { nodeIds: ["a"], edgeIds: [] },
                startMs: 0
              }
            ]
          }
        ]
      ),
      faultScenarioIds: ["scenario-1"]
    });
    const result = runSimulation(input);
    expect(result.events.some((e) => e.type === "node-unavailable")).toBe(true);
  });

  it("AC-CO-03/04: a cache hit skips the origin dependency; a miss invokes it", () => {
    const input = makeInput({
      projectSnapshot: project(
        [
          node("client", "client"),
          node("cache", "cache", { hitRatio: 1, baseLatencyMs: 2 }),
          node("origin", "server", { perInstanceCapacityRps: 1000, baseLatencyMs: 30 })
        ],
        [edge("e1", "client", "cache"), edge("e2", "cache", "origin")],
        [trafficProfile({ durationMs: 100, intervals: [{ kind: "constant", startMs: 0, endMs: 100, startRps: 20, endRps: 20 }] })]
      )
    });
    const result = runSimulation(input);
    const originMetrics = result.componentMetrics.filter((m) => m.nodeId === "origin");
    const totalOriginWork = originMetrics.reduce((sum, m) => sum + m.activeWork, 0);
    expect(totalOriginWork).toBe(0); // 100% hit ratio means origin is never invoked

    const missInput = makeInput({
      projectSnapshot: project(
        [
          node("client", "client"),
          node("cache", "cache", { hitRatio: 0, baseLatencyMs: 2 }),
          node("origin", "server", { perInstanceCapacityRps: 1000, baseLatencyMs: 30 })
        ],
        [edge("e1", "client", "cache"), edge("e2", "cache", "origin")],
        [trafficProfile({ durationMs: 100, intervals: [{ kind: "constant", startMs: 0, endMs: 100, startRps: 20, endRps: 20 }] })]
      )
    });
    const missResult = runSimulation(missInput);
    const cacheMetrics = missResult.componentMetrics.filter((m) => m.nodeId === "cache");
    expect(cacheMetrics.some((m) => m.cacheHitRatio === 0)).toBe(true);
  });

  it("AC-CO-05: when producers exceed consumer throughput, queue depth grows", () => {
    const input = makeInput({
      projectSnapshot: project(
        [
          node("client", "client"),
          node("app", "server", { perInstanceCapacityRps: 1000 }),
          node("queue", "message-queue", { maxQueueDepth: 10000 }),
          node("worker", "worker", { perInstanceCapacityRps: 1, baseLatencyMs: 500 })
        ],
        [
          edge("e1", "client", "app"),
          edge("e2", "app", "queue", { kind: "event" }),
          edge("e3", "queue", "worker", { kind: "event" })
        ],
        [trafficProfile({ durationMs: 500, intervals: [{ kind: "constant", startMs: 0, endMs: 500, startRps: 50, endRps: 50 }] })]
      )
    });
    const result = runSimulation(input);
    const queueMetrics = result.componentMetrics.filter((m) => m.nodeId === "queue");
    const maxDepth = Math.max(0, ...queueMetrics.map((m) => m.queueDepth ?? 0));
    expect(maxDepth).toBeGreaterThan(0);
  });

  it("returns an invalid result when the graph fails validation", () => {
    const input = makeInput({
      projectSnapshot: project([node("app", "server")], [])
    });
    const result = runSimulation(input);
    expect(result.status).toBe("invalid");
  });

  it("AC-CO-07: bounded retries honor max attempts, backoff, and the request deadline", () => {
    const input = makeInput({
      projectSnapshot: project(
        [
          node("client", "client", { timeoutMs: 5000, maxRetries: 3, retryBackoffMs: 10 }),
          node("app", "server", {
            perInstanceCapacityRps: 1000,
            baseLatencyMs: 1,
            errorRate: 1 // always fails so every attempt is retried until budget exhausted
          })
        ],
        [edge("e1", "client", "app")],
        [trafficProfile({ durationMs: 50, intervals: [{ kind: "constant", startMs: 0, endMs: 50, startRps: 20, endRps: 20 }] })]
      )
    });
    const result = runSimulation(input);
    const retryEvents = result.events.filter((e) => e.type === "retry-scheduled");
    expect(retryEvents.length).toBeGreaterThan(0);
    // Every root request must still terminate as a failure; retries never fabricate a success.
    const totalFailures = result.systemMetrics.reduce((sum, snap) => sum + snap.failureCount, 0);
    expect(totalFailures).toBeGreaterThan(0);
  });

  it("Object Storage behaves as a capacity-bound terminal node (client -> server -> object storage)", () => {
    const input = makeInput({
      projectSnapshot: project(
        [
          node("client", "client"),
          node("app", "server", { perInstanceCapacityRps: 1000, baseLatencyMs: 1, jitterMs: 0 }),
          node("store", "object-storage", { perInstanceCapacityRps: 1000, baseLatencyMs: 20, jitterMs: 0 })
        ],
        [edge("e1", "client", "app"), edge("e2", "app", "store")]
      )
    });
    const result = runSimulation(input);
    expect(result.status).toBe("completed");
    const totalFailures = result.systemMetrics.reduce((sum, snap) => sum + snap.failureCount, 0);
    expect(totalFailures).toBe(0);
    const storeMetrics = result.componentMetrics.filter((m) => m.nodeId === "store");
    expect(storeMetrics.length).toBeGreaterThan(0);
  });
});
