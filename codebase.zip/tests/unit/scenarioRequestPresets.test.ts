import { describe, expect, it } from "vitest";
import { getScenarioRequestPresets, scenarioTemplates } from "@/domain/scenarios/registry";
import { toManualRequestDefinition } from "@/domain/scenarios/requestPresets";
import { manualRequestDefinitionSchema } from "@/domain/simulation/manualRequest";

describe("scenario request presets", () => {
  it("provides all deterministic request exercises for every scenario", () => {
    for (const template of scenarioTemplates) {
      const first = getScenarioRequestPresets(template.metadata.id);
      const second = getScenarioRequestPresets(template.metadata.id);
      expect(first).toEqual(second);
      expect(first.map((preset) => preset.intent)).toEqual([
        "baseline",
        "read-path",
        "write-path",
        "burst",
        "sustained",
        "boundary",
        "overload"
      ]);
    }
  });

  it("uses each template's client as the request origin and produces valid manual batches", () => {
    for (const template of scenarioTemplates) {
      const client = template.blueprint.nodes.find((node) => node.type === "client");
      expect(client, template.metadata.id).toBeDefined();
      for (const preset of getScenarioRequestPresets(template.metadata.id)) {
        expect(preset.request.sourceNodeId).toBe(client!.id);
        expect(manualRequestDefinitionSchema.safeParse(toManualRequestDefinition(preset)).success).toBe(
          true
        );
      }
    }
  });

  it("makes boundary and overload requests straddle the configured capacity", () => {
    for (const template of scenarioTemplates) {
      const presets = getScenarioRequestPresets(template.metadata.id);
      const boundary = presets.find((preset) => preset.intent === "boundary")!;
      const overload = presets.find((preset) => preset.intent === "overload")!;
      expect(boundary.request.requestCount, template.metadata.id).toBe(
        boundary.request.dispatchRateRps * 10
      );
      expect(overload.request.dispatchRateRps, template.metadata.id).toBeGreaterThan(
        boundary.request.dispatchRateRps
      );
    }
  });
});
