import { beforeEach, describe, expect, it } from "vitest";
import { usePlaybackStore, MIN_PLAYBACK_WALL_MS } from "@/stores/playbackStore";
import { useToastStore, findingsToToasts, MAX_VISIBLE_TOASTS } from "@/stores/toastStore";
import { useRequestStore, requiredDurationMs } from "@/stores/requestStore";
import { useUiStore } from "@/stores/uiStore";
import { sampleTimelineAt, playbackDurationMs, EMPTY_FRAME } from "@/domain/flow/playbackFrame";
import type { FlowTimeline } from "@/domain/metrics/flowTimeline";
import type { Finding } from "@/domain/metrics/schema";
import type { ManualRequestDefinition } from "@/domain/simulation/manualRequest";

function timeline(): FlowTimeline {
  return {
    bucketMs: 1000,
    durationMs: 4000,
    peakBucketCount: 20,
    buckets: [
      {
        timestampMs: 0,
        samples: [
          { edgeId: "e1", flowClass: "read", count: 20, failureCount: 0, retryCount: 0 }
        ]
      },
      // 1000ms is deliberately absent: quiet stretches produce no bucket.
      {
        timestampMs: 2000,
        samples: [
          { edgeId: "e1", flowClass: "read", count: 4, failureCount: 1, retryCount: 2 },
          { edgeId: "e1", flowClass: "write", count: 6, failureCount: 0, retryCount: 0 },
          { edgeId: "e2", flowClass: "replication", count: 3, failureCount: 0, retryCount: 0 }
        ]
      }
    ]
  };
}

function finding(overrides: Partial<Finding> = {}): Finding {
  return {
    id: "f1",
    severity: "warning",
    source: "analysis",
    title: "Cache is cold",
    detail: "Hit ratio stayed below 20%.",
    evidence: ["hit ratio 0.12"],
    relatedNodeIds: ["n1"],
    relatedEdgeIds: [],
    ...overrides
  } as Finding;
}

function batch(overrides: Partial<ManualRequestDefinition> = {}): ManualRequestDefinition {
  return {
    id: "b1",
    sourceNodeId: "client-1",
    method: "GET",
    requestCount: 100,
    dispatchRateRps: 50,
    startAtMs: 0,
    ...overrides
  };
}

describe("playback frame sampling", () => {
  it("returns an empty frame when there is no timeline", () => {
    const frame = sampleTimelineAt(undefined, 0);
    expect(frame.edges.size).toBe(0);
    expect(EMPTY_FRAME.edges.size).toBe(0);
  });

  it("finds the bucket covering an instant anywhere inside it", () => {
    const at0 = sampleTimelineAt(timeline(), 0);
    const at999 = sampleTimelineAt(timeline(), 999);
    expect(at0.edges.get("e1")?.count).toBe(20);
    expect(at999.edges.get("e1")?.count).toBe(20);
  });

  it("reports no traffic for a gap between buckets", () => {
    expect(sampleTimelineAt(timeline(), 1200).edges.size).toBe(0);
  });

  it("merges classes on one edge, keeping the busiest class as the visual", () => {
    const flow = sampleTimelineAt(timeline(), 2000).edges.get("e1");
    expect(flow?.count).toBe(10);
    expect(flow?.flowClass).toBe("write");
    expect(flow?.failureCount).toBe(1);
    expect(flow?.retryCount).toBe(2);
  });

  it("normalizes intensity against the run's peak bucket", () => {
    expect(sampleTimelineAt(timeline(), 0).edges.get("e1")?.intensity).toBe(1);
    expect(sampleTimelineAt(timeline(), 2000).edges.get("e1")?.intensity).toBeCloseTo(0.5, 5);
  });

  it("marks the target of each active edge as processing", () => {
    const targets = new Map([
      ["e1", "server-1"],
      ["e2", "replica-1"]
    ]);
    const frame = sampleTimelineAt(timeline(), 2000, targets);
    expect([...frame.activeNodeIds].sort()).toEqual(["replica-1", "server-1"]);
  });

  it("is deterministic for the same instant", () => {
    const a = sampleTimelineAt(timeline(), 2000);
    const b = sampleTimelineAt(timeline(), 2000);
    expect([...a.edges.entries()]).toEqual([...b.edges.entries()]);
  });

  it("covers trailing quiet time in the playback duration", () => {
    expect(playbackDurationMs(timeline())).toBe(4000);
    expect(playbackDurationMs(undefined)).toBe(0);
  });
});

describe("playback store", () => {
  beforeEach(() => {
    usePlaybackStore.getState().reset();
    usePlaybackStore.getState().setSpeed(1);
  });

  it("completes immediately when a run recorded no flow", () => {
    usePlaybackStore.getState().start(undefined);
    expect(usePlaybackStore.getState().status).toBe("completed");
  });

  it("stretches short runs to stay watchable but never compresses long ones", () => {
    usePlaybackStore.getState().start({ ...timeline(), durationMs: 1000 });
    expect(usePlaybackStore.getState().logicalPerWallMs).toBeCloseTo(1000 / MIN_PLAYBACK_WALL_MS, 5);

    usePlaybackStore.getState().reset();
    usePlaybackStore.getState().start({ ...timeline(), durationMs: 300_000 });
    expect(usePlaybackStore.getState().logicalPerWallMs).toBe(1);
  });

  it("advances logical time by the speed multiplier", () => {
    usePlaybackStore.getState().start({ ...timeline(), durationMs: 300_000 });
    usePlaybackStore.getState().setSpeed(4);
    usePlaybackStore.getState().advance(100);
    expect(usePlaybackStore.getState().currentLogicalTimeMs).toBeCloseTo(400, 5);
  });

  it("does not advance while paused", () => {
    usePlaybackStore.getState().start({ ...timeline(), durationMs: 300_000 });
    usePlaybackStore.getState().advance(100);
    const at = usePlaybackStore.getState().currentLogicalTimeMs;
    usePlaybackStore.getState().pause();
    usePlaybackStore.getState().advance(5000);
    expect(usePlaybackStore.getState().currentLogicalTimeMs).toBe(at);
    usePlaybackStore.getState().resume();
    expect(usePlaybackStore.getState().status).toBe("running");
  });

  it("clamps to the end of the run rather than overshooting", () => {
    usePlaybackStore.getState().start(timeline());
    usePlaybackStore.getState().advance(1_000_000);
    expect(usePlaybackStore.getState().status).toBe("completed");
    expect(usePlaybackStore.getState().currentLogicalTimeMs).toBe(4000);
  });

  it("skips to the end and replays from the start on restart", () => {
    usePlaybackStore.getState().start(timeline());
    usePlaybackStore.getState().skipToEnd();
    expect(usePlaybackStore.getState().currentLogicalTimeMs).toBe(4000);
    usePlaybackStore.getState().restart();
    expect(usePlaybackStore.getState().currentLogicalTimeMs).toBe(0);
    expect(usePlaybackStore.getState().status).toBe("running");
  });

  it("seeks within completed telemetry without changing its logical bounds", () => {
    usePlaybackStore.getState().start(timeline());
    usePlaybackStore.getState().seek(2_000);
    expect(usePlaybackStore.getState()).toMatchObject({
      currentLogicalTimeMs: 2_000,
      status: "paused"
    });

    usePlaybackStore.getState().seek(99_000);
    expect(usePlaybackStore.getState()).toMatchObject({
      currentLogicalTimeMs: 4_000,
      status: "completed"
    });

    usePlaybackStore.getState().seek(-100);
    expect(usePlaybackStore.getState()).toMatchObject({
      currentLogicalTimeMs: 0,
      status: "paused"
    });
  });
});

describe("findings toasts", () => {
  beforeEach(() => {
    useToastStore.setState({
      visible: [],
      queued: [],
      history: [],
      notificationCentreOpen: false
    });
  });

  it("labels the finding's subject component", () => {
    const [toast] = findingsToToasts([finding()], () => "Session cache", 1);
    expect(toast?.subjectLabel).toBe("Session cache");
    expect(toast?.focusNodeId).toBe("n1");
    expect(toast?.metricSummary).toBe("hit ratio 0.12");
  });

  it("promotes informational recommendations to their own severity", () => {
    const [toast] = findingsToToasts(
      [finding({ severity: "info", source: "recommendation" })],
      () => undefined,
      1
    );
    expect(toast?.severity).toBe("recommendation");
  });

  it("shows criticals first and queues the overflow", () => {
    const findings = [
      finding({ id: "a", severity: "info", relatedNodeIds: ["n1"] }),
      finding({ id: "b", severity: "info", relatedNodeIds: ["n2"] }),
      finding({ id: "c", severity: "info", relatedNodeIds: ["n3"] }),
      finding({ id: "d", severity: "critical", relatedNodeIds: ["n4"] })
    ];
    useToastStore.getState().publish(findingsToToasts(findings, () => undefined, 1));
    const state = useToastStore.getState();
    expect(state.visible).toHaveLength(MAX_VISIBLE_TOASTS);
    expect(state.visible[0]?.severity).toBe("critical");
    expect(state.queued).toHaveLength(1);
  });

  it("counts a repeated condition instead of stacking duplicates", () => {
    useToastStore.getState().publish(findingsToToasts([finding()], () => undefined, 1));
    useToastStore.getState().publish(findingsToToasts([finding()], () => undefined, 2));
    expect(useToastStore.getState().visible).toHaveLength(1);
    expect(useToastStore.getState().visible[0]?.repeatCount).toBe(1);
  });

  it("promotes a queued toast when a visible one is dismissed", () => {
    const findings = Array.from({ length: MAX_VISIBLE_TOASTS + 1 }, (_, index) =>
      finding({ id: `f${index}`, relatedNodeIds: [`n${index}`] })
    );
    useToastStore.getState().publish(findingsToToasts(findings, () => undefined, 1));
    const first = useToastStore.getState().visible[0]!;
    useToastStore.getState().dismiss(first.id);
    expect(useToastStore.getState().visible).toHaveLength(MAX_VISIBLE_TOASTS);
    expect(useToastStore.getState().queued).toHaveLength(0);
  });

  it("keeps dismissed findings reachable in history", () => {
    useToastStore.getState().publish(findingsToToasts([finding()], () => undefined, 1));
    useToastStore.getState().dismissAll();
    expect(useToastStore.getState().visible).toHaveLength(0);
    expect(useToastStore.getState().history).toHaveLength(1);
  });
});

describe("request batches", () => {
  beforeEach(() => {
    useRequestStore.setState({ batches: [], suppressProfileTraffic: false });
  });

  it("reports the run duration every queued batch needs", () => {
    useRequestStore.getState().addBatch(batch());
    useRequestStore.getState().addBatch(batch({ id: "b2", startAtMs: 5000, requestCount: 10, dispatchRateRps: 1 }));
    expect(requiredDurationMs(useRequestStore.getState().batches)).toBe(15_000);
  });

  it("removes a batch without disturbing the others", () => {
    useRequestStore.getState().addBatch(batch());
    useRequestStore.getState().addBatch(batch({ id: "b2" }));
    useRequestStore.getState().removeBatch("b1");
    expect(useRequestStore.getState().batches.map((item) => item.id)).toEqual(["b2"]);
  });
});

describe("metrics modal ui state", () => {
  it("opens focused on the component a finding names and clears focus on close", () => {
    useUiStore.getState().openMetrics("n1");
    expect(useUiStore.getState().metricsModalOpen).toBe(true);
    expect(useUiStore.getState().metricsFocusNodeId).toBe("n1");
    useUiStore.getState().closeMetrics();
    expect(useUiStore.getState().metricsModalOpen).toBe(false);
    expect(useUiStore.getState().metricsFocusNodeId).toBeUndefined();
  });
});
