import { describe, expect, it } from "vitest";
import { runSimulation } from "@/simulation-engine/core/SimulationEngine";
import { defaultSimulationSettings } from "@/domain/simulation/simulationInput";
import type { SimulationInput } from "@/domain/simulation/simulationInput";
import {
  batchDurationMs,
  effectiveRequestClass,
  generateManualArrivalTimestamps,
  isReadRequestClass,
  manualRequestDefinitionSchema,
  type ManualRequestDefinition
} from "@/domain/simulation/manualRequest";
import { FlowRecorder } from "@/simulation-engine/metrics/FlowRecorder";
import { edge, node, project, trafficProfile } from "./testFixtures";

function batch(overrides: Partial<ManualRequestDefinition> = {}): ManualRequestDefinition {
  return manualRequestDefinitionSchema.parse({
    id: "batch-1",
    sourceNodeId: "client",
    method: "PUT",
    requestCount: 1000,
    dispatchRateRps: 100,
    ...overrides
  });
}

function input(overrides: Partial<SimulationInput> = {}): SimulationInput {
  const document = project(
    [
      node("client", "client", { maxRetries: 0 }),
      node("api", "server", { perInstanceCapacityRps: 10_000, baseLatencyMs: 2 })
    ],
    [edge("e1", "client", "api")],
    [trafficProfile({ durationMs: 20_000, intervals: [{ kind: "constant", startMs: 0, endMs: 20_000, startRps: 10, endRps: 10 }] })]
  );
  return {
    projectSnapshot: document,
    trafficProfileId: "profile-1",
    faultScenarioIds: [],
    durationMs: 20_000,
    seed: 7,
    settings: defaultSimulationSettings(),
    ...overrides
  };
}

describe("manual request batches", () => {
  it("dispatches exactly the requested count over the implied duration", () => {
    const definition = batch();
    const arrivals = generateManualArrivalTimestamps(definition);

    expect(arrivals).toHaveLength(1000);
    expect(arrivals[0]).toBe(0);
    // 1,000 requests at 100 RPS occupies exactly 10 logical seconds.
    expect(batchDurationMs(definition)).toBe(10_000);
    expect(arrivals[arrivals.length - 1]).toBeCloseTo(9990, 6);
  });

  it("spaces arrivals without accumulating floating-point drift", () => {
    // 3 RPS gives a non-terminating interval, which is where naive repeated
    // addition would visibly drift over a long batch.
    const arrivals = generateManualArrivalTimestamps(
      batch({ requestCount: 30_000, dispatchRateRps: 3 })
    );
    expect(arrivals[29_999]).toBeCloseTo((29_999 * 1000) / 3, 6);
  });

  it("honours startAtMs", () => {
    const arrivals = generateManualArrivalTimestamps(
      batch({ requestCount: 3, dispatchRateRps: 1, startAtMs: 5000 })
    );
    expect(arrivals).toEqual([5000, 6000, 7000]);
  });

  it("derives request class from the method when none is given", () => {
    expect(effectiveRequestClass(batch({ method: "GET" }))).toBe("read");
    expect(effectiveRequestClass(batch({ method: "HEAD" }))).toBe("read");
    expect(effectiveRequestClass(batch({ method: "OPTIONS" }))).toBe("read");
    expect(effectiveRequestClass(batch({ method: "PUT" }))).toBe("write");
    expect(effectiveRequestClass(batch({ method: "DELETE" }))).toBe("write");
    // An explicit class always wins over the method's default.
    expect(effectiveRequestClass(batch({ method: "POST", requestClass: "read" }))).toBe("read");
  });

  it("treats an auth-required class by its method for the read/write split", () => {
    expect(isReadRequestClass("GET", "auth-required")).toBe(true);
    expect(isReadRequestClass("POST", "auth-required")).toBe(false);
  });

  it("rejects invalid batch definitions", () => {
    expect(() => batch({ requestCount: 0 })).toThrow();
    expect(() => batch({ dispatchRateRps: 0 })).toThrow();
    expect(() => manualRequestDefinitionSchema.parse({ id: "b", sourceNodeId: "c", method: "TRACE", requestCount: 1, dispatchRateRps: 1 })).toThrow();
  });

  it("records every manual request in the run's method distribution", () => {
    const result = runSimulation(
      input({ manualRequests: [batch({ requestCount: 50, dispatchRateRps: 50 })], suppressProfileTraffic: true })
    );

    expect(result.status).toBe("completed");
    expect(result.methodDistribution?.PUT).toBe(50);
    expect(result.manualBatchIds).toEqual(["batch-1"]);
    expect(result.summary?.requestCount).toBe(50);
  });

  it("runs manual batches alongside profile traffic", () => {
    const withBatch = runSimulation(input({ manualRequests: [batch({ requestCount: 20, dispatchRateRps: 20 })] }));
    const withoutBatch = runSimulation(input());

    expect(withBatch.summary!.requestCount).toBe(withoutBatch.summary!.requestCount + 20);
    expect(withBatch.methodDistribution?.PUT).toBe(20);
  });

  it("leaves profile traffic's random sequence untouched when a batch is added", () => {
    // Manual batches declare their own read/write class and so must not draw
    // from the seeded generator. If they did, adding a batch would silently
    // change the outcome of unrelated profile traffic.
    const withBatch = runSimulation(input({ manualRequests: [batch({ requestCount: 20, dispatchRateRps: 20 })] }));
    const withoutBatch = runSimulation(input());

    expect(withBatch.observedAvailability).toBe(withoutBatch.observedAvailability);
  });

  it("produces identical results for identical seed and input", () => {
    const first = runSimulation(input({ manualRequests: [batch({ requestCount: 100, dispatchRateRps: 100 })] }));
    const second = runSimulation(input({ manualRequests: [batch({ requestCount: 100, dispatchRateRps: 100 })] }));

    expect(second.summary).toEqual(first.summary);
    expect(second.flowTimeline).toEqual(first.flowTimeline);
    expect(second.methodDistribution).toEqual(first.methodDistribution);
  });

  it("dispatches from the requested origin node", () => {
    const document = project(
      [
        node("client-a", "client"),
        node("client-b", "client"),
        node("api-a", "server", { perInstanceCapacityRps: 10_000 }),
        node("api-b", "server", { perInstanceCapacityRps: 10_000 })
      ],
      [edge("ea", "client-a", "api-a"), edge("eb", "client-b", "api-b")]
    );
    const result = runSimulation(
      input({
        projectSnapshot: document,
        durationMs: 5000,
        suppressProfileTraffic: true,
        manualRequests: [batch({ sourceNodeId: "client-b", requestCount: 10, dispatchRateRps: 10 })]
      })
    );

    const edgeIds = new Set(
      result.flowTimeline!.buckets.flatMap((bucket) => bucket.samples.map((s) => s.edgeId))
    );
    expect(edgeIds).toEqual(new Set(["eb"]));
  });
});

describe("flow timeline", () => {
  it("buckets traversals rather than recording one entry per request", () => {
    const result = runSimulation(
      input({ manualRequests: [batch({ requestCount: 500, dispatchRateRps: 500 })], suppressProfileTraffic: true })
    );
    const timeline = result.flowTimeline!;

    const totalCount = timeline.buckets
      .flatMap((bucket) => bucket.samples)
      .reduce((sum, sample) => sum + sample.count, 0);

    expect(totalCount).toBe(500);
    // 500 requests collapse into a handful of buckets, which is what keeps
    // rendering cost independent of traffic volume.
    expect(timeline.buckets.length).toBeLessThan(20);
    expect(timeline.peakBucketCount).toBeGreaterThan(0);
  });

  it("classifies write batches as write flow", () => {
    const result = runSimulation(
      input({ manualRequests: [batch({ method: "PUT", requestCount: 10, dispatchRateRps: 10 })], suppressProfileTraffic: true })
    );
    const classes = new Set(
      result.flowTimeline!.buckets.flatMap((b) => b.samples.map((s) => s.flowClass))
    );
    expect(classes).toEqual(new Set(["write"]));
  });

  it("classifies read batches as read flow", () => {
    const result = runSimulation(
      input({ manualRequests: [batch({ method: "GET", requestCount: 10, dispatchRateRps: 10 })], suppressProfileTraffic: true })
    );
    const classes = new Set(
      result.flowTimeline!.buckets.flatMap((b) => b.samples.map((s) => s.flowClass))
    );
    expect(classes).toEqual(new Set(["read"]));
  });

  it("emits buckets in ascending time order", () => {
    const timeline = runSimulation(input()).flowTimeline!;
    const times = timeline.buckets.map((bucket) => bucket.timestampMs);
    expect(times).toEqual([...times].sort((a, b) => a - b));
  });
});

describe("FlowRecorder", () => {
  it("merges traversals of the same edge and class within a bucket", () => {
    const recorder = new FlowRecorder(100);
    recorder.record("e1", "read", 10);
    recorder.record("e1", "read", 50);
    recorder.record("e1", "write", 50);

    const timeline = recorder.build(100);
    expect(timeline.buckets).toHaveLength(1);
    expect(timeline.buckets[0]!.samples).toHaveLength(2);
    expect(timeline.buckets[0]!.samples[0]!.count).toBe(2);
    expect(timeline.peakBucketCount).toBe(2);
  });

  it("separates traversals into distinct buckets", () => {
    const recorder = new FlowRecorder(100);
    recorder.record("e1", "read", 10);
    recorder.record("e1", "read", 250);

    const timeline = recorder.build(300);
    expect(timeline.buckets.map((b) => b.timestampMs)).toEqual([0, 200]);
  });

  it("attributes failures to the samples a request actually traversed", () => {
    const recorder = new FlowRecorder(100);
    const first = recorder.record("e1", "read", 10);
    recorder.record("e2", "read", 10);

    recorder.markFailed([first]);

    expect(first.failureCount).toBe(1);
    const timeline = recorder.build(100);
    const untouched = timeline.buckets[0]!.samples.find((s) => s.edgeId === "e2")!;
    expect(untouched.failureCount).toBe(0);
  });

  it("never reports more failures than traversals", () => {
    const recorder = new FlowRecorder(100);
    const sample = recorder.record("e1", "read", 0);
    recorder.markFailed([sample]);
    recorder.markFailed([sample]);
    expect(sample.failureCount).toBe(1);
  });

  it("counts retry attempts separately from first attempts", () => {
    const recorder = new FlowRecorder(100);
    recorder.record("e1", "read", 0);
    recorder.record("e1", "read", 0, { isRetry: true });

    const sample = recorder.build(100).buckets[0]!.samples[0]!;
    expect(sample.count).toBe(2);
    expect(sample.retryCount).toBe(1);
  });
});
