import { describe, expect, it } from "vitest";
import { toggleFaultScenario } from "@/features/simulation/faultSelection";

describe("fault scenario selection", () => {
  it("keeps every selected fault instead of replacing the first selection", () => {
    const armed = toggleFaultScenario(["database-slowdown"], "app-outage", true);

    expect(armed).toEqual(["database-slowdown", "app-outage"]);
  });

  it("removes only the unchecked fault", () => {
    expect(toggleFaultScenario(["database-slowdown", "app-outage"], "app-outage", false)).toEqual([
      "database-slowdown"
    ]);
  });

  it("does not duplicate a selected fault", () => {
    expect(toggleFaultScenario(["database-slowdown"], "database-slowdown", true)).toEqual([
      "database-slowdown"
    ]);
  });
});
