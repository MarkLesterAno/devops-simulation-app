import { afterEach, describe, expect, it, vi } from "vitest";
import { defaultSimulationSettings, type SimulationInput } from "@/domain/simulation/simulationInput";
import { SimulationWorkerClient } from "@/simulation-engine/worker/SimulationWorkerClient";
import { edge, node, project } from "./testFixtures";

class MockWorker {
  static instances: MockWorker[] = [];

  onmessage: ((event: MessageEvent) => void) | null = null;
  onerror: ((event: ErrorEvent) => void) | null = null;
  readonly postMessage = vi.fn();
  readonly terminate = vi.fn();

  constructor() {
    MockWorker.instances.push(this);
  }
}

const input: SimulationInput = {
  projectSnapshot: project(
    [node("client", "client"), node("server", "server")],
    [edge("request", "client", "server")]
  ),
  trafficProfileId: "profile-1",
  faultScenarioIds: [],
  durationMs: 1000,
  seed: 42,
  settings: defaultSimulationSettings()
};

describe("SimulationWorkerClient", () => {
  const originalWorker = globalThis.Worker;

  afterEach(() => {
    MockWorker.instances = [];
    globalThis.Worker = originalWorker;
  });

  it("AC-SI-06: settles cancellation with an explicit no-metrics result", async () => {
    globalThis.Worker = MockWorker as unknown as typeof Worker;
    const client = new SimulationWorkerClient();

    const pending = client.run(input);
    const worker = MockWorker.instances[0];
    expect(worker).toBeDefined();

    client.cancel();

    await expect(pending).resolves.toMatchObject({
      status: "cancelled",
      seed: input.seed,
      systemMetrics: [],
      componentMetrics: [],
      events: [],
      findings: []
    });
    expect(worker!.terminate).toHaveBeenCalledTimes(1);
  });

  it("cancels a prior active run before starting a replacement", async () => {
    globalThis.Worker = MockWorker as unknown as typeof Worker;
    const client = new SimulationWorkerClient();

    const first = client.run(input);
    const firstWorker = MockWorker.instances[0];
    const second = client.run(input);

    await expect(first).resolves.toMatchObject({ status: "cancelled" });
    expect(firstWorker!.terminate).toHaveBeenCalledTimes(1);
    client.cancel();
    await expect(second).resolves.toMatchObject({ status: "cancelled" });
  });
});
