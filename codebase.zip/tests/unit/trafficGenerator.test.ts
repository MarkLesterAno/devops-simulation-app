import { describe, expect, it } from "vitest";
import { generateArrivalTimestamps } from "@/simulation-engine/core/trafficGenerator";
import { trafficProfile } from "./testFixtures";

describe("generateArrivalTimestamps", () => {
  it("generates exactly durationSeconds * rps arrivals for a constant profile", () => {
    const profile = trafficProfile({
      durationMs: 1000,
      intervals: [{ kind: "constant", startMs: 0, endMs: 1000, startRps: 100, endRps: 100 }]
    });
    const arrivals = generateArrivalTimestamps(profile);
    expect(arrivals).toHaveLength(100);
  });

  it("produces arrivals in non-decreasing timestamp order", () => {
    const profile = trafficProfile({
      durationMs: 2000,
      intervals: [
        { kind: "constant", startMs: 0, endMs: 1000, startRps: 50, endRps: 50 },
        { kind: "ramp", startMs: 1000, endMs: 2000, startRps: 50, endRps: 150 }
      ]
    });
    const arrivals = generateArrivalTimestamps(profile);
    for (let i = 1; i < arrivals.length; i += 1) {
      expect(arrivals[i]).toBeGreaterThanOrEqual(arrivals[i - 1]!);
    }
  });

  it("is deterministic given the same profile", () => {
    const profile = trafficProfile();
    expect(generateArrivalTimestamps(profile)).toEqual(generateArrivalTimestamps(profile));
  });

  it("produces more arrivals in the second half of a ramp than the first half", () => {
    const profile = trafficProfile({
      durationMs: 1000,
      intervals: [{ kind: "ramp", startMs: 0, endMs: 1000, startRps: 10, endRps: 200 }]
    });
    const arrivals = generateArrivalTimestamps(profile);
    const firstHalf = arrivals.filter((t) => t < 500).length;
    const secondHalf = arrivals.filter((t) => t >= 500).length;
    expect(secondHalf).toBeGreaterThan(firstHalf);
  });
});
