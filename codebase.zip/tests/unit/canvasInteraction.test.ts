import { beforeEach, describe, expect, it } from "vitest";
import { useProjectStore } from "@/stores/projectStore";
import { useUiStore } from "@/stores/uiStore";
import {
  architectureSignature,
  describeDeletionImpact,
  resultFreshness
} from "@/domain/architecture/projectAnalysis";
import { glyphForComponentType, technologyIconFor, monogramFor } from "@/domain/icons/iconRegistry";
import { componentDefinitions } from "@/domain/components/registry";
import { deriveFindings } from "@/simulation-engine/core/findings";
import type { ComponentType } from "@/domain/architecture/schema";
import type { ComponentMetricSnapshot } from "@/domain/metrics/schema";
import { ENGINE_VERSION, COMPONENT_MODEL_VERSION } from "@/simulation-engine/core/SimulationEngine";

function resetProject(): void {
  useProjectStore.getState().newProject();
}

describe("icon registry", () => {
  it("maps every catalog component type to a glyph", () => {
    for (const type of Object.keys(componentDefinitions) as ComponentType[]) {
      expect(glyphForComponentType(type)).toBeTruthy();
    }
  });

  it("falls back to a provider-tinted monogram when no logo asset is bundled", () => {
    const icon = technologyIconFor("redis", "Redis", "Redis");
    expect(icon.assetPath).toBeUndefined();
    expect(icon.monogram.length).toBeGreaterThan(0);
    expect(icon.accent).toMatch(/^#/);
  });

  it("produces a stable accent for unknown providers instead of throwing", () => {
    const icon = technologyIconFor("mystery", "Mystery Store", undefined);
    expect(icon.accent).toMatch(/^#/);
    expect(icon.monogram).toBe(monogramFor("Mystery Store"));
  });
});

describe("duplicateNode", () => {
  beforeEach(resetProject);

  it("creates an offset copy with a new id and no inherited edges", () => {
    const store = useProjectStore.getState();
    const originalId = store.addNode("server", { x: 100, y: 100 });
    const targetId = useProjectStore.getState().addNode("cache", { x: 400, y: 100 });
    useProjectStore.getState().addEdge(originalId, targetId, "request");

    const copyId = useProjectStore.getState().duplicateNode(originalId);
    expect(copyId).toBeDefined();
    expect(copyId).not.toBe(originalId);

    const state = useProjectStore.getState();
    const original = state.document.nodes.find((node) => node.id === originalId);
    const copy = state.document.nodes.find((node) => node.id === copyId);
    expect(copy?.type).toBe(original?.type);
    expect(copy?.position.x).toBeGreaterThan(original?.position.x ?? 0);
    expect(copy?.position.y).toBeGreaterThan(original?.position.y ?? 0);
    expect(copy?.config.displayName).toContain("copy");
    expect(state.document.edges.some((edge) => edge.sourceNodeId === copyId)).toBe(false);
    expect(state.selectedNodeId).toBe(copyId);
  });

  it("is undoable as a single step", () => {
    const originalId = useProjectStore.getState().addNode("server", { x: 0, y: 0 });
    const before = useProjectStore.getState().document.nodes.length;
    useProjectStore.getState().duplicateNode(originalId);
    expect(useProjectStore.getState().document.nodes.length).toBe(before + 1);

    useProjectStore.getState().undo();
    expect(useProjectStore.getState().document.nodes.length).toBe(before);
  });
});

describe("architectureSignature", () => {
  beforeEach(resetProject);

  it("ignores node position so dragging does not make results stale", () => {
    const nodeId = useProjectStore.getState().addNode("server", { x: 0, y: 0 });
    const before = architectureSignature(useProjectStore.getState().document);
    useProjectStore.getState().moveNode(nodeId, { x: 500, y: 320 });
    expect(architectureSignature(useProjectStore.getState().document)).toBe(before);
  });

  it("changes when configuration changes", () => {
    const nodeId = useProjectStore.getState().addNode("server", { x: 0, y: 0 });
    const before = architectureSignature(useProjectStore.getState().document);
    useProjectStore.getState().updateNodeConfig(nodeId, { instanceCount: 7 });
    expect(architectureSignature(useProjectStore.getState().document)).not.toBe(before);
  });

  it("changes when edge routing behavior changes", () => {
    const sourceId = useProjectStore.getState().addNode("client", { x: 0, y: 0 });
    const targetId = useProjectStore.getState().addNode("server", { x: 300, y: 0 });
    useProjectStore.getState().addEdge(sourceId, targetId, "request");
    const before = architectureSignature(useProjectStore.getState().document);
    const edgeId = useProjectStore.getState().document.edges[0]!.id;
    useProjectStore.setState((state) => ({
      document: {
        ...state.document,
        edges: state.document.edges.map((edge) =>
          edge.id === edgeId ? { ...edge, routingStrategy: "weighted", weight: 0.25 } : edge
        )
      }
    }));
    expect(architectureSignature(useProjectStore.getState().document)).not.toBe(before);
  });

  it("marks model-version-incompatible results stale without treating positioning as behavior", () => {
    const document = useProjectStore.getState().document;
    const signature = architectureSignature(document);
    const result = {
      runId: "run",
      seed: 42,
      status: "completed" as const,
      engineVersion: ENGINE_VERSION,
      componentModelVersion: "older-model",
      systemMetrics: [],
      componentMetrics: [],
      events: [],
      findings: [],
      assumptions: []
    };
    expect(resultFreshness(result, document, signature)).toBe("simulation-model-changed");
    expect(COMPONENT_MODEL_VERSION).not.toBe("older-model");
  });
});

describe("describeDeletionImpact", () => {
  beforeEach(resetProject);

  it("does not require confirmation for an unconnected node", () => {
    const nodeId = useProjectStore.getState().addNode("server", { x: 0, y: 0 });
    const impact = describeDeletionImpact(useProjectStore.getState().document, nodeId);
    expect(impact.edgeCount).toBe(0);
    expect(impact.requiresConfirmation).toBe(false);
  });

  it("reports connected edges and requires confirmation", () => {
    const sourceId = useProjectStore.getState().addNode("server", { x: 0, y: 0 });
    const targetId = useProjectStore.getState().addNode("cache", { x: 300, y: 0 });
    useProjectStore.getState().addEdge(sourceId, targetId, "request");

    const impact = describeDeletionImpact(useProjectStore.getState().document, targetId);
    expect(impact.edgeCount).toBe(1);
    expect(impact.requiresConfirmation).toBe(true);
  });
});

describe("uiStore", () => {
  it("defaults the node modal to Simulation settings and resets per node", () => {
    const ui = useUiStore.getState();
    ui.openNodeConfig("node-a");
    expect(useUiStore.getState().configTab).toBe("inspector");

    useUiStore.getState().setConfigTab("implementation");
    useUiStore.getState().openNodeConfig("node-a");
    expect(useUiStore.getState().configTab).toBe("implementation");

    useUiStore.getState().openNodeConfig("node-b");
    expect(useUiStore.getState().configTab).toBe("inspector");
    useUiStore.getState().closeNodeConfig();
  });

  it("closes the context menu when a configuration modal opens", () => {
    useUiStore.getState().openContextMenu({ nodeId: "node-a", x: 10, y: 10 });
    expect(useUiStore.getState().contextMenu).toBeDefined();
    useUiStore.getState().openNodeConfig("node-a");
    expect(useUiStore.getState().contextMenu).toBeUndefined();
    useUiStore.getState().closeNodeConfig();
  });
});

describe("finding severity", () => {
  it("labels saturation as critical and its remedy as informational", () => {
    const snapshots: ComponentMetricSnapshot[] = [
      {
        nodeId: "node-1",
        timestampMs: 0,
        utilization: 0.99,
        activeWork: 10,
        queuedWork: 4,
        latencyMs: 120,
        errorRate: 0.1
      }
    ];
    const findings = deriveFindings([], snapshots, 0.9);
    const bottleneck = findings.find((finding) => finding.id === "bottleneck-node-1");
    const recommendation = findings.find((finding) => finding.id === "recommendation-node-1");
    const availability = findings.find((finding) => finding.id === "observed-availability");

    expect(bottleneck?.severity).toBe("critical");
    expect(bottleneck?.suggestedAction).toBeTruthy();
    expect(recommendation?.severity).toBe("info");
    expect(availability?.severity).toBe("critical");
  });

  it("downgrades a near-miss availability finding to a warning", () => {
    const findings = deriveFindings([], [], 0.97);
    expect(findings[0]?.severity).toBe("warning");
  });
});
