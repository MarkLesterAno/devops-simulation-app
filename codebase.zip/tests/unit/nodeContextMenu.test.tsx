import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it } from "vitest";
import { NodeContextMenu } from "@/features/canvas/NodeContextMenu";
import { useProjectStore } from "@/stores/projectStore";
import { useUiStore } from "@/stores/uiStore";

describe("NodeContextMenu", () => {
  beforeEach(() => {
    useProjectStore.getState().newProject();
    useUiStore.getState().closeContextMenu();
  });

  it("supports roving menu navigation and restores focus to its node on Escape", () => {
    const nodeId = useProjectStore.getState().addNode("server", { x: 0, y: 0 });
    const nodeElement = document.createElement("div");
    nodeElement.className = "react-flow__node";
    nodeElement.dataset.id = nodeId;
    nodeElement.tabIndex = 0;
    document.body.append(nodeElement);
    useUiStore.getState().openContextMenu({ nodeId, x: 10, y: 10 });
    render(<NodeContextMenu />);

    const configure = screen.getByRole("menuitem", { name: "Configure" });
    expect(configure).toHaveFocus();

    fireEvent.keyDown(configure, { key: "ArrowDown" });
    expect(screen.getByRole("menuitem", { name: "Duplicate" })).toHaveFocus();

    fireEvent.keyDown(document.activeElement!, { key: "End" });
    expect(screen.getByRole("menuitem", { name: "Delete" })).toHaveFocus();

    fireEvent.keyDown(document.activeElement!, { key: "Escape" });
    expect(useUiStore.getState().contextMenu).toBeUndefined();
    expect(nodeElement).toHaveFocus();
    nodeElement.remove();
  });
});
