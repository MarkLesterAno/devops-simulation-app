import { describe, expect, it } from "vitest";
import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { buildScenarioDocument } from "@/domain/scenarios/builder";
import { filterScenarios, getScenarioTags, scenarioTemplates } from "@/domain/scenarios/registry";
import { projectDocumentSchema } from "@/domain/architecture/projectDocument";
import { hasBlockingErrors, validateGraph } from "@/domain/validation/graphValidation";
import { resolveTechnologyAssignment } from "@/domain/technology/registry";

const repoRoot = resolve(__dirname, "..", "..");
const REQUIRED_SCENARIO_HEADINGS = [
  "Overview",
  "Learning Objectives",
  "Architecture Summary",
  "Functional Requirements",
  "Non-Functional Requirements",
  "Components and Responsibilities",
  "Request and Event Flows",
  "Data Model and Storage Assumptions",
  "Technology Suggestions",
  "Traffic Profile",
  "Capacity and Scaling Assumptions",
  "Caching Strategy",
  "Reliability and Failure Handling",
  "Security Considerations",
  "Observability Plan",
  "Simulation Exercises",
  "Expected Results",
  "Common Failure Modes",
  "Trade-Offs",
  "Simulator Limitations",
  "Extension Exercises"
];
const USER_GUIDE_PAGES = [
  "getting-started.md",
  "building-architectures.md",
  "configuring-simulation.md",
  "manual-requests.md",
  "running-and-playback.md",
  "understanding-results.md",
  "fault-injection-and-troubleshooting.md",
  "accessibility-and-keyboard.md",
  "data-privacy-and-security.md"
];

function docPath(relative: string): string {
  return resolve(repoRoot, relative);
}

describe("scenario library", () => {
  it("ships the full documented set of scenarios", () => {
    expect(scenarioTemplates).toHaveLength(16);
    const byDifficulty = scenarioTemplates.reduce<Record<string, number>>((counts, template) => {
      counts[template.metadata.difficulty] = (counts[template.metadata.difficulty] ?? 0) + 1;
      return counts;
    }, {});
    expect(byDifficulty).toEqual({
      beginner: 3,
      intermediate: 5,
      advanced: 5,
      specialized: 3
    });
  });

  it("builds every template into a valid project document", () => {
    for (const template of scenarioTemplates) {
      const document = buildScenarioDocument(template, {
        id: template.metadata.id,
        now: "2024-01-01T00:00:00.000Z"
      });
      const parsed = projectDocumentSchema.safeParse(document);
      expect(parsed.success, `${template.metadata.id}: ${parsed.error?.message ?? ""}`).toBe(true);
    }
  });

  it("produces graphs that can start a simulation", () => {
    for (const template of scenarioTemplates) {
      const document = buildScenarioDocument(template, { id: template.metadata.id });
      const issues = validateGraph(document.nodes, document.edges);
      const errors = issues.filter((issue) => issue.severity === "error");
      expect(
        hasBlockingErrors(issues),
        `${template.metadata.id} has blocking errors: ${errors.map((e) => e.message).join("; ")}`
      ).toBe(false);
    }
  });

  it("raises exactly the findings each template declares it will", () => {
    for (const template of scenarioTemplates) {
      const document = buildScenarioDocument(template, { id: template.metadata.id });
      const warnings = validateGraph(document.nodes, document.edges)
        .filter((issue) => issue.severity === "warning")
        .map((issue) => issue.code);
      expect(
        [...new Set(warnings)].sort(),
        `${template.metadata.id} warnings`
      ).toEqual([...new Set(template.metadata.expectedFindings)].sort());
    }
  });

  it("uses unique node ids and unique edge ids within each template", () => {
    for (const template of scenarioTemplates) {
      const document = buildScenarioDocument(template, { id: template.metadata.id });
      const nodeIds = document.nodes.map((node) => node.id);
      const edgeIds = document.edges.map((edge) => edge.id);
      expect(new Set(nodeIds).size, `${template.metadata.id} node ids`).toBe(nodeIds.length);
      expect(new Set(edgeIds).size, `${template.metadata.id} edge ids`).toBe(edgeIds.length);
    }
  });

  it("assigns only technologies that exist and suit the component type", () => {
    for (const template of scenarioTemplates) {
      const document = buildScenarioDocument(template, { id: template.metadata.id });
      for (const node of document.nodes) {
        if (!node.config.technology) continue;
        const resolution = resolveTechnologyAssignment(node.config.technology, node.type);
        expect(resolution.state, `${template.metadata.id}/${node.id}`).toBe("known");
        if (resolution.state === "known") {
          expect(resolution.compatible, `${template.metadata.id}/${node.id}`).toBe(true);
        }
      }
    }
  });

  it("keeps every traffic profile within its declared duration", () => {
    for (const template of scenarioTemplates) {
      const document = buildScenarioDocument(template, { id: template.metadata.id });
      expect(document.trafficProfiles.length, template.metadata.id).toBeGreaterThan(0);
      for (const profile of document.trafficProfiles) {
        for (const interval of profile.intervals) {
          expect(interval.endMs).toBeLessThanOrEqual(profile.durationMs);
          expect(interval.endMs).toBeGreaterThan(interval.startMs);
        }
      }
    }
  });

  it("schedules every fault inside its scenario's default profile duration", () => {
    for (const template of scenarioTemplates) {
      const document = buildScenarioDocument(template, { id: template.metadata.id });
      const defaultProfile = document.trafficProfiles.find(
        (profile) => profile.id === template.metadata.defaultTrafficProfileId
      );
      expect(defaultProfile, template.metadata.id).toBeDefined();
      const nodeIds = new Set(document.nodes.map((node) => node.id));
      for (const scenario of document.faultScenarios) {
        for (const scheduled of scenario.faults) {
          for (const nodeId of scheduled.target.nodeIds) {
            expect(nodeIds.has(nodeId), `${template.metadata.id}/${scheduled.id}`).toBe(true);
          }
        }
      }
      for (const scheduled of
        document.faultScenarios.find(
          (scenario) => scenario.id === template.metadata.defaultFaultScenarioIds[0]
        )?.faults ?? []) {
        expect(scheduled.startMs).toBeLessThan(defaultProfile!.durationMs);
      }
    }
  });

  it("points every template at documentation that exists and names it back", () => {
    for (const { metadata } of scenarioTemplates) {
      const path = docPath(metadata.documentationPath);
      expect(existsSync(path), `missing ${metadata.documentationPath}`).toBe(true);
      const contents = readFileSync(path, "utf8");
      expect(contents, metadata.documentationPath).toContain(`template-id: ${metadata.id}`);
      expect(contents, metadata.documentationPath).toContain(
        `template-version: ${metadata.version}`
      );
      for (const heading of REQUIRED_SCENARIO_HEADINGS) {
        expect(contents, `${metadata.documentationPath} missing ${heading}`).toContain(
          `## ${heading}`
        );
      }
    }
  });

  it("lists every scenario in the library index", () => {
    const index = readFileSync(docPath("docs/scenarios/README.md"), "utf8");
    for (const { metadata } of scenarioTemplates) {
      expect(index, `index missing ${metadata.id}`).toContain(`${metadata.id}.md`);
    }
  });

  it("provides a linked user-guide page for every documented workflow", () => {
    const indexPath = docPath("docs/user-guide/README.md");
    expect(existsSync(indexPath), "missing user guide index").toBe(true);
    const index = readFileSync(indexPath, "utf8");
    for (const page of USER_GUIDE_PAGES) {
      const pagePath = docPath(`docs/user-guide/${page}`);
      expect(existsSync(pagePath), `missing user guide ${page}`).toBe(true);
      expect(index, `user guide index missing ${page}`).toContain(`./${page}`);
    }
  });

  it("filters by difficulty, tag, and free text", () => {
    const beginners = filterScenarios(scenarioTemplates, { difficulty: "beginner" });
    expect(beginners).toHaveLength(3);
    expect(filterScenarios(scenarioTemplates, { search: "url shortener" })).toHaveLength(1);
    const tag = getScenarioTags()[0];
    expect(filterScenarios(scenarioTemplates, { tag }).length).toBeGreaterThan(0);
    expect(filterScenarios(scenarioTemplates, { search: "no such scenario" })).toHaveLength(0);
  });

  it("gives each template a distinct canvas position per node", () => {
    for (const template of scenarioTemplates) {
      const positions = template.blueprint.nodes.map((node) => `${node.x},${node.y}`);
      expect(new Set(positions).size, `${template.metadata.id} overlapping nodes`).toBe(
        positions.length
      );
    }
  });
});
