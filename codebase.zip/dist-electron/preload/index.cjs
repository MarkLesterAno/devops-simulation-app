"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const projectApi = {
    open: () => electron_1.ipcRenderer.invoke("project:open"),
    save: (payload) => electron_1.ipcRenderer.invoke("project:save", payload),
    exportJson: (payload) => electron_1.ipcRenderer.invoke("project:exportJson", payload),
    recent: () => electron_1.ipcRenderer.invoke("project:recent")
};
const autosaveApi = {
    read: () => electron_1.ipcRenderer.invoke("autosave:read"),
    write: (payload) => electron_1.ipcRenderer.invoke("autosave:write", payload),
    clear: () => electron_1.ipcRenderer.invoke("autosave:clear")
};
const bridge = {
    project: projectApi,
    autosave: autosaveApi,
    platform: process.platform,
    isElectron: true
};
electron_1.contextBridge.exposeInMainWorld("simulator", bridge);
