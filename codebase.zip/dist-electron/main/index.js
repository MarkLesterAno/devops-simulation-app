import { app, BrowserWindow, ipcMain, dialog, shell } from "electron";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { z } from "zod";
import { readProjectFile, writeProjectFile, listRecentProjects, addRecentProject, readAutosave, writeAutosave, clearAutosave } from "./projectStore.js";
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const isDev = process.env.NODE_ENV === "development" || !app.isPackaged;
let mainWindow = null;
function createMainWindow() {
    mainWindow = new BrowserWindow({
        width: 1440,
        height: 900,
        minWidth: 1024,
        minHeight: 700,
        show: false,
        webPreferences: {
            // Must be the CommonJS build: Electron cannot load an ESM preload under
            // sandbox, which would silently leave window.simulator undefined.
            preload: path.join(__dirname, "../preload/index.cjs"),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
            spellcheck: false
        }
    });
    mainWindow.once("ready-to-show", () => {
        mainWindow?.show();
    });
    // Never load remote content; only local dev server (dev) or bundled files (prod).
    if (isDev) {
        void mainWindow.loadURL("http://localhost:5173");
    }
    else {
        void mainWindow.loadFile(path.join(__dirname, "../../dist/index.html"));
    }
    mainWindow.webContents.setWindowOpenHandler(({ url }) => {
        // Catalog documentation links are the only external navigation the app offers.
        // Restrict handoff to https so no other scheme can be launched on the host.
        if (url.startsWith("https://")) {
            void shell.openExternal(url);
        }
        return { action: "deny" };
    });
    mainWindow.on("closed", () => {
        mainWindow = null;
    });
}
app.whenReady().then(() => {
    registerIpcHandlers();
    createMainWindow();
    app.on("activate", () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createMainWindow();
        }
    });
});
app.on("window-all-closed", () => {
    if (process.platform !== "darwin") {
        app.quit();
    }
});
/**
 * All IPC channels are allowlisted here. Every payload is validated with Zod
 * before touching the filesystem. The renderer never receives raw ipcRenderer,
 * Node APIs, or filesystem modules; see electron/preload/index.ts.
 */
function registerIpcHandlers() {
    const openProjectSchema = z.void();
    ipcMain.handle("project:open", async () => {
        openProjectSchema.parse(undefined);
        if (!mainWindow)
            return { ok: false, error: "no-window" };
        const result = await dialog.showOpenDialog(mainWindow, {
            title: "Open Project",
            filters: [{ name: "Simulator Project", extensions: ["sdsproj.json", "json"] }],
            properties: ["openFile"]
        });
        if (result.canceled || result.filePaths.length === 0) {
            return { ok: false, error: "cancelled" };
        }
        const filePath = result.filePaths[0];
        const readResult = await readProjectFile(filePath);
        if (readResult.ok) {
            await addRecentProject(filePath);
        }
        return { ...readResult, filePath };
    });
    const saveProjectSchema = z.object({
        filePath: z.string().min(1).optional(),
        document: z.unknown()
    });
    ipcMain.handle("project:save", async (_event, payload) => {
        const parsed = saveProjectSchema.safeParse(payload);
        if (!parsed.success) {
            return { ok: false, error: "invalid-payload" };
        }
        let { filePath } = parsed.data;
        if (!filePath) {
            if (!mainWindow)
                return { ok: false, error: "no-window" };
            const result = await dialog.showSaveDialog(mainWindow, {
                title: "Save Project",
                filters: [{ name: "Simulator Project", extensions: ["json"] }],
                defaultPath: "untitled-project.json"
            });
            if (result.canceled || !result.filePath) {
                return { ok: false, error: "cancelled" };
            }
            filePath = result.filePath;
        }
        const writeResult = await writeProjectFile(filePath, parsed.data.document);
        if (writeResult.ok) {
            await addRecentProject(filePath);
        }
        return { ...writeResult, filePath };
    });
    const exportJsonSchema = z.object({ document: z.unknown() });
    ipcMain.handle("project:exportJson", async (_event, payload) => {
        const parsed = exportJsonSchema.safeParse(payload);
        if (!parsed.success) {
            return { ok: false, error: "invalid-payload" };
        }
        if (!mainWindow)
            return { ok: false, error: "no-window" };
        const result = await dialog.showSaveDialog(mainWindow, {
            title: "Export Project JSON",
            filters: [{ name: "JSON", extensions: ["json"] }],
            defaultPath: "project-export.json"
        });
        if (result.canceled || !result.filePath) {
            return { ok: false, error: "cancelled" };
        }
        return writeProjectFile(result.filePath, parsed.data.document);
    });
    ipcMain.handle("project:recent", async () => {
        return listRecentProjects();
    });
    ipcMain.handle("autosave:read", async () => {
        return readAutosave();
    });
    const autosaveWriteSchema = z.object({
        record: z.unknown()
    });
    ipcMain.handle("autosave:write", async (_event, payload) => {
        const parsed = autosaveWriteSchema.safeParse(payload);
        if (!parsed.success) {
            return { ok: false, error: "invalid-payload" };
        }
        return writeAutosave(parsed.data.record);
    });
    ipcMain.handle("autosave:clear", async () => {
        return clearAutosave();
    });
}
