import { app } from "electron";
import fs from "node:fs/promises";
import path from "node:path";
const MAX_PROJECT_FILE_BYTES = 25 * 1024 * 1024; // 25 MB safety ceiling
const RECENT_PROJECTS_LIMIT = 10;
function getUserDataPath(...segments) {
    return path.join(app.getPath("userData"), ...segments);
}
/**
 * Reads and parses a project file with size and shape guards. This function
 * never throws; callers always receive a discriminated result so a malformed
 * or oversized project cannot crash the main process.
 */
export async function readProjectFile(filePath) {
    try {
        const stats = await fs.stat(filePath);
        if (stats.size > MAX_PROJECT_FILE_BYTES) {
            return { ok: false, error: "file-too-large" };
        }
        const raw = await fs.readFile(filePath, "utf-8");
        const parsed = JSON.parse(raw);
        return { ok: true, data: parsed };
    }
    catch {
        return { ok: false, error: "read-or-parse-failed" };
    }
}
export async function writeProjectFile(filePath, document) {
    try {
        const serialized = JSON.stringify(document, null, 2);
        if (Buffer.byteLength(serialized, "utf-8") > MAX_PROJECT_FILE_BYTES) {
            return { ok: false, error: "file-too-large" };
        }
        await fs.writeFile(filePath, serialized, "utf-8");
        return { ok: true };
    }
    catch {
        return { ok: false, error: "write-failed" };
    }
}
async function readRecentProjectsFile() {
    try {
        const raw = await fs.readFile(getUserDataPath("recent-projects.json"), "utf-8");
        const parsed = JSON.parse(raw);
        if (typeof parsed === "object" &&
            parsed !== null &&
            Array.isArray(parsed.paths)) {
            return parsed;
        }
        return { paths: [] };
    }
    catch {
        return { paths: [] };
    }
}
export async function listRecentProjects() {
    const file = await readRecentProjectsFile();
    return file.paths;
}
export async function addRecentProject(filePath) {
    const file = await readRecentProjectsFile();
    const next = [filePath, ...file.paths.filter((existing) => existing !== filePath)].slice(0, RECENT_PROJECTS_LIMIT);
    try {
        await fs.mkdir(app.getPath("userData"), { recursive: true });
        await fs.writeFile(getUserDataPath("recent-projects.json"), JSON.stringify({ paths: next }, null, 2), "utf-8");
    }
    catch {
        // Recent-project tracking is best-effort and must never block save/open.
    }
}
const AUTOSAVE_DIR = "autosave";
const AUTOSAVE_FILE = "draft.json";
const MAX_AUTOSAVE_BYTES = 25 * 1024 * 1024;
function autosavePath() {
    return getUserDataPath(AUTOSAVE_DIR, AUTOSAVE_FILE);
}
/**
 * Reads the crash/refresh recovery draft. Autosave lives in the
 * application-owned userData directory, never beside the user's own files.
 */
export async function readAutosave() {
    try {
        const target = autosavePath();
        const stats = await fs.stat(target);
        if (stats.size > MAX_AUTOSAVE_BYTES) {
            return { ok: false, error: "file-too-large" };
        }
        const raw = await fs.readFile(target, "utf-8");
        const parsed = JSON.parse(raw);
        return { ok: true, data: parsed };
    }
    catch {
        // A missing draft is the normal first-run case, not an error worth surfacing.
        return { ok: false, error: "no-autosave" };
    }
}
/**
 * Writes the recovery draft atomically: a partially flushed file after a crash
 * would otherwise be the exact thing recovery depends on.
 */
export async function writeAutosave(record) {
    try {
        const serialized = JSON.stringify(record);
        if (Buffer.byteLength(serialized, "utf-8") > MAX_AUTOSAVE_BYTES) {
            return { ok: false, error: "file-too-large" };
        }
        await fs.mkdir(getUserDataPath(AUTOSAVE_DIR), { recursive: true });
        const target = autosavePath();
        const temp = `${target}.tmp`;
        await fs.writeFile(temp, serialized, "utf-8");
        await fs.rename(temp, target);
        return { ok: true };
    }
    catch {
        return { ok: false, error: "write-failed" };
    }
}
export async function clearAutosave() {
    try {
        await fs.rm(autosavePath(), { force: true });
        return { ok: true };
    }
    catch {
        return { ok: false, error: "write-failed" };
    }
}
