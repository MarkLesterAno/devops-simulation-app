# Canvas Interaction Implementation Prompt

```text
Enhance the System Design Simulator canvas interaction model, node rendering, configuration workflow, simulation visualization, and results presentation.

The implementation must remain consistent with the existing React, TypeScript, Electron, React Flow, and deterministic simulation-engine architecture. Preserve keyboard accessibility, context isolation, existing graph behavior, and offline-first constraints.

## 1. Technology Logo Rendering on Canvas Nodes

For every canvas node with a selected technology or service implementation, display the corresponding technology logo within the node.

Examples:

- A `Cache` node configured with Redis must display the Redis logo.
- A `Relational Database` node configured with PostgreSQL must display the PostgreSQL logo.
- A `CDN` node configured with Cloudflare CDN must display the Cloudflare logo.
- A `Load Balancer` node configured with AWS Application Load Balancer must display the AWS or AWS ELB-related logo, subject to available approved assets.
- A `Message Queue` node configured with Apache Kafka must display the Kafka logo.

### Requirements

- The logo displayed must be derived from the node’s selected technology implementation metadata.
- Use a structured technology-icon registry keyed by stable technology IDs, not hard-coded conditional logic in canvas components.
- If a technology does not have an approved logo asset, display a generic component-category icon instead.
- If the node uses `Generic / Custom Implementation`, display the generic icon for its component type.
- Do not fetch logos dynamically from third-party URLs at runtime.
- Store approved logo assets locally within the application bundle.
- Ensure that logos have accessible labels or equivalent text for screen readers.
- Maintain sufficient contrast and ensure logos remain recognizable in light and dark themes.
- Do not use a logo as the only indicator of the selected implementation. Continue displaying the component name and selected technology name where space permits.
- Display a fallback state if an imported project references an unknown technology identifier.

### Node Layout

Each node should display:

1. Component category or generic component icon.
2. Technology logo when an implementation is selected.
3. User-defined node name.
4. Selected implementation name, if present.
5. Runtime simulation status, when a simulation is active.
6. Compact live metrics, such as utilization, latency, error rate, queue depth, or cache hit rate where relevant.

The node layout must remain readable at standard zoom levels and degrade gracefully at low zoom.

---

## 2. Node Configuration Modal with Tabs

Replace or supplement the persistent inspector sidebar with a node configuration modal that opens for the currently selected node.

The modal must contain two tabs in this exact order:

1. **Implementation**
2. **Inspector**

### Implementation Tab

The **Implementation** tab manages the technology or provider-specific assignment.

It must include:

- Component-compatible technology selector.
- Search input.
- Provider filter.
- Deployment-model filter.
- Managed-cloud, self-hosted, open-source, and SaaS filters where applicable.
- Technology logo and display name.
- Provider name.
- Description.
- Capability badges.
- Compatibility warnings.
- Legacy or deprecated status indicators.
- Official documentation link, opened through the controlled external-link mechanism.
- Optional simulation preset details.
- An action to preview and selectively apply a technology preset.
- A `Generic / Custom Implementation` option.
- Safe fallback behavior for unknown or removed technology IDs stored in imported projects.

Selecting a technology must not automatically overwrite manually configured simulation settings. Applying a preset must display a confirmation dialog that lists each affected configuration field and allows the user to:

- Apply all preset values.
- Apply selected preset values.
- Cancel without changing node configuration.

### Inspector Tab

The **Inspector** tab manages generic component configuration.

It must contain component-appropriate sections, such as:

- General: name, description, region, tags.
- Capacity: instance count, RPS, concurrency, workers, throughput, storage limits.
- Performance: base latency, jitter, timeout, connection limits, cache settings.
- Reliability: error rate, health behavior, retry policy, overflow behavior, failover configuration.
- Data behavior: read/write capacity, consistency assumptions, replication settings, retention, TTL, or partitioning where applicable.
- Cost: optional educational cost assumptions.
- Runtime status: read-only simulation state and latest measured metrics, when available.

The Inspector tab must validate inputs using the existing schema-validation approach and display actionable inline validation errors.

### Modal Behavior

- Double-clicking a node on the canvas must open the configuration modal for that node.
- The modal must open with the **Implementation** tab selected by default.
- The modal must retain its active tab while the same node remains open.
- Closing the modal must not discard valid changes that were explicitly saved or applied.
- Opening a different node while the modal is open must either update the modal to the new node or require an explicit close, following the existing application interaction pattern.
- The modal must support keyboard navigation, focus trapping, Escape-to-close behavior, and accessible tab semantics.
- Unsaved edits must be handled explicitly through save, discard, or cancel behavior.

---

## 3. Node Context Menu

Add a context menu when the user right-clicks a node on the canvas.

The context menu must contain:

1. **Configure**
2. **Duplicate**
3. **Delete**

### Configure

- Opens the node configuration modal.
- Selects the **Implementation** tab by default.
- Focuses the selected node in the canvas before opening the modal.

### Duplicate

- Creates a deep copy of the selected node.
- Generates a new node identifier.
- Creates the duplicate with an offset position so it is visible and does not overlap the original node.
- Preserves the component type, implementation assignment, simulation configuration, labels, and metadata.
- Does not duplicate edges by default.
- Adds the operation to undo/redo history.
- Selects the new duplicate after creation.

### Delete

- Deletes the selected node and all attached edges.
- Requires confirmation when the node has one or more attached edges or is referenced by a fault scenario, traffic path, or other persisted configuration.
- Removes or safely invalidates related references according to the project-data model.
- Adds the operation to undo/redo history.
- Displays a clear summary of affected connections or references before deletion.

### Context Menu Requirements

- Prevent the browser’s default context menu on canvas nodes.
- Position the menu within the viewport and prevent clipping.
- Support keyboard invocation where possible, including Shift+F10 or the context-menu key.
- Close when the user clicks outside, presses Escape, selects an action, or the selected node no longer exists.
- Use accessible menu semantics, focus management, and keyboard navigation.

---

## 4. Metrics and Findings Results Modal

Present simulation results in a dedicated modal instead of permanently occupying canvas space.

The modal must contain two tabs in this exact order:

1. **Metrics**
2. **Findings**

### Metrics Tab

Display:

- Total requests.
- Successful and failed requests.
- Requests per second.
- Error rate.
- p50, p95, and p99 latency.
- Per-component utilization.
- Per-component latency.
- Queue depth and consumer lag.
- Cache hit and miss ratio.
- Database read/write load.
- Replica lag.
- Retry count.
- Timeout count.
- Autoscaling events.
- Circuit-breaker state transitions.
- Observed availability.
- Optional educational cost estimate.

Metrics must be grouped logically and only shown when meaningful for the simulated architecture. Charts must be accessible and provide tabular or textual alternatives for essential values.

### Findings Tab

Display findings grouped by severity and type:

- Critical bottlenecks.
- Observed simulation results.
- Architecture warnings.
- Recommendations.
- Trade-offs.
- Simulation assumptions and model limitations.

Every finding must include:

- Severity.
- Finding category: observed result, architecture warning, or recommendation.
- A concise title.
- Technical explanation.
- Supporting metric, event, or topology evidence.
- Affected node or edge, where applicable.
- Suggested next action, where appropriate.

Clicking a finding should focus the affected canvas node or edge and optionally close or minimize the results modal according to the product’s established interaction pattern.

### Results Modal Behavior

- Open automatically when a simulation completes, unless the user has disabled automatic opening.
- Be accessible from the simulation toolbar and menu.
- Remain available for completed, cancelled, and failed runs when result data exists.
- Clearly identify stale results after the architecture, traffic profile, or fault scenario changes.
- Support keyboard navigation, focus management, Escape-to-close behavior, and accessible tab semantics.
- Avoid losing result data when the modal is closed.

---

## 5. Animated Request-Flow Visualization

Add request-flow animation to canvas edges while a simulation is running.

The animation must visually communicate the direction, type, volume, and health of traffic moving through the architecture graph without affecting simulation calculations.

### Flow Types

Use distinct visual treatments for:

| Flow Type | Suggested Visual Treatment |
|---|---|
| Synchronous request flow | Solid directional edge with animated particles |
| Asynchronous event flow | Dotted or dashed edge with animated event markers |
| Replication flow | Teal dashed edge with slower animation |
| Failover flow | Orange dashed edge; animate only when active |
| Observability flow | Muted line with low-emphasis markers |
| Failed or dropped traffic | Red markers that terminate or fade before the target |
| Retried traffic | Amber markers with a retry indicator or repeated pulse |

### Animation Requirements

- Request particles must travel from source to target according to the directed edge.
- Particle frequency or density must reflect sampled or normalized traffic volume, not necessarily one particle per simulated request.
- Animation speed should be based on logical latency where feasible, but must be capped to preserve visual clarity.
- Edge styling must reflect runtime health and utilization:
  - Healthy traffic: normal style.
  - Near capacity: warning style.
  - Overloaded or degraded: orange style.
  - Failed path: red style.
  - Inactive path: muted style.
- The animation must be derived from simulation metric snapshots or event summaries and must not modify the deterministic simulation result.
- High-throughput simulations must use aggregation, sampling, throttling, or pooling to prevent browser performance degradation.
- Animations must stop when the simulation is paused, completed, cancelled, or reset.
- Respect the user’s reduced-motion preference by replacing moving particles with static directional indicators and updated edge-state labels.
- Provide an option to disable request-flow animation independently of reduced-motion settings.
- Ensure animated edges do not prevent node selection, connection editing, drag-and-drop, keyboard interaction, or context-menu use.

---

## 6. State Management and Data Requirements

Update the project and UI state models as needed.

### Node Data

Persist, at minimum:

```ts
interface NodeImplementationReference {
  technologyId?: string;
  displayName?: string;
  provider?: string;
  catalogVersion?: string;
  isGeneric: boolean;
}
```

Technology metadata must remain recoverable when a catalog entry is renamed, deprecated, or unavailable.

### UI State

Track:

- Selected node and edge.
- Open node configuration modal and active tab.
- Unsaved modal changes.
- Context-menu target node and viewport position.
- Open results modal and active tab.
- Simulation state.
- Per-edge visualization state, such as normalized traffic volume, active flow type, health status, retry count, and dropped-request count.
- User preferences for automatic result-modal opening and request-flow animation.

### Backward Compatibility

- Existing projects without implementation assignments must load as `Generic / Custom Implementation`.
- Existing projects must not fail validation solely because implementation metadata is absent.
- Unknown implementation IDs must remain visible and safely editable without preventing generic simulation.
- Add schema migrations and tests for the new project data fields.

---

## 7. Testing Requirements

Add or update tests for:

### Canvas and Node Rendering

- Generic nodes render the generic component icon.
- Nodes with a known technology implementation render the mapped local logo.
- Nodes with unknown implementation IDs render a safe fallback.
- Node labels and logos remain accessible.

### Node Configuration Modal

- Double-click opens the modal for the correct node.
- The Implementation tab is selected by default.
- Technology selection filters by compatible component type.
- Applying a preset requires confirmation and does not overwrite settings without approval.
- Inspector validation errors are visible and actionable.
- Keyboard navigation and Escape-to-close behavior work correctly.

### Context Menu

- Right-click displays Configure, Duplicate, and Delete.
- Configure opens the modal.
- Duplicate creates an offset node with a new identifier and no duplicated edges.
- Delete removes attached edges and handles dependent references safely.
- All actions are represented correctly in undo/redo history.

### Results Modal

- Metrics and Findings appear in separate tabs.
- Results open on completion when automatic opening is enabled.
- Stale-result state appears after relevant project changes.
- Clicking a finding focuses the linked graph element.

### Request-Flow Animation

- Active flow indicators reflect the correct edge direction and flow type.
- Reduced-motion mode disables moving particle animation.
- Animations pause and stop at the required simulation states.
- High-volume visualization remains within established rendering-performance limits.
- Visualization state does not alter deterministic simulation output.

---

## 8. Documentation Updates

Update the following documents to reflect the new interaction model:

- `DESIGN_BRIEF.md`
  - Replace the persistent inspector-only assumption with the tabbed node configuration modal.
  - Document node context-menu interactions and request-flow visualization.
  - Document the tabbed simulation-results modal.

- `PRD.md`
  - Add user-facing requirements for implementation-logo rendering, node configuration modal, context menu, results modal, and animated traffic flow.

- `TRD.md`
  - Define UI state, local icon registry, modal accessibility, animation performance constraints, and persistence changes.

- `SIMULATION_SPEC.md`
  - Clarify that request-flow animation is derived from simulation output and is not part of deterministic calculation.

- `ACCEPTANCE_CRITERIA.md`
  - Add verifiable criteria for logo fallback behavior, modal tabs, context-menu actions, result tabs, stale result state, reduced motion, and animation lifecycle.

- `COMPONENT_CATALOG.md`
  - Document the mapping between component technologies and approved local icon assets.

Maintain an uncluttered canvas experience. Modals should provide detail on demand, while nodes, badges, edge state, and animations communicate only the information required for fast architectural understanding.
```
