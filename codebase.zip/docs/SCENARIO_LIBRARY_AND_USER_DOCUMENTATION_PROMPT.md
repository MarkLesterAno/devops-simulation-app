# Scenario Library and User Documentation Prompt

```text
Create a comprehensive library of example system-design projects for the System Design Simulator, ranging from foundational architectures to advanced distributed-system designs. For each example, provide complete supporting documentation that explains the architecture, component choices, data flows, scalability strategy, failure modes, simulation scenarios, expected outcomes, and key engineering trade-offs.

Also create end-user documentation that explains the entire simulator: how to build architectures, configure components, assign implementation technologies, run traffic simulations, inject failures, trigger manual requests, interpret metrics, review findings, and use visual playback.

The examples and documentation must remain consistent with the simulator’s offline-first, deterministic, educational model. Do not imply that these examples provision real infrastructure, use cloud credentials, or provide production guarantees.

## 1. Example System Design Library

Create reusable, version-controlled example projects/templates that users can open directly in the simulator.

Each example must include:

- A saved simulator project/template file.
- A concise overview.
- Architecture diagram or canvas preview.
- Functional requirements.
- Non-functional requirements.
- Estimated traffic profile.
- Data model assumptions.
- Component inventory.
- Request-flow explanation.
- Synchronous and asynchronous flow descriptions.
- Technology implementation suggestions.
- Capacity and scaling assumptions.
- Caching strategy.
- Persistence and replication strategy.
- Reliability and failure-handling strategy.
- Security considerations.
- Observability requirements.
- Cost considerations, clearly labeled as educational estimates.
- Recommended simulation scenarios.
- Expected metrics and outcomes.
- Known limitations and simplifications.
- Suggested extensions and advanced exercises.

Each example must explicitly identify:

- Which properties are modeled by the simulator.
- Which real-world concerns are simplified or excluded.
- Which technology selections are generic metadata versus simulation presets.
- Whether a workload is read-heavy, write-heavy, latency-sensitive, throughput-sensitive, consistency-sensitive, or availability-sensitive.

## 2. Example Difficulty Levels

Organize examples into the following learning levels:

1. **Beginner**
   - Demonstrates fundamental client-to-service-to-database flow.
   - Focuses on common components, basic traffic, latency, capacity, and failures.

2. **Intermediate**
   - Introduces caches, queues, workers, replicas, rate limiting, retries, autoscaling, and observability.

3. **Advanced**
   - Introduces multi-region design, event-driven architecture, replication, data consistency trade-offs, failover, backpressure, high-throughput stream processing, and complex failure scenarios.

4. **Specialized**
   - Covers domains such as payments, real-time communication, media delivery, search, analytics, machine learning, and large-scale notifications.

## 3. Required Example Architectures

Create the following examples at minimum.

### Beginner Examples

#### 3.1 Basic Web Application

Model a standard web application:

```text
Client -> DNS -> Load Balancer -> Application Server -> Relational Database
```

Concepts:

- Request routing.
- Application capacity.
- Database bottlenecks.
- Basic latency analysis.
- Single point of failure identification.
- Simple node-outage simulation.

Suggested technologies:

- DNS: Cloudflare DNS or Amazon Route 53.
- Load Balancer: AWS Application Load Balancer, NGINX, or HAProxy.
- Application Server: Node.js, Spring Boot, Django, or ASP.NET Core.
- Database: PostgreSQL or MySQL.

#### 3.2 URL Shortener

Model a URL-shortening platform:

```text
Client -> CDN / Load Balancer -> Application Service -> Cache -> Key-Value Store
```

Concepts:

- Read-heavy traffic.
- Key generation.
- Cache hit/miss behavior.
- Hot-key risks.
- Database pressure.
- URL redirection latency.

Suggested technologies:

- Cache: Redis.
- Data store: DynamoDB, PostgreSQL, Cassandra, or MongoDB.
- CDN: Cloudflare CDN or Amazon CloudFront.

#### 3.3 Simple File Upload Service

Model file upload and retrieval:

```text
Client -> API Gateway -> Upload Service -> Object Storage
                           -> Metadata Database
```

Concepts:

- Request size.
- Object storage.
- Metadata persistence.
- Upload failure and retry handling.
- Content delivery extension.

Suggested technologies:

- API Gateway: Kong, Amazon API Gateway, or NGINX.
- Object storage: Amazon S3, Cloudflare R2, MinIO, or Google Cloud Storage.
- Metadata database: PostgreSQL or MongoDB.

### Intermediate Examples

#### 3.4 E-Commerce Storefront

Model an e-commerce application:

```text
Client
  -> CDN
  -> API Gateway / Load Balancer
  -> Product Service -> Cache -> Product Database
  -> Cart Service -> Session Store
  -> Order Service -> Relational Database
  -> Message Queue -> Inventory Worker
  -> Notification Worker
```

Concepts:

- Service decomposition.
- Caching.
- Session management.
- Synchronous checkout flow.
- Asynchronous inventory and notification processing.
- Queue lag.
- Database scaling.
- Partial failure handling.

Suggested technologies:

- CDN: Cloudflare CDN or Amazon CloudFront.
- Cache/session store: Redis.
- Queue: RabbitMQ, Amazon SQS, Kafka, or Google Pub/Sub.
- Relational database: PostgreSQL, MySQL, Amazon Aurora, or Cloud SQL.

#### 3.5 Chat Application

Model a real-time messaging system:

```text
Client -> API Gateway -> Chat Service -> Message Store
                                -> Event Stream -> Delivery Workers
                                -> Presence Store
```

Concepts:

- Persistent connections represented conceptually.
- Message persistence.
- Fan-out.
- Delivery queues.
- Online presence.
- Ordering limitations.
- Backpressure.
- Consumer lag.

Suggested technologies:

- Gateway: NGINX, Envoy, or API Gateway.
- Stream: Kafka, Pulsar, NATS JetStream, or Redis Streams.
- Presence store: Redis.
- Message store: Cassandra, ScyllaDB, DynamoDB, MongoDB, or PostgreSQL.

#### 3.6 Notification Delivery Platform

Model asynchronous notification delivery:

```text
Client -> API Gateway -> Notification API -> Message Queue
                                              -> Email Worker -> Email Provider
                                              -> SMS Worker -> SMS Provider
                                              -> Push Worker -> Push Provider
                                              -> Dead-Letter Queue
```

Concepts:

- Queue-based decoupling.
- Consumer throughput.
- Retry policies.
- Dead-letter processing.
- Third-party provider failures.
- Notification status tracking.

Suggested technologies:

- Queue: Amazon SQS, RabbitMQ, Azure Service Bus, Google Pub/Sub, or Kafka.
- Workflow/worker tooling: Celery, Sidekiq, BullMQ, or Temporal.
- Providers: SendGrid, Amazon SES, Twilio, Firebase Cloud Messaging, or Apple Push Notification service.

#### 3.7 Social Media Feed

Model a social-feed system:

```text
Client -> CDN -> Feed API -> Cache
                         -> Feed Store
                         -> Social Graph Store
Post Service -> Event Stream -> Fan-out Workers -> Feed Store
```

Concepts:

- Fan-out on write versus fan-out on read.
- Cache strategy.
- Hot users.
- Event-driven feed generation.
- Storage trade-offs.
- Read/write workload separation.

Suggested technologies:

- Cache: Redis.
- Event stream: Kafka, Pulsar, or Amazon EventBridge.
- Feed store: Cassandra, DynamoDB, ScyllaDB, or Redis.
- Search extension: Elasticsearch or OpenSearch.

#### 3.8 Rate-Limited Public API

Model a public API platform:

```text
Client -> WAF -> API Gateway -> Rate Limiter -> API Service -> Database
```

Concepts:

- Request throttling.
- API keys or token-based authentication.
- Rate-limit algorithms.
- Abuse protection.
- Quota enforcement.
- Retry amplification.
- Service protection.

Suggested technologies:

- WAF: Cloudflare WAF, AWS WAF, Google Cloud Armor, or Azure WAF.
- API Gateway: Kong, Amazon API Gateway, Apigee, or Azure API Management.
- Rate limiter: Redis-based token bucket, Envoy, Kong, or API Gateway quotas.

### Advanced Examples

#### 3.9 Multi-Region E-Commerce Platform

Model an active-passive or active-active multi-region application:

```text
Global DNS / Traffic Manager
  -> Region A: CDN -> Load Balancer -> Application Cluster -> Primary Database
  -> Region B: CDN -> Load Balancer -> Application Cluster -> Replica / Standby Database
Primary Database -> Replication -> Secondary Database
```

Concepts:

- Global traffic routing.
- Regional failover.
- Replication lag.
- Active-active versus active-passive trade-offs.
- Data consistency.
- Recovery objectives.
- Regional outage simulation.

Suggested technologies:

- Global routing: Route 53, Cloudflare Load Balancing, Azure Front Door, or Google Cloud Load Balancing.
- Compute: Kubernetes, ECS, EKS, GKE, AKS, or Cloud Run.
- Database: Aurora Global Database, PostgreSQL with replication, CockroachDB, YugabyteDB, or Cosmos DB.

#### 3.10 Payment Processing Workflow

Model an idempotent payment-processing architecture:

```text
Client -> API Gateway -> Payment Service -> Payment Provider
                              -> Relational Database
                              -> Event Queue -> Ledger Worker
                                             -> Notification Worker
                                             -> Reconciliation Worker
                              -> Dead-Letter Queue
```

Concepts:

- Idempotency keys.
- Transaction boundaries.
- External payment-provider failure.
- At-least-once message delivery.
- Duplicate event handling.
- Ledger consistency.
- Reconciliation.
- Audit logging.

Suggested technologies:

- API Gateway: Kong, AWS API Gateway, or Apigee.
- Queue: Kafka, RabbitMQ, Amazon SQS, or Azure Service Bus.
- Database: PostgreSQL, MySQL, SQL Server, or Aurora.
- Workflow: Temporal or a queue-backed worker model.

#### 3.11 Video Streaming Platform

Model video ingestion and content delivery:

```text
Creator Client -> Upload API -> Object Storage -> Processing Queue -> Transcoding Workers
Viewer Client -> DNS -> CDN -> Object Storage / Media Origin
Metadata Service -> Database -> Search Index
```

Concepts:

- Large uploads.
- Asynchronous media processing.
- Worker autoscaling.
- Object storage.
- CDN caching.
- High-bandwidth read traffic.
- Queue backlog under upload spikes.

Suggested technologies:

- Storage: Amazon S3, Cloudflare R2, Google Cloud Storage, Azure Blob Storage, or MinIO.
- CDN: CloudFront, Cloudflare CDN, Fastly, or Akamai.
- Queue: SQS, Kafka, RabbitMQ, or Google Pub/Sub.
- Transcoding: FFmpeg represented as a worker workload.
- Search: OpenSearch, Elasticsearch, Meilisearch, or Algolia.

#### 3.12 Ride-Sharing Dispatch Service

Model a low-latency dispatch system:

```text
Rider Client -> API Gateway -> Trip Service -> Location Store
Driver Client -> Realtime Gateway -> Location Ingestion -> Event Stream
Dispatch Engine -> Cache / Geo Index -> Driver Matching
Trip Service -> Message Queue -> Notification Worker
```

Concepts:

- Real-time updates.
- Geospatial lookup.
- Event streams.
- Low-latency matching.
- Hot geographic regions.
- Backpressure during demand surges.
- Consistency versus availability trade-offs.

Suggested technologies:

- Realtime gateway: WebSocket-capable gateway represented conceptually.
- Event stream: Kafka, Pulsar, NATS, or Google Pub/Sub.
- Cache/geospatial store: Redis.
- Data store: PostgreSQL with PostGIS, DynamoDB, Cassandra, or MongoDB.
- Notification service: Firebase Cloud Messaging, APNs, or Twilio.

#### 3.13 Search and Recommendation Platform

Model a search-driven application:

```text
Client -> CDN -> Search API -> Cache -> Search Index
Content Service -> Database -> Change Data Capture -> Indexing Pipeline -> Search Index
Analytics Events -> Event Stream -> Recommendation Pipeline -> Feature Store
```

Concepts:

- Search indexing.
- Change data capture.
- Eventual consistency.
- Cache invalidation.
- Indexing backlogs.
- Read-heavy traffic.
- Recommendation data pipelines.

Suggested technologies:

- Search: Elasticsearch, OpenSearch, Solr, Meilisearch, Typesense, or Algolia.
- CDC: Debezium, AWS DMS, Airbyte, or Fivetran.
- Stream: Kafka, Pulsar, or Event Hubs.
- Feature store: Feast, Redis, or a generic feature-store component.

### Specialized Examples

#### 3.14 Analytics and Event Ingestion Pipeline

Model high-volume analytics ingestion:

```text
Client / SDK -> Event Collector -> Event Stream -> Stream Processor
                                             -> Data Lake
                                             -> Data Warehouse
                                             -> Real-Time Analytics Store
```

Concepts:

- High-throughput ingestion.
- Partitioning.
- Consumer lag.
- Batch versus streaming.
- Event retention.
- Schema evolution.
- Warehouse loading.
- Cost trade-offs.

Suggested technologies:

- Event stream: Kafka, Redpanda, Pulsar, Kinesis, or Event Hubs.
- Stream processing: Flink, Spark Structured Streaming, Kafka Streams, or Beam.
- Data lake: S3, Google Cloud Storage, Azure Data Lake Storage, or MinIO.
- Warehouse: BigQuery, Snowflake, Redshift, ClickHouse, or Synapse Analytics.

#### 3.15 Machine Learning Inference Platform

Model asynchronous and synchronous machine-learning inference:

```text
Client -> API Gateway -> Inference API -> Model Serving Endpoint
                                   -> Feature Store
                                   -> Prediction Cache
Batch Input -> Inference Queue -> Batch Inference Workers -> Object Storage
```

Concepts:

- Synchronous versus asynchronous inference.
- Model-serving capacity.
- GPU/CPU resource abstraction.
- Feature retrieval latency.
- Batch queueing.
- Prediction caching.
- Model rollout and fallback.

Suggested technologies:

- Model serving: KServe, Seldon, TorchServe, TensorFlow Serving, NVIDIA Triton, or SageMaker endpoints.
- Feature store: Feast, Redis, or generic feature-store abstraction.
- Queue: Kafka, SQS, RabbitMQ, or Pub/Sub.
- Object storage: S3, GCS, Azure Blob Storage, or MinIO.

#### 3.16 Multi-Tenant SaaS Platform

Model a SaaS platform with tenant isolation:

```text
Client -> CDN -> API Gateway -> Authentication Service -> Tenant-Aware Application Service
                                                              -> Tenant Database / Shared Database
                                                              -> Cache
                                                              -> Audit Log
                                                              -> Queue -> Background Workers
```

Concepts:

- Tenant identification.
- Isolation strategies.
- Per-tenant quotas.
- Rate limiting.
- Shared versus dedicated resources.
- Audit logging.
- Noisy-neighbor risks.
- Tenant-aware scaling.

Suggested technologies:

- Identity: Auth0, Okta, Keycloak, Cognito, Entra ID, or Clerk.
- Database: PostgreSQL, Aurora, CockroachDB, DynamoDB, or Cosmos DB.
- Cache: Redis.
- Audit log: Kafka, OpenSearch, PostgreSQL, or object storage.

## 4. Template Project Requirements

For each example, create a template project with:

- Stable template ID and semantic version.
- Difficulty level.
- Tags and learning objectives.
- Default node positions and readable edge layout.
- Default traffic profile.
- Default fault scenario.
- Default technology assignments.
- Known simulation limitations.
- Expected findings.
- Suggested learner challenges.
- Template metadata suitable for future filtering and search.

Suggested template metadata:

```ts
interface ScenarioTemplateMetadata {
  id: string;
  version: string;
  name: string;
  summary: string;
  difficulty: "beginner" | "intermediate" | "advanced" | "specialized";
  tags: string[];
  learningObjectives: string[];
  estimatedCompletionMinutes: number;
  recommendedPrerequisites: string[];
  supportedComponentTypes: ComponentType[];
  defaultTrafficProfileId: string;
  defaultFaultScenarioIds: string[];
  documentationPath: string;
}
```

## 5. Per-Scenario Documentation Structure

Create one Markdown document per scenario using this structure:

```text
# Scenario Name

## Overview
## Learning Objectives
## Architecture Summary
## Functional Requirements
## Non-Functional Requirements
## Components and Responsibilities
## Request and Event Flows
## Data Model and Storage Assumptions
## Technology Suggestions
## Traffic Profile
## Capacity and Scaling Assumptions
## Caching Strategy
## Reliability and Failure Handling
## Security Considerations
## Observability Plan
## Simulation Exercises
## Expected Results
## Common Failure Modes
## Trade-Offs
## Simulator Limitations
## Extension Exercises
```

Documentation must link to the relevant project template and clearly state that technology selections are examples, not deployment instructions.

## 6. Simulator User Documentation

Create complete end-user documentation explaining how to use the System Design Simulator.

### Required Documentation Sections

#### 6.1 Getting Started

Explain:

- Application purpose and simulation limitations.
- Creating a project.
- Opening an existing project.
- Starting from a template.
- Understanding the canvas.
- Saving, exporting, and importing projects.
- Generic components versus selected technology implementations.

#### 6.2 Building an Architecture

Explain:

- Adding components from the component palette.
- Connecting components with valid edge types.
- Understanding synchronous request, asynchronous event, replication, failover, and observability edges.
- Configuring nodes through the configuration modal.
- Selecting implementation technologies.
- Applying and reviewing technology presets.
- Using generic/custom component configurations.
- Duplicating and deleting nodes safely.
- Validating an architecture before simulation.

#### 6.3 Configuring Simulation Behavior

Explain:

- Traffic profiles.
- Capacity and concurrency.
- Latency, jitter, timeouts, and retries.
- Cache hit/miss behavior and TTL.
- Database replication and replica lag.
- Queue throughput, retention, consumer lag, and dead-letter queues.
- Load-balancing strategies.
- Health checks, circuit breakers, failover, and autoscaling.
- Fault scenarios and fault scheduling.

#### 6.4 Triggering Manual Requests

Explain:

- The request composer.
- HTTP-like request methods.
- Read/write classification.
- Request count and dispatch rate.
- Logical payload sizes.
- Request origin selection.
- Deterministic seed selection.
- How manual requests differ from real HTTP requests.
- How manual request batches appear in metrics and visual playback.

#### 6.5 Running and Viewing Simulations

Explain:

- Starting, pausing, resuming, resetting, cancelling, and rerunning simulations.
- Logical simulation execution versus visual playback.
- Playback speed controls.
- Request-flow animation.
- Reduced-motion and animation-disable settings.
- How to interpret node and edge runtime states.

#### 6.6 Understanding Results

Explain:

- Metrics modal.
- Requests per second.
- Success, failure, retry, and timeout counts.
- Latency percentiles.
- Utilization.
- Queue depth and consumer lag.
- Cache hit ratio.
- Database pressure and replication lag.
- Observed availability.
- Educational cost estimates.
- Finding toast notifications.
- Architecture warnings versus observed results versus recommendations.
- Stale-result status.

#### 6.7 Fault Injection and Troubleshooting

Explain:

- Creating outages, latency faults, error-rate faults, capacity reductions, network failures, cache failures, queue-consumer failures, traffic spikes, database failures, and regional outages.
- Reading fault timelines.
- Identifying bottlenecks.
- Understanding retry amplification and cascading failure.
- Using findings to improve an architecture.

#### 6.8 Accessibility and Keyboard Controls

Explain:

- Keyboard navigation.
- Canvas keyboard controls.
- Context-menu keyboard access.
- Focus management in modals.
- Reduced-motion preferences.
- Non-color state indicators.

#### 6.9 Data, Privacy, and Security

Explain:

- Local project storage.
- Offline-first behavior.
- No cloud credentials or real deployments.
- Imported-project validation.
- Technology logos and license notices.
- Privacy and telemetry policy.

## 7. Documentation Quality Requirements

- Use concise but technically accurate language.
- Clearly distinguish simulated behavior from real infrastructure behavior.
- State assumptions and limitations in every scenario.
- Use consistent terminology with `PRD.md`, `TRD.md`, `SIMULATION_SPEC.md`, `COMPONENT_CATALOG.md`, and `ACCEPTANCE_CRITERIA.md`.
- Use relative links between scenario documents, templates, and user guides.
- Keep scenario documentation versioned with the template it describes.
- Add screenshots, annotated diagrams, or canvas exports only after corresponding templates are available.
- Ensure all user documentation is accessible, searchable, and structured with clear headings.
- Do not include cloud credentials, provider-specific provisioning instructions, or any requirement for online connectivity.

## 8. Implementation and Validation Requirements

- Store scenario templates and documentation in version-controlled directories.
- Validate template project data against the same project schema used by the application.
- Add automated tests that load every scenario template successfully.
- Add tests ensuring every template references existing documentation.
- Add tests ensuring every documentation file references a valid template identifier and version.
- Add tests ensuring default traffic profiles, faults, and component types are valid.
- Add a documentation index grouped by difficulty level, domain, and learning objective.
- Ensure templates remain backward compatible through project-schema migrations.
- Add release validation requiring all templates and documentation links to be checked before distribution.

Prioritize scenarios that teach meaningful architectural trade-offs and demonstrate observable simulator behavior. Begin with a smaller, high-quality starter set if necessary, then expand the library incrementally while maintaining schema validity, documentation accuracy, and deterministic simulation compatibility.
```
