# UX / UI Review Report — Ultimate System Design Simulator

**Review type:** Evidence-based UX/UI and educational-product review
**Build reviewed:** dev server at `http://localhost:5173/` (Vite 5.4 / React 18.3 / Electron 33.2)
**Test baseline at time of review:** 27 files / 225 tests passing (~51 s)
**Mode:** Read-only. No application code was modified.

Every finding below is backed by either (a) a source location, (b) a live DOM/geometry
measurement, or (c) a reproducible interaction trace. Where I could not verify something,
it is listed explicitly under *Cannot verify* rather than asserted.

> **Remediation update (2026-09-29):** This report remains a historical evidence record.
> The base inspector fields now validate candidate values through
> `baseComponentConfigSchema` before changing project state. Invalid or empty required
> values remain in the editor, receive inline `aria-invalid` errors, and cannot be
> autosaved as configuration. This addresses the reproduced zero-instance and error-rate
> failures in C-9 for shared settings; specialized expansion fields remain a follow-up.
> The metrics modal now renders bounded latency, throughput, and conditional error-rate
> time-series charts with a read-only playback-time marker, peak-sorted component rows,
> utilization bars, and canvas selection. The tutorial, keyboard-connection, undo,
> toast-layering and high-contrast work documented below remain open. H-9 and H-10 are now remediated:
> playback uses a native, keyboard-operable range input that pauses at the selected recorded
> telemetry instant and clamps seeking to the finished run's logical bounds; the node context
> menu follows the expected keyboard and focus-restoration contract.

---

## 1. Executive summary

The simulator has a genuinely strong **engine and domain layer**. The deterministic
recommendation ranking, the scenario starting-state model, the request-exercise presets,
and the validation/findings plumbing are well-factored and, in several cases, exactly
match the written specification.

The weakness is concentrated in one place: **the tutorial framework does not teach.**

The product ships three learning modes — Guided Tour, Build, Challenge — and correctly
varies the *starting canvas* for each. But it renders **the same six steps** regardless of
mode, and those steps validate **UI actions, not understanding**. The result is a mode
system that looks pedagogically serious from the scenario picker and collapses the moment
a learner enters it.

The single most damaging observation in this review: in **Challenge mode**, which
deliberately starts with a blank canvas, step 2 of the tutorial instructs the learner to

> "On the canvas, follow Browser Client to DNS, Load Balancer, Application Server, and
> Primary Database."

…on an empty canvas, and the only way to advance is to tick a checkbox that says
**"I traced the request path."** The learner must assert something false to proceed.

Severity distribution:

| Severity | Count |
|---|---|
| 🔴 Critical | 7 |
| 🟠 High | 6 |
| 🟡 Medium | 5 |
| 🟢 Verified strengths | 5 |

---

## 2. Findings classification

Per the requested taxonomy.

| ID | Finding | Classification |
|---|---|---|
| C-1 | Tutorial steps do not branch by mode | Documented-but-missing |
| C-2 | Challenge-mode steps reference non-existent nodes | Implemented-but-broken |
| C-3 | "Show reference" leaks the answer in Build/Challenge | Doc–UI contradiction |
| C-4 | No estimation steps exist | Documented-but-missing |
| C-5 | No diagnosis challenges exist | Documented-but-missing |
| C-6 | Validation checks UI actions, not architecture | Partially-implemented |
| C-7 | Beginner tutorial auto-arms a fault, contaminating the baseline | Implemented-but-confusing |
| H-1 | `.modal input { width: 100% }` stretches radios/checkboxes | Implemented-but-broken |
| H-2 | Tutorial panel occludes the canvas it describes | Implemented-but-confusing |
| H-3 | "Next" button label clipped to "Nex" | Implemented-but-broken |
| H-4 | Toolbar wraps to ~3 rows at every tested width | Implemented-but-confusing |
| H-5 | 15 of 16 scenarios receive generic boilerplate tutorials | Partially-implemented |
| H-6 | Hints are a single generic string, no escalation | Partially-implemented |
| M-1..M-5 | See §6 | Various |

---

## 3. Critical findings

### C-1 — Tutorial steps are identical across all three learning modes
**Classification:** Documented-but-missing · **Confidence:** 10/10

`src/domain/tutorials/registry.ts` builds every step through two helpers, both of which
hardcode the full mode list:

- `automaticStep()` — `modes: ["guided-tour", "build", "challenge"]` (~L36)
- `manualStep()` — `modes: ["guided-tour", "build", "challenge"]` (~L57)

There is no branching on `TutorialMode` anywhere in the step content. The `modes` field
exists in the schema and is therefore *structurally* honoured, but since every step
declares all three values, it is a no-op.

This is notable because the **starting state layer does this correctly**. See
`getScenarioStartingState()` in `src/domain/scenarios/builder.ts:77`, which properly
returns `complete` for guided-tour, `origin-only`/`partial` for build, and `empty` for
challenge — matching the spec's mode table.

**So the canvas changes per mode, but the instructions do not.** That mismatch is the
root cause of C-2.

---

### C-2 — Challenge mode instructs the learner to trace components that do not exist
**Classification:** Implemented-but-broken · **Confidence:** 10/10

Reproduction (performed live):

1. Templates → *Basic Web Application*
2. Learning mode → **Challenge — start with an empty canvas**
3. Start tutorial

Observed, verbatim from the live DOM:

- **Step 1 of 6 — "Open the architecture"**, immediately marked
  *"Step requirement complete."* — on an empty canvas.
- **Step 2 of 6 — "Trace the request path"**: *"On the canvas, follow Browser Client to
  DNS, Load Balancer, Application Server, and Primary Database. Notice that every request
  follows this synchronous path."*

The canvas contains **zero nodes**. The advance control is a checkbox labelled
**"I traced the request path"**, and `Next` is `[disabled]` until it is ticked.

The learner's only path forward is to certify a falsehood. This is worse than an absent
tutorial: it actively trains learners to click through attestations without reading them,
which is precisely the habit an educational tool should suppress.

Simultaneously the status bar shows *"Start an architecture — Choose a template, or add a
Client and connect it to a component from the palette,"* directly contradicting the
tutorial's "Open the architecture."

---

### C-3 — "Show reference" hands over the answer in Challenge mode, on step 2, with no gate
**Classification:** Doc–UI contradiction · **Confidence:** 10/10

The footer of every tutorial step — in **all modes** — renders a `Show reference` button.
In Challenge mode at step 2, clicking it produced this confirm:

> "Show the reference solution? This replaces the current canvas. Your current project
> changes will be lost unless you save or export first."

Accepting it **populated the full five-node reference architecture** (Browser Client → DNS
→ Load Balancer → Application Server → Primary Database) and a **"Draft saved"** badge
appeared in the toolbar — i.e. the reference overwrote the learner's challenge attempt and
was persisted.

Three separate problems:

1. **Spec violation.** Challenge mode is defined as assessment by "graph validity and
   measured outcomes, not similarity to the reference." A one-click reference reveal makes
   the mode decorative.
2. **No escalation gate.** The spec requires hints to escalate (evidence → subsystem →
   answer) after `hintRevealAfterAttempts`, with an explicit, deliberate "show me the
   answer" affordance. Here the answer is a peer button to `Back` and `Restart`, available
   before any attempt.
3. **Silent mode collapse.** After the reference loaded, the context panel reverted from
   **"Build brief / Constraints / Out of scope"** to **"Learning objectives / Model
   limits"** — the guided-tour framing — with no notice that the learner had left
   Challenge mode.

---

### C-4 — The mandatory estimation phase does not exist
**Classification:** Documented-but-missing · **Confidence:** 10/10

The specification states the estimation phase *"is mandatory and must not be reducible to
clicking through,"* describes acceptance within a `tolerancePercent` band rather than an
exact value, and requires accepted estimates to propagate into configuration via
`feedsIntoConfigurationField`.

A repo-wide search for `estimation|tolerancePercent|feedsIntoConfigurationField` returns
**zero matches**. Neither the schema nor the registry can represent an estimation step.

Capacity estimation is the core transferable skill in system-design interviews and
practice. Its complete absence is the largest pedagogical gap in the product.

---

### C-5 — No diagnosis challenges exist
**Classification:** Documented-but-missing · **Confidence:** 10/10

A repo-wide search for `diagnosis|progressiveHints` returns **zero matches**.

The spec requires the learner to *diagnose* a problem before remediating it. Currently a
learner is told what to change and then changes it. The reasoning step — read the metrics,
form a hypothesis, identify the saturating component, *then* act — is never exercised,
even though the engine already produces exactly the time-series data such a step would
need.

---

### C-6 — Step validation tests UI actions, not architectural understanding
**Classification:** Partially-implemented · **Confidence:** 9/10

`src/domain/tutorials/schema.ts` defines `tutorialPredicateSchema` with exactly three
predicates:

```
"scenario-loaded" | "simulation-complete" | "metrics-open"
```

All three are UI-state assertions. None inspects the graph, the configuration, or the
measured outcome.

The spec requires validation to *"confirm that the user's design satisfies architectural
properties and measurable outcomes"* and requires that **at least two structurally
distinct valid solutions** pass. Neither is achievable with the current predicate
vocabulary — not as a matter of authoring effort, but because **the framework cannot
express it.** Any fix here is a schema change, not a content change.

Everything not covered by those three predicates falls back to a self-attestation
checkbox (see C-2).

---

### C-7 — The beginner tutorial auto-arms a fault, contaminating the first baseline run
**Classification:** Implemented-but-confusing · **Confidence:** 9/10

`src/domain/scenarios/templates/beginner.ts:34` sets:

```ts
defaultFaultScenarioIds: ["app-server-outage"]
```

This is auto-armed on scenario open. The toolbar was observed showing
**"Application server outage" checked** and **"1 armed"** before the learner ran anything.

The scenario's own learning objectives include both:

- *"Read utilisation to find which component saturates first"* — requires a **clean** baseline
- *"Observe what a node outage does to success rate and latency"* — requires a **comparison**

Arming the outage before the first run destroys the clean baseline, so the
baseline → inject-fault → compare loop that objective 4 depends on cannot be performed in
the intended order. The learner's first measurement is of a degraded system they have no
reason to know is degraded.

---

## 4. High-severity UI defects

### H-1 — A global modal rule stretches every radio and checkbox
**Classification:** Implemented-but-broken · **Confidence:** 10/10

`src/app/styles/global.css:1029`:

```css
.modal input,
.modal select,
.modal textarea {
  width: 100%;
}
```

This matches `input[type=radio]` and `input[type=checkbox]` too. Measured live via
`getBoundingClientRect()`:

| Control | Location | Expected | **Measured** |
|---|---|---|---|
| Learning-mode radio | Scenario library | ~13 px | **517 px** |
| "Dispatch only these batches" | Request composer | ~13 px | **165 px** |

Consequences:

- The radio control is visually stranded at the far left of the row while its label text
  sits at the far right, so the two do not read as a pair. This is clearly visible in the
  scenario library's "Learning mode" group.
- The clickable hit area spans the full row width, so clicks in apparently empty space
  silently change the learning mode.
- `.scenario-mode-picker label` already sets `display:flex; gap:7px` intending tight
  pairing; the global rule overrides that intent.

Affected modals include at minimum the scenario library and the request composer.
Markup/labelling is otherwise correct — labels wrap their inputs, so accessible names are
intact. This is purely a CSS specificity problem with a narrow fix
(`.modal input:not([type=checkbox]):not([type=radio])`).

---

### H-2 — The tutorial panel covers the architecture it is describing
**Classification:** Implemented-but-confusing · **Confidence:** 9/10

The tutorial renders inside the React Flow `application` element as a `dialog`, anchored
top-left over the canvas. With the reference solution loaded, the panel covered
**3 of the 5 nodes** while step 1 said *"Open the architecture"* and step 2 said *"On the
canvas, follow Browser Client to DNS…"*.

The instruction and its subject cannot be viewed at the same time. Panel width is
`min(380px, calc(100vw - 360px))` (`global.css:1725`), so on narrower windows the panel
consumes proportionally more of the canvas.

---

### H-3 — The primary "Next" action is clipped to "Nex"
**Classification:** Implemented-but-broken · **Confidence:** 9/10

The tutorial footer packs six controls — `Back`, `Restart`, `Show hint`,
`Show reference`, `Exit`, `Next` — into a fixed-width panel. The primary forward action
renders truncated as **"Nex"** at the panel edge.

Two compounding issues: the most important control in the component is the one being
clipped, and it is given no visual primacy over five secondary/destructive actions.

---

### H-4 — The toolbar wraps to roughly three rows at every tested width
**Classification:** Implemented-but-confusing · **Confidence:** 9/10

Measured toolbar heights:

| Viewport width | Toolbar height |
|---|---|
| 1280 px | 129 px |
| 1024 px | 136 px |
| 900 px | 136 px |

A single-row toolbar at this font size is ~44 px, so this is ~3 rows of controls
permanently consuming vertical space above the canvas. The toolbar now mixes application
commands (New/Open/Save/Export), learning commands (Tutorial/Help), run controls
(Run/Send requests/View Metrics/Findings), and simulation *parameters* (Traffic, Faults,
Seed, Duration) in one undifferentiated strip. The fault checkboxes in particular are
simulation inputs, not toolbar commands, and are the main driver of the extra rows.

---

### H-5 — 15 of 16 scenarios receive generic, auto-generated tutorials
**Classification:** Partially-implemented · **Confidence:** 9/10

`registry.ts` hand-authors exactly one tutorial — `basicWebApplicationTutorial`
(~L64–115). The remaining scenarios are produced by `buildOverviewTutorial()` (~L117–180),
which emits the same structural boilerplate with names substituted.

The advertised scenario depth (URL shortener, rate-limited API, multi-region e-commerce,
video streaming, payment workflow — each with distinct, interesting failure modes) is not
reflected in the guidance. A learner selecting "Multi-Region E-Commerce · Advanced ·
60 min" receives essentially the same six steps as the beginner scenario.

---

### H-6 — Hints are a single generic string with no escalation
**Classification:** Partially-implemented · **Confidence:** 9/10

Both step helpers in `registry.ts` attach one fixed hint string. The spec requires a
three-tier escalation — point at the evidence, then narrow to the subsystem, then reveal
the answer — gated on `hintRevealAfterAttempts`.

Because there is no attempt counter and no tiering, `Show hint` and `Show reference`
collapse into roughly the same affordance: ask once, receive everything.

---

## 5. Verified strengths

These were tested and genuinely work. They should be protected during any remediation.

### S-1 — Recommendation ranking is deterministic and spec-compliant ✅
`src/domain/recommendations/engine.ts:240-243`:

```ts
scored.sort((left, right) => {
  if (right.matchScore !== left.matchScore) return right.matchScore - left.matchScore;
  return left.displayName.localeCompare(right.displayName);
});
```

Score descending with a stable alphabetical tie-break — no randomised ordering, and rank
is assigned after sorting. This satisfies the determinism requirement exactly.

### S-2 — `RecommendationPanel` is a model of honest educational UI ✅
`src/features/inspector/RecommendationPanel.tsx` gets several hard things right:

- Explicit framing: *"Educational guidance ranked from the catalog above, not a vendor
  endorsement or procurement advice. Nothing is applied until you choose it explicitly."*
- Presents `rationale`, `strengths`, **`tradeOffs`**, `warnings`, and `typicalUseCases` —
  trade-offs sit directly alongside strengths.
- **No auto-apply.** Selection only pre-fills the manual picker via the same `onSelect`
  path a dropdown click would use.
- Provides an explicit opt-out: *"None of these — keep Generic / Custom Implementation."*

*Minor:* both strengths and trade-offs are hidden behind a collapsed toggle, while the
persuasive surface (rank, "% match", rationale) is always visible. Consider surfacing one
representative trade-off on the collapsed card so the cost is as visible as the pitch.

### S-3 — Scenario starting states correctly implement the mode model ✅
`getScenarioStartingState()` (`builder.ts:77`) returns the right `kind` per mode, carries
`omittedComponentTypes` / `omittedCapabilities`, and — importantly — each branch includes a
`rationale` string explaining *why*. The guided-tour branch even warns in a comment that
the reference topology must never be treated as the only correct solution. This is the
quality bar the tutorial content layer should be held to.

### S-4 — Modal focus restoration is correct ✅
Verified in the request composer: `Escape` closed the dialog and returned focus to the
**"Send requests"** trigger button (`document.activeElement` → `BUTTON/Send requests`).
`Tab` from modal open landed on the first interactive control inside the dialog. This is
frequently done wrong and is done right here.

### S-5 — Request-exercise presets are a strong teaching surface ✅
The request composer ships seven deterministic presets — Baseline request flow, Read path,
Write path, Burst load, Sustained load, **Capacity boundary**, **Capacity overload** — with
the reassurance that *"Presets never modify the scenario project"* and a live summary
(*"This will dispatch 100 GET requests over 2.00 simulated seconds"*). Capacity boundary
vs. capacity overload is exactly the right pedagogical pairing. **This surface is currently
unused by the tutorial framework** — it is the most obvious foundation for the missing
estimation and diagnosis steps (C-4, C-5).

---

## 6. Medium findings

| ID | Finding | Evidence |
|---|---|---|
| M-1 | `allowSkip: true` on every step, so the entire tutorial is click-through-able with no completion signal distinguishing "learned" from "skipped". | `registry.ts` step helpers |
| M-2 | Step 1 auto-completes on load in every mode, teaching the learner that steps clear themselves without action. | Live: "Step requirement complete." on empty canvas |
| M-3 | The "Tutorial" toolbar button is disabled until a scenario loads, with no tooltip explaining why — the primary learning entry point appears broken at first launch. | Live: `[disabled]` at cold start |
| M-4 | `matchScore` renders as "87% match", implying a precision the heuristic scoring does not have. A coarse band (Strong / Good / Possible) would be more honest. | `RecommendationPanel.tsx` |
| M-5 | `global.css` (~1240 lines, single stylesheet) defines only ~13 colour tokens and a focus ring — no spacing, radius, type, elevation, z-index, or motion scale. H-1/H-2/H-3 are all downstream symptoms of ad-hoc, untokenised layout values. | `global.css:1-16` |

---

## 7. Answers to the first-time-learner questions

Can a first-time user, unaided:

| # | Question | Verdict |
|---|---|---|
| 1 | Read the requirements? | ⚠️ Partially — the Build brief / Constraints / Out-of-scope panel is good, but it silently reverts to guided-tour framing (C-3) |
| 2 | Estimate the workload? | ❌ **No** — no estimation step exists (C-4) |
| 3 | Understand which components are available and why? | ⚠️ Partially — the palette is well grouped; the rationale lives only in recommendations, which require a node to already exist |
| 4 | Build a valid architecture from scratch? | ⚠️ Partially — possible, but the tutorial gives no build guidance in Build/Challenge (C-1) |
| 5 | Know whether their design is correct? | ❌ **No** — validation checks UI actions, not architecture (C-6) |
| 6 | Diagnose a failure? | ❌ **No** — no diagnosis challenges (C-5) |
| 7 | Compare a baseline against a fault? | ❌ **No** — the fault is pre-armed, so there is no clean baseline (C-7) |
| 8 | Understand *why* a component saturated? | ⚠️ Partially — metrics exist; no step asks the learner to interpret them |
| 9 | Explore alternative valid designs? | ❌ **No** — "≥2 structurally distinct valid solutions" is unrepresentable (C-6) |
| 10 | Receive escalating help? | ❌ **No** — one generic hint, answer always available (H-6, C-3) |
| 11 | Complete without seeing the reference solution? | ❌ **No** — in Challenge mode, step 2 cannot be honestly satisfied without it (C-2) |
| 12 | Trust that progress isn't corrupting their project? | ⚠️ Partially — step 1 states progress is device-local and unsaved, which is correct and good; but "Show reference" overwrote the canvas and auto-saved a draft (C-3) |

**Two ✅ out of twelve.** The tooling is present; the pedagogy is not wired to it.

---

## 8. Recommendations, in priority order

### Priority 1 — Make the tutorial framework capable (unblocks everything else)

These are **schema** changes. No amount of content authoring fixes C-4/C-5/C-6 without them.

1. **Extend `tutorialPredicateSchema` beyond UI state.** Add graph-shape predicates
   (`path-exists`, `no-single-point-of-failure`, `component-type-present`), configuration
   predicates, and measured-outcome predicates (`p99-below`, `success-rate-above`,
   `no-component-above-utilisation`). Outcome predicates are what allow two structurally
   different designs to both pass — satisfying the spec without structural equality.
2. **Add an `estimation` step type** with `tolerancePercent`, and
   `feedsIntoConfigurationField` so an accepted estimate flows into the node config the
   learner will then simulate.
3. **Add a `diagnosis` step type** that presents a degraded run and asks *which component
   saturated first and why* before permitting remediation. The engine's existing
   `componentMetrics` time series already supplies the evidence.
4. **Replace the single `hint` string with a tiered array** plus `hintRevealAfterAttempts`,
   and make reveal-the-answer the terminal tier rather than a peer button.

### Priority 2 — Fix the mode contract

5. **Author per-mode step content.** At minimum, stop emitting `modes:
   ["guided-tour","build","challenge"]` unconditionally; make `automaticStep()` /
   `manualStep()` take an explicit mode list, then split observe-style steps
   (guided-tour) from construct-style steps (build/challenge).
6. **Gate `Show reference`.** Hide it in Challenge mode until N failed validation attempts;
   when revealed, show it **side-by-side or as an overlay** rather than destroying the
   learner's canvas, and never auto-save over their attempt.
7. **Disarm default faults for the first run.** Either drop
   `defaultFaultScenarioIds` from `beginner.ts`, or have the tutorial explicitly sequence
   it: run clean → arm the outage → re-run → compare. The comparison *is* the lesson.
8. **Remove blanket `allowSkip: true`**, or distinguish "skipped" from "completed" in the
   progress model so completion means something.

### Priority 3 — UI defects

9. **Scope the modal input rule** — `.modal input:not([type=checkbox]):not([type=radio])`.
   One-line fix, removes two visible defects.
10. **Reposition the tutorial panel** so it never overlaps the canvas — dock it into the
    right-hand context panel as a tab, or as a bottom sheet. It should never occlude its
    own subject.
11. **Fix the clipped "Next"** and re-rank the footer: `Next` primary and right-aligned;
    `Back`/`Restart`/`Exit` demoted into an overflow menu; `Show hint` secondary.
12. **Split the toolbar.** Move Traffic / Faults / Seed / Duration out of the command strip
    into a "Run configuration" popover next to `Run`. They are simulation inputs, not
    application commands, and they are what forces three rows.

### Priority 4 — Foundations

13. **Introduce design tokens** for spacing, radius, type scale, elevation, z-index, and
    motion. The overlap, clipping, and wrapping defects above all trace back to ad-hoc
    values in a single 1240-line stylesheet.
14. **Author scenario-specific tutorials** for the advanced scenarios, replacing
    `buildOverviewTutorial()` boilerplate — prioritising the ones whose failure modes are
    most distinctive (rate-limited API, multi-region, payment workflow).
15. **Use the untouched charting dependency.** `recharts@^2.13.3` is in `dependencies` with
    **zero imports repo-wide**, while the engine records full `systemMetrics` /
    `componentMetrics` time series that the UI currently collapses to single peak values.
    Plotting utilisation over time is the most direct way to make saturation legible — and
    it is a prerequisite for credible diagnosis steps (C-5).

---

## 9. Cannot verify (Round 1)

Listed explicitly rather than assumed. **Several of these were resolved in Round 2 — see
the status column.**

| Item | Round 2 status |
|---|---|
| Canvas keyboard operation | ✅ **Resolved** — see C-8 (connections are impossible by keyboard) |
| Light theme / high-contrast | ✅ **Resolved** — see M-7 (no support for any of them) |
| React Flow `nodeTypes` warning | ⚠️ Still unconfirmed — a console listener attached post-load captured no messages; may be an HMR artifact |
| Performance at scale (100/250 nodes, 500 edges, 100k requests) | ❌ Still untested — no fixture of that size exists in the repo |
| Screen-reader narration quality | ⚠️ Partially — the accessibility tree is well-formed (named `dialog`, `progressbar`, `tablist`/`tab`, labelled edge groups) and politeness levels are correct (S-9), but actual SR output was not captured |
| Toast politeness under rapid successive runs | ⚠️ Partially — mapping verified correct (S-9); rapid-fire behaviour not stress-tested |

---

## 10. Closing note — Round 1

The gap here is not competence — the domain layer is, in places, better than the spec
required. It is that the **learning layer was built as a UI walkthrough and then asked to
carry an educational contract it was never structured to hold.** Three of its six steps are
attestation checkboxes; its validation vocabulary contains three UI-state predicates; its
reference answer is one click from step 1.

Fixing content will not close that gap. Extending the predicate schema (Priority 1) is the
change that makes every subsequent improvement possible — and the engine already produces
all the data those predicates would need.

---

## 11. Round 2 — additional gaps (data integrity, accessibility, analysis)

The first pass concentrated on the tutorial/learning layer. This second pass probed
surfaces previously listed as *cannot verify*: canvas keyboard operation, inspector
validation, undo semantics, playback analysis, and notification behaviour.

**These findings are arguably more serious than Round 1**, because Round 1 described a
learning layer that fails to teach, whereas several findings below describe the tool
**silently accepting invalid input and then actively misdiagnosing the result.**

### Round 2 severity summary

| ID | Finding | Classification |
|---|---|---|
| C-8 | Keyboard users can add nodes but can never connect them | Documented-but-missing |
| C-9 | Inspector performs no validation; invalid values persist silently | Implemented-but-broken |
| C-10 | The diagnostic engine blamed the wrong cause and steered the learner away from the real one | Implemented-but-confusing |
| C-11 | Undo is non-linear — it silently reverts a different action than the user's last one | Implemented-but-broken |
| H-7 | Canvas node badges contradict the run summary | Implemented-but-confusing |
| H-8 | Toasts never auto-dismiss and occlude 33% of the context panel | Implemented-but-confusing |
| H-9 | Playback cannot be paused, scrubbed, or stepped | Documented-but-missing |
| H-10 | Context menu violates the ARIA menu pattern and destroys focus | Implemented-but-broken |
| M-6 | Units are missing or ambiguous on several numeric fields | Implemented-but-confusing |
| M-7 | No high-contrast / forced-colors / light-scheme support | Documented-but-missing |
| M-8 | Recovery banner persists indefinitely and shifts the whole layout | Implemented-but-confusing |

---

### C-8 — Keyboard users can create components but can never connect them
**Classification:** Documented-but-missing · **Confidence:** 10/10

The core task of this application is *connecting components into an architecture*. That
task is **mouse-only**.

Measured on the live canvas:

| Element | `tabindex` | `role` | `aria-label` |
|---|---|---|---|
| `.react-flow__node` (×5) | `0` | `group` | present |
| `.react-flow__edge` (×4) | `0` | — | present |
| **`.react-flow__handle` (×10)** | **`null`** | **`null`** | **`null`** |

Connection handles are the only affordance for creating an edge, and they are absent from
the tab order, have no role, and have no accessible name.

The gap is confirmed on all three possible alternative paths:

1. **Keyboard shortcuts** — `src/features/shortcuts/shortcuts.ts` lists nine shortcuts
   (Save, Undo, Redo, Metrics, Configure, Delete, Context menu, and two for Help). **None
   adds a component and none creates a connection.**
2. **Node context menu** — `NodeContextMenu.tsx` offers exactly `Configure`, `Duplicate`,
   `Delete`. There is no "Connect to…".
3. **Palette** — `Palette.tsx:49` renders each component as a real `<button>` with
   `onClick={() => handleAdd(...)}`, so **adding works fine by keyboard.**

The combination is the problem: a keyboard user can populate a canvas with components and
is then permanently unable to join them. They can reach a state they cannot act on. Since
an unconnected architecture fails validation and cannot be meaningfully simulated, the
product's primary workflow is unavailable without a pointer.

**Recommendation:** add a keyboard connect mode — e.g. select source node → `C` → arrow/tab
to target → `Enter`. Give handles `role="button"`, a `tabindex`, and names like
"Connect from Application Server output".

---

### C-9 — The inspector accepts invalid configuration silently and persists it
**Classification:** Implemented-but-broken · **Confidence:** 10/10

`src/features/inspector/NodeConfigForm.tsx` contains **no validation of any kind**. A
search for `errors|formState|aria-invalid|role="alert"` in that file returns **zero
matches**. Every field writes straight through:

```ts
onChange={(event) => updateNodeConfig(node.id, { [field.key]: Number(event.target.value) })}
```

`min` / `max` are passed as **HTML attributes only**. They style the field and set
`validity`, but they do not block a React state write, and nothing calls the Zod schema
(`baseComponentConfigSchema`) on this path.

Two reproducible failures, both measured live:

**(a) Out-of-range values are accepted.** Typing `5` into *Error rate* (schema bound
`0–1`, `max="1"`):

```
value            : "5"
validity.valid   : false
rangeOverflow    : true
validationMessage: "Value must be less than or equal to 1."
visible error    : []          ← nothing rendered anywhere in the DOM
```

The browser *knows* it is invalid. The user is never told. Moments later the toolbar
showed **"Autosaving…" → "Draft saved"** — the invalid value was persisted.

**(b) Clearing a field silently writes `0`.** Because `Number("") === 0`:

| Field | Schema min | Value after clearing |
|---|---|---|
| `perInstanceCapacityRps` | 0 | `0` |
| `instanceCount` | **1** | **`0`** |

`instanceCount: 0` violates the schema's own minimum. No error appeared, the
**Run button remained enabled**, and the Architecture guidance panel continued to report
only *"Node 'Application Server' runs a single instance and has no redundancy"* — saying
nothing about a component with zero instances and zero capacity.

This is the most dangerous defect in the product, because it is the input half of C-10.

---

### C-10 — The diagnostic engine blamed the wrong cause and steered the learner away from the real one
**Classification:** Implemented-but-confusing · **Confidence:** 9/10

Direct consequence of C-9, and observed end-to-end.

**Setup:** Basic Web Application, reference topology, with the Browser Client set (via
C-9) to `instanceCount: 0`, `perInstanceCapacityRps: 0`.

**Run result:** 3,000 requests, **39.97% observed availability**, **68.0% error rate**.

**What the tool told the learner**, verbatim from the Critical finding:

> **Observed availability below 99%**
> The run completed with 39.97% observed availability **without a saturated component**, so
> inspect timeouts, injected faults, and dependency errors.
> `observed-availability=0.3997`
> *Compare the same seed with faults disabled and inspect timeout or dependency events
> **before changing capacity**.*

The actual cause was **zero capacity**. The guidance asserts there is no saturated
component and explicitly directs the learner *away* from capacity — the one thing that was
wrong. A zero-capacity node apparently does not register as "saturated" (plausibly a
`0/0` utilisation computation), so it is excluded from the saturation check and from the
"Component peaks" list, which showed only *"Application Server: 4% utilisation · 43 ms"*.

For a general-purpose tool this is a bug. For an **educational** tool it is worse than no
guidance: a learner who trusts the remedy will spend their time inspecting timeouts and
fault injection while the real fault sits in the inspector, unflagged. It teaches an
incorrect debugging heuristic with the full authority of the simulator behind it.

**Recommendation:** treat zero/degenerate capacity as a first-class validation error at
input time (C-9), and add a pre-flight check so any component with
`instanceCount × perInstanceCapacityRps === 0` on a request path is reported as the
prime suspect before generic timeout/fault advice is offered.

---

### C-11 — Undo silently reverts a different action than the one the user just performed
**Classification:** Implemented-but-broken · **Confidence:** 10/10

The undo stack snapshots only `nodes` and `edges`. Changes to traffic profile and fault
arming are never recorded. The consequence is not merely "undo is incomplete" — it is that
**undo reverts the wrong thing, without saying so.**

Measured sequence:

| Step | Action | Result |
|---|---|---|
| 1 | Rename node "Browser Client" → "RENAMED-BY-TEST" | applied |
| 2 | Change Traffic profile → `steady-100` | applied |
| 3 | Press **Ctrl+Z** once | — |

Outcome:

```
trafficAfterUndo : "steady-100"   ← user's LAST action: NOT reverted
nameAfterUndo    : "Browser Client" ← an OLDER, unrelated action: silently reverted
```

The user pressed Undo intending to revert the traffic change. The traffic change stayed,
and a node rename they were not thinking about was undone instead. Both the Undo toolbar
button and `Ctrl+Z` are presented generically, implying a single linear history.

A confirming earlier measurement: with only non-undoable actions pending (traffic +
fault toggle), `Ctrl+Z` was a **complete silent no-op** — neither reverted, no feedback.

**Recommendation:** either bring traffic/fault changes into the same history stack (correct
fix), or scope the control explicitly ("Undo design edit") and disable it when the top of
the stack is not the user's most recent action.

---

### H-7 — Canvas node badges contradict the run summary
**Classification:** Implemented-but-confusing · **Confidence:** 8/10

After the failed run described in C-10 (68.0% error rate, 39.97% availability), every node
on the canvas read:

```
CLIENT | Browser Client | healthy · 0% | P50 0 ms | ERR 0.0%
DNS    | DNS            | healthy · 0% | P50 0 ms | ERR 0.0%
...all five identical
```

The canvas — the primary visual surface, and the one the tutorial repeatedly directs
attention to — declared the system **healthy with 0% errors** while the run summary
reported a critical failure.

This is at least partly because playback had settled at its final frame (`30.0s / 30.0s`),
where traffic has ceased. But that is precisely the state a learner is left in after every
run completes, so the misleading reading is the *default* post-run view, not an edge case.
There is no "peak" or "worst-case" badge mode, and because playback cannot be scrubbed
(H-9), the learner cannot easily navigate to a frame where the badges tell the truth.

---

### H-8 — Toasts never auto-dismiss and cover a third of the context panel
**Classification:** Implemented-but-confusing · **Confidence:** 9/10

Measured with two findings toasts displayed:

```
context panel area : 227,880 px²
area covered       :  75,480 px²
                   →      33% occluded
```

Toast count was `2` immediately and still `2` after a further **9 seconds** — there is no
auto-dismiss; each must be closed manually.

The compound problem: at ≥1280px, `App.tsx:92-95` routes **"View Metrics"** to
`openContextPanel("metrics")` rather than a modal. That is sound responsive design — but it
means the toast's own **"View Metrics"** action navigates the user to a panel that the
toast itself is covering by a third. Confirmed live: after clicking it, the selected tab
was `Metrics` and the panel remained 33% occluded.

Toasts also stacked with an unrelated persistent recovery notice (M-8), compounding the
loss of space.

**Recommendation:** dock findings into the existing **Findings** tab (which already exists
and is already counted in the toolbar as "Findings (2)"), and reserve transient toasts for
brief, auto-dismissing confirmations that do not overlap the panel they reference.

---

### H-9 — Playback cannot be paused, scrubbed, or stepped ✅ REMEDIATED
**Classification:** Documented-but-missing · **Confidence:** 10/10

The playback timeline is a **`role="progressbar"`**, not a slider:

```html
<div class="playback-progress" role="progressbar" aria-label="Playback position"
     aria-valuemin="0" aria-valuemax="30000" aria-valuenow="...">
```

`progressbar` is a read-only output role. A repo query for `input[type=range]` / `role=slider`
on this surface returned **0**.

The complete control set is: **`↻ Replay`**, **`⏭ Skip`**, and a **Speed** select
(0.25×–8×). There is **no pause/resume**, no seek, and no frame stepping.

For a tool whose purpose is observing *when and where* a system degrades, this is a
significant analytical gap. A learner who notices a latency spike at roughly t=12s has no
way to return to it — the only options are replaying all 30 seconds or skipping to the end.
It also undermines H-7: the frame where the failure is visible cannot be revisited.

**Remediation (2026-09-29):** The read-only progress output was replaced with a native
`input[type="range"]`. It supplies keyboard arrow and `Home`/`End` navigation, exposes the
current logical timestamp to assistive technology, and pauses playback at the selected instant
so evidence does not advance beneath the learner's cursor. `seek()` clamps to the completed
timeline's `0…durationMs` bounds and changes no result, metric, finding, or simulation input.
Store tests cover in-range seeking and both bounds.

---

### H-10 — The node context menu violates the ARIA menu pattern and destroys focus ✅ REMEDIATED
**Classification:** Implemented-but-broken · **Confidence:** 10/10

`NodeContextMenu.tsx` declares `role="menu"` with `role="menuitem"` children — which
commits it to the ARIA Authoring Practices menu keyboard contract. It implements only part
of it.

Measured, opening the menu with `Shift+F10` on a focused node:

| Behaviour | Expected (ARIA APG) | **Observed** |
|---|---|---|
| Focus on open | first item | ✅ `"Configure"` |
| `ArrowDown` | move to next item | ❌ **stays on `"Configure"`** |
| `Escape` | close **and restore focus to the node** | ❌ closes, focus → **`BODY`** |

Two distinct defects:

1. **No arrow-key navigation.** The component announces itself as a menu to assistive
   technology, so a screen-reader user is told to use arrow keys; they do nothing. Only
   `Tab` works, which is not the advertised contract.
2. **Focus is destroyed on close.** Focus lands on `<body>`, so a keyboard user is dumped
   to the top of the document and must tab all the way back to the canvas.

This is notably inconsistent with `ModalShell`, which handles the same problem correctly —
see **S-4**, where `Escape` restored focus precisely to the triggering button. The correct
pattern already exists in the codebase and simply is not applied here.

**Remediation (2026-09-29):** The menu now auto-focuses its first action and implements
cyclic **ArrowDown**/**ArrowUp**, **Home**, and **End** navigation. **Escape** and outside
dismissal restore focus to the matching React Flow node rather than the document body.
Action clicks that open the configuration dialog deliberately let that dialog own focus.
A component test covers keyboard movement, Escape dismissal, and focus restoration.

---

### M-6 — Units are missing or ambiguous on numeric fields
**Classification:** Implemented-but-confusing · **Confidence:** 9/10

From `NodeConfigForm.tsx:14-23`, compared against the underlying field keys:

| Label shown | Underlying key | Problem |
|---|---|---|
| "Per-instance capacity" | `perInstanceCapacityRps` | **The unit (RPS) exists in the key and is dropped from the label.** Capacity is meaningless without it. |
| "Error rate" | `errorRate` (0–1) | No indication whether to enter `0.05` or `5`. Directly caused the C-9(a) reproduction. |
| "Hit ratio" | `hitRatio` (0–1) | Same ambiguity, same absence of a hint. |
| "Estimated cost / hour" | `estimatedCostPerHour` | Period given, but no currency. |

Most other fields do carry units ("Base latency (ms)", "Retry backoff (ms)"), so the
omissions read as oversights rather than a deliberate convention. The three 0–1 fractional
fields are the highest risk: the natural mental model for "error rate" and "hit ratio" is a
percentage, and the UI does nothing to correct it.

**Recommendation:** append units to every label ("Per-instance capacity (RPS)"), and render
fractional fields either as percentages at the UI boundary or with an explicit `0–1` hint.

---

### M-7 — No high-contrast, forced-colors, or light-scheme support
**Classification:** Documented-but-missing · **Confidence:** 9/10

Stylesheet audit of all loaded rules:

| Media feature | Rules found |
|---|---|
| `prefers-reduced-motion` | **2** ✅ |
| `prefers-color-scheme` | **0** |
| `prefers-contrast` | **0** |
| `forced-colors` | **0** |

The product is dark-theme only, with no light mode and — more importantly — no support for
Windows High Contrast / forced-colors mode. Given this is an **Electron desktop
application on Windows**, forced-colors is a realistic accessibility requirement, and node
status is partly encoded in colour (health badges, severity chips, edge classes).

This compounds M-5 from Round 1: with only ~13 colour tokens and no semantic contrast
layer, there is no structural seam at which a high-contrast theme could be introduced.

---

### M-8 — The recovery banner persists indefinitely and shifts the layout
**Classification:** Implemented-but-confusing · **Confidence:** 8/10

The notice *"Recovered unsaved work from 11:55 AM. Use Save to write it to a project
file. [Keep] [Discard]"* renders as a **full-width bar above the toolbar**, pushing the
entire application down, and remains until explicitly actioned.

It was still present more than an hour later (timestamps observed from 11:55 AM through
12:57 PM) across scenario loads, tutorial sessions, and simulation runs, stacking with
unrelated findings toasts (H-8). Because it displaces rather than overlays, it compounds
the toolbar's existing 3-row height (H-4) and further reduces canvas space.

---

## 12. Round 2 — additional verified strengths

### S-6 — Result staleness is correctly detected and surfaced ✅
After editing the architecture following a run, the Metrics panel displayed
**"Stale — architecture changed since this run"**. This is a subtle correctness issue that
many tools miss, and it is handled properly — the learner is not shown metrics that no
longer correspond to the design on screen.

### S-7 — `prefers-reduced-motion` is respected ✅
Two `@media (prefers-reduced-motion: reduce)` blocks are present. For an application with
animated request-flow edges, honouring this is both an accessibility requirement and a
comfort issue, and it is implemented.

### S-8 — Deletion impact is explained before it happens ✅
`describeDeletionImpact()` drives a confirmation that names the node, states how many
connections will also be removed, **and** lists any fault scenarios that reference it.
Surfacing the downstream fault-scenario dependency is a genuinely thoughtful touch.

### S-9 — Toast politeness is correctly mapped to severity ✅
The Critical finding used `aria-live="assertive"`; the Warning used `aria-live="polite"`.
This is the correct mapping and is frequently got wrong.

### S-10 — Findings carry evidence, remedy, and a focus action ✅
Each finding renders a title, a plain-language explanation, a machine-readable evidence
value (e.g. `observed-availability=0.3997`), a suggested remedy, and **"View Metrics" /
"Focus component"** actions. The *structure* is exactly right for a teaching tool — C-10 is
a failure of the diagnostic logic populating it, not of this presentation layer.

---

## 13. Revised priority order (Rounds 1 + 2 combined)

Round 2 changes the sequencing. Correctness and data-integrity defects should precede the
tutorial rework, because the tutorial's credibility depends on the simulator being
trustworthy.

**P0 — Correctness and trust (new, blocks everything)**
1. **C-9** — validate in the inspector: run values through the Zod schema, render errors,
   set `aria-invalid`, and never coerce empty input to `0`.
2. **C-10** — detect degenerate (zero) capacity as the prime suspect; stop emitting remedies
   that steer away from the real cause.
3. **C-11** — make undo linear, or scope and disable it honestly.

**P1 — Accessibility blockers (new)**
4. **C-8** — provide a keyboard path to create connections.
5. **H-10** — implement arrow-key menu navigation and restore focus on close, reusing the
   pattern already correct in `ModalShell`.

**P2 — Tutorial framework** — Round 1 items C-1 … C-7, H-5, H-6 (extend
`tutorialPredicateSchema`; add estimation and diagnosis step types; branch content by mode;
gate `Show reference`).

**P3 — Analysis and layout** — H-7, H-8, H-9 (scrubable playback, dock findings, truthful
post-run badges), plus Round 1 H-1 … H-4.

**P4 — Foundations** — M-5 design tokens, M-6 units, M-7 contrast/forced-colors themes.

---

## 14. Closing note — Round 2

Round 1 concluded that the learning layer was never structured to carry its educational
contract. Round 2 shows the problem reaches deeper: **the simulator will accept an
impossible configuration without comment, run it, and then confidently explain the failure
incorrectly.**

The through-line across C-9, C-10, C-11 and H-7 is the same: **the UI does not tell the
user the truth about state it already knows.** The browser knew the error rate was out of
range. The store knew undo was about to revert a different action. The run summary knew the
error rate was 68% while the canvas said 0%. In each case the information existed and was
not surfaced.

That is an encouraging diagnosis, because it is mostly a presentation problem over a sound
engine — the same conclusion Round 1 reached about the recommendation and findings layers
(S-1, S-2, S-10). The engine is largely right. It is the moments where the interface stays
silent that need attention, and for an educational product those silences are the most
expensive defects of all.

---

## 15. Round 3 — additional gaps (data loss, editability, WCAG conformance)

Round 3 probed surfaces untouched by the first two passes: destructive file/project
operations, edge editability, text scaling, measured colour contrast, focus visibility,
and empty states.

**This round surfaced the first outright data-loss defect (C-12) and the first
"whole feature is unreachable" defect (C-13).**

### Round 3 severity summary

| ID | Finding | Classification |
|---|---|---|
| C-12 | "New" destroys unsaved work with no confirmation, unrecoverably, then reports "Saved" | Implemented-but-broken |
| C-13 | Edge properties are entirely uneditable despite driving the simulation | Documented-but-missing |
| H-11 | Text does not scale with user font settings (WCAG 1.4.4 failure) | Implemented-but-broken |
| H-12 | Canvas nodes have no visible keyboard focus indicator (WCAG 2.4.7 failure) | Implemented-but-broken |
| H-13 | The primary "Run" button fails WCAG contrast at 3.2:1 | Implemented-but-broken |
| M-9 | 12 rules set font sizes below 12px; monograms render at 6.44px | Implemented-but-confusing |
| M-10 | Palette shows a blank void on no search results | Implemented-but-confusing |
| M-11 | No `<h1>`; document outline starts at `<h2>` | Implemented-but-broken |
| M-12 | Tag filter is a flat 65-option select | Implemented-but-confusing |

---

### C-12 — "New" silently destroys unsaved work, cannot be undone, and then reports "Saved"
**Classification:** Implemented-but-broken · **Confidence:** 10/10

This is the most severe defect found across all three rounds, because the user loses work
with no warning and no recovery.

Measured sequence, with the toolbar explicitly displaying **"Unsaved changes"**:

| Step | Observation |
|---|---|
| Before | `Unsaved changes` badge shown; **5 nodes** on canvas |
| Click **New** | **no `confirm()` dialog fired** (listener captured `null`) |
| After | **0 nodes** |
| Press **Ctrl+Z** | **0 nodes** — not recovered |
| Undo button state | **enabled** — but a no-op |
| Toolbar badge | now reads **"Saved"** |

The source confirms there is no guard whatsoever — `App.tsx:248-252`:

```tsx
onClick={() => {
  newProject();
  setActiveScenario(undefined);
  exitTutorial();
}}
```

And `projectStore.ts:398-409` explains why it is unrecoverable:

```ts
newProject() {
  set({
    document: seedInitialProject(),
    filePath: undefined,
    isDirty: false,      // ← why the badge flips to "Saved"
    past: [],            // ← undo history destroyed
    future: [],          // ← redo history destroyed
    ...
```

Three compounding failures:

1. **No confirmation** despite the application already knowing `isDirty === true`.
2. **No recovery** — `past: []` wipes the undo stack, so `Ctrl+Z` cannot help. The Undo
   button nonetheless remains *enabled*, inviting a recovery attempt that silently fails.
3. **Actively misleading feedback** — `isDirty: false` makes the badge read **"Saved"**,
   which a user will reasonably interpret as "my work was preserved". The opposite is true.

The pattern for doing this correctly already exists elsewhere in the product: opening a
scenario warns *"Opening a scenario creates a new unsaved project"*, and "Show reference"
fires an explicit `confirm()` about losing changes. **"New" is the one destructive path
with no guard** — and it is the most destructive of them all.

*Mitigating factor:* the autosave recovery draft remained available afterwards, so work is
theoretically retrievable — but nothing in the UI tells the user this at the moment of
loss, and the "Saved" badge actively discourages them from looking.

---

### C-13 — Edge properties drive the simulation but cannot be edited anywhere
**Classification:** Documented-but-missing · **Confidence:** 10/10

`architectureEdgeSchema` (`src/domain/architecture/schema.ts:114-122`) defines four
simulation-affecting properties:

```ts
kind: connectionKindSchema,
routingStrategy: routingStrategySchema.optional(),
weight: z.number().min(0).optional(),
latencyMs: z.number().min(0).default(0)
```

**None of them is editable in the UI.** A repo-wide search for
`updateEdge|latencyMs|routingStrategy|edgeConfig` across all `.tsx` files returns exactly
**one** match — a read-only node badge at `ArchitectureCanvas.tsx:140`. There is no edge
inspector, no edge context menu, and no edge modal.

`ContextPanel.tsx` confirms the omission structurally: it reads `selectedNodeId`
(L45, L47, L56) and has **no reference to `selectedEdgeId` at all**. Verified live —
clicking an edge sets `.react-flow__edge.selected` and the store's `selectedEdgeId`, but
the context panel stays on **Objectives** and never offers edge properties. Edges are
effectively **create-and-delete only**.

Meanwhile template authors use these properties heavily:

| Template file | `latencyMs` / `routingStrategy` / `weight` usages |
|---|---|
| `advanced.ts` | 99 |
| `intermediate.ts` | 87 |
| `specialised.ts` | 62 |
| `beginner.ts` | 23 |
| **Total** | **271** |

The pedagogical cost is significant. **Network latency between components is a core
system-design concept** — it is the entire reason multi-region architectures are hard. A
learner in the "Multi-Region E-Commerce" scenario can *observe* cross-region latency
baked in by the template author but can never ask *"what if this link were 50 ms slower?"*
Likewise `routingStrategy` and `weight` are exactly the levers a load-balancing lesson
needs. The engine models all of it; the UI exposes none of it.

---

### H-11 — Text does not scale with user font settings (WCAG 1.4.4)
**Classification:** Implemented-but-broken · **Confidence:** 10/10

Doubling the root font size produced **no change whatsoever**:

| Element | at `html{font-size:16px}` | at `32px` | Scale factor |
|---|---|---|---|
| Toolbar button | 13px | 13px | **1.00×** |
| Palette item | 13px | 13px | **1.00×** |
| Context tab | 11px | 11px | **1.00×** |

The cause is a fully px-locked type system:

```
font-size rules in px  : 99
font-size rules in rem : 1
```

WCAG 2.1 **1.4.4 Resize Text (AA)** requires text to scale to 200% without loss of content
or function. Here it does not scale at all, so a user who has set a larger default font
size — the primary accommodation for low vision, and a standard OS-level setting — sees
no effect. Because this is an Electron desktop app, browser page-zoom is not the everyday
fallback it would be on the web.

*Related positive:* at an emulated 200% the layout did **not** break — no horizontal
overflow (`1440 vs 1440`), toolbar and context panel both unclipped. Only the palette
overflowed vertically, and it scrolls. So the layout is robust; converting the type scale
to `rem` is unlikely to cause reflow damage.

---

### H-12 — Canvas nodes have no visible keyboard focus indicator (WCAG 2.4.7)
**Classification:** Implemented-but-broken · **Confidence:** 9/10

React Flow's stylesheet sets `outline: none` on focused nodes:

```css
.react-flow__node.selectable:focus,
.react-flow__node.selectable:focus-visible { outline: none; }
```

and **no application CSS re-adds one** — a scan for focus rules matching `.node-card` or
`.node` returned `[]`.

Measured on a focused node:

```
outline    : none
box-shadow : none
border     : rgb(51,58,70)   ← unchanged from unfocused
```

Nodes carry `tabindex="0"` (Round 2, C-8), so a keyboard user *will* tab through all five
nodes — receiving **no visual indication of where they are**. Combined with C-8 (handles
unreachable), keyboard navigation of the canvas is both invisible and unproductive.

Two contrasts worth noting, both of which show the fix is straightforward:

- **Edges are handled correctly** — a focused edge showed `solid 2px`.
- **The rest of the app is handled correctly** — see S-11.

---

### H-13 — The primary "Run" button fails WCAG contrast
**Classification:** Implemented-but-broken · **Confidence:** 9/10

Computed contrast ratios against actual rendered backgrounds. Six distinct text elements
fail WCAG AA:

| Element | Ratio | Required | Font |
|---|---|---|---|
| `.autosave-pill` "Draft saved" | **1.29:1** | 4.5:1 | 11px |
| Recovery banner text | **1.63:1** | 4.5:1 | 12px |
| `.technology-monogram` "CD" / "AA" | **2.58:1** | 4.5:1 | **6.44px** |
| **`.primary-action` "▶ Run"** | **3.20:1** | 4.5:1 | 13px |
| React Flow attribution | 1.04:1 | 4.5:1 | 10px |

The **"▶ Run" button is the single most important control in the application** and the
focal point of the primary workflow, and it is the most visible of these failures at
3.20:1 — a shortfall of nearly 30%.

`.autosave-pill` at **1.29:1** is effectively invisible; since it is the only indicator
distinguishing "Draft saved" from "Unsaved changes", this directly compounds C-12, where
that same badge is also *factually wrong*.

---

### M-9 — Twelve rules set text below the 12px minimum; monograms render at 6.44px
**Classification:** Implemented-but-confusing · **Confidence:** 9/10

```
.react-flow__attribution = 10px     .palette-category h3      = 11px
.react-flow__edge-text   = 10px     .palette-item .fidelity   = 10px
.context-tabs button     = 11px     .node-card .node-type     = 10px
.toolbar-faults legend   = 11px     .node-card .node-status   = 11px
.toolbar-fault-options   = 11px     .tech-note                = 11px
.toolbar-fault-count     = 11px     .palette-help             = 11px
```

The worst case is the technology monogram, measured at a **rendered 6.44px** — roughly half
the accepted minimum for body text — and it simultaneously fails contrast at 2.58:1 (H-13).

Note what is affected: `.context-tabs button` (the primary navigation for Objectives /
Inspector / Metrics / Findings), `.toolbar-fault-options` (the fault-arming controls central
to the comparison exercise), and `.node-card .node-status` (the health readout the tutorial
tells learners to read). These are not decorative labels. With H-11 preventing any scaling,
a user who needs larger text has no recourse.

---

### M-10 — The palette shows a blank void when a search matches nothing
**Classification:** Implemented-but-confusing · **Confidence:** 10/10

Typing a non-matching query into **Search components** produced:

```
itemCount     : 0
categoryCount : 0
visible text  : "COMPONENTS |  | Click to add to the canvas, or drag to choose a position."
```

The entire component list vanishes with **no "no results" message**, no result count, and
no affordance to clear the query. The residual help text ("Click to add to the canvas")
now describes items that are not there, making the panel look broken rather than filtered.

This is an internal inconsistency rather than an unknown pattern: the **Scenario library
handles the identical case correctly**, rendering an explicit empty-state message (verified
live). The palette simply does not.

---

### M-11 — The page has no `<h1>`
**Classification:** Implemented-but-broken · **Confidence:** 10/10

`document.querySelectorAll('h1').length === 0`. The document outline begins at `<h2>`:

```
H2: Components
  H3: entry / compute / performance / data / messaging / reliability / operations …
H2: Basic Web Application
  H3: Learning objectives
  H3: Model limits
```

The application title — *"Ultimate System Design Simulator"* — is marked up as `<strong>`,
which conveys no structural meaning. Screen-reader users navigating by heading (a primary
navigation mode) have no top-level landmark, and the outline implies two co-equal level-2
sections with no parent.

Otherwise the hierarchy is clean and correctly nested — this is a single-element fix.

---

### M-12 — The scenario tag filter is a flat 65-option select
**Classification:** Implemented-but-confusing · **Confidence:** 8/10

The **Tag** dropdown in the Scenario library contains **65 options** (vs. 5 for Difficulty),
presented as one flat alphabetical list — `abuse, analytics, api-gateway, async,
backpressure, batch, cache, cdc, cdn, checkout, circuit-breaker, consistency, data-lake,
dead-letter, dead-letter-queue, dns, etl, …`

Problems: the list is long enough to require scrolling in a native select; it mixes
categories (architectural patterns, domains, infrastructure) with no grouping; it contains
near-duplicates (**`dead-letter`** and **`dead-letter-queue`**) that fragment results; and
only one tag can be selected at a time. For 16 scenarios, 65 single-select tags is a
filtering mechanism finer-grained than the collection it filters.

---

## 16. Round 3 — additional verified strengths

### S-11 — Focus indicators outside the canvas are excellent ✅
Tabbing through the toolbar produced a consistent, high-visibility ring on every control:

```
outline: solid 2px rgb(125, 179, 255)
```

A 2px solid ring in a clearly distinguishable blue, applied uniformly. This is exactly
right — and it is why H-12 (canvas nodes) reads as an oversight rather than a philosophy.

*Method note:* an earlier programmatic `.focus()` probe suggested focus rings were missing
everywhere. That was a **false positive** — programmatic focus does not trigger
`:focus-visible`. Re-tested with real `Tab` keypresses, the rings are present and correct.

### S-12 — The Scenario library handles empty results properly ✅
A non-matching search renders an explicit empty-state message rather than a blank pane
(the correct counterpart to M-10).

### S-13 — Pre-run node badges are honest ✅
Before any simulation, every node reads **"not run"** rather than fabricating a health
value. This is the correct treatment of "no data yet" and makes the post-run contradiction
in H-7 clearly a playback-frame issue rather than a general modelling flaw.

### S-14 — Edge focus indication is present ✅
Focused edges receive `outline: solid 2px`, and each edge carries a descriptive accessible
name (*"Edge from client to dns"*). Edges are better served than nodes here.

### S-15 — The layout survives 200% scaling without breaking ✅
At an emulated 200%, there was **no horizontal overflow** (`scrollWidth 1440` vs
`innerWidth 1440`), and neither the toolbar nor the context panel clipped its content. The
palette overflowed vertically and scrolled correctly. The grid is genuinely robust — which
means fixing H-11 is a type-scale change, not a layout rewrite.

---

## 17. Consolidated priority order (Rounds 1–3)

Round 3 introduces a new top priority: **a user can lose all of their work in one click.**

**P0 — Data loss and correctness**
1. **C-12** — confirm before `newProject()` when `isDirty`; preserve or explicitly offer the
   recovery draft; never set `isDirty:false` on a discard path.
2. **C-9** — validate inspector input against the Zod schema (Round 2).
3. **C-10** — stop misdiagnosing zero-capacity components (Round 2).
4. **C-11** — make undo linear and honest (Round 2).

**P1 — Unreachable functionality**
5. **C-13** — build an edge inspector for `kind` / `routingStrategy` / `weight` / `latencyMs`.
6. **C-8** — provide a keyboard path to create connections (Round 2).

**P2 — WCAG conformance**
7. **H-11** — convert the type scale from px to rem (1.4.4).
8. **H-12** — restore a focus indicator on canvas nodes (2.4.7).
9. **H-13** — fix contrast on `.primary-action`, `.autosave-pill`, monograms (1.4.3).
10. **H-10** — ARIA menu keyboard pattern and focus restoration (Round 2).

**P3 — Tutorial framework** — Round 1 C-1 … C-7, H-5, H-6.

**P4 — Analysis, layout, polish** — H-7, H-8, H-9, H-1 … H-4, M-1 … M-12.

---

## 18. Closing note — Round 3

Rounds 1 and 2 found a learning layer that could not teach and a simulator that could
misdiagnose itself. Round 3 found something simpler and more urgent: **the application can
destroy a user's work in a single click, cannot undo it, and then tells them it was
"Saved".**

The recurring theme across all three rounds holds and sharpens. In every major finding, the
application **already possesses the information it fails to act on**:

- It knows `isDirty === true` — and skips the confirm (C-12).
- It knows the edge schema has four editable properties — and renders none (C-13).
- It knows `validity.rangeOverflow` is true — and shows no error (C-9).
- It knows the error rate was 68% — while the canvas says 0% (H-7).
- It knows which action is on top of the undo stack — and reverts a different one (C-11).

None of these are modelling or architecture failures. They are failures to **surface state
the system has already computed.** That is encouraging: the expensive part — a correct,
deterministic, well-factored engine — is largely built. What remains is making the
interface tell the truth about it, consistently, at the moment the user needs it.

For a tool whose purpose is to teach people how systems fail, the irony is worth stating
plainly: **the most valuable fix is not new capability, but honest feedback.**

---

## 19. Round 4 — deep check (playback truthfulness, input validation, graph hygiene)

**Method.** Round 4 differs from Rounds 1–3: it began by **re-verifying every prior
finding** before probing anything new. This was necessary because other agents have been
modifying the codebase between review passes, and three findings turned out to be fixed.
New probing then focused on four areas untouched so far: whether playback badges tell the
truth over time, whether the toolbar's simulation inputs validate, whether duplicate nodes
are distinguishable, and whether node auto-placement produces a usable layout.

All measurements below are from the live app at `http://localhost:5173/` with the Basic Web
Application scenario loaded, **Application server outage** fault armed, seed 42, duration
30 000 ms, producing 3 000 requests at a **60.0 % error rate**.

### 19.1 Status changes since Round 3

| ID | Round 3 status | Round 4 status | Evidence |
|---|---|---|---|
| **C-9** — inspector accepts invalid values silently | Broken | ✅ **Fixed** | `NodeConfigForm.tsx` now holds `draftValues` / `fieldErrors`, runs `baseComponentConfigSchema.safeParse` per field, and renders `role="alert"` messages with `aria-invalid` + `aria-describedby`. Empty input yields "A value is required." |
| **M-6** — numeric fields have no units | Broken | ✅ **Fixed** | Labels now read `Per-instance capacity (req/s)`, `Error rate (0–1)`, `Estimated cost / hour ($)`. |
| **H-9** — playback cannot be scrubbed | Broken | ✅ **Largely fixed** | A real `input[type=range]` now exists with `aria-label="Playback position"` and `aria-valuetext="14.9 of 30.0 simulated seconds"`. `ArrowLeft` moves 15 000 → 14 940, so it is keyboard-operable. A **Resume playback** button appears once scrubbed. Residual gap in M-15 below. |
| C-12 — New destroys work silently | Broken | ❌ Still broken | Destroyed a 9-node document, no confirm, badge still read "Saved". |
| H-1 — modal checkbox stretched full-width | Broken | ❌ Still broken | Measured 165 px. |
| H-11 — text does not scale | Broken | ❌ Still broken | 1.00× ratio at 200 % zoom. |
| H-12 — no focus ring on canvas nodes | Broken | ❌ Still broken | `outline: none`, `box-shadow: none`. |
| M-10 — palette has an empty void | Broken | ❌ Still broken | — |
| M-11 — no `<h1>` on the page | Broken | ❌ Still broken | `document.querySelectorAll('h1').length === 0`. |

**A standing "cannot verify" item is now resolved.** Rounds 1–3 could not reproduce the
React Flow `nodeTypes` console warning. Round 4 captured it:
`[React Flow]: It looks like you've created a new nod…`. It surfaces on re-render, not on
cold load, which is why earlier passes missed it. Filed as M-16.

### 19.2 Severity summary — Round 4

| ID | Severity | Finding | Confidence |
|---|---|---|---|
| **C-14** | 🔴 Critical | Canvas never shows failure: node status frozen at `healthy · 0%` on every frame of a 60 %-error run | 10/10 |
| **C-15** | 🔴 Critical | Toolbar simulation inputs are unvalidated; `Duration = 0` runs anyway and silently produces a full 30 s result | 9/10 |
| **H-14** | 🟠 High | Duplicate node names produce byte-identical, unactionable validation messages | 9/10 |
| **H-15** | 🟠 High | Auto-placement cascade overlaps nodes by up to 86 % | 9/10 |
| **M-13** | 🟡 Medium | Edge accessible names leak raw node IDs instead of display names | 10/10 |
| **M-15** | 🟡 Medium | Playback has no pause control until after the user scrubs | 8/10 |
| **M-16** | 🟡 Medium | React Flow `nodeTypes` warning fires on re-render | 7/10 |

---

### C-14 — The canvas never shows failure, on any frame

**Classification:** Correctness / feedback truthfulness. **Confidence: 10/10.**

This supersedes and escalates **H-7**. Round 2 recorded that the canvas showed 0 % error
*after* playback ended, and assumed it was a final-frame artifact. It is not. Node badges
are **never** time-varying, and node status is **never** derived from errors.

**Measurement — status across the whole timeline.** With the app-server outage armed and
the run summary reporting **60.0 % error rate**, the playback slider was driven to eight
positions spanning the run and every node's status chip was read at each:

| Sampled positions | Distinct node statuses observed |
|---|---|
| 1 s, 4 s, 8 s, 12 s, 16 s, 20 s, 24 s, 28 s | `healthy / 0%` — **and nothing else** |

`anyFailureShown: false`. Across the entire simulated timeline, with a component outage
armed and 3 of every 5 requests failing, **not one node is ever rendered as
warning, degraded, or failed.**

**Measurement — badges are static.** The two busiest nodes read identically at every
position:

| Playback position | Application Server | Primary Database |
|---|---|---|
| 8.0 s | `P50 41 ms · ERR 0.0% · healthy 0%` | `P50 25 ms · ERR 0.0% · healthy 0%` |
| 20.0 s | `P50 41 ms · ERR 0.0% · healthy 0%` | `P50 25 ms · ERR 0.0% · healthy 0%` |
| 29.0 s | `P50 41 ms · ERR 0.0% · healthy 0%` | `P50 25 ms · ERR 0.0% · healthy 0%` |

**Root cause — two independent defects in `ArchitectureCanvas.tsx`.**

*1. The badge source is a single end-of-run snapshot, not a time series.*

```ts
// ArchitectureCanvas.tsx:180-188
function latestUtilizationByNode(snapshots) {
  const map = new Map();
  for (const snapshot of snapshots ?? []) map.set(snapshot.nodeId, snapshot);  // last wins
  return map;
}

// ArchitectureCanvas.tsx:223-226
const utilizationByNode = useMemo(
  () => latestUtilizationByNode(lastResult?.componentMetrics),
  [lastResult]          // ← no flowFrame dependency
);
```

The loop keeps the **last** snapshot per node, discarding the series. The memo depends on
`[lastResult]` only, so it cannot change during playback. Of all the node fields, only
`processing` is wired to `flowFrame` (`ArchitectureCanvas.tsx:264`).

*2. Status is computed from utilisation alone, ignoring `errorRate`.*

```ts
// ArchitectureCanvas.tsx:239-249
const status = !lastResult ? "inactive"
  : metric === undefined ? "inactive"
  : metric.utilization >= 0.95 ? "failed"
  : metric.utilization >= 0.8  ? "degraded"
  : metric.utilization >= 0.6  ? "warning"
  : "healthy";
```

`errorRate` is present on the snapshot — `nodeMetricLines` reads it at line 141 — but no
threshold consults it. Because measured utilisation is `0` for every node in this scenario,
the four-tier scale collapses to a constant `healthy`. **The `failed`, `degraded` and
`warning` branches are unreachable in practice**, as is the `saturated` ⚠ icon at line 263
and the `.node-utilization` progress bar.

The "Component peaks" list in the metrics panel repeats the same figure
(`Application Server: 0% utilisation`), so a learner who cross-checks gets the same wrong
answer twice and has no reason to doubt it.

**Why this is the most serious finding in the review.** The product's stated purpose is to
teach how distributed systems fail. A learner arms an outage, runs it, watches the
animation, and sees five green "healthy" nodes — while the summary panel says 60 % of
requests failed. The canvas is the primary teaching surface, and it is **actively
contradicting** the lesson. The most likely learner conclusion is that outages are
harmless, which is the precise opposite of the intended takeaway.

**The plumbing already exists.** Edges are time-varying — `totalsByEdge` plus live
`flowFrame` buckets. The fix is to give nodes the same treatment, not to build new
infrastructure.

**Recommended fix.**
1. Index `componentMetrics` by `(nodeId, timestamp)` and select the bucket for the current
   `flowFrame`, mirroring the edge path.
2. Fold `errorRate` into the status derivation, e.g. `errorRate >= 0.5 → failed`,
   `>= 0.2 → degraded`, `>= 0.05 → warning`, taking the worst of the error-based and
   utilisation-based tiers.
3. Add a regression test asserting that a run with an armed outage yields at least one node
   whose status is not `healthy`.

---

### C-15 — Toolbar simulation inputs are unvalidated, and an invalid duration runs anyway

**Classification:** Input validation / silent data corruption. **Confidence: 9/10.**

The Round 3 fix for C-9 hardened the **inspector**. It did not reach the **toolbar**, where
the two inputs that control every run still have no validation.

**Measured attribute state:**

| Input | `min` | `max` | `step` | Accepts |
|---|---|---|---|---|
| Seed | *(none)* | *(none)* | *(none)* | `-7.5` — negative, fractional |
| Duration (ms) | `1000` | *(none)* | — | `0`; also accepts arbitrarily large values |

**The silent-failure trace.** Setting Duration to `0` via the native React setter:

| Observation | Value |
|---|---|
| `validity.rangeUnderflow` | `true` |
| Visible error message | **none** |
| `aria-invalid` | not set |
| Run button `disabled` | `false` |
| Run button label | `"Ready to run"` |
| Result after clicking Run | **3 000 requests over a full 30 s timeline** |

The browser knows the value is invalid. The UI neither reports it nor blocks the run;
instead the engine silently substitutes the previous valid duration and returns a result
that **does not correspond to the value shown in the input**.

This is worse than a rejected input. The learner sees `0` in the box, a result on screen,
and a "Ready to run" affirmation — and has every reason to believe those numbers describe
each other. Any conclusion drawn about how duration affects the system is then based on a
figure the simulation ignored. A negative fractional seed is the same hazard against the
tool's determinism guarantee, which is one of its genuine strengths (S-3).

**Recommended fix.** Apply the `NodeConfigForm` pattern that already works: bound both
inputs in the schema (`seed`: non-negative integer; `duration`: `1000 – 600000`), surface
`role="alert"` messages, set `aria-invalid`, and **disable Run with an explanatory label**
while any field is invalid. Never let the engine silently substitute a value the user
cannot see.

---

### H-14 — Duplicate node names produce identical, unactionable validation messages

**Classification:** Identity / error-message quality. **Confidence: 9/10.**

Adding the same component four times produces four nodes whose `displayName` is byte-identical:

| Nodes added | Resulting display names |
|---|---|
| Cache ×4 | `"Cache"`, `"Cache"`, `"Cache"`, `"Cache"` |

The validation panel then emits four messages that cannot be told apart:

```
Node "Cache" is not connected to any edge.
Node "Cache" is not connected to any edge.
Node "Cache" is not connected to any edge.
Node "Cache" is not connected to any edge.
```

Since the messages are not click-to-select and carry no coordinates, index, or other
discriminator, a learner who wires up three of the four caches still sees an identical
message and has **no way to determine which node is still unconnected** other than clicking
every node in turn. Combined with H-15 below — where those same four nodes are stacked with
up to 86 % overlap — three of the four are not even reliably clickable.

**Recommended fix.** Auto-disambiguate on insert (`Cache`, `Cache 2`, `Cache 3`), and make
each validation message a button that selects and pans to the offending node. The second
change is the more valuable one and fixes the whole class of problem.

---

### H-15 — Auto-placement stacks new nodes with up to 86 % overlap

**Classification:** Layout / discoverability. **Confidence: 9/10.**

Nodes added from the palette are placed on a fixed 24 px cascade while node cards are
125 × 69 px:

| Node | Position | Card size |
|---|---|---|
| 1 | `200, 80` | 125 × 69 |
| 2 | `224, 80` | 125 × 69 |
| 3 | `248, 80` | 125 × 69 |
| 4 | `272, 80` | 125 × 69 |

A 24 px step against a 125 px-wide card leaves **101 px of horizontal overlap (81 %)** and,
because `y` never changes, **100 % vertical overlap**. Measured across the four nodes:
**6 overlapping pairs, worst case 86 % occlusion.**

The consequence is not merely cosmetic. The topmost card intercepts pointer events for the
covered area, so the connection handles of the buried nodes are largely unreachable — and
per C-8 there is no keyboard route to create a connection either. A learner adding several
components in a row must drag each one clear before the canvas becomes usable at all, and
nothing on screen explains that the stack contains four nodes rather than one.

**Recommended fix.** Increase the cascade step beyond the card footprint (e.g. `+40, +90`),
or place new nodes at the first free grid cell in the current viewport. Select and briefly
highlight each newly added node so its arrival and location are unambiguous.

---

### M-13 — Edge accessible names leak raw node IDs

**Classification:** Accessibility / naming. **Confidence: 10/10.**

| Edge accessible name | Names shown on canvas |
|---|---|
| `"Edge from client to dns"` | `"Browser Client"` → `"DNS"` |
| `"Edge from lb to app"` | `"Load Balancer"` → `"Application Server"` |

The accessible name is built from internal node IDs rather than `config.displayName`. A
screen-reader user hears `"lb"` and `"app"`; a sighted user reading the same diagram sees
"Load Balancer" and "Application Server". The two groups cannot discuss the same diagram
using the same words, and the identifiers a screen-reader user is given appear nowhere in
the visible UI. This also degrades as soon as a learner renames a node — the spoken name
keeps the original ID and silently diverges from the label on screen.

**Recommended fix.** Resolve both endpoints to `config.displayName` when composing the
label, falling back to the ID only if a name is genuinely absent.

---

### M-15 — Playback has no pause control until the user scrubs

**Classification:** Control affordance. **Confidence: 8/10.**

The H-9 fix is otherwise good, but one gap remains. On a freshly completed run the control
group contains **no pause button** (`hasPause: false`). A **Resume playback** button appears
only *after* the user has moved the slider.

The result is that pausing is reachable only by accident: the user must first discover the
slider, drag it, and thereby stop playback in order to be offered the control that stops
playback. A learner who wants to freeze a moment mid-animation — the single most likely
request during a fault demonstration — has no visible way to do it.

**Recommended fix.** Render a persistent play/pause toggle next to the slider whose label
reflects the current state, rather than conjuring a Resume button as a side effect of
scrubbing.

---

### M-16 — React Flow `nodeTypes` warning fires on re-render

**Classification:** Performance / code hygiene. **Confidence: 7/10.**

Carried as "cannot verify" through Rounds 1–3; now reproduced:

```
[React Flow]: It looks like you've created a new nod…
```

It appears on re-render rather than cold load, which is why earlier passes missed it. The
warning indicates the `nodeTypes` (or `edgeTypes`) object is being recreated on each render,
forcing React Flow to remount every node component. On the small template graphs this is
not perceptible, but it scales with node count and is exactly the kind of cost that would
surface in the large-graph scenarios this tool is meant to teach.

**Recommended fix.** Hoist `nodeTypes` / `edgeTypes` to module scope, or wrap in `useMemo`
with a stable dependency list. Low effort, and it removes noise that masks real warnings.

---

## 20. Round 4 — verified strengths

**S-16 — The playback slider is a genuinely well-built accessible control.**
`aria-valuetext="14.9 of 30.0 simulated seconds"` is materially better than the bare
`aria-valuenow` most implementations settle for: it narrates a *meaningful* quantity with
units rather than a raw tick index. Arrow-key seek works (15 000 → 14 940 on `ArrowLeft`),
and `aria-label="Playback position"` is unambiguous. This is above the standard of the rest
of the app and is the right template for the remaining controls.

**S-17 — The inspector validation fix is exemplary.** The C-9 remedy did not merely block
bad input: it added per-field Zod `safeParse`, `aria-invalid`, `aria-describedby`,
`role="alert"` live messages, and a distinct "A value is required." for empty input — while
preserving the draft value so the user's keystrokes are not destroyed. This is the pattern
C-15 should adopt verbatim for the toolbar.

**S-18 — Edge-level playback is already time-correct.** `totalsByEdge` combined with live
`flowFrame` buckets means connections show both live traffic during playback and retained
totals afterwards. This is precisely the behaviour C-14 asks for on nodes, which means the
node fix is a port of working local code rather than new design work.

---

## 21. Consolidated priority order (Rounds 1–4)

Ordered by learner impact per unit of effort. Status reflects Round 4 re-verification.

| # | ID | Finding | Status |
|---|---|---|---|
| 1 | **C-14** | Canvas never shows failure on any frame | ❌ Open |
| 2 | **C-1** | Challenge mode gives Guided Tour instructions on an empty canvas | ❌ Open |
| 3 | **C-12** | New silently destroys unsaved work, then reports "Saved" | ❌ Open |
| 4 | **C-15** | Toolbar inputs unvalidated; invalid duration runs anyway | ❌ Open |
| 5 | **C-13** | Edge properties are simulation-affecting but uneditable | ❌ Open |
| 6 | **C-11** | Undo reverts a different action than the last one | ❌ Open |
| 7 | **H-15** | New nodes stack with up to 86 % overlap | ❌ Open |
| 8 | **C-8** | No keyboard path to add or connect nodes | ❌ Open |
| 9 | **H-14** | Duplicate names → indistinguishable validation messages | ❌ Open |
| 10 | **H-12** | No focus ring on canvas nodes | ❌ Open |
| 11 | **H-11** | Text does not scale at 200 % zoom | ❌ Open |
| 12 | **H-1** | Modal checkboxes/radios stretched full-width | ❌ Open |
| 13 | **M-15** | No pause control until after scrubbing | ❌ Open |
| 14 | **M-13** | Edge accessible names leak raw node IDs | ❌ Open |
| 15 | **M-11** | No `<h1>` on the page | ❌ Open |
| 16 | **M-16** | React Flow `nodeTypes` re-render warning | ❌ Open |
| 17 | **M-10** | Palette empty void | ❌ Open |
| — | **C-9** | Inspector accepts invalid values silently | ✅ Fixed |
| — | **M-6** | Numeric fields have no units | ✅ Fixed |
| — | **H-9** | Playback cannot be scrubbed | ✅ Largely fixed (see M-15) |

**Note on §2 and §17.** The status tables in those sections predate Round 4 and still list
C-9, M-6 and H-9 as open. This table supersedes them.

---

## 22. Closing note — Round 4

Round 4 changed the shape of the review in two ways.

**First, the codebase is moving.** Three findings were fixed between passes, and the C-9
remedy in particular is better work than the defect it replaced — it is now the reference
pattern the rest of the app should follow. Any consumer of this report must re-verify before
acting; the §21 table is the current truth, and §2 and §17 are historical.

**Second, the central finding got worse on inspection.** H-7 was recorded in Round 2 as a
final-frame reporting glitch. It is not. Node badges are wired to a single end-of-run
snapshot and node status is computed from utilisation alone, so a run with an armed outage
and a 60 % error rate renders **five healthy green nodes at every point on the timeline**.
The `failed`, `degraded` and `warning` branches, the saturation warning icon, and the
utilisation progress bar are all effectively unreachable.

That reframes the Round 3 closing observation rather than contradicting it. The engine
computes the right answer — the run summary says 60 %, the fault is genuinely applied, the
per-edge timeline is time-correct. The failure remains one of **surfacing state the system
has already computed**. But C-14 shows the cost is higher than "the UI is quiet": on the
canvas, the tool's primary teaching surface, the UI is confidently stating the opposite of
what the engine concluded.

For a simulator built to teach how systems fail, a canvas that cannot show failure is not a
missing feature. It is the product not doing the one thing it exists to do — and because
the edge pipeline already works correctly, the fix is largely a port of code that is
already in the file.
