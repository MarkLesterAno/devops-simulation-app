# Product Requirements Document

## Ultimate System Design Simulator

### Product overview

The Ultimate System Design Simulator is an offline-first desktop application for learning, designing, and testing distributed-system architectures without provisioning real cloud infrastructure. It combines a visual architecture editor, deterministic workload simulation, controlled fault injection, metrics, and technical guidance.

The product models the behavior and trade-offs of common infrastructure components, including CDNs, load balancers, compute services, caches, databases, queues, workers, replicas, and observability services. It is an educational simulator, not a deployment or production capacity-planning platform.

### Problem statement

Static diagramming tools show architecture topology but not runtime behavior. Learning resources explain patterns but do not safely demonstrate what occurs when traffic grows, dependencies slow down, cache hit rates change, queues lag, or services fail. Real cloud experimentation can also be costly and requires operational expertise.

This product allows users to design architectures, simulate traffic and failure conditions, inspect measurable outcomes, and iteratively improve designs in a fully local sandbox.

### Goals

1. Enable visual creation and configuration of distributed architectures.
2. Simulate traffic flow, capacity limits, queueing, retries, timeouts, caching, failures, and recovery.
3. Explain observed behavior, bottlenecks, and architecture trade-offs.
4. Provide guided scenarios for beginner through advanced learners.
5. Remain offline, deterministic, and safe by never creating real cloud resources.
6. Support extensible infrastructure-component definitions and simulation behavior.

### Non-goals

- Provisioning or managing real cloud infrastructure.
- Guaranteeing real-world performance, cost, or availability.
- Executing untrusted user code in simulated services.
- Replacing dedicated production load-testing, observability, or chaos-engineering platforms.
- Requiring cloud credentials, accounts, or a hosted backend for the initial release.

### Target users

| Persona | Primary need |
|---|---|
| Beginner learner | Learn the purpose and interaction of foundational infrastructure components. |
| Interview candidate | Practice system-design requirements and justify architectural trade-offs. |
| Software engineer | Experiment with a candidate architecture before documenting it. |
| Technical educator | Build repeatable lessons and challenges. |
| Senior engineer | Compare system-design alternatives under a consistent workload. |

### Core user stories

- As a user, I can drag components onto a canvas and connect them to create a system architecture.
- As a user, I can configure capacity, latency, error rate, resiliency, and scaling settings for a component.
- As a user, I can define a workload and simulate its behavior through the graph.
- As a user, I can send simulated HTTP-like request batches from a client node without performing real network I/O.
- As a user, I can inject outages, degradation, and traffic spikes and understand their effects.
- As a user, I can inspect latency, throughput, utilization, errors, retries, queue depth, and cache performance.
- As a user, I can receive accessible finding toasts that distinguish measured simulation outcomes from inferred architecture warnings and recommendations, and jump from a finding to the related metrics.
- As a user, I can replay recorded request flow visually without changing the calculated simulation result.
- As a user, I can save, reopen, export, and reuse projects locally.
- As a learner, I can start from templates and complete measurable system-design challenges.
- As a learner, I can choose Guided Tour, Build, or Challenge mode without being told that the
  reference topology is the only valid design.
- As a learner, I can use local-only tutorials, deterministic request exercises, and contextual
  technology guidance without changing the simulation or contacting a vendor.
- As a first-time learner, I can see the simulator's educational-model boundary and start a guided
  beginner scenario, browse scenarios, or continue with a blank canvas.

### Functional requirements

#### Visual architecture editor

The editor must provide:

- Drag-and-drop component placement.
- Directed, configurable connections representing request, response, event, replication, failover, or observability flow.
- Selection, movement, resize where applicable, grouping, duplication, deletion, undo, and redo.
- Zoom, pan, fit-to-view, minimap, and clear node status overlays.
- Design validation before a simulation begins.
- Local save/load and JSON/image export.
- A workspace layout where the canvas fills the available area beside the component palette and a
  collapsible docked context panel. Metrics and findings open in that panel on wide screens and
  retain modal/notification-centre fallbacks on compact screens; there is no persistent bottom
  results panel.
- Toolbar actions for **Send requests**, **View Metrics**, and **Findings (n)**.
- A checkbox group for every available fault scenario. Multiple faults can be armed together and
  the toolbar reports the current armed count; the selected ids are runtime UI input, not project
  mutations.
- A **Help** action that reopens local first-run guidance without changing the current project.
- A shortcut reference available with **?** or **F1**, plus non-color high-utilization indicators
  and zoom-adaptive node detail that retains the utilization bar when secondary text is hidden.

#### First-run learning route

On first launch, the application presents a dismissible local welcome experience. It must:

- state that traffic, faults, and metrics are deterministic local modeling rather than live
  infrastructure measurements or production guarantees;
- state that the application does not send HTTP requests, provision infrastructure, or contact
  cloud providers;
- offer **Start guided beginner scenario**, **Browse scenarios**, and **Build from scratch**;
- load the Basic Web Application reference graph and its tutorial only after the user explicitly
  selects the guided route; and
- persist only that the welcome screen was seen. It must never dirty, save, export, or otherwise
  alter a project merely because it was opened or dismissed.

#### Canvas interaction model

The editor must present architecture information on the canvas sparingly and offer detail on demand:

- Every node card shows a category glyph and, once a technology is assigned, a badge with the product name tinted by its provider. The application ships no third-party brand assets; when no approved local logo is available the badge renders a provider-tinted monogram. Icons are always paired with text so they are never the sole indicator.
- Node cards show live status and a short set of run metrics, and shed the metric lines below a zoom threshold so large designs stay legible.
- A node opens the configuration modal via double-click, `Enter` on a focused node, or the context menu. The modal renders the node configuration form and opening it must not modify the project or create an undo entry.
- Right-click or `Shift+F10` on a node opens a menu with **Configure**, **Duplicate**, and **Delete**. Duplicate copies configuration only, never connections. Delete states how many connections it will remove before it is confirmed.
- Metrics are opened on demand from **View Metrics**, `Ctrl+M`, simulation-completion actions, or a finding toast. The metrics modal is single-purpose: it has no tab strip and shows only metrics the run produced. Editing the architecture after a run marks displayed metrics stale instead of clearing them.
- Findings appear as non-auto-dismissing toasts and remain reviewable in a session-scoped notification centre. Toasts are capped on screen, prioritized by severity, deduplicated across unchanged reruns, and include non-colour severity marks, human-readable titles, affected component labels, metric summaries, suggested actions, **View Metrics**, and **Focus component** when applicable.
- Connections show a playback flow overlay from recorded telemetry. Colour encodes flow class (read, write, auth, asynchronous event, replication), failures are shown in red, retries tighten the dash, and a bottom-right legend explains the treatments.
- A playback control bar below the canvas supports replay controls and speed selection after the worker has completed the deterministic run. Playback is read-only: pausing, scrubbing, changing speed, or skipping to the end never changes metrics or findings.
- Flow animation can be disabled, and animation is suppressed automatically under `prefers-reduced-motion`; directional markers, class labels, counters, and node processing glyphs remain so motion is never the only channel carrying meaning.

#### Initial component catalog

The catalog is delivered in phases. [COMPONENT_CATALOG.md](./COMPONENT_CATALOG.md) is the
authoritative specification; this table records approved product scope.

**Delivered**

| Category | Components |
|---|---|
| Entry | Client, CDN, Load Balancer |
| Compute | Server, Worker |
| Data | Relational Database, Read Replica, Object Storage |
| Messaging | Message Queue, Dead-Letter Queue |
| Performance | Cache |
| Reliability | Circuit Breaker, Autoscaler |
| Operations | Observability |

**Priority 1 expansion**

| Category | Components |
|---|---|
| Entry | DNS / Traffic Manager, API Gateway |
| Data | NoSQL Database |
| Messaging | Event Topic |
| Identity | Identity & Auth Service |
| External | External Service (third-party dependency) |

**Priority 2 and 3 expansion**

Search Index, Stream Processor, Scheduler / Cron, Service Discovery Registry, Configuration &
Feature Flag Service, Secrets & Key Management Service, Distributed Lock Service, Workflow
Orchestrator, Change Data Capture, Analytical Store, Model Serving Endpoint, Deployment Controller,
Failover Controller, Backup & Restore Service.

**Reconciled concepts.** The following were previously listed as separate components and are now
represented as configuration, because they add no distinct routing, capacity, or timing decision:

- **Session Store** — a Cache with `role: session`, plus sticky sessions on the load balancer.
- **Health Check** — health-probe configuration on a load balancer and its targets.
- **Logging Service, Metrics Service, Alerting Service** — an Observability component with a `role`
  discriminator.
- **Identity Provider and Authentication Service** — a single Identity & Auth Service with a `mode`
  discriminator.
- **Web Server, Application Server, Microservice** — configurations of Server.
- **Reverse Proxy** — a Load Balancer operating at layer 7.

Each component must support appropriate settings. Shared settings include display name, region, capacity, latency, timeout, error rate, availability assumption, scaling behavior, health status, and estimated cost. Specialized settings include load-balancer algorithms, cache TTL and eviction strategy, database replica and consistency settings, queue throughput and retention configuration, gateway route tables and quota policy, DNS TTL and resolution policy, topic subscriber groups, and identity token lifetime and fail mode.

#### Traffic profiles

Users must be able to define traffic duration, baseline and peak requests per second, traffic bursts, read/write ratio, concurrent users, request and response sizes, authentication and session-affinity requirements, geographic distribution, and request-path distribution.

Traffic may originate from a Client component or, once the Scheduler / Cron component is delivered, from a scheduled trigger. Scheduled arrivals are a second, independent arrival source and must be deterministic with respect to the configured logical timestamps.

Users may also queue manual request batches from a Client component. A batch declares method (`GET`, `POST`, `PUT`, `PATCH`, `DELETE`, `HEAD`, or `OPTIONS`), count, dispatch rate, optional path, request class, payload and response sizes, timeout, seed, and label. The composer previews the logical duration, lists queued batches, allows removal, and warns when the configured run duration is shorter than the queued batches require. Queued batches are UI state outside the project document, so they do not dirty the project or enter undo history. They are translated into deterministic logical arrivals only; the product never sends real HTTP requests or performs network I/O.

#### Simulation behavior

The simulation must model request routing, component capacity, latency accumulation, overload, queues and backpressure, timeouts, bounded retries, cache hits and misses, data-store load, queue throughput and consumer lag, load-balancing distribution, autoscaling, circuit breakers, dependency failure propagation, and configured failover paths.

#### Fault injection

Users must be able to schedule or immediately introduce node outages, partial degradation, latency increase, error-rate increase, capacity reduction, network failures, traffic spikes, cache failures or eviction, database-primary failure, replica lag, queue-consumer failure, and regional outages.

As components are added, the fault list grows with them. Priority 1 adds quota exhaustion, stale DNS records, partition hotspots, subscriber-group stalls, credential-store unavailability, and third-party provider throttling. Fault type identifiers are append-only so saved fault scenarios remain loadable.

#### Observability and findings

The metrics modal must expose system and component metrics:

- Request count, success count, failure count, and requests per second.
- Error rate and p50, p95, p99 latency.
- Time-series latency (p50/p95/p99), throughput, and, when present, error-rate trends,
  with a read-only marker for the current visual playback time.
- Component utilization and latency.
- Queue depth and consumer lag.
- Cache hit/miss ratio.
- Database read/write pressure and replica lag.
- Retry, timeout, scaling, and circuit-breaker events.
- Observed availability and optional educational cost estimate.
- Request-method distribution, manual batch identifiers, request-flow event timeline, and run assumptions when produced by the current engine.

Component-specific metrics are added alongside their components. Priority 1 adds quota-rejection rate, per-route gateway latency, DNS cache-hit ratio and time-to-failover, per-partition utilization and stale-read count, per-subscriber-group lag and fan-out factor, auth latency share and blocked-request count, and third-party throttle count.

Requests rejected by quota, authentication, or a third-party rate limit must be counted as failures with a distinct reason code. They must never be silently dropped, because observed availability would otherwise be misleading.

Metrics are accessed through the metrics modal rather than a persistent dashboard panel. Per-component metric rows emphasize peak utilization, peak latency, queue depth or lag, replica lag, and cache hit ratio because a short saturation interval is often the relevant learning signal. Rows expose a visual utilization bar and select the component on the canvas; long system-metric series are downsampled for display only and never alter the result.

Findings must be labelled as one of:

1. **Observed simulation result**: directly produced by the run.
2. **Architecture warning**: topology or configuration concern.
3. **Recommendation**: proposed improvement with stated trade-offs.

Findings are presented as toast notifications and retained in a notification-centre history for the session. Dismissing a toast hides it but does not delete the finding or persist toast UI state into the project file.

#### Persistence and learning content

The application must persist projects, graph data, traffic profiles, fault scenarios, results, and user settings locally. It must include starter scenarios for a URL shortener, e-commerce system, chat application, social feed, notification platform, video platform, ride-sharing dispatch, and payment workflow.

The delivered scenario library contains 16 versioned templates across beginner, intermediate,
advanced, and specialized tiers. Every template has a complete reference graph for Guided Tour,
an intentionally incomplete Build starting state, and an empty Challenge starting state. Alternative
learner graphs are assessed through validation and measured outcomes rather than graph-isomorphism
with the reference.

Scenario request exercises are deterministic logical inputs: baseline, read path, write path,
burst, sustained, boundary, and overload. They populate the normal request composer and remain
session-only until queued. Tutorials, hints, recommendation preferences, and active scenario mode
are local UI state and never become `ProjectDocument` data.

The Implementation tab provides deterministic catalog recommendations based on compatible role,
selected scenario workload/difficulty, connected assignments, and local deployment preferences.
Recommendations are educational guidance, show strengths and trade-offs, retain the full catalog
and Generic option, and never auto-apply technology or simulation presets.

### MVP scope

The first usable release includes the Electron desktop shell, a React graph editor, core palette, node configuration modal, traffic profiles, deterministic request simulation, capacity and latency modeling, core metrics, node outage and traffic-spike faults, local persistence, example scenarios, and unit tests for the simulation engine.

### Success metrics

| Metric | Target |
|---|---:|
| Time to first completed simulation | Under 10 minutes for a new user |
| Time to create a basic architecture | Under 5 minutes |
| Responsive canvas size | At least 100 nodes |
| Logical simulation capacity | At least 100,000 RPS |
| Reproducibility | Identical input and seed yield identical output |
| Typical startup time | Under 5 seconds |
| Included scenarios | At least 8 |
| Simulation-domain unit-test coverage | Target 80% or higher |
