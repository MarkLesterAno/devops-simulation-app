# Security and Privacy Requirements

## Security posture

The application is an offline-first simulator. It must not provision, modify, or require access to external cloud infrastructure. It must minimize local privilege and expose only the operating-system capabilities required to open, save, and export user-selected files.

## Electron requirements

- Enable context isolation.
- Disable renderer Node.js integration.
- Use renderer sandboxing where compatible.
- Use a single narrow preload bridge.
- Do not expose `ipcRenderer`, filesystem modules, process APIs, or shell APIs directly to the renderer.
- Validate IPC request and response payloads with Zod schemas.
- Keep IPC channels allowlisted and versioned.
- Use a restrictive Content Security Policy and do not load remote production content.
- Never use `eval`, dynamic code execution, or untrusted HTML injection.

## Local file handling

- Open and save actions originate from native file dialogs or explicit user-approved locations.
- The main process validates file extensions, schema, size limits, and parse errors before use.
- Project import must reject malformed, oversized, or unsupported documents safely.
- Autosave/recovery files must be stored in an application-owned local directory, not beside user files unless the user opts in.
  - Implemented: see [AUTOSAVE_AND_RECOVERY.md](./AUTOSAVE_AND_RECOVERY.md). Drafts are written atomically under `userData/autosave/`, size-bounded, and validated through the project schema before restore.
- Export must use user-selected paths and safe overwrite confirmation behavior.

## Privacy

- The initial release collects no telemetry, analytics, usage data, cloud credentials, or user identifiers.
- Projects remain local unless a user explicitly exports them.
- Local tutorial progress, technology preferences, and welcome-screen visibility are display
  preferences only. They contain no credentials or identifiers and are not embedded in project
  files or exports.
- No external network request is required for normal use.
- If optional diagnostics are introduced later, they must be opt-in, documented, minimized, and independently configurable.

## Dependency and release security

- Lock dependency versions and review production dependency updates.
- Run dependency vulnerability scanning in CI.
- Build installers through a controlled release pipeline.
- Code-sign distributable builds when platform support requires or permits it.
- Publish checksums for release artifacts where practical.

## Security verification

Release verification must prove:

1. Renderer code cannot access Node.js APIs directly.
2. Unrecognized IPC channels and invalid payloads are rejected.
3. A malformed project cannot crash the application or execute code.
4. The production application does not require network access for core functionality.
5. The content security policy blocks unexpected remote script execution.

Current automated regression evidence covers the source-level CSP directives, Electron
`contextIsolation`/sandbox/Node-integration settings, and the absence of direct `ipcRenderer` or
`require` exposure through the preload bridge. These checks do not replace the packaged-build and
running-Electron verification still required by [REMAINING_GAPS.md](./REMAINING_GAPS.md).
