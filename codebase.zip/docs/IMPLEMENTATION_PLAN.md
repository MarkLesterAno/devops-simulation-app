# Implementation Plan

## Delivery approach

Build the product in tested vertical slices. Each phase must leave a usable, integrated increment rather than only framework code. Prioritize a secure desktop boundary, valid graph editing, deterministic simulation, observable results, and then richer reliability and learning features.

## Phase 0: Foundation

**Objective:** Create a secure, buildable Electron, Vite, React, and TypeScript application.

Tasks:

1. Initialize Electron, Vite, React, and TypeScript.
2. Enable strict TypeScript, ESLint, Prettier, Vitest, and React Testing Library.
3. Set up Electron main, preload, and renderer boundaries.
4. Enforce context isolation, disabled renderer Node integration, and validated IPC.
5. Create application shell, navigation, theme foundation, and preferences storage.
6. Document development, build, lint, and test commands.

**Exit criteria:** Development launch and production build work; renderer isolation and IPC validation tests pass.

## Phase 1: Architecture editor MVP

**Objective:** Let users build and configure diagrams.

Tasks:

1. Integrate React Flow.
2. Create a component-definition registry.
3. Add Client, CDN, Load Balancer, Application Server, Cache, Relational Database, Message Queue, and Worker.
4. Implement palette search, drag-and-drop placement, connection creation, deletion, duplicate, undo, and redo.
5. Implement schema-validated node configuration, now presented through the node configuration modal rather than a persistent sidebar.
6. Implement graph serialization and initial validation.

**Exit criteria:** A user can create and configure a valid client-to-load-balancer-to-application-to-database topology.

## Phase 2: Persistence and templates

**Objective:** Preserve and reuse work.

Tasks:

1. Define a versioned `ProjectDocument` schema.
2. Implement Open, Save, Save As, export JSON, and recent projects.
3. Validate and safely reject malformed documents.
4. Export the diagram as an image.
5. Add starter templates: basic web application, URL shortener, and queue-backed notification service.
6. Add bounded autosave and result retention. *(Autosave implemented — see [AUTOSAVE_AND_RECOVERY.md](./AUTOSAVE_AND_RECOVERY.md).)*

**Exit criteria:** A saved project can be reopened with the same graph and configuration.

## Phase 3: Simulation-engine foundation

**Objective:** Run reproducible request-flow simulations.

Tasks:

1. Define input, event, runtime-state, metric, and result models.
2. Implement a seeded deterministic random generator and time-ordered event queue.
3. Generate traffic from profiles.
4. Implement routing and a component behavior contract.
5. Implement initial Client, Load Balancer, Application Server, Cache, Database, Queue, and Worker behaviors.
6. Execute the engine in a Web Worker and stream aggregated metric snapshots.

**Exit criteria:** Same inputs and seed produce the same result; canvas UI remains responsive during a simulation.

## Phase 4: Capacity and reliability behavior

**Objective:** Model common runtime constraints and resilience patterns.

Tasks:

1. Implement capacity and concurrency limits.
2. Implement queueing, overload penalties, load shedding, and timeouts.
3. Implement bounded retries with exponential backoff and jitter.
4. Model cache hit, miss, expiry, eviction, and origin fallback.
5. Model queue depth, consumer throughput, lag, and dead-letter handling.
6. Add load-balancing algorithms, circuit breakers, health checks, failover, and autoscaling.

**Exit criteria:** Overload, queue buildup, retries, cache benefits, and configured failure recovery are measurable and test-covered.

## Phase 4.5: Catalog expansion — Priority 1

**Objective:** Close the structural gaps identified by the architecture review: policy enforcement,
name resolution, non-relational consistency, fan-out messaging, identity, and third-party egress.

Tasks:

1. Add the `external` component category and the six Priority 1 component types to the schema as
   append-only enum values.
2. Introduce per-type configuration schemas layered over the shared base configuration.
3. Register API Gateway, DNS / Traffic Manager, NoSQL Database, Event Topic, Identity & Auth
   Service, and External Service in the component registry with allowed edge kinds and defaults.
4. Implement their simulation behaviors, new event types, and runtime state.
5. Add the new fault types and the new validation errors and warnings.
6. Add configuration controls: route table, subscriber-group editor, TTL and consistency selectors, and
   fail-open/fail-closed control, all keyboard-operable.
7. Map the previously orphaned technology-catalog categories onto the new component types.
8. Bump the project schema and component-model versions and ship the forward migration.

**Exit criteria:** A client → DNS → gateway → auth → service → NoSQL → topic → worker →
external-provider topology simulates deterministically, every new validation rule is test-covered,
and all pre-existing projects load unchanged.

## Phase 5: Fault injection

**Objective:** Test resilience under controlled failure.

Tasks:

1. Add a fault model and timeline editor.
2. Support scheduled outage, degradation, latency, error-rate, capacity, network, cache, primary-database, consumer-outage, and traffic-spike faults.
3. Show fault and recovery state on canvas nodes and edges.
4. Add a causal failure-analysis summary.

**Exit criteria:** A user can schedule a fault, see its impact, and inspect affected requests and dependencies.

## Phase 6: Metrics and recommendations

**Objective:** Turn simulation data into useful engineering insights.

Tasks:

1. Aggregate time-series metrics and calculate latency percentiles.
2. Build node-level utilization, queue, cache, database, retry, and error charts.
3. Add static topology analysis.
4. Implement a rules-based findings engine.
5. Label every finding as observed result, architecture warning, or recommendation.
6. Add a comparison-ready result model.

**Exit criteria:** Users can identify a bottleneck and understand the supported evidence and trade-offs for a proposed change.

## Phase 6.1: Live playback and request simulation — implemented

**Objective:** Simplify the simulation workspace, add user-triggered logical request batches, and
make finished request-flow telemetry replayable without changing deterministic results.

Completed scope:

1. Added a collapsible docked context panel on wide screens and retained modal/notification-centre
   fallbacks on compact screens; no persistent bottom metrics/findings panel is used.
2. Kept node configuration in the modal opened by double-click, `Enter`, or the context menu, with
   context-panel inspection available on wide screens.
3. Added manual request batch composition from Client nodes, with HTTP-like method metadata and no
   real network I/O.
4. Replaced the tabbed results modal with a metrics-only modal opened on explicit user request.
5. Presented findings as accessible, non-auto-dismissing toasts backed by a session notification
   centre.
6. Recorded bucketed flow telemetry in the deterministic run and replayed it through a read-only
   playback control bar below the canvas.
7. Preserved offline-first icon behavior: locally authored glyphs and monogram fallbacks, with no
   bundled third-party brand assets.

**Exit criteria:** Manual request batches, live playback, findings toasts, metrics navigation,
layout removal, icon fallback, reduced-motion behavior, rendering-performance constraints, TypeScript
checks, ESLint, and the full unit-test suite are passing.

## Phase 6.5: Catalog expansion — Priority 2

**Objective:** Add components that require broader engine support than Priority 1.

Tasks:

1. Search Index with asynchronous indexing lag.
2. Stream Processor with windowing and checkpoint/restart recovery.
3. Scheduler / Cron as a second arrival source, including thundering-herd behavior.
4. Service Discovery Registry with registration TTL and propagation delay.
5. Configuration & Feature Flag Service with fail-open and fail-closed modes.
6. Secrets & Key Management Service with caching and rotation.
7. Distributed Lock Service with a deterministic FIFO contention queue.

**Exit criteria:** Scheduled traffic, index lag, stale service discovery, and lock contention each
produce an explainable, test-covered effect on latency, throughput, or availability.

## Phase 7: Learning experience

**Objective:** Provide structured practice.

Tasks:

1. Add all starter scenarios.
2. Add guided walkthroughs and measurable challenges.
3. Build component explanation panels.
4. Implement beginner and advanced configuration modes.
5. Implement architecture comparison using the same workload and seed.

**Exit criteria:** Users can complete a challenge against explicit latency, throughput, availability, or fault-tolerance targets.

### Delivered learning-experience increment

- Shipped 16 schema-validated scenario templates and documentation.
- Added Guided Tour, Build, and Challenge starting states; Build/Challenge are intentionally
  incomplete and do not grade graph similarity to the reference solution.
- Added in-canvas local tutorials with a full Basic Web Application walkthrough, capability-gated
  overviews for other scenarios, local progress, progressive hints, and a confirmed reference view.
- Added deterministic scenario request exercises and paired fault teaching metadata.
- Added deterministic, explainable technology recommendations in the Implementation tab.
- Added local first-run guidance that explains model boundaries and routes learners to the Basic
  Web Application Guided Tour, the scenario library, or a blank canvas. Welcome completion is a
  local display preference and never project data.

Full capacity estimation, automatic property-based Build/Challenge assessment, design comparison,
and advanced tutorial actions remain future work because they require additional engine semantics
and browser/Electron integration coverage.

## Phase 8: Advanced expansion

Candidate work includes multi-region behavior, availability-zone failures, advanced consistency modeling, partitioning and sharding, delivery guarantees, richer CDN and storage behavior, cost modeling, plug-in component definitions, template sharing, and optional collaboration.

Priority 3 catalog components are delivered here: Workflow Orchestrator, Change Data Capture,
Analytical Store, Model Serving Endpoint, Deployment Controller, Failover Controller, and Backup &
Restore Service.

## Proposed repository structure

```text
electron/
  main/
  preload/
src/
  app/
  components/
  domain/
    architecture/
    components/
    simulation/
    metrics/
    validation/
  features/
    canvas/
    component-library/
    modals/
    simulation/
    metrics/
    projects/
    scenarios/
  simulation-engine/
    core/
    components/
    events/
    faults/
    metrics/
    worker/
  persistence/
  stores/
  templates/
tests/
  unit/
  integration/
  e2e/
```

## Major risks and mitigation

| Risk | Mitigation |
|---|---|
| Simulation complexity grows too quickly | Add component behavior incrementally through a registry and maintain deterministic tests. |
| Renderer becomes unresponsive | Keep simulation execution in a Web Worker and aggregate high-volume metrics. |
| Users mistake results for guaranteed production behavior | Display assumptions, limits, and confidence boundaries near findings. |
| Project schemas become incompatible | Version schemas and ship explicit migrations. |
| Electron IPC exposes unsafe capabilities | Use a narrow preload bridge and validate every message. |
| Metrics cause memory growth | Bound detailed event history and retain rolled-up aggregates. |
| Catalog growth outpaces simulation fidelity | Require the 7-step expansion contract and the configuration-first test in [COMPONENT_CATALOG.md](./COMPONENT_CATALOG.md) before any new node type is accepted. |
| Technology catalog entries have no assignable component | Enforce with a registry test that every technology category maps to at least one component type or is explicitly marked as edge/configuration metadata. |
