# Autosave and Recovery

The simulator continuously saves a **recovery draft** of the working project so a crash, an
accidental window close, or a browser refresh never loses design work.

## What autosave is (and is not)

| | Explicit **Save** | **Autosave** |
|---|---|---|
| Writes to | The user's chosen project file | An application-owned recovery draft |
| Triggered by | The user (button / `Ctrl+S`) | Automatically, ~1s after edits settle |
| Location | Anywhere the user picks | `userData/autosave/draft.json` (Electron) or `localStorage` (browser dev) |
| Clears "Unsaved changes" | Yes | **No** |

Autosave never writes to the user's own project file and never marks work as saved. It is purely a
safety net; `Save` remains the only action that produces a real project file.

## Storage location

Per [SECURITY_AND_PRIVACY.md](./SECURITY_AND_PRIVACY.md), recovery data is stored in an
application-owned directory, never beside the user's files:

- **Electron** — `app.getPath("userData")/autosave/draft.json`, written through the allowlisted
  `autosave:read` / `autosave:write` / `autosave:clear` IPC channels. The renderer never touches
  the filesystem directly. On Windows this resolves to
  `%APPDATA%\Ultimate System Design Simulator\autosave\draft.json`.
- **Browser dev (`npm run dev`)** — `localStorage` under `sds:autosave-draft`, so the app stays
  usable without Electron.

Drafts stay on the local machine. Nothing is uploaded.

## Durability

- Writes are **atomic**: the draft is written to a `.tmp` file and then renamed, so a crash
  mid-write cannot corrupt the very file recovery depends on.
- Writes are **bounded**: 25 MB in Electron, 4 MB in the browser (to stay within the localStorage
  quota). Oversized drafts are refused rather than throwing mid-edit.
- Writes are **debounced** by one second so rapid edits coalesce into a single write.
- Autosave is **best-effort**: every failure path is swallowed and surfaced only as an
  "Autosave failed" indicator. A storage problem can never interrupt editing.

## Recovery on startup

On launch the app reads the draft and validates it through the **same schema as any opened project
file**. A draft that is missing, corrupt, of an unsupported envelope version, or schema-invalid is
silently discarded — recovery never blocks startup and never shows a parse error.

A valid draft is restored automatically, and:

- If the work had **unsaved changes**, a banner reports when it was captured and offers **Keep** or
  **Discard**. Discard requires confirmation, then clears the draft and starts a new project.
- If the work had already been saved to a file, it is restored silently with its file path intact
  and is *not* flagged dirty.

Restored graphs are re-validated immediately, so an incomplete recovered design still correctly
blocks **Run** rather than leaving it enabled.

Undo history is intentionally **not** restored: replaying undo into a pre-recovery graph would
produce states the user never actually visited.

## Draft lifecycle

- A draft is only kept when the project contains at least one node or edge, so a pristine empty
  project never produces a recovery prompt.
- Emptying the canvas or choosing **New** clears the draft rather than resurrecting old work.
- The draft records the project's file path, so recovered work continues saving to the same file.

## Preload must be CommonJS

The renderer reaches storage only through the `window.simulator` bridge exposed by
`electron/preload/index.cts`. Electron **cannot load an ESM preload under `sandbox: true`**, and a
preload that fails to load does so *silently* — `window.simulator` is simply `undefined` and the
app quietly falls back to browser behaviour.

The preload source therefore uses the `.cts` extension so TypeScript always emits CommonJS
(`dist-electron/preload/index.cjs`), and `BrowserWindow` points at that `.cjs` file. Do not rename
it to `.ts` or change the emitted module format.
