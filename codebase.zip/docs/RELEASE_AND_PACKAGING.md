# Release and Packaging Plan

## Supported platforms

Initial release priority:

1. Windows 10/11, 64-bit.
2. macOS and Linux after automated build, signing, and test coverage are established.

The supported platform matrix, minimum operating-system versions, CPU architectures, and installer formats must be recorded for each release.

## Distribution

- Windows: signed installer or packaged executable selected during release planning.
- macOS: signed and notarized application package before public distribution.
- Linux: package format selected from AppImage, `.deb`, or equivalent based on target users.
- Every distributable must include version metadata and a release note summary.

## Update policy

The MVP must support manual update discovery through a release page or in-app version display. Automatic updates are post-MVP unless update signing, rollback, privacy, and failure handling are fully specified.

## Release channels

| Channel | Purpose |
|---|---|
| Development | Local developer builds. |
| Preview | Internal or invited tester validation. |
| Stable | Publicly supported release. |

Preview builds must be clearly labeled and must not silently replace Stable builds.

## Release gates

Before a Stable release:

1. Type check, lint, unit tests, integration tests, and applicable end-to-end tests pass.
2. Dependency vulnerability scan is reviewed.
3. Core offline workflow is verified on supported platforms.
4. Project save/open and malformed-project rejection are tested.
5. Security checks for Electron isolation and IPC validation pass.
6. Accessibility checks cover keyboard workflows and reduced-motion mode.
7. A 100-node canvas benchmark and reference simulation benchmark meet documented targets.
8. Release notes document new features, known limitations, schema compatibility, and migration behavior.

## Support and compatibility

Project documents use versioned schemas. Releases must state:

- The oldest project schema version supported for import.
- Migration behavior and backup policy.
- Whether a newer project may be opened by an older application version.
- Any known destructive compatibility limitation before users save.
