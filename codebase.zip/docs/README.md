# Documentation Guide

## Source-of-truth order

When documents overlap, use this order of precedence:

1. [SIMULATION_SPEC.md](./SIMULATION_SPEC.md) for deterministic runtime behavior, event ordering, and model limitations.
2. [TRD.md](./TRD.md) for technical architecture, security constraints, persistence, performance, and testing.
3. [PRD.md](./PRD.md) for product scope, users, and outcomes.
4. [ACCEPTANCE_CRITERIA.md](./ACCEPTANCE_CRITERIA.md) for MVP verification.
5. [IMPLEMENTATION_PLAN.md](./IMPLEMENTATION_PLAN.md) for delivery sequence.
6. [COMPONENT_CATALOG.md](./COMPONENT_CATALOG.md) for component-model policy and planned inventory.
7. [DESIGN_BRIEF.md](./DESIGN_BRIEF.md) for interface and interaction requirements.
8. [SECURITY_AND_PRIVACY.md](./SECURITY_AND_PRIVACY.md) and [RELEASE_AND_PACKAGING.md](./RELEASE_AND_PACKAGING.md) for cross-cutting delivery requirements.

## Document roles

| Document | Role |
|---|---|
| [PRD.md](./PRD.md) | Defines the problem, users, scope, functional requirements, and product success measures. |
| [TRD.md](./TRD.md) | Defines technical architecture and quality requirements. |
| [SIMULATION_SPEC.md](./SIMULATION_SPEC.md) | Defines how simulations behave and what they do not model. |
| [ACCEPTANCE_CRITERIA.md](./ACCEPTANCE_CRITERIA.md) | Defines verifiable MVP outcomes. |
| [COMPONENT_CATALOG.md](./COMPONENT_CATALOG.md) | Defines component abstractions, fidelity labels, and expansion gates. |
| [DESIGN_BRIEF.md](./DESIGN_BRIEF.md) | Defines product experience, layout, visual language, and accessibility. |
| [IMPLEMENTATION_PLAN.md](./IMPLEMENTATION_PLAN.md) | Defines phase-by-phase delivery work. |
| [SECURITY_AND_PRIVACY.md](./SECURITY_AND_PRIVACY.md) | Defines local security and privacy commitments. |
| [RELEASE_AND_PACKAGING.md](./RELEASE_AND_PACKAGING.md) | Defines platform, distribution, compatibility, and release gates. |
| [REMAINING_GAPS.md](./REMAINING_GAPS.md) | Records remediated gaps and the bounded advanced-modeling and release work that remains. |
| [scenarios/README.md](./scenarios/README.md) | Indexes the versioned, openable system-design scenario library. |
| [user-guide/README.md](./user-guide/README.md) | Explains how to build, simulate, inspect, and troubleshoot architectures in the application. |

## Current implementation snapshot

The shipped application includes 16 schema-validated scenarios, Guided Tour / Build / Challenge
starting states, local-only tutorial progress and hints, deterministic scenario request exercises,
contextual technology recommendations, and a local first-run welcome experience. The welcome flow
explains model limits and routes learners to a Basic Web Application Guided Tour, the scenario
library, or a blank canvas without modifying project data. It also includes autosave recovery,
diagram PNG export, JSON export, result freshness checks, graph validation, fault scenarios,
deterministic worker-based simulation, and recorded telemetry playback.

The simulator remains an educational logical model. It does not provision infrastructure, contact
providers, perform HTTP traffic, or make production capacity, availability, cost, or security
guarantees. For the current supported behavior and remaining limitations, read
[SIMULATION_SPEC.md](./SIMULATION_SPEC.md) and [REMAINING_GAPS.md](./REMAINING_GAPS.md).
