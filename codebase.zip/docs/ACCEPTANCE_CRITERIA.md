# MVP Acceptance Criteria

## Purpose

This document converts MVP requirements into verifiable outcomes. Each criterion is satisfied only when it is covered by automated tests, repeatable manual verification, or both.

## Architecture editing

| ID | Criterion |
|---|---|
| AC-ED-01 | A user can drag a Client, Load Balancer, Server, Cache, Database, Queue, and Worker onto a canvas. |
| AC-ED-02 | A user can create and remove compatible directed edges. Incompatible edges are rejected with a specific explanation. |
| AC-ED-03 | A user can open node configuration from the canvas and edit schema-validated settings in the modal. |
| AC-ED-04 | Undo and redo restore canvas and configuration changes in correct order. |
| AC-ED-05 | The canvas remains usable with a 100-node reference architecture. |
| AC-ED-06 | Keyboard interaction supports selection, deletion, canvas navigation, and simulation controls. |

## Canvas interaction

| ID | Criterion |
|---|---|
| AC-CI-01 | Every node card shows a category glyph and a text label. When a technology is assigned the card shows the product name in a provider-tinted badge; when no approved local logo asset exists the badge falls back to a provider-tinted monogram rather than an empty or broken image. |
| AC-CI-02 | Node metric lines are hidden below the zoom detail threshold and reappear above it. |
| AC-CI-03 | Double-clicking a node, pressing `Enter` on a focused node, or choosing Configure from the context menu opens the node configuration modal without dirtying the project. |
| AC-CI-04 | The configuration modal traps focus, closes on `Escape` and on an outside click, and returns focus to the element that opened it. Opening and closing it without editing leaves the project undirtied and adds no undo entry. |
| AC-CI-05 | Right-click or `Shift+F10` on a node opens a menu offering Configure, Duplicate, and Delete, positioned within the viewport, and closes on `Escape`, an outside click, or canvas panning. |
| AC-CI-06 | Duplicate creates a node whose display name is derived from the original, copies its configuration, copies none of its connections, and is reversible with a single undo. |
| AC-CI-07 | Delete from the context menu states how many connections will be removed before the action is confirmed. |
| AC-CI-08 | Completed runs do not auto-open results. The toolbar **View Metrics** action and `Ctrl+M` open the metrics modal on demand. |
| AC-CI-09 | Findings appear as prioritized, accessible toasts and remain reviewable in the session notification centre after dismissal. |
| AC-CI-10 | Editing the architecture after a run marks the displayed result stale without clearing it; moving a node does not mark it stale. |
| AC-CI-11 | During playback, edges carrying recorded traffic show a flow overlay whose speed scales with volume, whose colour encodes flow class, and whose treatment shows failures and retries. |
| AC-CI-12 | Disabling the flow-animation preference, or enabling `prefers-reduced-motion`, stops moving particles while leaving directional markers, class labels, counters, and node processing state visible. |
| AC-CI-13 | Loading a result produced before the severity field existed renders without error, with findings defaulting to `info` severity. |
| AC-CI-14 | First launch presents an accessible welcome dialog that explains the simulator's local educational-model boundary and offers guided beginner, scenario-browse, and blank-canvas routes. |
| AC-CI-15 | Dismissing welcome guidance or reopening it from **Help** does not dirty, save, export, or mutate the current project. Starting the guided route explicitly loads Basic Web Application in Guided Tour mode and opens its tutorial. |
| AC-CI-16 | The docked context metrics and metrics modal both report per-component peak utilization and latency, identify components by display name, and visibly mark stale architecture/model results. |
| AC-CI-17 | Selecting a node does not take a learner away from the open Metrics or Findings context tab and does not reopen a collapsed context panel. Compact workspaces render no inert context rail. |
| AC-CI-18 | Node cards hide secondary technology/status/metric text below the zoom-detail threshold while retaining utilization bars. Components at or above 85% utilization also show a non-color high-utilization warning glyph and highlighted border. |
| AC-CI-19 | Pressing `?` or `F1` outside a form field opens an accessible shortcut reference rendered from the same shared shortcut definitions used for documentation and interaction discovery. |

## Validation and persistence

| ID | Criterion |
|---|---|
| AC-VA-01 | A graph with no client/request origin cannot start a simulation. |
| AC-VA-02 | A graph with no valid terminal path cannot start a simulation. |
| AC-VA-03 | A load balancer with no initially eligible target is rejected before simulation; if all targets become unhealthy during a run, newly routed requests fail with `no-healthy-target`. |
| AC-VA-04 | A queue without a consumer is warned about and reports accumulating depth if producers publish to it. |
| AC-PE-01 | A valid project can be saved, closed, reopened, and retains its graph, configurations, profiles, and fault scenarios. |
| AC-PE-02 | A malformed or unsupported project file is rejected without crashing and gives an actionable error. |
| AC-PE-03 | The user can export a valid project document as JSON and the current diagram as an image. |

## Deterministic simulation

| ID | Criterion |
|---|---|
| AC-SI-01 | Running the same project, profile, faults, settings, and seed twice produces equivalent aggregated outcomes and event order. |
| AC-SI-02 | A constant 100 RPS profile produces 100 requests per logical second, subject only to configured duration boundaries. |
| AC-SI-03 | A component receiving work above configured capacity applies its declared overflow behavior. |
| AC-SI-04 | A queued request contributes queue wait time to end-to-end latency. |
| AC-SI-05 | A request whose deadline elapses before completion is counted as a timeout and never later counted as successful. |
| AC-SI-06 | A simulation can be cancelled; it resolves to a valid `cancelled` result without hanging the UI. Because cancellation terminates the worker rather than checkpointing metric state, that result contains no partial metrics and directs the user to rerun for complete measurements. |
| AC-SI-07 | Simulation execution does not block normal canvas interaction. |

## Live playback and request simulation

| ID | Criterion |
|---|---|
| AC-LP-01 | A user can queue a manual request batch from a Client component with method `GET`, `POST`, `PUT`, `PATCH`, `DELETE`, `HEAD`, or `OPTIONS`, request count, dispatch rate, optional path, request class, sizes, timeout, seed, and label. |
| AC-LP-02 | A batch of 1,000 `PUT` requests at 100 RPS creates exactly 1,000 logical arrivals over exactly 10 logical seconds and performs no real network I/O. |
| AC-LP-03 | Adding a manual request batch consumes no random draws and does not change existing profile-traffic sequence numbers or observed availability for an otherwise unchanged run. |
| AC-LP-04 | Queued manual batches are removable UI state outside the project document; queueing or removing one does not dirty the project and does not create an undo entry. |
| AC-LP-05 | The Web Worker computes the full deterministic run before playback replays recorded telemetry; pause, resume, restart, scrub, speed change, skip, and cancel never modify metrics or findings. |
| AC-LP-06 | Playback exposes the states idle, preparing, running, paused, completed, and cancelled, and supports speeds from 0.25× through 8×. |
| AC-LP-07 | Flow rendering uses bucketed telemetry, not one DOM element per request; a high-volume batch collapses into bounded edge/class/time buckets. |
| AC-LP-08 | The playback sampler runs through `requestAnimationFrame` at no more than 30 fps and stops entirely when playback is not running. |
| AC-LP-09 | Flow visuals distinguish read, write, auth, asynchronous event, and replication classes; failures are visible in red and retries have a distinct dash treatment. |
| AC-LP-10 | With flow animation disabled or `prefers-reduced-motion` enabled, moving particles are replaced by directional markers, class labels, live/total counters, and node processing indicators. |
| AC-LP-11 | At most three finding toasts are visible at once, sorted by severity, with overflow available through a "N more findings" notification-centre link. |
| AC-LP-12 | Finding toasts are deduplicated by finding and related graph elements across unchanged reruns, incrementing repeat count instead of stacking duplicates. |
| AC-LP-13 | Critical finding toasts use `role="alert"` and `aria-live="assertive"` and receive focus; warning, info, and recommendation toasts use polite status announcements. |
| AC-LP-14 | Dismissing a finding toast hides it without deleting the finding from the session notification-centre history, and toast state is not persisted in the project file. |
| AC-LP-15 | A finding toast's **View Metrics** action opens the metrics modal focused on the related component row and indicates stale, invalid, cancelled, or failed run status when applicable. |
| AC-LP-16 | The metrics modal has no findings tab and renders only metrics produced by the run, including request totals, method distribution, manual batch ids, retry and timeout counts, event timeline, assumptions, and peak per-component values when available. |
| AC-LP-17 | The main layout has no persistent bottom metrics/findings panel. A collapsible docked context panel provides Objectives, Inspector, Metrics, and Findings on wide screens; compact layouts retain modal/notification-centre fallbacks. Node configuration remains available through double-click, `Enter`, and the context menu. |
| AC-LP-18 | Technology badges fall back to provider-tinted monograms when `LOGO_ASSETS` has no approved local asset; no runtime icon fetch is attempted. |

## Component behavior

| ID | Criterion |
|---|---|
| AC-CO-01 | Round-robin load balancing distributes successive requests in a stable target order. |
| AC-CO-02 | Unhealthy load-balancer targets receive no newly routed requests. |
| AC-CO-03 | A cache hit does not invoke its origin dependency and records cache latency. |
| AC-CO-04 | A cache miss invokes the configured origin dependency and records a miss. |
| AC-CO-05 | When producers exceed queue consumer throughput, queue depth and consumer lag increase. |
| AC-CO-06 | A failed message is routed to a configured dead-letter queue after its maximum processing attempts. |
| AC-CO-07 | Retry attempts honor maximum attempts, backoff, retry budget, and request deadline. |
| AC-CO-08 | An open circuit breaker fails eligible calls fast and emits a state-change event. |
| AC-CO-09 | Autoscaling only changes capacity after its configured evaluation and provisioning delays. |
| AC-CO-10 | A DNS component caches its resolution for the configured TTL; traffic continues to reach a cached target until the entry expires, and the resulting delay is reported as time-to-failover. |
| AC-CO-11 | Every subscriber group of an event topic receives each published event and tracks an independent offset, depth, and lag. |
| AC-CO-12 | An API gateway rejects over-quota requests with a distinct reason code, counts them as failures, and does not forward them downstream. |
| AC-CO-13 | A NoSQL read under eventual consistency can return stale data while replication lag is non-zero, and every such read is counted. |
| AC-CO-14 | A NoSQL partition skew concentrates load on a subset of partitions and throttles below aggregate configured capacity. |
| AC-CO-15 | A fail-closed identity component that becomes unavailable causes dependent requests to fail with `auth-unavailable`; a fail-open component admits them and records a security-posture finding. |
| AC-CO-16 | An external service rejects calls above its provider rate limit and never gains capacity from an autoscaler. |

## Catalog expansion validation

| ID | Criterion |
|---|---|
| AC-VA-05 | An API gateway with no reachable route target cannot start a simulation. |
| AC-VA-06 | An API gateway configured to delegate authentication with no reachable identity component cannot start a simulation. |
| AC-VA-07 | A DNS component with no resolvable target cannot start a simulation. |
| AC-VA-08 | An event topic with no subscriber group cannot start a simulation. |
| AC-VA-09 | A NoSQL component configured for strong consistency with non-zero replication lag cannot start a simulation. |
| AC-VA-10 | A third-party external service with neither a circuit breaker nor a finite inbound timeout produces a warning. |
| AC-VA-11 | A request-routing cycle cannot start a simulation. |
| AC-VA-12 | A replication edge that does not connect two data components cannot start a simulation. |
| AC-VA-13 | Multi-consumer topic/queue topology and multi-region failover gaps are surfaced as explanatory warnings rather than silently modeled as consumer-group or disaster-recovery behavior. |
| AC-PE-04 | A project saved under the previous schema version opens without data loss, retains its technology assignments, and receives defaults for newly added configuration fields. |
| AC-SI-08 | Every result records an engine version and a component-model version; results from different component-model versions are marked stale and refused for comparison. |

## Fault injection and metrics

| ID | Criterion |
|---|---|
| AC-FA-01 | A scheduled node outage begins and ends at the configured logical timestamps. |
| AC-FA-02 | A traffic spike changes generated arrival rate only during its configured interval. |
| AC-FA-03 | An edge-network fault affects targeted traffic without changing unrelated paths. |
| AC-FA-04 | The toolbar can arm multiple fault scenarios simultaneously, shows the armed count, and passes all selected scenario ids to the simulation input. |
| AC-ME-01 | Results display request count, success count, failure count, RPS, error rate, and p50/p95/p99 latency. |
| AC-ME-02 | Queue-enabled scenarios display queue depth and consumer lag. |
| AC-ME-03 | Cache-enabled scenarios display hit and miss counts or ratios. |
| AC-ME-04 | Clicking a significant event or component metric focuses the relevant graph element. |
| AC-ME-05 | Findings identify whether they are observed results, warnings, or recommendations and include supporting evidence. |
| AC-ME-06 | A low-availability finding identifies saturated components when supported by telemetry; otherwise it directs the user to inspect faults, timeouts, and dependencies. |
| AC-ME-07 | Metrics and playback explicitly identify their deterministic educational-model scope and do not claim to be live infrastructure telemetry. |

## Security and accessibility

| ID | Criterion |
|---|---|
| AC-SE-01 | The renderer cannot access Node.js APIs directly. |
| AC-SE-02 | Invalid IPC payloads are rejected by the main process. |
| AC-SE-03 | Project-file selection is initiated through approved native file dialogs. |
| AC-SE-04 | Regression tests verify a local-only CSP (`default-src`, `script-src`, and `connect-src` restricted to `self`; plugins and base navigation disabled) and permit `blob:` images only for locally generated diagram PNG export. |
| AC-SE-05 | Regression tests verify that Electron windows enable context isolation and sandboxing, disable renderer Node integration, and do not expose raw `ipcRenderer` or `require` through the preload bridge. |
| AC-AX-01 | All primary user journeys can be completed using a keyboard. |
| AC-AX-02 | Status does not rely on color alone and reduced-motion mode disables non-essential traffic animations. |
