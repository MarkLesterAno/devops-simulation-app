# Scenario Library

The System Design Simulator scenario library is a set of offline templates for practicing architecture trade-offs. Opening a template creates the learner's own editable copy on the canvas; it does not provision infrastructure or contact external services. Every scenario documents its simplifications so simulated behavior is not confused with production behavior.

## How to open a scenario

Use the **Templates** button in the app toolbar to open the scenario gallery. Choose a scenario to load it onto the canvas as a new project, then edit, simulate, save, export, or discard that copy as needed.

## Guided exercises

Each loaded scenario exposes optional, offline learning aids:

- **Learning mode** controls the starting canvas. **Guided Tour** opens the reference solution,
  **Build** supplies a deliberate origin-only or partial starting state, and **Challenge** starts
  empty. The reference is one valid approach; learner architectures are evaluated by their
  graph validity and measured outcomes, not by topology matching.
- **Tutorial** in the toolbar starts a step-by-step walkthrough. Progress and revealed hints are
  stored locally on the device, never in the scenario project file. The tutorial can show the
  reference solution only after confirmation, so it never overwrites a learner design silently.
- **Send requests** contains deterministic scenario request exercises: baseline, read path,
  write path, burst, sustained load, capacity boundary, and capacity overload. Loading an
  exercise fills the normal request composer without changing the project. Learners can inspect
  or adjust it before queueing the session-only batch for the next run.
- The **Implementation** tab presents deterministic, contextual technology recommendations.
  These are educational guidance only: catalog compatibility, workload, topology, scenario, and
  local preferences determine the ranking; selecting a recommendation still requires an explicit
  user action.

## Index by difficulty

### Beginner

| Scenario | Summary | Est. minutes | Prerequisites |
| --- | --- | --- | --- |
| [Basic Web Application](./basic-web-application.md) | A single synchronous path from client through DNS and a load balancer to one application server and one relational database. | 20 | None |
| [URL Shortener](./url-shortener.md) | A read-dominated redirect service fronted by a CDN, served from a cache, and backed by a partitioned key-value store. | 25 | [Basic Web Application](./basic-web-application.md) |
| [Simple File Upload Service](./file-upload-service.md) | A write-heavy upload path that stores bytes in object storage and records metadata in a relational database behind an API gateway. | 25 | [Basic Web Application](./basic-web-application.md) |

### Intermediate

| Scenario | Summary | Est. minutes | Prerequisites |
| --- | --- | --- | --- |
| [E-Commerce Storefront](./ecommerce-storefront.md) | A decomposed storefront with cached product reads, a session-backed cart, a synchronous checkout, and queue-driven inventory and notification work. | 40 | [Basic Web Application](./basic-web-application.md), [URL Shortener](./url-shortener.md) |
| [Chat Application](./chat-application.md) | A messaging backend that persists messages to a wide-column store, tracks presence in a cache, and fans messages out to delivery workers through an event topic. | 40 | [E-Commerce Storefront](./ecommerce-storefront.md) |
| [Notification Delivery Platform](./notification-delivery-platform.md) | A queue-decoupled notification pipeline delivering through email, SMS, and push providers, each guarded by a circuit breaker and backed by a dead-letter queue. | 45 | [E-Commerce Storefront](./ecommerce-storefront.md) |
| [Social Media Feed](./social-media-feed.md) | A feed platform that reads from cache and a precomputed feed store while writes fan out through an event topic to feed-building workers. | 45 | [URL Shortener](./url-shortener.md), [Chat Application](./chat-application.md) |
| [Rate-Limited Public API](./rate-limited-public-api.md) | A public API protected by an edge filtering layer, token-bucket quotas, and delegated key validation, so abusive traffic is rejected before it reaches the service. | 35 | [Basic Web Application](./basic-web-application.md) |

### Advanced

| Scenario | Summary | Est. minutes | Prerequisites |
| --- | --- | --- | --- |
| [Multi-Region E-Commerce](./multi-region-ecommerce.md) | An active-active read topology across two regions with a single write primary, geo-routed at DNS and backed by asynchronous replication to regional read replicas. | 60 | [E-Commerce Storefront](./ecommerce-storefront.md), [Basic Web Application](./basic-web-application.md) |
| [Payment Processing Workflow](./payment-processing-workflow.md) | A checkout path that records an order synchronously and settles payment asynchronously through a rate-limited third-party processor behind a circuit breaker, with a dead-letter queue for poison messages. | 55 | [E-Commerce Storefront](./ecommerce-storefront.md), [Notification Delivery Platform](./notification-delivery-platform.md) |
| [Video Streaming Platform](./video-streaming-platform.md) | Edge-cached playback served from object storage, with uploads fanned out to a pool of transcoding workers through a partitioned job topic. | 55 | [Simple File Upload Service](./file-upload-service.md), [E-Commerce Storefront](./ecommerce-storefront.md) |
| [Ride-Sharing Dispatch](./ride-sharing-dispatch.md) | High-frequency driver location ingestion into a partitioned key-value store, with trip matching driven off an ordered event topic and push notification through a third-party provider. | 60 | [Chat Application](./chat-application.md), [Social Media Feed](./social-media-feed.md) |
| [Search & Recommendation Platform](./search-and-recommendation-platform.md) | A query path served from a search index and a vector index, kept current by an indexing pipeline that consumes catalogue change events rather than reading the source database. | 60 | [E-Commerce Storefront](./ecommerce-storefront.md), [Social Media Feed](./social-media-feed.md) |

### Specialized

| Scenario | Summary | Est. minutes | Prerequisites |
| --- | --- | --- | --- |
| [Analytics Event Ingestion](./analytics-event-ingestion.md) | A high-volume telemetry pipeline that buffers events in a partitioned topic, enriches them in a stream processor, lands raw data in object storage, and serves aggregates from an analytical store. | 55 | [Notification Delivery Platform](./notification-delivery-platform.md), [Social Media Feed](./social-media-feed.md) |
| [ML Inference Platform](./ml-inference-platform.md) | A model-serving tier with a synchronous low-latency path for small requests and an asynchronous queue-backed path for expensive inference, sharing a feature store and a result cache. | 55 | [Search & Recommendation Platform](./search-and-recommendation-platform.md), [Payment Processing Workflow](./payment-processing-workflow.md) |
| [Multi-Tenant SaaS Platform](./multi-tenant-saas.md) | A shared control and data plane with per-tenant quota enforcement at the gateway, a pooled tenant database, and a dedicated shard for large tenants to contain the noisy-neighbour problem. | 60 | [Rate-Limited Public API](./rate-limited-public-api.md), [E-Commerce Storefront](./ecommerce-storefront.md) |

## Index by domain

### Web & API

- [Basic Web Application](./basic-web-application.md)
- [Simple File Upload Service](./file-upload-service.md)
- [E-Commerce Storefront](./ecommerce-storefront.md)
- [Rate-Limited Public API](./rate-limited-public-api.md)
- [Multi-Tenant SaaS Platform](./multi-tenant-saas.md)

### Data & Storage

- [URL Shortener](./url-shortener.md)
- [Simple File Upload Service](./file-upload-service.md)
- [Social Media Feed](./social-media-feed.md)
- [Video Streaming Platform](./video-streaming-platform.md)
- [Search & Recommendation Platform](./search-and-recommendation-platform.md)
- [Analytics Event Ingestion](./analytics-event-ingestion.md)

### Messaging & Async

- [E-Commerce Storefront](./ecommerce-storefront.md)
- [Chat Application](./chat-application.md)
- [Notification Delivery Platform](./notification-delivery-platform.md)
- [Social Media Feed](./social-media-feed.md)
- [Payment Processing Workflow](./payment-processing-workflow.md)
- [Video Streaming Platform](./video-streaming-platform.md)
- [Ride-Sharing Dispatch](./ride-sharing-dispatch.md)
- [Analytics Event Ingestion](./analytics-event-ingestion.md)
- [ML Inference Platform](./ml-inference-platform.md)

### Global & Multi-Region

- [Multi-Region E-Commerce](./multi-region-ecommerce.md)

### AI/ML, Search & Analytics

- [Search & Recommendation Platform](./search-and-recommendation-platform.md)
- [Analytics Event Ingestion](./analytics-event-ingestion.md)
- [ML Inference Platform](./ml-inference-platform.md)

### Platform & Multi-Tenancy

- [Rate-Limited Public API](./rate-limited-public-api.md)
- [Multi-Tenant SaaS Platform](./multi-tenant-saas.md)

### Realtime & Media

- [Chat Application](./chat-application.md)
- [Social Media Feed](./social-media-feed.md)
- [Video Streaming Platform](./video-streaming-platform.md)
- [Ride-Sharing Dispatch](./ride-sharing-dispatch.md)

### Payments & External Dependencies

- [Notification Delivery Platform](./notification-delivery-platform.md)
- [Payment Processing Workflow](./payment-processing-workflow.md)
- [Ride-Sharing Dispatch](./ride-sharing-dispatch.md)

## Index by learning objective

### Caching

- [URL Shortener](./url-shortener.md)
- [E-Commerce Storefront](./ecommerce-storefront.md)
- [Social Media Feed](./social-media-feed.md)
- [Search & Recommendation Platform](./search-and-recommendation-platform.md)
- [ML Inference Platform](./ml-inference-platform.md)
- [Multi-Tenant SaaS Platform](./multi-tenant-saas.md)

### Queuing & backpressure

- [Simple File Upload Service](./file-upload-service.md)
- [E-Commerce Storefront](./ecommerce-storefront.md)
- [Chat Application](./chat-application.md)
- [Notification Delivery Platform](./notification-delivery-platform.md)
- [Social Media Feed](./social-media-feed.md)
- [Payment Processing Workflow](./payment-processing-workflow.md)
- [Video Streaming Platform](./video-streaming-platform.md)
- [Ride-Sharing Dispatch](./ride-sharing-dispatch.md)
- [Search & Recommendation Platform](./search-and-recommendation-platform.md)
- [Analytics Event Ingestion](./analytics-event-ingestion.md)
- [ML Inference Platform](./ml-inference-platform.md)

### Replication & consistency

- [URL Shortener](./url-shortener.md)
- [Chat Application](./chat-application.md)
- [Social Media Feed](./social-media-feed.md)
- [Multi-Region E-Commerce](./multi-region-ecommerce.md)
- [Ride-Sharing Dispatch](./ride-sharing-dispatch.md)
- [Search & Recommendation Platform](./search-and-recommendation-platform.md)
- [Multi-Tenant SaaS Platform](./multi-tenant-saas.md)

### Failure isolation & circuit breaking

- [Basic Web Application](./basic-web-application.md)
- [E-Commerce Storefront](./ecommerce-storefront.md)
- [Notification Delivery Platform](./notification-delivery-platform.md)
- [Payment Processing Workflow](./payment-processing-workflow.md)
- [Ride-Sharing Dispatch](./ride-sharing-dispatch.md)
- [Multi-Tenant SaaS Platform](./multi-tenant-saas.md)

### Rate limiting & quotas

- [Rate-Limited Public API](./rate-limited-public-api.md)
- [Payment Processing Workflow](./payment-processing-workflow.md)
- [ML Inference Platform](./ml-inference-platform.md)
- [Multi-Tenant SaaS Platform](./multi-tenant-saas.md)

### Partitioning & hot keys

- [URL Shortener](./url-shortener.md)
- [Chat Application](./chat-application.md)
- [Social Media Feed](./social-media-feed.md)
- [Ride-Sharing Dispatch](./ride-sharing-dispatch.md)
- [Analytics Event Ingestion](./analytics-event-ingestion.md)
- [Search & Recommendation Platform](./search-and-recommendation-platform.md)

### Fan-out & indexing

- [E-Commerce Storefront](./ecommerce-storefront.md)
- [Chat Application](./chat-application.md)
- [Social Media Feed](./social-media-feed.md)
- [Video Streaming Platform](./video-streaming-platform.md)
- [Search & Recommendation Platform](./search-and-recommendation-platform.md)
- [Analytics Event Ingestion](./analytics-event-ingestion.md)

### Multi-region routing

- [Multi-Region E-Commerce](./multi-region-ecommerce.md)

### Cost & capacity sizing

- [Basic Web Application](./basic-web-application.md)
- [Simple File Upload Service](./file-upload-service.md)
- [Notification Delivery Platform](./notification-delivery-platform.md)
- [Video Streaming Platform](./video-streaming-platform.md)
- [Analytics Event Ingestion](./analytics-event-ingestion.md)
- [ML Inference Platform](./ml-inference-platform.md)
- [Multi-Tenant SaaS Platform](./multi-tenant-saas.md)

## Suggested learning path

1. [Basic Web Application](./basic-web-application.md)
2. [URL Shortener](./url-shortener.md)
3. [Simple File Upload Service](./file-upload-service.md)
4. [E-Commerce Storefront](./ecommerce-storefront.md)
5. [Rate-Limited Public API](./rate-limited-public-api.md)
6. [Chat Application](./chat-application.md)
7. [Notification Delivery Platform](./notification-delivery-platform.md)
8. [Social Media Feed](./social-media-feed.md)
9. [Multi-Region E-Commerce](./multi-region-ecommerce.md)
10. [Payment Processing Workflow](./payment-processing-workflow.md)
11. [Video Streaming Platform](./video-streaming-platform.md)
12. [Ride-Sharing Dispatch](./ride-sharing-dispatch.md)
13. [Search & Recommendation Platform](./search-and-recommendation-platform.md)
14. [Analytics Event Ingestion](./analytics-event-ingestion.md)
15. [ML Inference Platform](./ml-inference-platform.md)
16. [Multi-Tenant SaaS Platform](./multi-tenant-saas.md)

## Limitations

Scenarios are deterministic teaching models. Technology choices are generic metadata and simulation presets, not deployment instructions. The simulator omits many real infrastructure details, especially credentials, live networks, provider control planes, operational runbooks, and production correctness guarantees. See the [user guide](../user-guide/README.md) for how to build, run, interpret, and troubleshoot simulations.
