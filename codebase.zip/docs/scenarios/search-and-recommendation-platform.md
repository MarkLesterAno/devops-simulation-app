---
template-id: search-and-recommendation-platform
template-version: 1.0.0
difficulty: advanced
estimated-minutes: 60
---

# Search & Recommendation Platform

## Overview
This advanced scenario models search and recommendation reads served from derived stores rather than from the catalogue database. Catalogue writes publish change events that index workers use to update the search index, vector index, and feature store. Use it with the [user guide](../user-guide/README.md) and the scenario library index at [./README.md](./README.md). Technology names are simulator metadata only.

## Learning Objectives
You learn to separate query-optimized read stores from the system of record by comparing `catalog-db` with `search-index`, `vector-index`, and `feature-store`. Index freshness is treated as an intentional consistency trade-off: `change-topic` backlog and `indexer` throughput determine how stale derived stores become. The template shows change events from `catalog-api` rather than database polling. It also compares keyword-style search and vector-style recommendation as two request paths with different latency and capacity settings.

## Architecture Summary
`client` calls `gateway`, which routes search requests to `search-api`, recommendation requests to `recs-api`, and catalogue writes to `catalog-api`. `search-api` uses `query-cache` and `search-index`. `recs-api` reads from `feature-store` and `vector-index`. `catalog-api` writes `catalog-db` and publishes events to `change-topic`. `indexer` consumes catalogue changes and updates the derived stores. Search and indexing components report to `telemetry`.

## Functional Requirements
- Serve search queries from cache and a search index.
- Serve recommendations from feature and vector stores.
- Persist catalogue writes in the catalogue database.
- Publish catalogue change events for asynchronous indexing.
- Keep search, vector, and feature stores updated through index workers.
- Observe query and indexing behavior.

## Non-Functional Requirements
The workload is read-heavy, latency-sensitive, and consistency-sensitive. Query performance depends on cache hit ratio and derived-store capacity. Freshness depends on event-topic backlog and indexer throughput. The simulator does not model ranking quality, embeddings, recall, ANN algorithms, segment merges, shard rebalancing, or true log-based CDC.

## Components and Responsibilities
| Node ID | Type | Display Name | Key Configuration | Responsibility |
|---|---|---|---|---|
| `client` | client | Search Client | no additional config | Generates search, recommendation, and catalogue traffic. |
| `gateway` | api-gateway | API Gateway | technology `cloudflare-api-gateway`; auth none; policy 2 ms; capacity 9000 RPS | Routes traffic to the correct API. |
| `search-api` | server | Search API | technology `fastapi`; 5 instances; 160 RPS each; base 18 ms; jitter 7 ms; cost 0.35/hour | Handles keyword query requests. |
| `recs-api` | server | Recommendation API | technology `fastapi`; 4 instances; 110 RPS each; base 28 ms; jitter 11 ms; cost 0.3/hour | Handles recommendation requests. |
| `catalog-api` | server | Catalogue Service | technology `spring-boot`; 2 instances; 80 RPS each; base 26 ms; cost 0.16/hour | Writes catalogue records and emits change events. |
| `query-cache` | cache | Query Cache | technology `redis`; hit ratio 0.62; TTL 45000 ms; base 1 ms; capacity 12000 RPS | Absorbs repeated head queries. |
| `search-index` | nosql-database | Search Index | generic technology; document model; eventual consistency; 24 partitions; lag 60 ms; capacity 2500 RPS; base 12 ms; cost 0.7/hour | Represents the search engine / inverted index stand-in. |
| `feature-store` | nosql-database | Feature Store | technology `aerospike`; key-value model; eventual consistency; 32 partitions; lag 20 ms; capacity 5000 RPS; base 3 ms | Serves online recommendation features. |
| `vector-index` | nosql-database | Vector Index | generic technology; vector model; eventual consistency; 12 partitions; lag 120 ms; capacity 900 RPS; base 35 ms; cost 0.85/hour | Represents vector search index behavior. |
| `catalog-db` | relational-database | Catalogue Database | technology `postgresql`; capacity 400 RPS; base 20 ms; cost 0.3/hour | Stores source-of-record catalogue data. |
| `change-topic` | event-topic | Catalogue Change Events | technology `redpanda`; 8 partitions; ordering `partition`; retention 21600000 ms; max depth 25000; capacity 7000 RPS | Carries catalogue change events to indexers. |
| `indexer` | worker | Index Writers | technology `bullmq`; 4 instances; 90 RPS each; base 45 ms; jitter 15 ms; cost 0.32/hour | Updates search, vector, and feature stores from change events. |
| `telemetry` | observability | Telemetry | technology `grafana`; capacity 30000 RPS | Collects query and indexer signals. |

## Request and Event Flows
**Synchronous search flow.** `client` → `gateway` is a request edge. `gateway` → `search-api` is a request edge with 2 ms latency. `search-api` → `query-cache` is a request edge with 1 ms latency, and `search-api` → `search-index` is a request edge with 3 ms latency for derived-store lookup.

**Synchronous recommendation flow.** `gateway` → `recs-api` is a request edge with 2 ms latency. `recs-api` → `feature-store` is a request edge with 2 ms latency, and `recs-api` → `vector-index` is a request edge with 4 ms latency.

**Catalogue write and asynchronous indexing flow.** `gateway` → `catalog-api` is a request edge with 2 ms latency. `catalog-api` → `catalog-db` is a request edge with 3 ms latency. `catalog-api` → `change-topic` is an event edge with 2 ms latency. `change-topic` → `indexer` is an event edge with 2 ms latency. `indexer` updates `search-index` over a request edge with 4 ms latency, `vector-index` over a request edge with 6 ms latency, and `feature-store` over a request edge with 3 ms latency.

**Observability flow.** `search-api` → `telemetry` and `indexer` → `telemetry` are observability edges.

## Data Model and Storage Assumptions
`catalog-db` is the relational system of record. `search-index` is a document-model NoSQL stand-in with 24 partitions and 60 ms replication lag. `vector-index` is a vector-model NoSQL stand-in with 12 partitions and 120 ms replication lag. `feature-store` is a key-value NoSQL store with 32 partitions and 20 ms replication lag. `change-topic` retains change events for 21600000 ms with max depth 25000.

## Technology Suggestions
The template assigns `cloudflare-api-gateway`, `fastapi`, `spring-boot`, `redis`, `aerospike`, `postgresql`, `redpanda`, `bullmq`, and `grafana`. `search-index` and `vector-index` are generic NoSQL components without a named technology assignment. These labels are educational metadata, not installation or provisioning instructions.

## Traffic Profile
The default profile is `query-load`. It runs for 45000 ms at a constant 520 RPS with `readRatio` 0.93 and 7000 concurrent users. The alternate `trending-spike` profile runs for 60000 ms: 450 RPS from 0-20000 ms, a 1600 RPS burst from 20000-33000 ms, then 450 RPS from 33000-60000 ms, with `readRatio` 0.95.

## Capacity and Scaling Assumptions
`gateway` handles 9000 RPS. `search-api` has 5 instances at 160 RPS each, while `recs-api` has 4 instances at 110 RPS each. `query-cache` has 12000 RPS capacity, `search-index` has 2500 RPS, `feature-store` has 5000 RPS, and `vector-index` has 900 RPS. `catalog-api` has 2 instances at 80 RPS each, `catalog-db` has 400 RPS, and `indexer` has 4 instances at 90 RPS each.

## Caching Strategy
`query-cache` has hit ratio 0.62, TTL 45000 ms, base latency 1 ms, and capacity 12000 RPS. It protects the search index from repeated head queries. Recommendation traffic is not routed through the cache in the template; it reads directly from `feature-store` and `vector-index`.

## Reliability and Failure Handling
The default fault scenario is `indexer-stall`. It contains fault `idx-stall`, type `subscriber-group-stall`, targeting `indexer` from 16000 ms to 40000 ms with capacity multiplier 0.15. Scenario `index-latency` contains fault `idx-slow`, type `latency-increase`, targeting `search-index` from 14000 ms to 36000 ms with 260 ms added latency. Scenario `cache-cold` contains fault `qc-cold`, type `cache-failure`, targeting `query-cache` from 12000 ms to 34000 ms.

## Security Considerations
The gateway has `authMode: none`, so authentication, authorization, query privacy, abuse prevention, and data protection policies are not modelled. The scenario does not connect to external search or recommendation services and does not require credentials.

## Observability Plan
Use `telemetry` to compare query behavior and indexing behavior. Watch query-cache hit effects, search-index latency, vector-index pressure, change-topic backlog, indexer utilization, and derived-store freshness during indexer faults.

## Simulation Exercises
Run `query-load` without faults to establish the baseline. Apply `indexer-stall` and observe index freshness through topic backlog and reduced indexer throughput. Apply `index-latency` to see direct search-index latency impact. Apply `cache-cold` to evaluate how much protection the query cache normally provides.

## Expected Results
The `expectedFindings` list is empty, so a clean default run raises no architecture warnings. Interesting behavior appears only after a fault is applied: indexer stall should make derived stores stale, index latency should affect search queries, and cache failure should push more traffic to the search index.

## Common Failure Modes
`indexer-stall` / `idx-stall` is a `subscriber-group-stall` fault against `indexer` from 16000 to 40000 ms with capacity multiplier 0.15. `index-latency` / `idx-slow` is a `latency-increase` fault against `search-index` from 14000 to 36000 ms with 260 ms added latency. `cache-cold` / `qc-cold` is a `cache-failure` against `query-cache` from 12000 to 34000 ms.

## Trade-Offs
Derived stores protect the catalogue database from query load but introduce freshness lag. A query cache reduces repeated-search pressure but can hide search-index capacity limits until it fails. Vector and keyword paths have different capacity and latency assumptions, which makes recommendation traffic more sensitive to `vector-index` constraints.

## Simulator Limitations
The search engine / inverted index is modelled as a `nosql-database`; the simulator has no search-engine component, so ranking, analyzers, relevance, recall, segment merges, and shard rebalancing are not simulated. The vector search index is also modelled as a `nosql-database`; the simulator has no vector-index component, so embeddings and ANN algorithms are not simulated. The feature store is a `nosql-database`, so training/serving skew is omitted. The change data capture pipeline is modelled as a `worker`; the simulator has no CDC component, so log-based replication is not simulated. It also has no failover-controller or workflow-orchestrator component.

## Extension Exercises
Stall `indexer` and describe how stale the search index becomes in seconds. Halve `query-cache` hit ratio and identify the new bottleneck. Route recommendation traffic through the query cache as a thought exercise and argue whether that would be safe for the model.
