---
template-id: ride-sharing-dispatch
template-version: 1.0.0
difficulty: advanced
estimated-minutes: 60
---

# Ride-Sharing Dispatch

## Overview
This advanced scenario models high-rate driver and rider traffic, location ingestion, dispatch event processing, trip persistence, and push notification isolation. It focuses on hot partitions, ordered event processing, and third-party push-provider behavior. Use it with the [user guide](../user-guide/README.md) and the scenario library index at [./README.md](./README.md). The simulator runs locally and does not contact real providers.

## Learning Objectives
You size a write-heavy ingestion path by following location requests through `gateway`, `location-svc`, `geo-cache`, and `driver-state` without a relational database on the ingest path. The hot-partition objective is represented by `driver-state` with `hotPartitionSkew` 0.35 and a targeted partition-hotspot fault. Matching uses `dispatch-topic` with partition-scoped ordering, showing why per-partition ordering can matter without global ordering. The push provider is isolated behind `push-breaker`, so provider behavior does not become the only dispatch dependency.

## Architecture Summary
`client` sends rider and driver app traffic to `gateway`, which forwards it to `location-svc`. The location service reads nearby state from `geo-cache`, writes current driver state to `driver-state`, and publishes dispatch events to `dispatch-topic`. `matcher` consumes ordered partition events, reads `driver-state`, writes trips to `trips-db`, and calls the push provider through `push-breaker`. Location and matching components emit observability events to `telemetry`.

## Functional Requirements
- Accept high-frequency rider and driver app requests.
- Ingest location updates through a scalable server path.
- Maintain a low-latency proximity cache and driver state store.
- Publish dispatch events with partition ordering.
- Match trips asynchronously and persist trip records.
- Notify users through a protected external push provider.

## Non-Functional Requirements
The workload is write-heavy, latency-sensitive, and throughput-sensitive. The design emphasizes ingestion capacity, hot-partition behavior, partition-ordered event processing, and isolation from provider latency or limits. It does not model persistent connections, geospatial indexes, matching fairness, surge pricing, driver acceptance, cancellations, or full trip state machines.

## Components and Responsibilities
| Node ID | Type | Display Name | Key Configuration | Responsibility |
|---|---|---|---|---|
| `client` | client | Rider & Driver Apps | no additional config | Generates rider and driver traffic. |
| `gateway` | api-gateway | API Gateway | technology `apache-apisix`; auth none; policy 2 ms; rate limit 0; capacity 12000 RPS | Accepts app traffic and forwards to location ingestion. |
| `location-svc` | server | Location Ingest | technology `google-cloud-run`; 10 instances; 320 RPS each; base 8 ms; jitter 3 ms; cost 0.75/hour | Processes location pings and emits dispatch events. |
| `geo-cache` | cache | Geo Proximity Cache | technology `redis`; hit ratio 0.9; TTL 15000 ms; base 1 ms; capacity 20000 RPS | Represents proximity lookup for nearby drivers. |
| `driver-state` | nosql-database | Driver State Store | technology `scylladb`; key-value model; eventual consistency; 64 partitions; hot skew 0.35; lag 25 ms; capacity 6000 RPS; base 4 ms | Stores current driver state and exposes hot-partition behavior. |
| `dispatch-topic` | event-topic | Dispatch Events | technology `apache-kafka`; 24 partitions; ordering `partition`; retention 1800000 ms; max depth 30000; capacity 15000 RPS | Buffers ordered dispatch work for matchers. |
| `matcher` | worker | Matching Workers | technology `nestjs`; 6 instances; 120 RPS each; base 35 ms; jitter 12 ms; cost 0.48/hour | Consumes dispatch events, reads driver state, writes trips, and requests push notifications. |
| `trips-db` | relational-database | Trips Database | technology `amazon-aurora`; capacity 800 RPS; base 16 ms; cost 0.6/hour | Stores trip records. |
| `push-breaker` | circuit-breaker | Push Breaker | technology `resilience4j`; failure threshold 0.4; base 1 ms; capacity 8000 RPS | Protects matching from push-provider failure. |
| `push-provider` | external-service | Push Provider | technology `firebase-cloud-messaging`; label `Mobile push gateway`; SLA 180 ms; provider limit 600 RPS; idempotency false; async callback; capacity 700 RPS | Simulates third-party mobile push delivery. |
| `telemetry` | observability | Telemetry | technology `prometheus`; capacity 40000 RPS | Collects location and matching signals. |

## Request and Event Flows
**Synchronous ingestion flow.** `client` → `gateway` is a request edge. `gateway` → `location-svc` is a request edge with 2 ms latency. `location-svc` → `geo-cache` is a request edge with 1 ms latency, and `location-svc` → `driver-state` is a request edge with 2 ms latency.

**Asynchronous dispatch flow.** `location-svc` → `dispatch-topic` is an event edge with 2 ms latency. `dispatch-topic` → `matcher` is an event edge with 2 ms latency. The matcher then performs request edges to `driver-state` with 2 ms latency and `trips-db` with 4 ms latency.

**Push notification flow.** `matcher` → `push-breaker` is a request edge with 1 ms latency, and `push-breaker` → `push-provider` is a request edge with 20 ms latency. The provider is configured with call mode `async-callback`, but callback details are not expanded in the graph.

**Observability flow.** `location-svc` → `telemetry` and `matcher` → `telemetry` are observability edges.

## Data Model and Storage Assumptions
`driver-state` is a key-value NoSQL store with eventual consistency, 64 partitions, 25 ms replication lag, and hot-partition skew 0.35. `geo-cache` is a cache stand-in for proximity lookup with TTL 15000 ms and hit ratio 0.9. `dispatch-topic` retains events for 1800000 ms and uses partition ordering. `trips-db` is the relational trip record store.

## Technology Suggestions
The template assigns `apache-apisix`, `google-cloud-run`, `redis`, `scylladb`, `apache-kafka`, `nestjs`, `amazon-aurora`, `resilience4j`, `firebase-cloud-messaging`, and `prometheus`. These are educational technology assignments only and require no online connectivity.

## Traffic Profile
The default profile is `rush-hour`. It runs for 60000 ms: 800 RPS from 0-20000 ms, ramps from 800 to 2600 RPS from 20000-40000 ms, and holds 2600 RPS from 40000-60000 ms, with `readRatio` 0.2 and 25000 concurrent users. The alternate `event-letout` profile runs for 60000 ms: 900 RPS from 0-22000 ms, a 3200 RPS burst from 22000-36000 ms, then 900 RPS from 36000-60000 ms, with `readRatio` 0.2.

## Capacity and Scaling Assumptions
`gateway` is configured for 12000 RPS with no rate limit. `location-svc` has 10 instances at 320 RPS each. `geo-cache` has 20000 RPS capacity, while `driver-state` has 6000 RPS capacity but may lose effective capacity under hot skew. `matcher` has 6 instances at 120 RPS each, `trips-db` has 800 RPS capacity, and `push-provider` is limited to 600 provider RPS.

## Caching Strategy
`geo-cache` represents proximity lookup with hit ratio 0.9, TTL 15000 ms, base latency 1 ms, and capacity 20000 RPS. It is a stand-in for geospatial indexing rather than a true S2/geohash index. If the cache is lost, more pressure moves to the state and matching path.

## Reliability and Failure Handling
The default fault scenario is `downtown-hot-partition`. It contains fault `hot-shard`, type `partition-hotspot`, targeting `driver-state` from 16000 ms to 42000 ms with capacity multiplier 0.45 and 90 ms added latency. Scenario `geo-cache-loss` contains fault `geo-down`, type `cache-failure`, targeting `geo-cache` from 14000 ms to 38000 ms. Scenario `matcher-lag` contains fault `match-stall`, type `subscriber-group-stall`, targeting `matcher` from 15000 ms to 40000 ms with capacity multiplier 0.3.

## Security Considerations
The gateway uses `authMode: none`, so authentication, authorization, device trust, abuse prevention, location privacy, and encryption are not simulated. The push provider is a rate-limited external-service model only and does not exchange credentials or send real notifications.

## Observability Plan
Use `telemetry` to compare ingestion and matching behavior. Watch for driver-state pressure, hot-partition symptoms, dispatch-topic backlog, matcher utilization, trips-db pressure, push-provider isolation, and circuit-breaker effects when provider pressure increases.

## Simulation Exercises
Run `rush-hour` without faults to establish the write-heavy baseline. Apply `downtown-hot-partition` and watch driver-state capacity and latency. Apply `geo-cache-loss` to see what happens when proximity lookup fails. Apply `matcher-lag` to examine subscriber backlog and delayed trip matching.

## Expected Results
The template declares no `expectedFindings`, so a clean default run raises no architecture warnings. Interesting behavior appears only under faults: hot partitions should reduce effective driver-state capacity, cache loss should disturb proximity lookups, and matcher lag should increase event backlog.

## Common Failure Modes
`downtown-hot-partition` / `hot-shard` is a `partition-hotspot` fault against `driver-state` from 16000 to 42000 ms with capacity multiplier 0.45 and 90 ms added latency. `geo-cache-loss` / `geo-down` is a `cache-failure` against `geo-cache` from 14000 to 38000 ms. `matcher-lag` / `match-stall` is a `subscriber-group-stall` against `matcher` from 15000 to 40000 ms with capacity multiplier 0.3.

## Trade-Offs
A fast write path keeps location ingestion responsive, but eventual consistency and hot partitions affect matching freshness. Partition ordering protects per-partition correctness while limiting some forms of parallelism. A push breaker isolates the provider, but notification delivery is still a third-party dependency in the model.

## Simulator Limitations
The geospatial index is modelled as a `cache`; therefore S2/geohash behavior, radius queries, and index maintenance are not simulated. The push notification provider is modelled as an `external-service`; therefore device tokens, provider callbacks, and real delivery semantics are not simulated. The simulator has no failover-controller, workflow-orchestrator, search-engine, vector-index, or CDC component. Persistent connections, streaming transports, fairness, surge pricing, acceptance behavior, and cancellation flows are also omitted.

## Extension Exercises
Run the hot-partition fault and identify which metric changes before latency. Reduce `driver-state` `hotPartitionSkew` to 0 and compare recovered throughput. Set `dispatch-topic` `orderingScope` to `none` and explain what dispatch correctness you traded away.
