---
template-id: social-media-feed
template-version: 1.0.0
difficulty: intermediate
estimated-minutes: 45
---
# Social Media Feed

## Overview
This scenario documents the `social-media-feed` template. It models a feed platform with a cache-backed read path and a write path that publishes post events for asynchronous fan-out into a precomputed feed store. Use it with `./README.md` and `../user-guide/README.md`.

The workload is read-heavy and throughput-sensitive. The template highlights feed-cache behavior, hot partitions, and feed-builder lag.

## Learning Objectives
Learners compare fan-out on write against fan-out on read. Reads use `feed-cache` and `feed-store`; writes use `post-topic` and `fanout-worker` to update feeds asynchronously.

The scenario also shows why a hot user can break fan-out-on-write. A celebrity-style event is represented as a `partition-hotspot` fault on `feed-store`, while worker loss shows feed staleness from lagging materialization.

## Architecture Summary
The read path is `client` -> `cdn` -> `gateway` -> `feed-api` -> `feed-cache` -> `feed-store`, with `feed-api` also calling `graph-store`. The write path is `gateway` -> `post-svc` -> `post-topic` -> `fanout-worker` -> `feed-store`.

There is no message queue, dead-letter queue, explicit replica, or observability node.

## Functional Requirements
- Serve feed reads through `cdn`, `gateway`, `feed-api`, `feed-cache`, and `feed-store`.
- Query `graph-store` from `feed-api`.
- Accept post writes through `post-svc`.
- Publish post events to `post-topic`.
- Use `fanout-worker` to update `feed-store` asynchronously.

## Non-Functional Requirements
- Favor read-path latency through `cdn` and `feed-cache`.
- Keep write fan-out asynchronous and decoupled from post intake.
- Make hot-partition skew visible in feed and graph storage.
- Show feed-builder worker lag as feed staleness.

## Components and Responsibilities
| Node ID | Type | Display Name | Key Configuration | Responsibility |
| --- | --- | --- | --- | --- |
| `client` | client | Mobile Client | display name only | Generates simulated feed reads and post writes. |
| `cdn` | cdn | CDN | `fastly`; `hitRatio: 0.3`; `baseLatencyMs: 10` | Serves a portion of edge-cacheable requests. |
| `gateway` | api-gateway | API Gateway | `kong-gateway`; `authMode: validate-local`; `policyLatencyMs: 2`; `perInstanceCapacityRps: 8000` | Applies local policy and routes reads and writes. |
| `feed-api` | server | Feed API | `nodejs`; `instanceCount: 6`; `perInstanceCapacityRps: 250`; `baseLatencyMs: 14`; `jitterMs: 5`; `estimatedCostPerHour: 0.36` | Serves feed reads using cache, feed store, and graph store. |
| `feed-cache` | cache | Feed Cache | `redis`; `hitRatio: 0.9`; `ttlMs: 60000`; `baseLatencyMs: 1`; `perInstanceCapacityRps: 15000` | Caches precomputed feed reads. |
| `feed-store` | nosql-database | Feed Store | `scylladb`; `model: wide-column`; `consistency: eventual`; `partitionCount: 64`; `hotPartitionSkew: 0.25`; `replicationLagMs: 60`; `perInstanceCapacityRps: 1200`; `baseLatencyMs: 8`; `estimatedCostPerHour: 0.6` | Stores precomputed feed data. |
| `graph-store` | nosql-database | Social Graph Store | `amazon-dynamodb`; `model: graph`; `consistency: eventual`; `partitionCount: 32`; `hotPartitionSkew: 0.4`; `replicationLagMs: 50`; `perInstanceCapacityRps: 800`; `baseLatencyMs: 12`; `estimatedCostPerHour: 0.4` | Represents social graph lookups. |
| `post-svc` | server | Post Service | `django`; `instanceCount: 3`; `perInstanceCapacityRps: 120`; `baseLatencyMs: 25`; `estimatedCostPerHour: 0.18` | Accepts post writes and emits post events. |
| `post-topic` | event-topic | Post Events | `apache-kafka`; `partitionCount: 24`; `orderingScope: partition`; `retentionMs: 43200000`; `maxQueueDepth: 300000`; `perInstanceCapacityRps: 25000` | Buffers post events for fan-out. |
| `fanout-worker` | worker | Fan-out Worker | `nodejs`; `instanceCount: 6`; `perInstanceCapacityRps: 100`; `baseLatencyMs: 30`; `maxProcessingAttempts: 3`; `estimatedCostPerHour: 0.3` | Consumes post events and writes fan-out results to `feed-store`. |

## Request and Event Flows
- `client` -> `cdn` is a `request` edge; `cdn` -> `gateway` is a `request` edge with 6 ms latency.
- `gateway` -> `feed-api` is a `request` edge with 2 ms latency and weight 8.
- `feed-api` -> `feed-cache` is a `request` edge with 1 ms latency; `feed-cache` -> `feed-store` is a `request` edge with 2 ms latency.
- `feed-api` -> `graph-store` is a `request` edge with 2 ms latency.
- `gateway` -> `post-svc` is a `request` edge with 2 ms latency and weight 1; `post-svc` -> `post-topic` is an `event` edge with 1 ms latency; `post-topic` -> `fanout-worker` is an `event` edge with 2 ms latency; `fanout-worker` -> `feed-store` is a `request` edge with 3 ms latency.
- The template has no `replication`, `failover`, or `observability` edges.

## Data Model and Storage Assumptions
`feed-store` is a wide-column NoSQL store with eventual consistency, 64 partitions, hot-partition skew of 0.25, and 60 ms replication lag. `graph-store` is a NoSQL store with `model: graph`, eventual consistency, 32 partitions, hot-partition skew of 0.4, and 50 ms replication lag. `post-topic` retains events for 43200000 ms and has `maxQueueDepth: 300000`.

## Technology Suggestions
The template assigns `fastly`, `kong-gateway`, `nodejs`, `redis`, `scylladb`, `amazon-dynamodb`, `django`, and `apache-kafka`. These names are educational metadata only; they do not provision services and require no online connectivity or credentials.

## Traffic Profile
Default traffic profile: `feed-traffic`.

- `feed-traffic` (`Feed reads 1200 RPS`): constant, 45000 ms, 1200 RPS, `readRatio: 0.93`, `concurrentUsers: 8000`, `requestSizeBytes: 512`, `responseSizeBytes: 8192`.
- `breaking-news` (`Breaking news surge`): burst, 60000 ms, baseline 900 RPS, peak 4000 RPS, burst from 18000 ms to 34000 ms, `readRatio: 0.9`, `concurrentUsers: 20000`.

## Capacity and Scaling Assumptions
`gateway` has 8000 RPS per-instance capacity. `feed-api` has 6 instances at 250 RPS each, and `post-svc` has 3 instances at 120 RPS each. `feed-cache` has 15000 RPS per-instance capacity. `feed-store` has 1200 RPS, `graph-store` 800 RPS, `post-topic` 25000 RPS, and `fanout-worker` 6 instances at 100 RPS each.

## Caching Strategy
Caching exists at `cdn` and `feed-cache`. `cdn` has `hitRatio: 0.3` and `baseLatencyMs: 10`. `feed-cache` has `hitRatio: 0.9`, `ttlMs: 60000`, `baseLatencyMs: 1`, and `perInstanceCapacityRps: 15000`. There is no separate cache for writes, graph lookups, or post events.

## Reliability and Failure Handling
Default fault scenario: `hot-user-fanout`.

- `hot-user-fanout`: fault `hot-1`, type `partition-hotspot`, targets `feed-store`, starts at 15000 ms and ends at 36000 ms, with `additionalLatencyMs: 200`.
- `fanout-worker-loss`: fault `fanout-1`, type `capacity-reduction`, targets `fanout-worker`, starts at 12000 ms and ends at 34000 ms, with `capacityMultiplier: 0.3`.
- `feed-cache-loss`: fault `cache-1`, type `cache-failure`, targets `feed-cache`, starts at 15000 ms and ends at 30000 ms.

## Security Considerations
`gateway` uses `authMode: validate-local`. The template has no separate identity service and no WAF node. Security behavior is limited to gateway policy latency and local validation metadata.

## Observability Plan
The template has no observability node and no `observability` edges. Use simulator metrics for cache hit behavior, `post-topic` depth, `fanout-worker` utilization, storage latency, and failure counts.

## Simulation Exercises
Run `feed-traffic` without faults. Then run `hot-user-fanout`, `fanout-worker-loss`, and `feed-cache-loss` to compare storage latency, topic lag, worker utilization, and read pressure on `feed-store`.

## Expected Results
The template declares no `expectedFindings`, so a clean default run raises no warnings. During `hot-user-fanout`, operations involving `feed-store` should become slower. During `fanout-worker-loss`, backlog behind `post-topic` should grow while fan-out capacity is reduced. During `feed-cache-loss`, reads should shift toward `feed-store`.

## Common Failure Modes
- `hot-user-fanout`: `partition-hotspot` on `feed-store` from 15000 ms to 36000 ms adds 200 ms latency.
- `fanout-worker-loss`: `capacity-reduction` on `fanout-worker` from 12000 ms to 34000 ms applies `capacityMultiplier: 0.3`.
- `feed-cache-loss`: `cache-failure` on `feed-cache` from 15000 ms to 30000 ms removes the cache benefit and shifts read pressure to `feed-store`.

## Trade-Offs
Fan-out on write improves read latency by precomputing feeds, but it can create write amplification and lag for hot users. The cache-backed read path is fast when `feed-cache` is healthy, but cache loss increases storage pressure. Eventual consistency and replication lag make freshness directional rather than immediate.

## Simulator Limitations
Follower graph traversal is a single request hop, not a real graph query. Ranking, relevance scoring, ad insertion, feed deduplication, and pagination cursors are not modelled.

Stand-ins are explicit. `Social graph store` is modelled as the `nosql-database` component `graph-store`, so graph traversal algorithms, follower expansion, and graph-query semantics are not simulated. The simulator has no persistent-connection or WebSocket transport model and no first-class rate limiter or WAF node in this scenario.

## Extension Exercises
Raise `fanout-worker` count until feed lag stays under one second during `hot-user-fanout`. Switch conceptually to fan-out on read by removing `post-topic` and querying `graph-store` directly. Compare educational cost estimates between those strategies.
