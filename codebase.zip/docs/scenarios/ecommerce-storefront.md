---
template-id: ecommerce-storefront
template-version: 1.0.0
difficulty: intermediate
estimated-minutes: 40
---

# E-Commerce Storefront

## Overview

E-Commerce Storefront is an intermediate, read-heavy and availability-sensitive scenario. It decomposes browsing, cart, and checkout behind `gateway`, uses cached product reads through `product-cache`, stores cart state in `session-store`, writes orders to `order-db`, and emits order events to workers through `order-queue`.

## Learning Objectives

Use this scenario to separate the synchronous checkout path from asynchronous inventory and notification work, compare cached product reads with uncached writes, watch queue depth build when a consumer stalls, and reason about partial failure where browsing can continue while checkout degrades.

## Architecture Summary

Traffic flows from `client` through `cdn` and `gateway`. `gateway` delegates validation to `identity` and fans out to `product-svc`, `cart-svc`, and `order-svc` with weights 6, 3, and 1. Product reads use `product-cache` and `product-db`; carts use `session-store`; checkout writes to `order-db` and emits events to `order-queue`, which feeds `inventory-worker` and `notification-worker`.

## Functional Requirements

The storefront serves product browsing, cart access, and checkout requests. Product traffic reads through a cache-backed service, cart traffic uses a session-style cache lookup, checkout writes orders synchronously, and follow-up inventory and notification work is asynchronous through a queue.

## Non-Functional Requirements

The template models gateway fan-out, identity token validation with cacheHitRatio 0.9, independently scaled services, queue depth and consumer lag, and the blast radius of one database failing while the rest of the system serves traffic. It does not model payment authorisation, inventory reservation, overselling, distributed transactions, or sticky sessions.

## Components and Responsibilities

| Node ID | Type | Display Name | Key Configuration | Responsibility |
| --- | --- | --- | --- | --- |
| `client` | client | Shopper Client | No additional configuration | Starts shopper traffic. |
| `cdn` | cdn | CDN | technology `amazon-cloudfront`; hitRatio 0.45; baseLatencyMs 12 | Serves CDN hits and forwards misses to the gateway. |
| `gateway` | api-gateway | API Gateway | technology `kong-gateway`; authMode `delegate`; policyLatencyMs 3; perInstanceCapacityRps 3000 | Applies gateway policy and fans traffic to identity and services. |
| `identity` | identity-auth-service | Identity Service | technology `auth0`; instanceCount 2; mode `authn`; validationMode `local-jwt`; cacheHitRatio 0.9; failMode `fail-closed`; perInstanceCapacityRps 1200 | Validates authentication decisions for gateway traffic. |
| `product-svc` | server | Product Service | technology `spring-boot`; instanceCount 4; perInstanceCapacityRps 150; baseLatencyMs 20; jitterMs 8; estimatedCostPerHour 0.24 | Handles product requests and calls the product cache. |
| `product-cache` | cache | Product Cache | technology `redis`; hitRatio 0.88; ttlMs 120000; baseLatencyMs 1; perInstanceCapacityRps 6000 | Serves cached product reads and forwards misses. |
| `product-db` | relational-database | Product Database | technology `postgresql`; perInstanceCapacityRps 400; baseLatencyMs 20; estimatedCostPerHour 0.28 | Stores product data for cache misses. |
| `cart-svc` | server | Cart Service | technology `nodejs`; instanceCount 3; perInstanceCapacityRps 120; baseLatencyMs 15; estimatedCostPerHour 0.15 | Handles cart requests and calls the session store. |
| `session-store` | cache | Session Store | technology `amazon-elasticache`; hitRatio 0.95; ttlMs 1800000; baseLatencyMs 2; perInstanceCapacityRps 5000 | Stores session-backed cart state as keyed cache data. |
| `order-svc` | server | Order Service | technology `spring-boot`; instanceCount 3; perInstanceCapacityRps 80; baseLatencyMs 45; jitterMs 15; maxRetries 1; estimatedCostPerHour 0.2 | Processes checkout, writes orders, and emits order events. |
| `order-db` | relational-database | Order Database | technology `amazon-aurora`; perInstanceCapacityRps 250; baseLatencyMs 28; estimatedCostPerHour 0.45 | Stores order records for checkout. |
| `order-queue` | message-queue | Order Events | technology `amazon-sqs`; maxQueueDepth 20000; retentionMs 3600000; perInstanceCapacityRps 3000 | Buffers asynchronous order events for workers. |
| `inventory-worker` | worker | Inventory Worker | technology `celery`; instanceCount 3; perInstanceCapacityRps 40; baseLatencyMs 70; maxProcessingAttempts 3; estimatedCostPerHour 0.12 | Consumes order events for inventory work. |
| `notification-worker` | worker | Notification Worker | technology `sidekiq`; instanceCount 2; perInstanceCapacityRps 60; baseLatencyMs 40; estimatedCostPerHour 0.08 | Consumes order events for notification work. |

## Request and Event Flows

Browsing starts `client` -> `cdn` as a request edge, `cdn` -> `gateway` as a request edge with 8 ms latency, `gateway` -> `identity` as a request edge with 2 ms latency, `gateway` -> `product-svc` as a request edge with 2 ms latency and weight 6, `product-svc` -> `product-cache` as a request edge with 1 ms latency, and `product-cache` -> `product-db` as a request edge with 2 ms latency on misses. Cart traffic uses `gateway` -> `cart-svc` as a request edge with 2 ms latency and weight 3, then `cart-svc` -> `session-store` as a request edge with 1 ms latency. Checkout uses `gateway` -> `order-svc` as a request edge with 2 ms latency and weight 1, then `order-svc` -> `order-db` as a request edge with 3 ms latency. Follow-up work uses `order-svc` -> `order-queue` as an event edge with 2 ms latency, then `order-queue` -> `inventory-worker` and `order-queue` -> `notification-worker` as event edges with 2 ms latency each. There are no replication, failover, or observability edges.

## Data Model and Storage Assumptions

`product-db` stores product data behind `product-cache`. `session-store` is modelled as cache-based session state with ttlMs 1800000 and hitRatio 0.95. `order-db` stores checkout order records. `order-queue` stores order events up to maxQueueDepth 20000 and retentionMs 3600000 for worker consumption.

## Technology Suggestions

The template assigns `amazon-cloudfront`, `kong-gateway`, `auth0`, `spring-boot`, `redis`, `postgresql`, `nodejs`, `amazon-elasticache`, `amazon-aurora`, `amazon-sqs`, `celery`, and `sidekiq` to components. These names are educational metadata and simulation presets only; they do not require cloud credentials, provisioning, or online connectivity.

## Traffic Profile

The default traffic profile is `storefront-traffic`: Storefront 400 RPS for 45000 ms at 400 RPS, readRatio 0.85, and concurrentUsers 900. The alternate `flash-sale` burst runs for 60000 ms, starts at 300 RPS, peaks at 1600 RPS from 20000 ms to 35000 ms, and uses readRatio 0.7 with concurrentUsers 2500.

## Capacity and Scaling Assumptions

`product-svc` has 4 instances at 150 RPS each, `cart-svc` has 3 instances at 120 RPS each, and `order-svc` has 3 instances at 80 RPS each. `inventory-worker` has 3 instances at 40 RPS each and `notification-worker` has 2 instances at 60 RPS each. The gateway weights make product traffic the largest share, while checkout is lower volume but depends on `order-db` and the event queue.

## Caching Strategy

`cdn` has hitRatio 0.45 and baseLatencyMs 12 before requests reach `gateway`. `identity` uses cacheHitRatio 0.9 for local JWT validation behaviour. `product-cache` has hitRatio 0.88, ttlMs 120000, baseLatencyMs 1, and capacity 6000 RPS. `session-store` has hitRatio 0.95, ttlMs 1800000, baseLatencyMs 2, and capacity 5000 RPS. The session store is a cache stand-in; no sticky routing is modelled.

## Reliability and Failure Handling

The default fault scenario is `checkout-database-failure`. It contains fault `order-db-1`, a `database-primary-failure` targeting `order-db` from 15000 ms to 32000 ms. `inventory-consumer-stall` contains fault `stall-1`, a `queue-consumer-failure` targeting `inventory-worker` from 12000 ms to 36000 ms. `cache-eviction-storm` contains fault `cache-1`, a `cache-failure` targeting `product-cache` from 15000 ms to 30000 ms.

## Security Considerations

`gateway` uses authMode `delegate`, and `identity` is an authn component with validationMode `local-jwt`, cacheHitRatio 0.9, failMode `fail-closed`, and two instances. The simulator models validation latency and capacity, not real credentials, token issuance, payment authorisation, or provider security controls.

## Observability Plan

There is no observability node and no observability edge. Use simulator metrics to inspect service utilisation, identity capacity, product cache hit and miss behaviour, order database impact, queue depth, worker lag, success rate, and p95 latency under `storefront-traffic` and `flash-sale`.

## Simulation Exercises

Run `storefront-traffic` as the baseline and verify that product, cart, and checkout paths show different utilisation. Run `flash-sale` to observe the effect of higher read load. Then run `checkout-database-failure`, `inventory-consumer-stall`, and `cache-eviction-storm` separately to compare partial checkout failure, queue backlog, and product cache loss.

## Expected Results

`expectedFindings` is empty, so a clean default run raises no warnings. During `checkout-database-failure`, checkout success should degrade while browsing and cart paths can continue. During `inventory-consumer-stall`, `order-queue` depth should rise and `inventory-worker` lag should increase. During `cache-eviction-storm`, product database utilisation and product-read p95 should rise.

## Common Failure Modes

`checkout-database-failure` models a `database-primary-failure` on `order-db` from 15000 ms to 32000 ms, affecting checkout. `inventory-consumer-stall` models a `queue-consumer-failure` on `inventory-worker` from 12000 ms to 36000 ms, allowing queue depth to build. `cache-eviction-storm` models a `cache-failure` on `product-cache` from 15000 ms to 30000 ms, shifting product reads to `product-db`.

## Trade-Offs

Service decomposition limits blast radius and lets browsing, cart, and checkout scale differently, but it introduces more synchronous hops and an asynchronous queue to monitor. Product caching reduces read pressure on `product-db`, while checkout remains more sensitive to the availability of `order-db`.

## Simulator Limitations

Simplifications are explicit: cart state is a cache lookup with no session affinity or sticky routing; inventory reservation, overselling, and distributed transactions are not modelled; payment authorisation is out of scope. Stand-in: the real-world concept `Session store` is modelled as `cache`, so session replication protocols, persistence modes, failover topology, and sticky-session behaviour are not simulated.

## Extension Exercises

Run `inventory-consumer-stall` and find when depth exceeds `order-queue` maxQueueDepth 20000. Halve `product-cache` hitRatio from 0.88 and identify which component saturates first. Add a read replica for `product-db` and route reads to it.
