---
template-id: video-streaming-platform
template-version: 1.0.0
difficulty: advanced
estimated-minutes: 55
---

# Video Streaming Platform

## Overview
This advanced scenario separates high-volume playback reads from upload and transcoding work. Viewers use an edge cache in front of rendition object storage, while creators upload raw media that is converted by workers consuming a partitioned job topic. Use it with the [user guide](../user-guide/README.md) and the scenario library index at [./README.md](./README.md). All technology names are educational metadata for an offline simulator.

## Learning Objectives
You compare a bandwidth-heavy read path against a compute-heavy write path by following playback through `edge`, `playback`, `catalog`, and `renditions`, then uploads through `upload`, `raw-storage`, and `transcode-topic`. The CDN objective is represented by `edge` hit ratio and origin request behavior. Worker sizing is based on job arrival rate because `transcoder` drains `transcode-topic` with only 8 instances at 6 RPS each. The upload-spike profile shows how the topic can absorb work while the worker pool catches up.

## Architecture Summary
`client` first reaches `edge`, the CDN stand-in for playback. Cache misses can read `renditions` directly or pass through `gateway` to `playback`, which reads video metadata from `catalog`. Uploads go from `gateway` to `upload`, which stores raw content in `raw-storage` and emits jobs to `transcode-topic`. `transcoder` consumes those jobs, writes finished renditions to `renditions`, updates `catalog`, and emits observability signals to `telemetry`.

## Functional Requirements
- Serve playback through an edge cache and rendition object store.
- Route API requests through a gateway to playback or upload services.
- Persist video metadata in a catalogue store.
- Store raw uploads separately from generated renditions.
- Publish transcode jobs to a partitioned event topic.
- Move failed transcode jobs to a dead-letter queue.

## Non-Functional Requirements
The workload is read-heavy and throughput-sensitive. Playback performance depends on CDN hit ratio and origin capacity. Upload processing depends on topic depth, partitioning, and worker throughput. The simulator does not model bitrate ladders, adaptive-bitrate decisions, bytes transferred, DRM, licensing, moderation, or egress cost.

## Components and Responsibilities
| Node ID | Type | Display Name | Key Configuration | Responsibility |
|---|---|---|---|---|
| `client` | client | Viewer Client | no additional config | Generates viewer and creator requests. |
| `edge` | cdn | Streaming Edge | technology `akamai-cdn`; hit ratio 0.93; base 10 ms | Serves cached playback traffic and shields origin. |
| `gateway` | api-gateway | API Gateway | technology `kong-gateway`; auth none; policy 2 ms; capacity 6000 RPS | Routes API calls to playback and upload services. |
| `playback` | server | Playback Service | technology `nodejs`; 6 instances; 200 RPS each; base 14 ms; jitter 5 ms; cost 0.36/hour | Handles playback metadata requests. |
| `upload` | server | Upload Service | technology `nodejs`; 3 instances; 40 RPS each; base 60 ms; jitter 25 ms; cost 0.18/hour | Stores raw uploads and emits transcode jobs. |
| `catalog` | nosql-database | Video Catalogue | technology `amazon-dynamodb`; document model; eventual consistency; 16 partitions; lag 40 ms; capacity 1200 RPS; base 9 ms | Stores video metadata and rendition state. |
| `raw-storage` | object-storage | Raw Upload Bucket | technology `amazon-s3`; capacity 300 RPS; base 40 ms; cost 0.08/hour | Stores uploaded source media. |
| `renditions` | object-storage | Rendition Bucket | technology `amazon-s3`; capacity 900 RPS; base 32 ms; cost 0.22/hour | Stores generated playback renditions and serves origin reads. |
| `transcode-topic` | event-topic | Transcode Jobs | technology `apache-kafka`; 12 partitions; ordering `partition`; retention 7200000 ms; max depth 20000; capacity 8000 RPS | Buffers transcode jobs. |
| `transcoder` | worker | Transcoding Workers | technology `aws-fargate`; 8 instances; 6 RPS each; base 900 ms; jitter 300 ms; cost 1.6/hour | Converts upload jobs into renditions and metadata updates. |
| `transcode-dlq` | dead-letter-queue | Failed Transcodes | technology `apache-pulsar`; max depth 3000 | Holds failed transcode jobs. |
| `telemetry` | observability | Telemetry | technology `grafana`; capacity 25000 RPS | Collects playback and transcoder signals. |

## Request and Event Flows
**Synchronous playback flow.** `client` → `edge` is a request edge. On origin access, `edge` → `renditions` is a request edge with 12 ms latency. API playback also follows `edge` → `gateway` as a request edge with 8 ms latency, `gateway` → `playback` as a request edge with 2 ms latency, and `playback` → `catalog` as a request edge with 2 ms latency.

**Synchronous upload flow.** Upload API traffic follows `edge` → `gateway` as a request edge with 8 ms latency, then `gateway` → `upload` as a request edge with 2 ms latency. `upload` → `raw-storage` is a request edge with 6 ms latency.

**Asynchronous transcode flow.** `upload` → `transcode-topic` is an event edge with 2 ms latency. `transcode-topic` → `transcoder` is an event edge with 2 ms latency. After processing, `transcoder` → `renditions` is a request edge with 8 ms latency and `transcoder` → `catalog` is a request edge with 3 ms latency.

**Failover flow.** `transcode-topic` → `transcode-dlq` is a failover edge with 1 ms latency.

**Observability flow.** `playback` → `telemetry` and `transcoder` → `telemetry` are observability edges.

## Data Model and Storage Assumptions
`catalog` is a document-model NoSQL store with eventual consistency, 16 partitions, and 40 ms replication lag. `raw-storage` holds source media, while `renditions` holds generated playback assets. `transcode-topic` retains jobs for 7200000 ms with max depth 20000; `transcode-dlq` holds failed jobs up to depth 3000. A playback request is one logical request, not a sequence of media segments.

## Technology Suggestions
The template assigns `akamai-cdn`, `kong-gateway`, `nodejs`, `amazon-dynamodb`, `amazon-s3`, `apache-kafka`, `aws-fargate`, `apache-pulsar`, and `grafana`. These are simulator labels and presets only, not provisioning guidance.

## Traffic Profile
The default profile is `evening-playback-peak`. It runs for 60000 ms: 300 RPS from 0-20000 ms, ramps from 300 to 1400 RPS from 20000-40000 ms, and holds 1400 RPS from 40000-60000 ms, with `readRatio` 0.95 and 9000 concurrent users. The alternate `upload-spike` profile runs for 60000 ms: 250 RPS from 0-18000 ms, a 900 RPS burst from 18000-32000 ms, then 250 RPS from 32000-60000 ms, with `readRatio` 0.55.

## Capacity and Scaling Assumptions
Playback capacity is spread across `edge`, `gateway`, `playback`, `catalog`, and `renditions`. `playback` has 6 instances at 200 RPS each. `renditions` handles 900 RPS as origin storage. Upload capacity is smaller: `upload` has 3 instances at 40 RPS each, and `raw-storage` handles 300 RPS. Transcoding capacity is 8 workers at 6 RPS each, so backlog is expected when job arrival exceeds worker drain.

## Caching Strategy
`edge` is the primary cache with hit ratio 0.93 and base latency 10 ms. High hit ratio keeps playback away from `renditions` and reduces pressure on API metadata paths. Lowering the hit ratio should move more request pressure to origin and playback components.

## Reliability and Failure Handling
The default fault scenario is `transcoder-stall`. It contains fault `tc-stall`, type `queue-consumer-failure`, targeting `transcoder` from 16000 ms to 42000 ms. Scenario `edge-miss-storm` contains fault `edge-cold`, type `cache-failure`, targeting `edge` from 14000 ms to 36000 ms. Scenario `origin-degraded` contains fault `origin-slow`, type `degradation`, targeting `renditions` from 18000 ms to 40000 ms with capacity multiplier 0.4 and 120 ms added latency.

## Security Considerations
The gateway uses `authMode: none` in this template, so authentication and authorization are outside the scenario. DRM, license issuance, content moderation, signed URLs, and access control are not modelled. No online storage or cloud credentials are used.

## Observability Plan
Use `telemetry` to inspect playback service pressure and transcoder behavior. Key signals are edge hit/miss effects, origin pressure on `renditions`, `transcode-topic` backlog, `transcoder` utilization, and failed transcode movement to `transcode-dlq`.

## Simulation Exercises
Start with `evening-playback-peak` and no faults. Run `edge-miss-storm` to see origin pressure after cache failure. Run `upload-spike` with and without `transcoder-stall` to observe backlog behavior. Run `origin-degraded` to study how slower rendition storage affects playback.

## Expected Results
Because `expectedFindings` is empty, a clean default run raises no architecture warnings. The meaningful behavior is fault-driven: cache failure should increase origin pressure, transcoder stall should grow job backlog, and origin degradation should increase playback latency and reduce effective origin capacity.

## Common Failure Modes
`transcoder-stall` / `tc-stall` is a `queue-consumer-failure` against `transcoder` from 16000 to 42000 ms. `edge-miss-storm` / `edge-cold` is a `cache-failure` against `edge` from 14000 to 36000 ms. `origin-degraded` / `origin-slow` is a `degradation` fault against `renditions` from 18000 to 40000 ms with capacity multiplier 0.4 and 120 ms added latency.

## Trade-Offs
A high CDN hit ratio protects origin but can hide origin capacity limits until a cold-cache event. A partitioned topic allows upload bursts to be buffered, but worker count and per-worker capacity still set transcode throughput. Object storage separates raw and rendered assets, but byte-level bandwidth and cost are not represented.

## Simulator Limitations
The media transcoding pipeline is modelled as a `worker`; therefore codec choices, per-asset job length, bitrate ladders, segment sizes, and adaptive-bitrate switching are not simulated. The video metadata catalogue is modelled as a `nosql-database`; catalogue schema and query semantics are not simulated. The simulator has no failover-controller, workflow-orchestrator, search-engine, vector-index, or CDC component. It also does not model DRM, content moderation, bandwidth, or egress cost.

## Extension Exercises
Lower `edge` hit ratio to 0.6 and identify which component saturates first. Run `upload-spike` and adjust the `transcoder` pool so backlog drains before the run ends. Increase `transcode-topic` `partitionCount` and explain why partitions alone do not help without enough workers.
