---
template-id: chat-application
template-version: 1.0.0
difficulty: intermediate
estimated-minutes: 40
---
# Chat Application

## Overview
This scenario documents the `chat-application` template. It models a messaging backend where `chat-svc` persists messages, checks presence, and publishes events for delivery and archive workers. Use it with `./README.md` and `../user-guide/README.md`.

The workload is write-heavy, latency-sensitive, and throughput-sensitive. The simulator models arrivals and event fan-out, not real sockets.

## Learning Objectives
Learners model fan-out through `topic`, an `event-topic` with independent subscriber groups for `delivery-worker` and `archive-worker`. They distinguish message persistence in `messages` from message delivery, so accepted messages and delivered messages can be reasoned about separately.

The scenario also shows consumer lag: when delivery cannot keep up, backlog accumulates even if ingest remains available. Because `topic` uses 12 partitions with `orderingScope: partition`, ordering is partition-scoped rather than global or per-conversation.

## Architecture Summary
The request path is `client` -> `gateway` -> `chat-svc`. The service calls `presence`, writes `messages`, and publishes to `topic`. The topic fans events out to `delivery-worker` and `archive-worker`; `delivery-worker` also calls `presence`.

There is no CDN, queue, dead-letter queue, or observability node.

## Functional Requirements
- Accept chat requests from `client` through `gateway`.
- Route validated traffic to `chat-svc`.
- Store messages in `messages`.
- Track short-lived presence in `presence`.
- Publish message events to `topic`.
- Deliver and archive messages through separate workers.

## Non-Functional Requirements
- Keep the ingest path latency-sensitive with low configured latencies.
- Sustain the default `chat-traffic` write-heavy load.
- Scale `chat-svc`, `delivery-worker`, and `archive-worker` independently.
- Make topic lag visible when a subscriber group stalls.
- Use the wide-column message store to discuss persistence and replication-lag trade-offs.

## Components and Responsibilities
| Node ID | Type | Display Name | Key Configuration | Responsibility |
| --- | --- | --- | --- | --- |
| `client` | client | Chat Client | display name only | Generates simulated chat requests. |
| `gateway` | api-gateway | Realtime Gateway | `apache-apisix`; `authMode: validate-local`; `policyLatencyMs: 2`; `perInstanceCapacityRps: 6000` | Routes realtime requests and applies local auth policy. |
| `chat-svc` | server | Chat Service | `nestjs`; `instanceCount: 6`; `perInstanceCapacityRps: 200`; `baseLatencyMs: 12`; `jitterMs: 6`; `estimatedCostPerHour: 0.36` | Handles ingest, presence lookup, persistence, and event publication. |
| `presence` | cache | Presence Store | `redis`; `hitRatio: 0.97`; `ttlMs: 60000`; `baseLatencyMs: 1`; `perInstanceCapacityRps: 12000` | Stores short-lived presence state. |
| `messages` | nosql-database | Message Store | `apache-cassandra`; `model: wide-column`; `consistency: quorum`; `partitionCount: 32`; `hotPartitionSkew: 0.1`; `replicationLagMs: 30`; `perInstanceCapacityRps: 900`; `baseLatencyMs: 14`; `estimatedCostPerHour: 0.5` | Persists messages. |
| `topic` | event-topic | Message Topic | `apache-kafka`; `partitionCount: 12`; `orderingScope: partition`; `retentionMs: 86400000`; `maxQueueDepth: 200000`; `perInstanceCapacityRps: 20000` | Fans message events to independent subscribers. |
| `delivery-worker` | worker | Delivery Worker | `nodejs`; `instanceCount: 8`; `perInstanceCapacityRps: 150`; `baseLatencyMs: 18`; `maxProcessingAttempts: 3`; `estimatedCostPerHour: 0.32` | Delivers messages and checks presence. |
| `archive-worker` | worker | Archive Worker | `celery`; `instanceCount: 2`; `perInstanceCapacityRps: 300`; `baseLatencyMs: 25`; `estimatedCostPerHour: 0.08` | Archives consumed message events. |

## Request and Event Flows
- `client` -> `gateway` is a `request` edge; `gateway` -> `chat-svc` is a `request` edge with 2 ms latency.
- `chat-svc` -> `presence` is a `request` edge with 1 ms latency.
- `chat-svc` -> `messages` is a `request` edge with 2 ms latency.
- `chat-svc` -> `topic` is an `event` edge with 1 ms latency.
- `topic` -> `delivery-worker` and `topic` -> `archive-worker` are `event` edges with 2 ms latency each.
- `delivery-worker` -> `presence` is a `request` edge with 1 ms latency.
- The template has no `replication`, `failover`, or `observability` edges.

## Data Model and Storage Assumptions
`messages` is a wide-column NoSQL store with quorum consistency, 32 partitions, hot-partition skew of 0.1, 30 ms replication lag, 900 RPS per-instance capacity, and 14 ms base latency. `presence` is keyed TTL state with a 60000 ms TTL and 0.97 hit ratio. `topic` retains events for 86400000 ms and has `maxQueueDepth: 200000`.

## Technology Suggestions
The template assigns `apache-apisix`, `nestjs`, `redis`, `apache-cassandra`, `apache-kafka`, `nodejs`, and `celery`. These names are educational metadata only; they do not provision services and require no online connectivity or credentials.

## Traffic Profile
Default traffic profile: `chat-traffic`.

- `chat-traffic` (`Messaging 900 RPS`): constant, 45000 ms, 900 RPS, `readRatio: 0.35`, `concurrentUsers: 5000`, `requestSizeBytes: 512`, `responseSizeBytes: 256`.
- `evening-peak` (`Evening peak`): ramp, 60000 ms, 600 RPS to 3000 RPS, `readRatio: 0.35`, `concurrentUsers: 12000`.

## Capacity and Scaling Assumptions
`gateway` has 6000 RPS per-instance capacity. `chat-svc` has 6 instances at 200 RPS each. `messages` has 900 RPS per-instance capacity, and `topic` has 20000 RPS per-instance capacity. `delivery-worker` has 8 instances at 150 RPS each, while `archive-worker` has 2 instances at 300 RPS each.

## Caching Strategy
The only cache is `presence`, with `hitRatio: 0.97`, `ttlMs: 60000`, `baseLatencyMs: 1`, and `perInstanceCapacityRps: 12000`. There is no CDN cache and no message-history cache.

## Reliability and Failure Handling
Default fault scenario: `delivery-backlog`.

- `delivery-backlog`: fault `stall-1`, type `subscriber-group-stall`, targets `delivery-worker`, starts at 15000 ms and ends at 33000 ms.
- `message-store-pressure`: fault `hot-1`, type `partition-hotspot`, targets `messages`, starts at 12000 ms and ends at 34000 ms, with `additionalLatencyMs: 160`.

Persistence and delivery are separated, so a delivery stall primarily affects `topic` lag and `delivery-worker`, while message-store pressure affects writes to `messages`.

## Security Considerations
`gateway` uses `authMode: validate-local`. The template has no identity service, WAF node, or first-class persistent-connection security model.

## Observability Plan
The template has no observability node and no `observability` edges. Use simulator metrics for `topic` depth, subscriber lag, node utilization, success and failure counts, and latency changes during faults.

## Simulation Exercises
Run `chat-traffic` without faults, then run `delivery-backlog` and watch `topic` backlog and `delivery-worker` lag. Run `message-store-pressure` and compare message-store latency. Try raising `topic` partitions from 12 to 48 and describe the ordering effect.

## Expected Results
The template declares no `expectedFindings`, so a clean default run raises no warnings. During `delivery-backlog`, queue depth or lag on `topic` should grow while `delivery-worker` is stalled, then drain directionally after the fault ends if capacity allows. During `message-store-pressure`, requests involving `messages` should become slower.

## Common Failure Modes
- `delivery-backlog`: `subscriber-group-stall` on `delivery-worker` from 15000 ms to 33000 ms causes delivery lag behind `topic`.
- `message-store-pressure`: `partition-hotspot` on `messages` from 12000 ms to 34000 ms adds 160 ms latency.

## Trade-Offs
Separating `messages` from `topic` protects persistence concerns from delivery concerns, but accepted and delivered messages must be interpreted separately. Partitioned topics improve throughput, but ordering is only partition-scoped. Presence in a cache is fast and short-lived, but not durable user state.

## Simulator Limitations
Persistent connections are conceptual: the simulator models arrivals, not sockets, and has no persistent-connection or WebSocket transport model. No per-conversation ordering is enforced beyond topic partition ordering. Read receipts, typing indicators, and history pagination are not modelled.

Stand-ins are explicit. `WebSocket gateway` is modelled as the `api-gateway` component `gateway`, so connection lifecycle and WebSocket transport are not simulated. `Presence store` is modelled as the `cache` component `presence`, so rich presence semantics beyond keyed TTL state are not simulated. The simulator has no first-class rate limiter or WAF node in this scenario.

## Extension Exercises
Raise `topic` partitions from 12 to 48 and describe partition-scoped ordering. Run `delivery-backlog` and observe how long backlog takes to drain. Add a dead-letter queue conceptually for messages exceeding `delivery-worker` attempts and explain the changed event paths.
