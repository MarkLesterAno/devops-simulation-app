---
template-id: basic-web-application
template-version: 1.0.0
difficulty: beginner
estimated-minutes: 20
---

# Basic Web Application

## Overview

Basic Web Application is a beginner scenario for a single synchronous path from `client` through `dns` and `lb` to `app` and `db`. It is read-heavy and latency-sensitive, and it demonstrates per-hop latency, instance capacity, queueing once capacity is exceeded, and the effect of losing a component.

## Learning Objectives

Use this scenario to trace a request from the browser client to the primary database and back, then read utilisation to identify whether the application server or database saturates first. The template also asks you to recognise single points of failure from the architecture alone and to observe how a node outage changes success rate and latency.

## Architecture Summary

The canvas contains `client` -> `dns` -> `lb` -> `app` -> `db`. DNS uses a failover policy with a 60 second TTL, the load balancer fronts one Node.js application server instance, and the application server calls one PostgreSQL relational database. There is no cache, queue, replica, or observability node in this blueprint.

## Functional Requirements

The system accepts browser requests, resolves traffic through DNS, routes through the load balancer, executes application logic on `app`, and reads or writes relational data in `db`. The template models the complete synchronous request path rather than background jobs or event processing.

## Non-Functional Requirements

The scenario focuses on latency, capacity, and availability. It models base latency and jitter on `app` and `db`, per-instance RPS limits on `lb`, `app`, and `db`, and total component loss during a fault. TLS handshakes, connection pooling, keep-alive behaviour, database connection limits, and lock contention are not modelled.

## Components and Responsibilities

| Node ID | Type | Display Name | Key Configuration | Responsibility |
| --- | --- | --- | --- | --- |
| `client` | client | Browser Client | No additional configuration | Starts the simulated browser request path. |
| `dns` | dns-traffic-manager | DNS | technology `cloudflare-dns`; ttlSeconds 60; policy `failover` | Represents DNS resolution before traffic reaches the load balancer. |
| `lb` | load-balancer | Load Balancer | technology `aws-application-load-balancer`; perInstanceCapacityRps 5000 | Routes request traffic to the application server. |
| `app` | server | Application Server | technology `nodejs`; instanceCount 1; perInstanceCapacityRps 120; baseLatencyMs 35; jitterMs 12; estimatedCostPerHour 0.12 | Runs the application tier and calls the database. |
| `db` | relational-database | Primary Database | technology `postgresql`; perInstanceCapacityRps 300; baseLatencyMs 22; jitterMs 6; estimatedCostPerHour 0.25 | Stores the relational data used by the application. |

## Request and Event Flows

The only concrete path is synchronous: `client` -> `dns` is a request edge, `dns` -> `lb` is a request edge with 4 ms latency, `lb` -> `app` is a request edge with 2 ms latency, and `app` -> `db` is a request edge with 3 ms latency. There are no event, replication, failover, or observability edges in the template.

## Data Model and Storage Assumptions

`db` is a single logical relational database named Primary Database. The simulator treats it as one node with 300 RPS capacity, 22 ms base latency, and 6 ms jitter. It does not model table design, connection pools, lock contention, replicas, or backup behaviour.

## Technology Suggestions

The template assigns `cloudflare-dns` to `dns`, `aws-application-load-balancer` to `lb`, `nodejs` to `app`, and `postgresql` to `db`. These names are educational metadata and simulation presets only; they are not provisioning instructions and do not require online connectivity.

## Traffic Profile

The default traffic profile is `steady-100`: Steady 100 RPS for 30000 ms at 100 RPS with readRatio 0.8. The alternate `lunch-peak` burst profile runs for 40000 ms, starts at 80 RPS, peaks at 260 RPS between 15000 ms and 25000 ms, and uses readRatio 0.8.

## Capacity and Scaling Assumptions

`app` has one instance at 120 RPS, while `db` has 300 RPS and `lb` has 5000 RPS. Because the application tier has the lowest declared request capacity, utilisation on `app` is the first signal to watch as traffic approaches or exceeds steady demand. Scaling experiments should adjust `instanceCount` or `perInstanceCapacityRps` rather than assuming automatic infrastructure changes.

## Caching Strategy

This scenario has no cache node. Every application request that needs storage continues from `app` to `db`; there is no hit ratio, TTL, or cache-miss path to tune.

## Reliability and Failure Handling

The default fault scenario is `app-server-outage`. It contains fault `outage-1`, a `node-outage` targeting `app` from 12000 ms to 20000 ms. The second fault scenario is `database-slowdown`; fault `latency-1` is a `latency-increase` targeting `db` from 10000 ms to 25000 ms with additionalLatencyMs 180.

## Security Considerations

The template does not include an identity, authentication, authorisation, WAF, or secrets component. Security-related behaviour is outside this scenario except for recognising that all requests traverse the same exposed client-to-server path.

## Observability Plan

There is no observability node and no observability edge. Use the simulator's built-in metrics to inspect latency, success rate, queueing, overflow, and utilisation for `lb`, `app`, and `db` during the selected traffic and fault profiles.

## Simulation Exercises

Run `steady-100` first and inspect whether the expected `single-point-of-failure` finding appears. Then run `lunch-peak` to compare the application server's utilisation at peak traffic. Finally, run `app-server-outage` and `database-slowdown` separately to compare total component loss against a slower dependency.

## Expected Results

A default run is expected to raise `single-point-of-failure`. Under higher traffic, utilisation on `app` should rise before `db` saturates, and p95 latency should increase as queueing appears. During `app-server-outage`, success rate should fall sharply while `app` is unavailable. During `database-slowdown`, p95 should rise on paths that wait for `db`.

## Common Failure Modes

`app-server-outage` models a `node-outage` on `app` from 12000 ms to 20000 ms, so the only application server becomes unavailable. `database-slowdown` models a `latency-increase` on `db` from 10000 ms to 25000 ms, adding 180 ms and making the database path slower without removing the database node.

## Trade-Offs

The design is simple and easy to reason about, but it has no redundancy at the application or database tier. Keeping one synchronous path makes bottlenecks clear, while omitting caches, replicas, and queues limits availability and hides more advanced consistency and recovery choices.

## Simulator Limitations

Simplifications are explicit: TLS handshakes, connection pooling, and keep-alive are not modelled; the database is a single logical node without connection limits or lock contention; DNS is one TTL-based hop rather than a recursive resolver hierarchy. There are no stand-ins in this template.

## Extension Exercises

Raise `app` to three instances and compare p95 latency before and after. Add a read replica and route read traffic to it. Lower `db` capacity until the database, not `app`, becomes the bottleneck, then compare utilisation and latency changes.
