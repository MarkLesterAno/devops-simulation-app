---
template-id: payment-processing-workflow
template-version: 1.0.0
difficulty: advanced
estimated-minutes: 55
---

# Payment Processing Workflow

## Overview
This advanced scenario models checkout as a synchronous order-recording path plus an asynchronous payment-settlement path. The unreliable third-party payment processor is isolated behind a circuit breaker and a settlement queue, with a dead-letter queue for failed messages. Use it with the [user guide](../user-guide/README.md) and the scenario library index at [./README.md](./README.md). The simulator is offline; technology labels do not provision real services.

## Learning Objectives
You learn to keep a third-party dependency out of the user-facing checkout response by writing the order first and settling payment asynchronously. The circuit breaker objective is demonstrated by `psp-breaker`, which can stop calls from amplifying processor failures. The dead-letter objective is represented by `settlement-dlq`, which receives failed settlement work from the queue path. Idempotency is visible as metadata on `processor`, reminding learners that settlement retry behavior needs deduplication even though the simulator does not enforce it.

## Architecture Summary
`client` calls `gateway`, which validates through `identity` and forwards checkout work to `checkout`. `checkout` synchronously writes `orders-db` and publishes settlement work to `settlement-queue`. `settlement-worker` consumes queue events, calls `psp-breaker`, and then calls the `processor` external service. Failed queue work can move to `settlement-dlq`. `checkout` and `settlement-worker` emit observability data to `telemetry`.

## Functional Requirements
- Accept checkout requests through an API gateway.
- Delegate authentication checks to the identity service.
- Persist order records before payment settlement completes.
- Queue settlement work for asynchronous processing.
- Call a rate-limited payment processor through a circuit breaker.
- Preserve failed settlement messages in a dead-letter queue.

## Non-Functional Requirements
The workload is write-heavy, availability-sensitive, and consistency-sensitive. The design prioritizes bounded provider failures, queue-based backpressure, explicit retry behavior, and isolation of checkout response latency from payment processor latency. It does not model real money movement, accounting, or card-network authorization and capture stages.

## Components and Responsibilities
| Node ID | Type | Display Name | Key Configuration | Responsibility |
|---|---|---|---|---|
| `client` | client | Checkout Client | no additional config | Generates checkout traffic. |
| `gateway` | api-gateway | API Gateway | technology `amazon-api-gateway`; auth `delegate`; policy 3 ms; rate limit 400 RPS; burst 200; capacity 4000 RPS | Enforces gateway policy and forwards checkout requests. |
| `identity` | identity-auth-service | Identity Service | technology `auth0`; 2 instances; mode `authn`; `local-jwt`; cache hit ratio 0.92; fail closed; 1500 RPS each | Validates authentication for gateway requests. |
| `checkout` | server | Checkout Service | technology `spring-boot`; 4 instances; 90 RPS each; base 38 ms; jitter 14 ms; cost 0.32/hour | Writes orders and publishes settlement events. |
| `orders-db` | relational-database | Orders Database | technology `postgresql`; capacity 450 RPS; base 20 ms; jitter 7 ms; cost 0.38/hour | Stores order records synchronously. |
| `settlement-queue` | message-queue | Settlement Queue | technology `amazon-sqs`; max depth 4000; base 4 ms; capacity 5000 RPS | Buffers payment settlement work. |
| `settlement-worker` | worker | Settlement Worker | technology `temporal`; 3 instances; 45 RPS each; base 25 ms; max retries 2; backoff 400 ms; cost 0.24/hour | Processes settlement jobs and calls the processor through the breaker. |
| `psp-breaker` | circuit-breaker | Processor Breaker | technology `resilience4j`; failure threshold 0.35; base 1 ms; capacity 5000 RPS | Opens when downstream processor failures exceed the threshold. |
| `processor` | external-service | Payment Processor | technology `stripe-payments`; label `Card processor`; SLA 320 ms; provider limit 90 RPS; idempotency supported; sync call; error rate 0.01; capacity 120 RPS | Simulates a third-party payment processor. |
| `settlement-dlq` | dead-letter-queue | Settlement DLQ | technology `amazon-sqs`; max depth 2000 | Holds failed or overflowed settlement messages. |
| `telemetry` | observability | Telemetry | technology `opentelemetry`; capacity 20000 RPS | Collects checkout and settlement-worker signals. |

## Request and Event Flows
**Synchronous checkout flow.** `client` → `gateway` is a request edge. `gateway` → `identity` is a request edge with 2 ms latency, and `gateway` → `checkout` is a request edge with 2 ms latency. `checkout` → `orders-db` is a request edge with 3 ms latency, so the order is recorded before asynchronous settlement proceeds.

**Asynchronous settlement flow.** `checkout` → `settlement-queue` is an event edge with 2 ms latency. `settlement-queue` → `settlement-worker` is an event edge with 2 ms latency. `settlement-worker` → `psp-breaker` is a request edge with 1 ms latency, then `psp-breaker` → `processor` is a request edge with 25 ms latency.

**Failover flow.** `settlement-queue` → `settlement-dlq` is a failover edge with 1 ms latency for failed or overflowing settlement work.

**Observability flow.** `checkout` → `telemetry` and `settlement-worker` → `telemetry` are observability edges.

## Data Model and Storage Assumptions
`orders-db` is the durable relational order store. `settlement-queue` holds pending settlement messages up to depth 4000, while `settlement-dlq` holds failed messages up to depth 2000. `processor` advertises `idempotencySupported: true`, but the simulator treats idempotency as a configuration flag and does not perform deduplication. Ledger correctness, reconciliation, and double-entry accounting are not modelled.

## Technology Suggestions
The template uses `amazon-api-gateway`, `auth0`, `spring-boot`, `postgresql`, `amazon-sqs`, `temporal`, `resilience4j`, `stripe-payments`, and `opentelemetry` as educational technology assignments. They are metadata for simulation presets and discussion only; do not supply credentials or connect to online services.

## Traffic Profile
The default profile is `checkout-load`. It runs for 45000 ms at a constant 180 RPS with `readRatio` 0.25 and 900 concurrent users. The alternate `flash-sale` profile runs for 60000 ms: 150 RPS from 0-20000 ms, a 620 RPS burst from 20000-34000 ms, then 150 RPS from 34000-60000 ms, with `readRatio` 0.2.

## Capacity and Scaling Assumptions
`gateway` has 4000 RPS capacity but applies a 400 RPS rate limit and 200 burst. `checkout` has 4 instances at 90 RPS each. `orders-db` is 450 RPS. `settlement-worker` has 3 instances at 45 RPS each, while `processor` has provider rate limit 90 RPS and capacity 120 RPS. This means provider throttling and worker throughput can dominate queue behavior.

## Caching Strategy
There is no application cache in this scenario. The only cache-like behavior is authentication validation metadata on `identity`, which has `cacheHitRatio` 0.92 for local JWT validation. Checkout correctness should not depend on cached payment settlement state.

## Reliability and Failure Handling
The default fault scenario is `processor-throttling`. It contains fault `psp-throttle`, type `provider-throttling`, targeting `processor` from 15000 ms to 38000 ms with capacity multiplier 0.25 and additional error rate 0.3. Scenario `processor-latency` contains fault `psp-slow`, type `latency-increase`, targeting `processor` from 12000 ms to 36000 ms with 1400 ms added latency. Scenario `settlement-stall` contains fault `worker-stall`, type `queue-consumer-failure`, targeting `settlement-worker` from 14000 ms to 34000 ms.

## Security Considerations
`gateway` delegates authentication to `identity`, which runs in authentication mode with local JWT validation and fail-closed behavior. The simulator does not model PCI scope, key management, tokenization, encryption, fraud controls, or real payment credentials.

## Observability Plan
Use `telemetry` to compare checkout service behavior with settlement-worker behavior. Important signals are settlement queue depth, worker retry pressure, processor latency or throttling, circuit-breaker impact, and dead-letter movement during failure windows.

## Simulation Exercises
Run `checkout-load` with no faults to establish a clean baseline. Apply `processor-throttling` and watch for breaker behavior and queue growth. Apply `processor-latency` to separate slow provider effects from explicit throttling. Apply `settlement-stall` to observe what happens when consumers stop draining the queue.

## Expected Results
The template's `expectedFindings` array is empty, so a clean default run raises no architecture warnings. Interesting behavior should appear only after faults are applied: throttling should stress the breaker and queue, latency should stretch settlement processing, and worker stall should increase backlog.

## Common Failure Modes
`processor-throttling` / `psp-throttle` is a `provider-throttling` fault against `processor` from 15000 to 38000 ms with capacity multiplier 0.25 and extra error rate 0.3. `processor-latency` / `psp-slow` is a `latency-increase` fault against `processor` from 12000 to 36000 ms with 1400 ms added latency. `settlement-stall` / `worker-stall` is a `queue-consumer-failure` against `settlement-worker` from 14000 to 34000 ms.

## Trade-Offs
Asynchronous settlement protects checkout latency but introduces eventual settlement and queue backlog. More retries may improve transient recovery, but they can worsen provider throttling. A circuit breaker limits downstream amplification but can also pause successful calls while open.

## Simulator Limitations
The payment gateway or processor is modelled as an `external-service`; therefore no real money movement, card-network flow, credential exchange, fraud check, or provider API behavior is simulated. The workflow orchestrator is modelled as a `worker`; the simulator has no workflow-orchestrator component, so durable multi-step state and compensation are not simulated. It also has no failover-controller, search-engine, vector-index, or CDC component; those concepts are approximated by other generic components when present in other scenarios.

## Extension Exercises
Run the throttling scenario and identify when `psp-breaker` would open based on downstream failure behavior. Increase `settlement-worker` `maxRetries` and explain why retry pressure can make throttling worse. Lower `settlement-queue` `maxQueueDepth` until messages move to `settlement-dlq`.
