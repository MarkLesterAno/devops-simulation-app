---
template-id: ml-inference-platform
template-version: 1.0.0
difficulty: specialized
estimated-minutes: 55
---

# ML Inference Platform

## Overview

ML Inference Platform models a low-latency synchronous inference path and an asynchronous queue-backed path for expensive inference. Both paths share a result cache, an online feature store, a model artifact store, and observability. Use this page with the [scenario library index](./README.md) and the [user guide](../user-guide/README.md).

## Learning Objectives

This scenario teaches deciding which inference requests deserve synchronous responses, sizing a scarce low-throughput serving tier, using cache hits to avoid deterministic recomputation, and protecting expensive compute with queueing instead of retries. The key lesson is how demand transfers from synchronous serving to queue growth when capacity is reduced.

## Architecture Summary

`client` reaches `gateway`, which validates through `identity` and routes to `router`. The router checks `result-cache`, reads `feature-store`, and either calls `realtime-serving` or publishes work to `inference-queue`. `batch-serving` consumes asynchronous work, reads features, fetches artifacts from `model-registry`, and reports to `telemetry`. Realtime serving also fetches artifacts and emits telemetry.

## Functional Requirements

- Accept authenticated inference requests at `gateway`.
- Validate API keys through `identity`.
- Route requests through `router` to cache, feature lookup, realtime serving, or asynchronous queueing.
- Serve deterministic repeated work from `result-cache` when possible.
- Execute realtime inference on `realtime-serving`.
- Buffer expensive work in `inference-queue` and process it with `batch-serving`.
- Send failed queued work to `inference-dlq`.
- Fetch model artifacts from `model-registry` and emit telemetry.

## Non-Functional Requirements

The workload is latency-sensitive, throughput-sensitive, and availability-sensitive. It emphasizes scarce accelerator-like capacity, queue depth, cache-hit effects, feature-store latency, and graceful degradation when synchronous serving capacity drops.

## Components and Responsibilities

| Node ID | Type | Display Name | Key Configuration | Responsibility |
| --- | --- | --- | --- | --- |
| `client` | client | Application Client | no explicit capacity settings | Sends inference requests. |
| `gateway` | api-gateway | Inference Gateway | technology `amazon-api-gateway`; authMode `delegate`; policyLatencyMs 3; rateLimitRps 300; rateLimitBurst 150; perInstanceCapacityRps 5000 | Applies gateway policy, quota, and delegated authentication routing. |
| `identity` | identity-auth-service | API Key Service | technology `amazon-cognito`; instanceCount 2; mode `both`; validationMode `local-jwt`; cacheHitRatio 0.95; failMode `fail-closed`; perInstanceCapacityRps 2000 | Validates API keys for gateway requests. |
| `router` | server | Inference Router | technology `fastapi`; instanceCount 4; perInstanceCapacityRps 250; baseLatencyMs 6; jitterMs 2; estimatedCostPerHour 0.28 | Chooses cache, feature lookup, realtime serving, or queued inference path. |
| `result-cache` | cache | Inference Result Cache | technology `redis`; hitRatio 0.55; ttlMs 300000; baseLatencyMs 1; perInstanceCapacityRps 15000 | Avoids recomputing deterministic inference results. |
| `feature-store` | nosql-database | Online Feature Store | technology `aerospike`; model `key-value`; consistency `eventual`; partitionCount 32; replicationLagMs 15; perInstanceCapacityRps 6000; baseLatencyMs 3 | Provides online feature lookups for realtime and batch inference. |
| `realtime-serving` | server | Realtime Model Serving | technology `google-kubernetes-engine`; instanceCount 6; perInstanceCapacityRps 12; baseLatencyMs 180; jitterMs 60; timeoutMs 3000; estimatedCostPerHour 4.8 | Capacity-limited synchronous model-serving stand-in. |
| `inference-queue` | message-queue | Batch Inference Queue | technology `amazon-sqs`; maxQueueDepth 15000; baseLatencyMs 3; perInstanceCapacityRps 8000 | Buffers expensive asynchronous inference work. |
| `batch-serving` | worker | Batch Model Workers | technology `kubernetes`; instanceCount 4; perInstanceCapacityRps 8; baseLatencyMs 900; jitterMs 250; estimatedCostPerHour 3.2 | Consumes queued inference requests. |
| `inference-dlq` | dead-letter-queue | Failed Inference | technology `amazon-sqs`; maxQueueDepth 5000 | Receives failed queued inference work. |
| `model-registry` | object-storage | Model Artifact Store | technology `amazon-s3`; perInstanceCapacityRps 120; baseLatencyMs 60; estimatedCostPerHour 0.1 | Stores model artifacts as immutable objects. |
| `telemetry` | observability | Model Telemetry | technology `opentelemetry`; perInstanceCapacityRps 20000 | Receives serving and worker telemetry. |

## Request and Event Flows

- Synchronous path: `client` -> `gateway` (request), `gateway` -> `identity` (request), `gateway` -> `router` (request), `router` -> `result-cache` (request), `router` -> `feature-store` (request), `router` -> `realtime-serving` (request), `realtime-serving` -> `model-registry` (request).
- Asynchronous path: `router` -> `inference-queue` (event), `inference-queue` -> `batch-serving` (event), `batch-serving` -> `feature-store` (request), `batch-serving` -> `model-registry` (request).
- Failure path: `inference-queue` -> `inference-dlq` (failover).
- Observability path: `realtime-serving` -> `telemetry` (observability) and `batch-serving` -> `telemetry` (observability).

## Data Model and Storage Assumptions

`result-cache` has a configured hit ratio and TTL. `feature-store` is an eventual-consistency key-value NoSQL store with partitioning and replication lag. `inference-queue` is a bounded asynchronous work queue. `model-registry` is object storage for large immutable artifacts; metadata and promotion workflows are outside the model.

## Technology Suggestions

The template uses example technologies: Amazon API Gateway, Amazon Cognito, FastAPI, Redis, Aerospike, Google Kubernetes Engine, Amazon SQS, Kubernetes, Amazon S3, and OpenTelemetry. These are simulator metadata and presets, not deployment steps, credentials, or online service requirements.

## Traffic Profile

The default profile is `inference-demand`: growing inference demand for 60000 ms, ramping from 40 RPS to 180 RPS, readRatio 0.6, concurrentUsers 800. The alternate profile is `campaign-burst`: campaign burst for 60000 ms, base 50 RPS, peak 320 RPS, burst from 22000 ms to 36000 ms, readRatio 0.6.

## Capacity and Scaling Assumptions

`gateway` enforces 300 RPS with a burst of 150. `router` has four instances at 250 RPS each. `realtime-serving` is deliberately scarce at six instances times 12 RPS, with high base latency. `batch-serving` is even lower throughput at four workers times 8 RPS, so queue depth is expected to show deferred demand. Cache hits reduce pressure on serving capacity.

## Caching Strategy

`result-cache` has hitRatio 0.55 and ttlMs 300000, so cache hits reduce expensive serving work. `identity` also has cacheHitRatio 0.95 for local JWT validation behavior. The template does not simulate cache eviction policy or model-result correctness; hit ratio is a configured simulator input.

## Reliability and Failure Handling

The default fault scenario is `accelerator-capacity-loss`: fault `gpu-loss`, type `capacity-reduction`, target `realtime-serving`, starts at 16000 ms and ends at 42000 ms with capacityMultiplier 0.35. `feature-store-latency` uses fault `fs-slow`, type `latency-increase`, target `feature-store`, starts at 14000 ms and ends at 36000 ms with additionalLatencyMs 150. `batch-worker-stall` uses fault `batch-stall`, type `queue-consumer-failure`, target `batch-serving`, starts at 15000 ms and ends at 40000 ms.

## Security Considerations

Authentication is represented by `gateway` delegating to `identity`, with `identity` configured to fail closed. Gateway rate limiting protects the downstream path. The model does not simulate secrets, model access policy, artifact signing, tenant isolation, or real authorization decisions.

## Observability Plan

Watch `gateway` rejection behavior, `router` utilization, `result-cache` hit and miss effects, `feature-store` latency, `realtime-serving` utilization and timeouts, `inference-queue` depth, `batch-serving` lag, `inference-dlq` growth, and telemetry volume from realtime and batch paths.

## Simulation Exercises

Run `inference-demand` without faults and identify when realtime serving becomes the bottleneck. Increase `result-cache` hitRatio to 0.8 and compare serving pressure. Run `accelerator-capacity-loss` and decide whether extra replicas or more queue depth better protects users. Run `batch-worker-stall` and inspect queue behavior.

## Expected Results

A clean default run raises no architecture warnings because `expectedFindings` is empty. Directionally, cache hits should reduce expensive serving load, realtime serving should be the scarce synchronous resource, and batch-worker failures should appear as queue growth rather than immediate downstream errors. Treat all outputs as educational trends, not production forecasts.

## Common Failure Modes

- `accelerator-capacity-loss`: `capacity-reduction` on `realtime-serving` from 16000 ms to 42000 ms cuts serving capacity and shifts pressure toward queuing or failures.
- `feature-store-latency`: `latency-increase` on `feature-store` from 14000 ms to 36000 ms adds latency to both realtime and batch paths.
- `batch-worker-stall`: `queue-consumer-failure` on `batch-serving` from 15000 ms to 40000 ms causes asynchronous backlog and possible DLQ pressure.

## Trade-Offs

Synchronous inference gives immediate responses but exposes users to scarce serving capacity. Queue-backed inference protects scarce compute but changes the user experience to deferred completion. Result caching reduces cost and latency when requests repeat, but the simulator only models a hit ratio, not semantic cache validity.

## Simulator Limitations

The model-serving endpoint is a `server` with very low per-instance capacity, so accelerator hardware, device scheduling, batching, token streaming, and per-request compute cost are not simulated. The feature store is a `nosql-database`, so training-serving skew, point-in-time correctness, and feature backfill are not simulated. The inference queue is a `message-queue`, so it models depth and lag but not workflow state. The model artifact registry is `object-storage`, so metadata, approval, and promotion workflows are not simulated. Model accuracy, versioning, A/B routing, drift, training, and fine-tuning are out of scope.

## Extension Exercises

Use the template challenges: raise the result-cache hit ratio to 0.8 and observe freed serving capacity; run capacity loss and compare replicas versus queue depth; move the synchronous path behind the queue and describe the changed user experience. Keep the exercise offline inside the simulator.
