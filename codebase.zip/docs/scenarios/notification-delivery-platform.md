---
template-id: notification-delivery-platform
template-version: 1.0.0
difficulty: intermediate
estimated-minutes: 45
---
# Notification Delivery Platform

## Overview
This scenario documents the `notification-delivery-platform` template. It models a queue-decoupled notification pipeline where `notify-api` accepts producer requests and workers call email, SMS, and push providers through circuit breakers. Use it with `./README.md` and `../user-guide/README.md`.

The workload is throughput-sensitive and availability-sensitive. Provider nodes are simulated external dependencies; no real provider calls, credentials, or online connectivity are involved.

## Learning Objectives
Learners decouple a fast API from slower third-party delivery by placing `queue` between `notify-api` and the workers. They learn that consumers should be sized against provider throughput, not only ingest rate.

They also observe circuit breakers opening after failure thresholds and dead-letter routing through `dlq` when work cannot be processed successfully.

## Architecture Summary
The intake path is `client` -> `gateway` -> `notify-api`. The API publishes to `queue`, which fans out to `email-worker`, `sms-worker`, and `push-worker`. Each worker calls a matching breaker and provider. The queue has a failover edge to `dlq`.

There is no cache, database, CDN, or observability node.

## Functional Requirements
- Accept notification production requests through `gateway`.
- Enqueue delivery work from `notify-api` to `queue`.
- Process email, SMS, and push work in separate worker pools.
- Guard each provider with a channel-specific circuit breaker.
- Route failed work from `queue` to `dlq` through the failover edge.

## Non-Functional Requirements
- Keep intake responsive by decoupling provider delivery from the API.
- Make queue depth, worker utilization, provider latency, and provider rate limits visible.
- Isolate email, SMS, and push provider failures.
- Show circuit-breaker behavior during provider degradation.

## Components and Responsibilities
| Node ID | Type | Display Name | Key Configuration | Responsibility |
| --- | --- | --- | --- | --- |
| `client` | client | Producer Client | display name only | Generates simulated notification requests. |
| `gateway` | api-gateway | API Gateway | `amazon-api-gateway`; `authMode: validate-local`; `policyLatencyMs: 3` | Applies local gateway policy and routes intake. |
| `notify-api` | server | Notification API | `fastapi`; `instanceCount: 3`; `perInstanceCapacityRps: 250`; `baseLatencyMs: 10`; `estimatedCostPerHour: 0.15` | Accepts requests and publishes delivery work. |
| `queue` | message-queue | Delivery Queue | `amazon-sqs`; `maxQueueDepth: 50000`; `retentionMs: 14400000`; `perInstanceCapacityRps: 5000` | Buffers delivery work. |
| `dlq` | dead-letter-queue | Dead-Letter Queue | display name only | Receives failed work through failover. |
| `email-worker` | worker | Email Worker | `celery`; `instanceCount: 4`; `perInstanceCapacityRps: 30`; `baseLatencyMs: 60`; `maxProcessingAttempts: 3`; `estimatedCostPerHour: 0.1` | Processes email deliveries. |
| `sms-worker` | worker | SMS Worker | `bullmq`; `instanceCount: 3`; `perInstanceCapacityRps: 25`; `baseLatencyMs: 70`; `maxProcessingAttempts: 3`; `estimatedCostPerHour: 0.08` | Processes SMS deliveries. |
| `push-worker` | worker | Push Worker | `sidekiq`; `instanceCount: 3`; `perInstanceCapacityRps: 80`; `baseLatencyMs: 35`; `maxProcessingAttempts: 2`; `estimatedCostPerHour: 0.08` | Processes push deliveries. |
| `email-breaker` | circuit-breaker | Email Breaker | `resilience4j`; `failureThreshold: 0.5`; `rollingWindowSize: 20`; `recoveryIntervalMs: 10000` | Protects email provider calls. |
| `sms-breaker` | circuit-breaker | SMS Breaker | `polly`; `failureThreshold: 0.4`; `rollingWindowSize: 20`; `recoveryIntervalMs: 15000` | Protects SMS provider calls. |
| `push-breaker` | circuit-breaker | Push Breaker | `hystrix`; `failureThreshold: 0.5`; `rollingWindowSize: 20`; `recoveryIntervalMs: 10000` | Protects push provider calls. |
| `email-provider` | external-service | Email Provider | `sendgrid-email`; `providerLabel: Transactional email provider`; `slaLatencyMs: 220`; `providerRateLimitRps: 120`; `baseLatencyMs: 220`; `timeoutMs: 5000`; `idempotencySupported: true` | Simulates email dependency and rate limit. |
| `sms-provider` | external-service | SMS Provider | `twilio-messaging`; `providerLabel: SMS provider`; `slaLatencyMs: 400`; `providerRateLimitRps: 60`; `baseLatencyMs: 400`; `timeoutMs: 6000`; `idempotencySupported: true` | Simulates SMS dependency and rate limit. |
| `push-provider` | external-service | Push Provider | `firebase-cloud-messaging`; `providerLabel: Push notification provider`; `slaLatencyMs: 150`; `providerRateLimitRps: 400`; `baseLatencyMs: 150`; `timeoutMs: 4000` | Simulates push dependency and rate limit. |

## Request and Event Flows
- `client` -> `gateway` is a `request` edge; `gateway` -> `notify-api` is a `request` edge with 2 ms latency.
- `notify-api` -> `queue` is an `event` edge with 2 ms latency.
- `queue` -> `email-worker`, `queue` -> `sms-worker`, and `queue` -> `push-worker` are `event` edges with 2 ms latency.
- `queue` -> `dlq` is a `failover` edge with 1 ms latency.
- Each worker -> matching breaker is a `request` edge with 1 ms latency; each breaker -> matching provider is a `request` edge with 4 ms latency.
- The template has no `replication` or `observability` edges.

## Data Model and Storage Assumptions
There is no database or cache. Delivery work is represented by `queue`, with `maxQueueDepth: 50000`, `retentionMs: 14400000`, and `perInstanceCapacityRps: 5000`. Failed work is represented by `dlq`. Delivery receipts, bounce handling, unsubscribe flows, per-recipient templates, and localisation are not modelled.

## Technology Suggestions
The template assigns `amazon-api-gateway`, `fastapi`, `amazon-sqs`, `celery`, `bullmq`, `sidekiq`, `resilience4j`, `polly`, `hystrix`, `sendgrid-email`, `twilio-messaging`, and `firebase-cloud-messaging`. These names are educational metadata only; they do not provision services and require no online connectivity or credentials.

## Traffic Profile
Default traffic profile: `notification-traffic`.

- `notification-traffic` (`Notifications 300 RPS`): constant, 45000 ms, 300 RPS, `readRatio: 0.05`, `requestSizeBytes: 2048`, `responseSizeBytes: 256`.
- `campaign-send` (`Marketing campaign send`): burst, 60000 ms, baseline 200 RPS, peak 2000 RPS, burst from 15000 ms to 30000 ms, `readRatio: 0.02`.

## Capacity and Scaling Assumptions
`notify-api` has 3 instances at 250 RPS each. `queue` accepts 5000 RPS per instance and buffers up to 50000 messages. Email workers provide 4 instances at 30 RPS each, SMS workers 3 at 25 RPS each, and push workers 3 at 80 RPS each. Provider limits are 120 RPS for email, 60 RPS for SMS, and 400 RPS for push.

## Caching Strategy
This scenario has no cache node. It focuses on queue buffering, worker throughput, circuit breakers, external-service rate limits, and dead-letter routing.

## Reliability and Failure Handling
Default fault scenario: `provider-outage`.

- `provider-outage`: fault `sms-1`, type `error-rate-increase`, targets `sms-provider`, starts at 15000 ms and ends at 35000 ms, with `additionalErrorRate: 0.9`.
- `provider-throttle`: fault `email-1`, type `provider-throttling`, targets `email-provider`, starts at 12000 ms and ends at 36000 ms, with `capacityMultiplier: 0.25`.
- `worker-loss`: fault `push-1`, type `node-outage`, targets `push-worker`, starts at 18000 ms and ends at 33000 ms.

## Security Considerations
`gateway` uses `authMode: validate-local`. Providers are external-service stand-ins and perform no real network calls or credential checks. Do not treat this as guidance to configure provider secrets or production integrations.

## Observability Plan
The template has no observability node and no `observability` edges. Use simulator metrics for `queue` depth, worker utilization, circuit-breaker behavior, provider failures, throttling, and `dlq` routing.

## Simulation Exercises
Run `notification-traffic` without faults. Then run `provider-outage` for SMS, `provider-throttle` for email, and `worker-loss` for push. Compare queue pressure, breaker behavior, provider failures, and dead-letter movement.

## Expected Results
The template declares no `expectedFindings`, so a clean default run raises no warnings. During `provider-outage`, SMS failures should rise and `sms-breaker` should matter more. During `provider-throttle`, email work should back up behind reduced provider capacity. During `worker-loss`, push queue pressure should increase while `push-worker` is unavailable.

## Common Failure Modes
- `provider-outage`: `error-rate-increase` on `sms-provider` from 15000 ms to 35000 ms adds 0.9 error rate.
- `provider-throttle`: `provider-throttling` on `email-provider` from 12000 ms to 36000 ms applies `capacityMultiplier: 0.25`.
- `worker-loss`: `node-outage` on `push-worker` from 18000 ms to 33000 ms removes push processing capacity.
- Exhausted processing attempts may route work from `queue` to `dlq` through the `failover` edge.

## Trade-Offs
Queue decoupling protects `notify-api` from slow providers but introduces delayed delivery. Circuit breakers reduce repeated calls to unhealthy providers but can shed work. Separate workers isolate channels, while shared intake means all channels depend on `queue` capacity.

## Simulator Limitations
Providers perform no real network calls and hold no credentials. Delivery receipts, bounce handling, unsubscribe flows, per-recipient templating, and localisation are not modelled.

Stand-ins are explicit. `Email, SMS, and push providers` are modelled as `external-service` components `email-provider`, `sms-provider`, and `push-provider`, so provider APIs, authentication, delivery receipts, message content, and provider-side state are not simulated. The simulator has no persistent-connection or WebSocket transport model and no first-class rate limiter or WAF node in this scenario.

## Extension Exercises
Lower the SMS provider rate limit until `dlq` receives messages. Compare failures with circuit-breaker `failureThreshold` at 0.3 versus 0.8. Add retry backoff conceptually and explain its effect on provider load during `provider-outage`.
