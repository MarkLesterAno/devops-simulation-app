---
template-id: file-upload-service
template-version: 1.0.0
difficulty: beginner
estimated-minutes: 25
---

# Simple File Upload Service

## Overview

Simple File Upload Service is a beginner write-heavy, throughput-sensitive scenario. It models upload traffic through `client`, `gateway`, and `upload`, then fans out to `objects` for bytes and `metadata` for relational metadata. It demonstrates large payload accounting, object storage latency, and retries against a slow dependency.

## Learning Objectives

Use this scenario to separate the bulk data path from the metadata path, see how large request payloads change throughput and cost accounting, understand why one upload service writes to two stores, and observe retry amplification when object storage becomes slow.

## Architecture Summary

The blueprint is `client` -> `gateway` -> `upload`, with `upload` calling both `objects` and `metadata`. The API gateway adds policy latency, the Spring Boot upload service has retries and a timeout, object storage has higher latency and jitter, and the metadata database is a PostgreSQL relational database. There is no cache, queue, CDN, or observability node.

## Functional Requirements

The system accepts upload requests, routes them through an API gateway, stores file bytes in object storage, and records file metadata in a relational database. The template does not model multipart uploads, resumable uploads, presigned URLs, virus scanning, content inspection, or thumbnailing.

## Non-Functional Requirements

The scenario focuses on write throughput, large request payloads, dependency latency, retries, and timeout behaviour. Object storage latency dominates the write path, while the metadata database remains a separate dependency with its own capacity and base latency.

## Components and Responsibilities

| Node ID | Type | Display Name | Key Configuration | Responsibility |
| --- | --- | --- | --- | --- |
| `client` | client | Uploader Client | No additional configuration | Starts upload requests. |
| `gateway` | api-gateway | API Gateway | technology `amazon-api-gateway`; authMode `none`; policyLatencyMs 4; perInstanceCapacityRps 2000 | Applies gateway policy latency and forwards uploads. |
| `upload` | server | Upload Service | technology `spring-boot`; instanceCount 3; perInstanceCapacityRps 60; baseLatencyMs 45; jitterMs 15; maxRetries 2; retryBackoffMs 200; timeoutMs 8000; estimatedCostPerHour 0.18 | Coordinates object and metadata writes. |
| `objects` | object-storage | Object Storage | technology `amazon-s3`; perInstanceCapacityRps 250; baseLatencyMs 90; jitterMs 30; estimatedCostPerHour 0.06 | Stores uploaded bytes as objects. |
| `metadata` | relational-database | Metadata Database | technology `postgresql`; perInstanceCapacityRps 400; baseLatencyMs 18; estimatedCostPerHour 0.22 | Stores metadata records for uploads. |

## Request and Event Flows

The upload request path is `client` -> `gateway` as a request edge, `gateway` -> `upload` as a request edge with 2 ms latency, then two request edges from `upload`: `upload` -> `objects` with 5 ms latency and `upload` -> `metadata` with 2 ms latency. There are no event, replication, failover, or observability edges.

## Data Model and Storage Assumptions

`objects` stores the file bytes as object storage with 250 RPS capacity, 90 ms base latency, and 30 ms jitter. `metadata` stores relational metadata with 400 RPS capacity and 18 ms base latency. Payload size is only a number for simulator cost and throughput accounting; no bytes are transferred.

## Technology Suggestions

The template assigns `amazon-api-gateway` to `gateway`, `spring-boot` to `upload`, `amazon-s3` to `objects`, and `postgresql` to `metadata`. These names are educational metadata and simulation presets only; they do not imply credentials, provisioning, or connectivity.

## Traffic Profile

The default traffic profile is `upload-traffic`: Uploads 120 RPS for 30000 ms at 120 RPS, readRatio 0.2, requestSizeBytes 1500000, and responseSizeBytes 512. The alternate `bulk-import` burst runs for 40000 ms, starts at 80 RPS, peaks at 400 RPS from 14000 ms to 24000 ms, and uses readRatio 0.1, requestSizeBytes 2000000, and responseSizeBytes 512.

## Capacity and Scaling Assumptions

`upload` has 3 instances at 60 RPS each, for a declared application-tier capacity of 180 RPS before retries. `objects` declares 250 RPS and `metadata` declares 400 RPS. The object path is expected to dominate latency because `objects` has higher base latency and jitter than `metadata`.

## Caching Strategy

This scenario has no cache node. Uploads go directly from `upload` to `objects` and `metadata`; there is no hit ratio, TTL, CDN, or cache-miss behaviour.

## Reliability and Failure Handling

The default fault scenario is `storage-slowdown`. It contains fault `storage-1`, a `latency-increase` targeting `objects` from 10000 ms to 24000 ms with additionalLatencyMs 450. The second scenario is `metadata-outage`; fault `meta-1` is a `database-primary-failure` targeting `metadata` from 12000 ms to 22000 ms.

## Security Considerations

`gateway` has authMode `none`, and the template includes no identity, authorisation, scanning, or inspection component. The scenario is not a security model for uploads; it is limited to request flow, storage latency, capacity, and retries.

## Observability Plan

There is no observability node and no observability edge. Use simulator metrics to inspect `upload` utilisation, retry effects, timeout pressure, `objects` latency, `metadata` latency, success rate, and p95 latency during the default and fault profiles.

## Simulation Exercises

Run `upload-traffic` and compare time spent on the object and metadata branches. Run `bulk-import` to see how a burst interacts with the 180 RPS service capacity. Then run `storage-slowdown` and adjust `upload` maxRetries to observe retry amplification.

## Expected Results

`expectedFindings` is empty, so a clean default run raises no warnings. Under `bulk-import`, utilisation on `upload` should rise and p95 latency should increase as traffic exceeds its declared capacity. During `storage-slowdown`, p95 should rise on the object path and retries may amplify pressure on `objects`.

## Common Failure Modes

`storage-slowdown` models a `latency-increase` on `objects` from 10000 ms to 24000 ms, adding 450 ms and stressing upload latency and retries. `metadata-outage` models a `database-primary-failure` on `metadata` from 12000 ms to 22000 ms, degrading the metadata write branch.

## Trade-Offs

Separating bytes from metadata keeps responsibilities clear, but one upload request depends on two downstream stores. Retries can improve tolerance of transient storage slowness, yet they also add latency and can increase downstream pressure during the same slowdown.

## Simulator Limitations

Simplifications are explicit: payload size is accounting metadata and no bytes are transferred; multipart uploads, resumable uploads, and presigned URLs are not modelled; virus scanning, content inspection, and thumbnailing are out of scope. There are no stand-ins in this template.

## Extension Exercises

Move metadata writes behind a queue and compare upload latency. Raise `upload` maxRetries during `storage-slowdown` and explain the result. Add a CDN in front of downloads and model a read-heavy traffic profile.
