---
template-id: multi-region-ecommerce
template-version: 1.0.0
difficulty: advanced
estimated-minutes: 60
---

# Multi-Region E-Commerce

## Overview
This advanced scenario models a globally distributed e-commerce read path with geo-routed DNS, two regional application stacks, regional caches, regional read replicas, and a single write primary in `us-east`. Use it with the general [user guide](../user-guide/README.md) and the scenario library index at [./README.md](./README.md). The template is offline and deterministic; technology names are educational metadata, not deployment instructions.

## Learning Objectives
You practice separating global reads from single-region writes by following how `dns` distributes requests to `lb-us` and `lb-eu`, while both applications ultimately write to `db-primary`. The scenario also makes cross-region write latency visible: `app-eu` reaches `db-primary` over an 85 ms request edge, so write-sensitive paths behave differently from local reads. Replication is treated as a correctness concern because `replica-us` and `replica-eu` receive updates with different lag edges. Finally, DNS TTL is part of the reliability model: `dns` has a 60 second TTL, so failover speed is bounded by routing policy and cached records.

## Architecture Summary
The architecture is active-active for reads and single-primary for writes. `client` sends traffic to `dns`, which applies geo policy and weighted request edges to the US and EU load balancers. Each regional load balancer forwards to a regional application service, cache, and read replica. Writes from both regions converge on `db-primary` in `us-east`; replication edges then update `replica-us` and `replica-eu`. `telemetry` receives observability edges from the applications and primary database.

## Functional Requirements
- Route global client traffic through geo-aware DNS.
- Serve read-heavy e-commerce requests from regional application, cache, and read-replica paths.
- Send writes to the single `db-primary` node in `us-east`.
- Replicate primary database changes to both regional read replicas.
- Record application and database signals through the observability component.

## Non-Functional Requirements
The workload is read-heavy, availability-sensitive, and consistency-sensitive. The design emphasizes regional read locality, controlled cross-region write behavior, and explicit replication lag. During regional failure, the simulator shows how DNS TTL and routing policy delay full recovery. It does not model regional cost, data residency, or conflict resolution.

## Components and Responsibilities
| Node ID | Type | Display Name | Key Configuration | Responsibility |
|---|---|---|---|---|
| `client` | client | Global Client | no additional config | Generates global user traffic. |
| `dns` | dns-traffic-manager | Global DNS | technology `amazon-route-53`; `ttlSeconds` 60; `resolutionLatencyMs` 18; policy `geo` | Selects the regional entry point and bounds failover speed through TTL. |
| `lb-us` | load-balancer | US Load Balancer | technology `aws-application-load-balancer`; region `us-east`; capacity 8000 RPS | Receives US-routed requests and forwards them to `app-us`. |
| `lb-eu` | load-balancer | EU Load Balancer | technology `aws-application-load-balancer`; region `eu-west`; capacity 8000 RPS | Receives EU-routed requests and forwards them to `app-eu`. |
| `app-us` | server | US Application | technology `spring-boot`; region `us-east`; 6 instances; 140 RPS each; base 24 ms; jitter 9 ms; cost 0.42/hour | Handles US application logic, cache reads, replica reads, primary writes, and telemetry. |
| `app-eu` | server | EU Application | technology `spring-boot`; region `eu-west`; 4 instances; 140 RPS each; base 24 ms; jitter 9 ms; cost 0.28/hour | Handles EU application logic and demonstrates cross-region writes to the US primary. |
| `cache-us` | cache | US Cache | technology `amazon-elasticache`; region `us-east`; hit ratio 0.86; TTL 60000 ms; base 1 ms; capacity 9000 RPS | Absorbs repeated US read traffic. |
| `cache-eu` | cache | EU Cache | technology `amazon-elasticache`; region `eu-west`; hit ratio 0.86; TTL 60000 ms; base 1 ms; capacity 9000 RPS | Absorbs repeated EU read traffic. |
| `db-primary` | relational-database | Write Primary (US) | technology `amazon-aurora`; region `us-east`; capacity 600 RPS; base 18 ms; jitter 6 ms; cost 0.95/hour | Authoritative write store and replication source. |
| `replica-us` | read-replica | US Read Replica | technology `amazon-aurora`; region `us-east`; capacity 800 RPS; base 14 ms; cost 0.55/hour | Serves local US reads after replication from the primary. |
| `replica-eu` | read-replica | EU Read Replica | technology `amazon-aurora`; region `eu-west`; capacity 800 RPS; base 14 ms; cost 0.55/hour | Serves EU reads subject to cross-region replication lag. |
| `telemetry` | observability | Global Telemetry | technology `datadog`; capacity 20000 RPS | Collects observability signals from app and database nodes. |

## Request and Event Flows
**Synchronous read flow.** `client` → `dns` is a request edge. `dns` then sends request traffic to `lb-us` with 12 ms latency and weight 0.6, or to `lb-eu` with 14 ms latency and weight 0.4. `lb-us` → `app-us` and `lb-eu` → `app-eu` are request edges with 2 ms latency. The applications use request edges to `cache-us` or `cache-eu` at 1 ms and to `replica-us` or `replica-eu` at 3 ms.

**Synchronous write flow.** After DNS and load-balancer routing, `app-us` writes to `db-primary` over a request edge with 4 ms latency. `app-eu` writes to the same `db-primary` over a request edge with 85 ms latency, making the cross-region write penalty explicit.

**Replication flow.** `db-primary` → `replica-us` is a replication edge with 20 ms latency. `db-primary` → `replica-eu` is a replication edge with 95 ms latency. These edges represent one-way asynchronous replica lag and do not simulate multi-primary conflict handling.

**Observability flow.** `app-us`, `app-eu`, and `db-primary` each emit observability edges to `telemetry`.

**Failover modelling.** There is no failover edge to a load balancer because this tool's connection rules do not allow a `failover` edge to target a load balancer. Regional failover is therefore modelled through `dns` routing policy, weights, and TTL rather than a direct failover connection.

## Data Model and Storage Assumptions
`db-primary` is the authoritative relational write store. `replica-us` and `replica-eu` are read replicas with one-way replication from the primary. Cache entries are regional, have a 60000 ms TTL, and use the configured 0.86 hit ratio. The simulator models request rate, latency, capacity, and lag; it does not model schema design, product data shape, data residency, or multi-primary conflict resolution.

## Technology Suggestions
The template assigns `amazon-route-53` to DNS, `aws-application-load-balancer` to regional load balancers, `spring-boot` to application servers, `amazon-elasticache` to caches, `amazon-aurora` to the primary and read replicas, and `datadog` to telemetry. These names are educational labels and presets only; no cloud credentials, provisioning, or online connectivity are required.

## Traffic Profile
The default traffic profile is `global-daily-cycle`. It runs for 60000 ms: 220 RPS from 0-20000 ms, ramps from 220 to 700 RPS from 20000-40000 ms, and stays at 700 RPS from 40000-60000 ms, with `readRatio` 0.85 and 4000 concurrent users. The alternate `steady-global` profile runs for 45000 ms at a constant 400 RPS with `readRatio` 0.85.

## Capacity and Scaling Assumptions
The two load balancers each accept 8000 RPS, while application capacity differs by region: `app-us` has 6 instances at 140 RPS each and `app-eu` has 4 instances at 140 RPS each. `db-primary` is lower capacity at 600 RPS, and each read replica is 800 RPS. Caches are high-capacity regional absorbers at 9000 RPS each. Scaling is represented through instance counts and per-instance capacity, not autoscaling policies.

## Caching Strategy
`cache-us` and `cache-eu` sit behind their regional application services. Each has hit ratio 0.86, TTL 60000 ms, base latency 1 ms, and capacity 9000 RPS. Cache misses are expected to move read pressure to the regional read replicas rather than the write primary.

## Reliability and Failure Handling
The default fault scenario is `eu-regional-outage`. It contains fault `eu-out`, type `regional-outage`, targeting `lb-eu`, `app-eu`, `cache-eu`, and `replica-eu` from 20000 ms to 45000 ms with region `eu-west`. Scenario `stale-dns` contains fault `dns-stale`, type `stale-dns-record`, targeting `dns` from 15000 ms to 40000 ms and adding 60 ms latency. Scenario `primary-failure` contains fault `primary-down`, type `database-primary-failure`, targeting `db-primary` from 18000 ms to 38000 ms.

## Security Considerations
Security is limited to architecture reasoning. The template does not model identity, authorization, data residency controls, encryption, or credential handling. Do not infer any real cloud access from the technology labels.

## Observability Plan
Watch `telemetry` for signals from `app-us`, `app-eu`, and `db-primary`. Useful observations include regional application pressure, write-primary pressure, latency movement during EU write paths, and visible effects when a fault removes the EU region or slows DNS decisions.

## Simulation Exercises
Run the default `global-daily-cycle` profile without faults first. Then apply `eu-regional-outage` and compare regional behavior before, during, and after 20000-45000 ms. Next, run `stale-dns` to isolate TTL and DNS effects, and `primary-failure` to see how a single write primary changes availability.

## Expected Results
A clean default run has an empty `expectedFindings` list, so it should raise no architecture warnings by default. Interesting behavior is directional and appears once a fault is applied: EU outage should shift attention to regional availability and DNS recovery, stale DNS should delay routing recovery, and primary failure should expose the write-path dependency.

## Common Failure Modes
`eu-regional-outage` / `eu-out` is a `regional-outage` against `lb-eu`, `app-eu`, `cache-eu`, and `replica-eu` from 20000 to 45000 ms. `stale-dns` / `dns-stale` is a `stale-dns-record` fault against `dns` from 15000 to 40000 ms with 60 ms added latency. `primary-failure` / `primary-down` is a `database-primary-failure` against `db-primary` from 18000 to 38000 ms.

## Trade-Offs
The topology improves read locality and regional availability for reads, but writes remain bound to `db-primary`. Lower DNS TTL can improve failover reaction time, but this simulator only shows the TTL/routing effect, not resolver behavior outside the model. One-way replication makes lag easy to reason about, but it excludes the hard part of multi-primary correctness.

## Simulator Limitations
The simulator has no failover-controller component. The real-world regional failover controller is modelled as `dns-traffic-manager`; therefore controller health checks, election logic, runbooks, and automated promotion are not simulated. Replication is one-way and conflict-free. Data residency, regional pricing, and inter-region egress cost are also outside the model. The simulator also has no workflow-orchestrator, search-engine, vector-index, or CDC component; those concepts are not part of this scenario and would be approximated by generic nodes if added.

## Extension Exercises
Try lowering the `dns` TTL from 60 seconds to 10 seconds and observe how much sooner traffic leaves the failed region. Promote the EU replica conceptually to a second primary and write down which correctness questions the simulator can no longer answer. Increase the EU replication lag to 2000 ms and decide which reads should no longer be served from `replica-eu`.
