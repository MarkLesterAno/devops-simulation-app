---
template-id: url-shortener
template-version: 1.0.0
difficulty: beginner
estimated-minutes: 25
---

# URL Shortener

## Overview

URL Shortener is a beginner read-heavy, latency-sensitive scenario for redirect traffic. Requests travel from `client` through `cdn`, `lb`, and `redirect` to `cache`, with misses reaching `store`. The scenario teaches cache hit ratios, CDN edge hits, hot partitions, and what happens when the cache fails.

## Learning Objectives

Use the template to quantify how `cache` hit ratio changes origin load, why a small fast path works for read-heavy redirects, and how hot-partition skew defeats average-case capacity. It also shows how traffic shifts to `store` when the cache is unavailable.

## Architecture Summary

The blueprint is `client` -> `cdn` -> `lb` -> `redirect` -> `cache` -> `store`. `cdn` has its own edge hit ratio, `redirect` has three Node.js instances, `cache` is Redis with a TTL, and `store` is a partitioned NoSQL key-value store. There is no queue or observability node.

## Functional Requirements

The service accepts redirect lookups from clients, routes them through a CDN and load balancer, serves redirect data from `cache` when possible, and falls back to `store` for misses. The template does not model short-code generation, collision handling, ID encoding, or HTTP redirect semantics beyond returning a response.

## Non-Functional Requirements

The scenario prioritises low latency under read-heavy load. It models CDN hit ratio, cache hit ratio, cache miss traffic, partition count, hot-partition skew, replication lag, and component capacity. It deliberately treats cache eviction as a configured hit ratio rather than a simulated working set.

## Components and Responsibilities

| Node ID | Type | Display Name | Key Configuration | Responsibility |
| --- | --- | --- | --- | --- |
| `client` | client | Client | No additional configuration | Starts redirect requests. |
| `cdn` | cdn | CDN | technology `cloudflare-cdn`; hitRatio 0.35; baseLatencyMs 12 | Handles edge cache hits before the request reaches origin components. |
| `lb` | load-balancer | Load Balancer | technology `nginx`; perInstanceCapacityRps 8000 | Routes origin requests to the redirect service. |
| `redirect` | server | Redirect Service | technology `nodejs`; instanceCount 3; perInstanceCapacityRps 400; baseLatencyMs 8; jitterMs 3; estimatedCostPerHour 0.09 | Executes redirect lookup logic and calls the link cache. |
| `cache` | cache | Link Cache | technology `redis`; hitRatio 0.92; ttlMs 300000; baseLatencyMs 1; perInstanceCapacityRps 5000; estimatedCostPerHour 0.08 | Serves cached short-code mappings and forwards misses. |
| `store` | nosql-database | Link Store | technology `amazon-dynamodb`; model `key-value`; consistency `eventual`; partitionCount 8; hotPartitionSkew 0.35; replicationLagMs 40; perInstanceCapacityRps 500; baseLatencyMs 9; estimatedCostPerHour 0.2 | Stores authoritative key-value mappings for cache misses. |

## Request and Event Flows

The redirect path is `client` -> `cdn` as a request edge, `cdn` -> `lb` as a request edge with 6 ms latency, `lb` -> `redirect` as a request edge with 1 ms latency, `redirect` -> `cache` as a request edge with 1 ms latency, and `cache` -> `store` as a request edge with 2 ms latency on misses. There are no event, replication, failover, or observability edges.

## Data Model and Storage Assumptions

`store` is modelled as a NoSQL key-value database with eventual consistency, 8 partitions, hotPartitionSkew 0.35, and replicationLagMs 40. The key-value store is a stand-in for systems such as DynamoDB or Cassandra, but the simulator only models the key-value, partition, skew, and lag behaviours declared in the template.

## Technology Suggestions

The template assigns `cloudflare-cdn`, `nginx`, `nodejs`, `redis`, and `amazon-dynamodb` to the CDN, load balancer, service, cache, and store. These are educational metadata and simulation presets only, not cloud provisioning steps or online dependencies.

## Traffic Profile

The default traffic profile is `redirect-traffic`: Redirect traffic 600 RPS for 30000 ms at 600 RPS, readRatio 0.97, requestSizeBytes 256, and responseSizeBytes 512. The alternate `viral-link` burst runs for 40000 ms, starts at 400 RPS, peaks at 2200 RPS from 12000 ms to 22000 ms, and uses readRatio 0.99 with the same request and response sizes.

## Capacity and Scaling Assumptions

`redirect` provides 3 instances at 400 RPS each, while `cache` can handle 5000 RPS and `store` declares 500 RPS across the configured NoSQL component. The CDN hit ratio and cache hit ratio reduce origin and store load; lowering either value should move more traffic toward `redirect` and `store`.

## Caching Strategy

Caching is central to the design. `cdn` has hitRatio 0.35 and baseLatencyMs 12 before origin. `cache` has hitRatio 0.92, ttlMs 300000, baseLatencyMs 1, and a 5000 RPS capacity. Cache misses continue to `store`; no cache invalidation workflow is modelled.

## Reliability and Failure Handling

The default fault scenario is `cache-outage`. It contains fault `cache-1`, a `cache-failure` targeting `cache` from 12000 ms to 24000 ms. The second scenario is `hot-partition`; fault `hot-1` is a `partition-hotspot` targeting `store` from 10000 ms to 26000 ms with additionalLatencyMs 120.

## Security Considerations

There is no identity, authentication, authorisation, secrets, or abuse-prevention component in the template. The scenario is scoped to redirect performance, cache behaviour, and hot-key pressure, so security controls are not simulated.

## Observability Plan

There is no observability node and no observability edge. Use simulator metrics to compare CDN hits, cache hits, cache misses, `redirect` utilisation, `store` utilisation, p95 latency, and success rate under the default and burst profiles.

## Simulation Exercises

Run `redirect-traffic` to establish the default cache-assisted path. Drop `cache` hitRatio from 0.92 to 0.5 and compare the resulting origin RPS increase. Run `viral-link`, then run `cache-outage` and `hot-partition` separately to distinguish cache loss from skewed store latency.

## Expected Results

`expectedFindings` is empty, so a clean default run raises no warnings. Lower cache hit ratio or `cache-outage` should shift load toward `store`, increasing utilisation and p95 latency on the miss path. `hot-partition` should make tail latency worse for `store` even if average traffic appears manageable.

## Common Failure Modes

`cache-outage` models a `cache-failure` on `cache` from 12000 ms to 24000 ms, removing the fast lookup layer and exposing `store` to more reads. `hot-partition` models a `partition-hotspot` on `store` from 10000 ms to 26000 ms, adding 120 ms to represent concentrated key pressure.

## Trade-Offs

The design is fast when CDN and cache hit ratios hold, but origin capacity becomes more important when hits fall. A partitioned key-value store suits short-code lookup, while hot-key skew means nominal aggregate capacity can hide a stressed partition.

## Simulator Limitations

Simplifications are explicit: short-code generation, collision handling, and ID encoding are not modelled; cache eviction is a fixed hit ratio, not a working-set simulation; redirects are ordinary responses, not HTTP semantics. Stand-in: the real-world concept `Key-value store (DynamoDB, Cassandra)` is modelled as `nosql-database`, so provider-specific APIs, adaptive partitioning, billing modes, and operational behaviour are not simulated.

## Extension Exercises

Drop `cache` hitRatio from 0.92 to 0.5 and measure origin RPS. Raise `store` hotPartitionSkew to 0.8 and watch tail latency separate from the median. Run `cache-outage` and decide what `store` capacity would be needed to survive it.
