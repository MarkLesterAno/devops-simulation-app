---
template-id: analytics-event-ingestion
template-version: 1.0.0
difficulty: specialized
estimated-minutes: 55
---

# Analytics Event Ingestion

## Overview

Analytics Event Ingestion is a specialized, write-heavy telemetry pipeline for bursty event producers. It buffers events in a partitioned topic, enriches them with a stream-processor stand-in, lands raw data in a data-lake stand-in, and serves realtime dashboard reads from aggregate storage. Open it from the scenario gallery and use the [scenario library index](./README.md) and [user guide](../user-guide/README.md) for simulator workflow details.

## Learning Objectives

This scenario teaches sizing an ingestion buffer for bursts instead of averages, separating hot serving data from cold archived events, reading backpressure when processing capacity is below producer rate, and keeping analytical queries away from the ingestion path. The important question is where lag accumulates when collector, topic, processor, archive, aggregate, and warehouse capacities differ.

## Architecture Summary

Instrumented apps send requests through `ingest-lb` to `collector`. The collector synchronously checks `schema-svc`, publishes valid events to `event-topic`, and emits observability data to `telemetry`. `stream-processor` consumes the topic and writes to `aggregate-store`, `data-lake`, and `warehouse`. `dashboard-svc` uses `aggregate-store` rather than the warehouse so dashboard reads stay off the ingestion path.

## Functional Requirements

- Accept telemetry events from instrumented applications.
- Validate event shape before ingest using `schema-svc`.
- Buffer raw events in `event-topic` with partition ordering and retention.
- Process buffered events into realtime aggregates, raw archive storage, and analytical warehouse storage.
- Route malformed events from `event-topic` to `malformed-dlq`.
- Serve dashboard reads from `aggregate-store` through `dashboard-svc`.
- Emit collector and processor telemetry to `telemetry`.

## Non-Functional Requirements

The workload is write-heavy and throughput-sensitive. The model emphasizes topic depth, processor throughput, archive divergence, aggregate serving latency, and graceful behavior when a burst exceeds processing capacity. It does not claim production correctness for data-lake formats, warehouse planning, or scheduled batch jobs.

## Components and Responsibilities

| Node ID | Type | Display Name | Key Configuration | Responsibility |
| --- | --- | --- | --- | --- |
| `client` | client | Instrumented Apps | no explicit capacity settings | Produces telemetry events and dashboard requests. |
| `ingest-lb` | load-balancer | Ingest Load Balancer | technology `aws-network-load-balancer`; perInstanceCapacityRps 40000 | Routes ingest and dashboard traffic to backend services. |
| `collector` | server | Event Collector | technology `google-cloud-run`; instanceCount 12; perInstanceCapacityRps 400; baseLatencyMs 6; jitterMs 2; estimatedCostPerHour 0.9 | Accepts events, checks schema, publishes to the topic, and emits telemetry. |
| `schema-svc` | server | Schema Validation | technology `fastapi`; instanceCount 3; perInstanceCapacityRps 900; baseLatencyMs 3; estimatedCostPerHour 0.18 | Synchronous validation service before events enter the topic. |
| `event-topic` | event-topic | Raw Event Topic | technology `amazon-msk`; partitionCount 48; orderingScope `partition`; retentionMs 86400000; maxQueueDepth 200000; perInstanceCapacityRps 60000 | Buffers raw telemetry and exposes consumer lag and depth. |
| `stream-processor` | worker | Stream Processor | technology `apache-airflow`; instanceCount 10; perInstanceCapacityRps 450; baseLatencyMs 20; jitterMs 8; estimatedCostPerHour 1.2 | Consumes events and writes aggregates, raw archive data, and warehouse records. |
| `malformed-dlq` | dead-letter-queue | Malformed Events | technology `google-pubsub`; maxQueueDepth 20000 | Receives malformed events through the failover path. |
| `data-lake` | object-storage | Raw Data Lake | technology `google-cloud-storage`; perInstanceCapacityRps 2000; baseLatencyMs 45; estimatedCostPerHour 0.3 | Stores raw append-oriented event data as the data-lake stand-in. |
| `aggregate-store` | nosql-database | Realtime Aggregates | technology `google-cloud-bigtable`; model `time-series`; consistency `eventual`; partitionCount 32; replicationLagMs 30; perInstanceCapacityRps 8000; baseLatencyMs 6 | Serves realtime aggregate reads for dashboards. |
| `warehouse` | relational-database | Analytics Warehouse | technology `google-bigquery`; perInstanceCapacityRps 60; baseLatencyMs 850; jitterMs 300; estimatedCostPerHour 1.4 | Represents analytical serving with low capacity and high latency. |
| `dashboard-svc` | server | Dashboard Service | technology `nodejs`; instanceCount 2; perInstanceCapacityRps 60; baseLatencyMs 30; estimatedCostPerHour 0.12 | Serves dashboard requests against realtime aggregates. |
| `telemetry` | observability | Pipeline Telemetry | technology `prometheus`; perInstanceCapacityRps 50000 | Receives observability events from collector and processor. |

## Request and Event Flows

- Ingest request path: `client` -> `ingest-lb` (request), `ingest-lb` -> `collector` (request), `collector` -> `schema-svc` (request), then `collector` -> `event-topic` (event).
- Processing path: `event-topic` -> `stream-processor` (event), then `stream-processor` -> `aggregate-store` (request), `stream-processor` -> `data-lake` (request), and `stream-processor` -> `warehouse` (request).
- Malformed-event path: `event-topic` -> `malformed-dlq` (failover).
- Dashboard path: `client` -> `ingest-lb` (request), `ingest-lb` -> `dashboard-svc` (request), `dashboard-svc` -> `aggregate-store` (request).
- Observability path: `collector` -> `telemetry` (observability) and `stream-processor` -> `telemetry` (observability).

## Data Model and Storage Assumptions

`event-topic` is partitioned with per-partition ordering, one-day retention, and a bounded queue depth. `aggregate-store` is an eventual-consistency time-series NoSQL store. `data-lake` is object storage for raw events. `warehouse` is a relational-database stand-in with intentionally low capacity and high latency to show why reporting queries should not sit on the ingest path.

## Technology Suggestions

The template records example technologies: AWS Network Load Balancer, Google Cloud Run, FastAPI, Amazon MSK, Apache Airflow, Google Pub/Sub, Google Cloud Storage, Google Cloud Bigtable, Google BigQuery, Node.js, and Prometheus. These are metadata choices for education, not provisioning instructions and not requirements for online connectivity.

## Traffic Profile

The default profile is `telemetry-firehose`: steady telemetry firehose for 45000 ms at 3200 RPS, readRatio 0.05, and concurrentUsers 50000. The alternate profile is `release-burst`: release-day burst for 60000 ms, base 2800 RPS, peak 9000 RPS, burst from 20000 ms to 34000 ms, readRatio 0.05.

## Capacity and Scaling Assumptions

The collector tier can scale by instance count and per-instance RPS. The topic has high ingest capacity and bounded depth, so it can absorb bursts only until backlog exceeds processing capacity or max depth. `stream-processor` is the pipeline ceiling at ten workers times 450 RPS. `aggregate-store` is sized for high-rate reads and writes, while `warehouse` is deliberately slow and low-capacity.

## Caching Strategy

This template has no cache node. The design relies on buffering in `event-topic` and serving dashboard reads from `aggregate-store`, not on cache hit ratios. The separation between `aggregate-store`, `data-lake`, and `warehouse` is the main read/write isolation mechanism.

## Reliability and Failure Handling

The default fault scenario is `stream-processor-stall`: fault `sp-stall`, type `subscriber-group-stall`, target `stream-processor`, starts at 16000 ms and ends at 40000 ms with capacityMultiplier 0.2. `warehouse-degraded` uses fault `wh-slow`, type `degradation`, target `warehouse`, starts at 14000 ms and ends at 38000 ms with capacityMultiplier 0.3 and additionalLatencyMs 900. `ingest-spike` uses fault `spike`, type `traffic-spike`, target `collector`, starts at 18000 ms and ends at 36000 ms with trafficMultiplier 3.

## Security Considerations

The model contains no identity, credential, or network perimeter component. Schema validation is represented by `schema-svc`, and malformed-event handling is represented by `malformed-dlq`. Do not infer authentication, authorization, encryption, schema-version governance, or cloud credential behavior from this scenario.

## Observability Plan

Watch `event-topic` depth, `stream-processor` utilization, consumer lag, `malformed-dlq` growth, `aggregate-store` pressure, `warehouse` latency, and `telemetry` throughput. The observability edges from collector and processor show what should be instrumented; they do not simulate a real metrics backend.

## Simulation Exercises

Run `telemetry-firehose` without faults and identify the processing ceiling. Run `release-burst` and inspect the topic depth high-water mark. Run `stream-processor-stall` and compare backlog growth and drain behavior. Run `warehouse-degraded` to see why dashboard reads use `aggregate-store`. Run `ingest-spike` to observe burst absorption limits.

## Expected Results

A clean default run raises no architecture warnings because `expectedFindings` is empty. Directionally, collector and topic capacity should admit the steady firehose, while processor throughput determines whether backlog drains. Warehouse degradation should mostly affect warehouse-facing work, not the hot dashboard path. The simulator should show relative pressure and lag rather than exact production numbers.

## Common Failure Modes

- `stream-processor-stall`: `subscriber-group-stall` on `stream-processor` from 16000 ms to 40000 ms reduces processing capacity and grows topic backlog.
- `warehouse-degraded`: `degradation` on `warehouse` from 14000 ms to 38000 ms lowers warehouse capacity and adds latency.
- `ingest-spike`: `traffic-spike` on `collector` from 18000 ms to 36000 ms multiplies traffic and can expose collector, topic, or processor limits.

## Trade-Offs

The design protects ingest by buffering events, but backlog can hide processing shortfall until lag is large. Realtime aggregates keep dashboards off the warehouse, but introduce eventual consistency. Writing raw archive, aggregate, and warehouse copies improves downstream use cases while increasing fan-out from the processor.

## Simulator Limitations

This scenario is intentionally blunt about stand-ins. The stream processor is a `worker`, so windowing, watermarks, late-arriving events, streaming state, and exactly-once semantics are not simulated. The data lake is `object-storage`, so file formats, catalogues, partition pruning, and query engines are not simulated. The warehouse is a `relational-database`, so columnar execution, query planning, and warehouse-specific scaling are not simulated. The schema registry is a `server`, so schema version negotiation and compatibility policy are not simulated. Event payload size, compression, and scheduled batch ETL are also not modelled.

## Extension Exercises

Try the template challenges as design changes: run the firehose burst and record the topic depth high-water mark; halve the stream processor instance count and observe drain time; route dashboard traffic to `warehouse` directly and explain the latency trade-off. Keep changes inside the simulator model rather than provisioning external services.
