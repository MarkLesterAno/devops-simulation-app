---
template-id: rate-limited-public-api
template-version: 1.0.0
difficulty: intermediate
estimated-minutes: 35
---
# Rate-Limited Public API

## Overview
This scenario documents the `rate-limited-public-api` template. It models a public API protected by an edge filtering stand-in, gateway token-bucket quotas, delegated API-key validation, and a downstream service/database path. Use it with `./README.md` and `../user-guide/README.md`.

The workload is throughput-sensitive and availability-sensitive. The template focuses on rejecting abusive traffic before it consumes downstream capacity.

## Learning Objectives
Learners enforce a token-bucket quota through `gateway` settings: `rateLimitRps: 400`, `rateLimitBurst: 800`, and `rateLimitAlgorithm: token-bucket`. They compare quota rejections with downstream failures.

They also see why cheap edge and gateway rejection protects `api-svc` and `db`, and how retry amplification can make overload worse when `api-svc` retries.

## Architecture Summary
The request path is `client` -> `waf` -> `gateway`. The gateway delegates validation to `identity` and forwards accepted requests to `api-svc`, which calls `db`.

There is no cache, queue, CDN serving-cache behavior, separate rate-limiter node, or observability node. `waf` is a CDN component with `hitRatio: 0` used as a WAF stand-in.

## Functional Requirements
- Accept public API requests from `client`.
- Pass traffic through `waf`, the edge filtering stand-in.
- Enforce gateway quota behavior at `gateway`.
- Validate API keys through `identity`.
- Serve accepted requests through `api-svc` and `db`.

## Non-Functional Requirements
- Reject abusive traffic before it reaches `api-svc` where possible.
- Keep quota rejections distinct from downstream failures.
- Protect `db` from traffic spikes and retry amplification.
- Make delegated credential validation visible as a dependency.

## Components and Responsibilities
| Node ID | Type | Display Name | Key Configuration | Responsibility |
| --- | --- | --- | --- | --- |
| `client` | client | API Consumer | display name only | Generates simulated public API traffic and abuse spikes. |
| `waf` | cdn | Edge Filtering Layer | `cloudflare-waf`; `hitRatio: 0`; `perInstanceCapacityRps: 50000`; `baseLatencyMs: 4` | Represents edge filtering capacity and latency, not inspection. |
| `gateway` | api-gateway | API Gateway | `kong-gateway`; `authMode: delegate`; `policyLatencyMs: 3`; `rateLimitRps: 400`; `rateLimitBurst: 800`; `rateLimitAlgorithm: token-bucket`; `perInstanceCapacityRps: 5000` | Enforces quota policy and delegates validation. |
| `identity` | identity-auth-service | API Key Service | `keycloak`; `instanceCount: 2`; `mode: both`; `validationMode: introspection`; `cacheHitRatio: 0.85`; `failMode: fail-closed`; `perInstanceCapacityRps: 1500`; `verificationLatencyMs: 10` | Validates API keys. |
| `api-svc` | server | API Service | `aspnet-core`; `instanceCount: 4`; `perInstanceCapacityRps: 120`; `baseLatencyMs: 28`; `jitterMs: 10`; `maxRetries: 1`; `retryBackoffMs: 150`; `estimatedCostPerHour: 0.24` | Handles accepted API requests and retries once. |
| `db` | relational-database | API Database | `postgresql`; `perInstanceCapacityRps: 600`; `baseLatencyMs: 18`; `estimatedCostPerHour: 0.3` | Stores data for accepted API requests. |

## Request and Event Flows
- `client` -> `waf` is a `request` edge.
- `waf` -> `gateway` is a `request` edge with 2 ms latency.
- `gateway` -> `identity` is a `request` edge with 2 ms latency.
- `gateway` -> `api-svc` is a `request` edge with 2 ms latency.
- `api-svc` -> `db` is a `request` edge with 2 ms latency.
- The template has no `event`, `replication`, `failover`, or `observability` edges.

## Data Model and Storage Assumptions
`db` is a relational database with 600 RPS per-instance capacity, 18 ms base latency, and 0.3 estimated cost per hour. The template defines no tables, schemas, cache nodes, queues, or replicas.

`identity` includes `cacheHitRatio: 0.85` for credential validation behavior, but there is no separate cache node.

## Technology Suggestions
The template assigns `cloudflare-waf`, `kong-gateway`, `keycloak`, `aspnet-core`, and `postgresql`. These names are educational metadata only; they do not provision services and require no online connectivity or credentials.

## Traffic Profile
Default traffic profile: `api-traffic`.

- `api-traffic` (`Steady API traffic 350 RPS`): constant, 45000 ms, 350 RPS, `readRatio: 0.75`.
- `abuse-burst` (`Abusive client burst`): burst, 60000 ms, baseline 300 RPS, peak 3000 RPS, burst from 15000 ms to 32000 ms, `readRatio: 0.9`.

## Capacity and Scaling Assumptions
`waf` has 50000 RPS per-instance capacity. `gateway` has 5000 RPS per-instance capacity but enforces 400 RPS with an 800-request burst. `identity` has 2 instances at 1500 RPS each. `api-svc` has 4 instances at 120 RPS each, and `db` has 600 RPS per-instance capacity. `api-svc` has `maxRetries: 1` and `retryBackoffMs: 150`.

## Caching Strategy
There is no cache node. `identity` has `cacheHitRatio: 0.85` inside the identity component. `waf` has `hitRatio: 0` because it stands in for a filtering layer that forwards traffic rather than serving cached responses.

## Reliability and Failure Handling
Default fault scenario: `abuse-spike`.

- `abuse-spike`: fault `spike-1`, type `traffic-spike`, targets `client`, starts at 15000 ms and ends at 33000 ms, with `trafficMultiplier: 6`.
- `quota-exhaustion`: fault `quota-1`, type `quota-exhaustion`, targets `gateway`, starts at 12000 ms and ends at 34000 ms.
- `identity-outage`: fault `identity-1`, type `credential-store-unavailable`, targets `identity`, starts at 15000 ms and ends at 30000 ms.

`identity` uses `failMode: fail-closed`, so unavailable credential validation should block unknown requests.

## Security Considerations
`gateway` uses `authMode: delegate` and calls `identity`, whose `validationMode` is `introspection`. The gateway also enforces token-bucket quota settings. `waf` is only an edge filtering stand-in; packet inspection, bot detection, CAPTCHA, and IP reputation are out of scope.

## Observability Plan
The template has no observability node and no `observability` edges. Use simulator metrics for quota rejections, downstream failures, utilization, retry counts, and latency changes at `gateway`, `identity`, `api-svc`, and `db`.

## Simulation Exercises
Run `api-traffic` without faults and compare the 350 RPS load with the 400 RPS gateway limit. Run `abuse-spike`, `quota-exhaustion`, and `identity-outage` to compare quota rejections, validation failures, service utilization, and database pressure.

## Expected Results
The template declares no `expectedFindings`, so a clean default run raises no warnings. During `abuse-spike`, rejections at `gateway` should increase before all traffic reaches `api-svc` and `db`. During `quota-exhaustion`, quota failures should be visible at the gateway. During `identity-outage`, validation failures should rise.

## Common Failure Modes
- `abuse-spike`: `traffic-spike` on `client` from 15000 ms to 33000 ms multiplies traffic by 6.
- `quota-exhaustion`: `quota-exhaustion` on `gateway` from 12000 ms to 34000 ms exercises rate-limit rejection.
- `identity-outage`: `credential-store-unavailable` on `identity` from 15000 ms to 30000 ms affects delegated validation with `failMode: fail-closed`.

## Trade-Offs
Rejecting at `gateway` protects `api-svc` and `db`, but aggressive quotas can reject legitimate traffic. Delegated validation centralizes API-key checks in `identity`, but makes it a critical dependency. Retrying once in `api-svc` may help transient failures, but under overload it can amplify load.

## Simulator Limitations
Per-key and per-tenant quotas are not modelled; the limit is per gateway. The edge filtering layer inspects nothing: it applies latency and capacity only. Bot detection, CAPTCHA, and IP reputation are out of scope.

Stand-ins are explicit. `Web application firewall / DDoS protection` is modelled as the `cdn` component `waf`, so packet inspection, payload inspection, DDoS mitigation semantics, and WAF rules are not simulated. `Rate limiter` is modelled as the `api-gateway` component `gateway`, so a separate first-class rate limiter node, distributed quota store, per-key quota buckets, and standalone limiter failure modes are not simulated. The simulator has no persistent-connection or WebSocket transport model and no first-class rate limiter or WAF node.

## Extension Exercises
Set `rateLimitRps` below the steady 350 RPS arrival rate and explain the success-rate change. Move quota behavior behind authentication conceptually and describe the new failure mode. Compare token-bucket against fixed-window behavior during `abuse-spike`.
