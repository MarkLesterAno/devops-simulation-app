---
template-id: multi-tenant-saas
template-version: 1.0.0
difficulty: specialized
estimated-minutes: 60
---

# Multi-Tenant SaaS Platform

## Overview

Multi-Tenant SaaS Platform models a shared control and data plane with gateway quota enforcement, a pooled tenant database, and a dedicated enterprise shard. It is designed to show noisy-neighbour containment, pooled versus siloed routing, and quota behavior. Use it with the [scenario library index](./README.md) and the [user guide](../user-guide/README.md).

## Learning Objectives

This scenario teaches recognizing noisy-neighbour failures, comparing pooled and siloed tenant data models, using gateway quotas as isolation controls, and reasoning about the blast radius of one tenant's traffic spike. The learner should compare how shared nodes and siloed nodes react under the same load.

## Architecture Summary

`client` traffic passes through `edge-filter` and `gateway`. The gateway checks `identity`, then sends most traffic to `app-pooled` and a smaller share to `app-silo`. Both app tiers read `tenant-config`. The pooled app tier uses `db-pooled`, `db-pooled-replica`, and `tenant-jobs`; the enterprise app tier uses `db-silo` and can also publish jobs. `job-worker` consumes background work and telemetry is emitted from pooled app and worker paths.

## Functional Requirements

- Accept tenant user traffic through an edge filter and API gateway.
- Delegate identity checks from `gateway` to `identity`.
- Enforce aggregate quota at `gateway`.
- Route pooled tenants to `app-pooled` and large tenants to `app-silo` using weighted request edges.
- Serve tenant configuration from `tenant-config`.
- Store pooled tenant data in `db-pooled` with reads also using `db-pooled-replica`.
- Store enterprise tenant data in `db-silo`.
- Queue background tenant jobs in `tenant-jobs` and process them with `job-worker`.

## Non-Functional Requirements

The workload is read-heavy, availability-sensitive, and throughput-sensitive. The architecture emphasizes quota shedding before shared capacity, isolation between pooled and siloed paths, database saturation from concentrated tenant load, and background work isolation through a queue.

## Components and Responsibilities

| Node ID | Type | Display Name | Key Configuration | Responsibility |
| --- | --- | --- | --- | --- |
| `client` | client | Tenant Users | no explicit capacity settings | Produces tenant user requests. |
| `edge-filter` | cdn | Edge Filter (WAF) | technology `cloudflare-waf`; hitRatio 0; baseLatencyMs 6; perInstanceCapacityRps 30000 | Pass-through WAF stand-in that adds inspection latency and capacity. |
| `gateway` | api-gateway | Tenant API Gateway | technology `kong-gateway`; authMode `delegate`; policyLatencyMs 4; rateLimitRps 900; rateLimitBurst 300; rateLimitAlgorithm `token-bucket`; perInstanceCapacityRps 8000 | Enforces aggregate quota and routes traffic to pooled or siloed app tiers. |
| `identity` | identity-auth-service | Tenant Identity | technology `keycloak`; instanceCount 3; mode `both`; validationMode `introspection`; cacheHitRatio 0.88; verificationLatencyMs 12; failMode `fail-closed`; perInstanceCapacityRps 1400 | Validates tenant identity requests for the gateway. |
| `tenant-config` | cache | Tenant Config Cache | technology `redis`; hitRatio 0.97; ttlMs 600000; baseLatencyMs 1; perInstanceCapacityRps 20000 | Caches tenant settings read on most requests. |
| `app-pooled` | server | Shared App Tier | technology `aspnet-core`; instanceCount 8; perInstanceCapacityRps 130; baseLatencyMs 22; jitterMs 9; estimatedCostPerHour 0.64 | Handles pooled tenant requests and shared dependencies. |
| `app-silo` | server | Enterprise App Tier | technology `aspnet-core`; instanceCount 3; perInstanceCapacityRps 130; baseLatencyMs 22; jitterMs 9; estimatedCostPerHour 0.24 | Handles the dedicated enterprise tenant path. |
| `db-pooled` | relational-database | Pooled Tenant Database | technology `amazon-aurora`; perInstanceCapacityRps 700; baseLatencyMs 19; jitterMs 8; estimatedCostPerHour 0.85 | Stores pooled tenant data and replicates reads. |
| `db-silo` | relational-database | Enterprise Tenant Shard | technology `amazon-aurora`; perInstanceCapacityRps 400; baseLatencyMs 17; estimatedCostPerHour 0.55 | Stores isolated enterprise tenant data. |
| `db-pooled-replica` | read-replica | Pooled Read Replica | technology `amazon-aurora`; perInstanceCapacityRps 900; baseLatencyMs 15; estimatedCostPerHour 0.5 | Serves pooled read traffic replicated from `db-pooled`. |
| `tenant-jobs` | message-queue | Tenant Background Jobs | technology `rabbitmq`; maxQueueDepth 12000; baseLatencyMs 3; perInstanceCapacityRps 6000 | Buffers background work from both app tiers. |
| `job-worker` | worker | Job Workers | technology `celery`; instanceCount 4; perInstanceCapacityRps 70; baseLatencyMs 70; jitterMs 25; estimatedCostPerHour 0.26 | Processes queued tenant background jobs. |
| `telemetry` | observability | Per-Tenant Telemetry | technology `datadog`; perInstanceCapacityRps 30000 | Receives telemetry from pooled app and worker paths. |

## Request and Event Flows

- Shared request path: `client` -> `edge-filter` (request), `edge-filter` -> `gateway` (request), `gateway` -> `identity` (request), `gateway` -> `app-pooled` (request, weight 0.8), `app-pooled` -> `tenant-config` (request), `app-pooled` -> `db-pooled` (request), and `app-pooled` -> `db-pooled-replica` (request).
- Siloed request path: `client` -> `edge-filter` (request), `edge-filter` -> `gateway` (request), `gateway` -> `app-silo` (request, weight 0.2), `app-silo` -> `tenant-config` (request), and `app-silo` -> `db-silo` (request).
- Replication path: `db-pooled` -> `db-pooled-replica` (replication).
- Background path: `app-pooled` -> `tenant-jobs` (event), `app-silo` -> `tenant-jobs` (event), and `tenant-jobs` -> `job-worker` (event).
- Observability path: `app-pooled` -> `telemetry` (observability) and `job-worker` -> `telemetry` (observability).

## Data Model and Storage Assumptions

The pooled model stores many tenants in `db-pooled` and uses `db-pooled-replica` for read capacity. The siloed model stores the large tenant in `db-silo`. Tenant settings are cache-friendly and read through `tenant-config`. The simulator has no tenant identity, so multi-tenant isolation is modelled structurally by routing to separate nodes rather than by row-level tenant ids.

## Technology Suggestions

The template records example technologies: Cloudflare WAF, Kong Gateway, Keycloak, Redis, ASP.NET Core, Amazon Aurora, RabbitMQ, Celery, and Datadog. These selections are simulator metadata, not instructions to provision cloud services, connect credentials, or use online infrastructure.

## Traffic Profile

The default profile is `mixed-tenant-load`: mixed tenant load for 45000 ms at 640 RPS, readRatio 0.82, concurrentUsers 6000. The alternate profile is `onboarding-growth`: tenant onboarding growth for 60000 ms, ramping from 400 RPS to 1500 RPS, readRatio 0.82.

## Capacity and Scaling Assumptions

`gateway` enforces token-bucket rate limiting at 900 RPS with a burst of 300. `app-pooled` has eight instances at 130 RPS each, while `app-silo` has three instances at 130 RPS each. `db-pooled` and `db-silo` have separate capacity ceilings, and the pooled read replica adds read capacity but depends on replication from the pooled primary. Background jobs are bounded by queue depth and worker throughput.

## Caching Strategy

`tenant-config` has hitRatio 0.97 and ttlMs 600000, modeling frequently read and rarely changed tenant settings. `identity` has cacheHitRatio 0.88 for introspection behavior. `edge-filter` has hitRatio 0 because the WAF stand-in forwards traffic rather than serving cached content.

## Reliability and Failure Handling

The default fault scenario is `noisy-neighbour-spike`: fault `noisy`, type `traffic-spike`, target `app-pooled`, starts at 16000 ms and ends at 40000 ms with trafficMultiplier 2.6. `quota-exhaustion` uses fault `quota`, type `quota-exhaustion`, target `gateway`, starts at 14000 ms and ends at 36000 ms with additionalErrorRate 0.25. `pooled-db-failure` uses fault `pooled-down`, type `database-primary-failure`, target `db-pooled`, starts at 18000 ms and ends at 40000 ms.

## Security Considerations

`gateway` delegates to `identity`, and `identity` is configured to fail closed. `edge-filter` represents WAF-like edge filtering only as capacity and latency. The simulator does not model tenant ids, row-level security, tenant-specific encryption keys, onboarding workflow, billing, metering, usage aggregation, or real WAF inspection.

## Observability Plan

Watch gateway quota rejections, shared versus siloed app utilization, `tenant-config` hit behavior, `db-pooled` and `db-silo` latency, `db-pooled-replica` pressure, replication lag, `tenant-jobs` depth, `job-worker` utilization, and telemetry throughput. Compare pooled and siloed paths during noisy-neighbour faults.

## Simulation Exercises

Run `mixed-tenant-load` without faults and compare pooled and siloed utilization. Run `noisy-neighbour-spike` and confirm the siloed tenant path remains structurally separate. Run `quota-exhaustion` and observe edge shedding. Run `pooled-db-failure` and inspect the blast radius of the pooled data model.

## Expected Results

A clean default run raises no architecture warnings because `expectedFindings` is empty. Directionally, gateway quotas should shed excess traffic before it reaches shared capacity, the pooled tier should show noisy-neighbour pressure, and the siloed path should remain less affected by pooled database saturation. Results are qualitative simulator observations, not production guarantees.

## Common Failure Modes

- `noisy-neighbour-spike`: `traffic-spike` on `app-pooled` from 16000 ms to 40000 ms multiplies pooled-tier traffic and stresses shared dependencies.
- `quota-exhaustion`: `quota-exhaustion` on `gateway` from 14000 ms to 36000 ms adds gateway-level errors to model exhausted tenant quota.
- `pooled-db-failure`: `database-primary-failure` on `db-pooled` from 18000 ms to 40000 ms affects pooled tenants and shows the blast radius of shared storage.

## Trade-Offs

Pooling improves shared capacity efficiency but increases noisy-neighbour blast radius. A siloed shard isolates large tenants but duplicates app and database capacity. Gateway quota enforcement rejects work early, which protects shared nodes but can reduce accepted traffic during bursts. The tenant-config cache reduces per-request cost but hides real configuration-store behavior.

## Simulator Limitations

The quota manager is the API gateway's rate limit, so independent per-tenant buckets, billing policy, and per-key quota state are not simulated. The WAF is a pass-through `cdn` node with hitRatio 0, so packet inspection, bot detection, rules, and payload filtering are not simulated. Tenant configuration is a `cache`, so source-of-truth configuration storage and invalidation workflows are not simulated. The simulator has no tenant identity, so multi-tenant isolation is modelled structurally by routing to separate nodes rather than by data-level enforcement. Row-level security, tenant-specific encryption keys, onboarding, billing, metering, and usage aggregation are out of scope.

## Extension Exercises

Use the template challenges: run the noisy-neighbour spike and confirm the siloed tenant's latency is unaffected; set `gateway` rateLimitRps to 0 and describe what the pooled tier does instead; move the large tenant back onto `db-pooled` and observe the cost to everyone else. Keep all changes inside the offline simulator.
