# Running and Viewing Simulations

> The simulator is offline and deterministic: a run always executes fully
> inside a local Web Worker, never over a real network, and the same
> architecture, traffic, and seed always produce the same result.

## Starting, cancelling, and rerunning simulations

The toolbar's simulation controls let you set a **Seed** and a **Duration
(ms)** for the run, then:

- **▶ Run** — starts a simulation. Disabled while the architecture has a
  blocking validation error (see
  [Building Architectures](./building-architectures.md)) or while no traffic
  profile is present; the status pill reads **Blocked: fix errors** or
  **Ready to run** accordingly.
- **■ Cancel** — appears while a run is in progress and stops it; a cancelled
  run's status is recorded as `cancelled` and its metrics cover only the part
  that ran.
- Re-running is simply pressing **▶ Run** again — for example after changing
  the seed, duration, architecture, or queued request batches. Each run
  replaces the previously displayed result.

There are no separate pause/resume controls for the simulation computation
itself: the engine always computes an entire run to completion (or
cancellation) as fast as it can. What you can pause, resume, and scrub is the
**visual playback** of that finished run, described next.

## Logical simulation execution versus visual playback

These are deliberately two different things:

1. **Simulation** happens first, entirely inside a Web Worker, using logical
   milliseconds rather than wall-clock time. It always runs to completion (or
   cancellation) before you see any result.
2. **Playback** replays the finished run's recorded request-flow telemetry on
   the canvas over real time, for teaching purposes. Playback can be paused,
   resumed, sped up, slowed down, or skipped to the end — none of this can
   ever change a metric, because playback only reads data that was already
   computed. A run whose logical duration is very short is stretched to a
   minimum watchable length; this only affects how long it takes to *watch*,
   never the logical timestamps in the result.

## Playback speed controls

The playback bar (bottom of the window) appears once a run has finished and
offers:

- **⏸ Pause** / **▶ Resume** — pause and resume the animation.
- **↻ Replay** — restart playback from the beginning once it has finished.
- **⏭ Skip** — jump immediately to the end of the run.
- **Speed** — a dropdown of playback multipliers: 0.25×, 0.5×, 1×, 2×, 4×, or
  8×.
- A keyboard-operable timeline slider and a running "elapsed / total" simulated-seconds
  readout. Drag the slider, use arrow keys for small moves, or use `Home` / `End` to jump
  to either boundary. Seeking pauses on the chosen recorded instant; choose **Resume** to
  continue playing from there. It never reruns or changes the completed simulation.

## Request-flow animation

While playback is running, the canvas animates small moving indicators along
each edge, colored and labeled by flow class (**read**, **write**, **auth**,
**event**, **replication** — shown in a legend under the canvas), with a
distinct color reserved for flows that recorded a failure. A node currently
receiving traffic during playback is marked as processing on its card.

A **Flow animation** checkbox in the toolbar lets you turn this movement off
entirely (edges and totals still update; only the moving animation stops).

## Reduced-motion and animation-disable settings

Independent of the in-app **Flow animation** toggle, the whole application
respects your operating system's reduced-motion preference
(`prefers-reduced-motion: reduce`): when enabled, all CSS animations and
transitions in the app — including the flow-particle animation — are
disabled globally.

## How to interpret node and edge runtime states

- Before any run, every node shows status **"not run"**.
- After a run, each node's status dot and text reflect its peak utilization
  during the run: **healthy** (below 60%), **warning** (60–80%), **degraded**
  (80–95%), or **failed** (95%+ utilization), alongside the numeric
  utilization percentage — the status is never conveyed by color alone.
- Node cards also show a compact metrics readout relevant to that component
  type (for example p50 latency and error rate for most components, hit ratio
  for a cache, or queue depth/consumer lag for a queue).
- Edges are colored and dashed by connection kind (request, response, event,
  replication, failover, observability) and, during and after playback, show
  the request counts they carried.

See [Understanding Results](./understanding-results.md) for the full metrics
modal, and
[Fault Injection and Troubleshooting](./fault-injection-and-troubleshooting.md)
for reading these signals when diagnosing a problem.
