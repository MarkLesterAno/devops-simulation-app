# Understanding Results

## Metrics modal

Choose **View Metrics** in the toolbar (or press **Ctrl/Cmd+M**) to open the
metrics modal for the most recent run. If no run has completed yet, it simply
says so. If the run did not complete normally, a status note explains why:
the architecture was invalid, the run was cancelled, or it failed
unexpectedly — in the latter two cases the displayed metrics only cover the
portion that actually ran.

## Requests per second

The **Requests** section reports total request count, successful count,
failed count, requests per second, and error rate for the whole run.

## Success, failure, retry, and timeout counts

Alongside successful/failed counts, the modal reports **Retries** and
**Timeouts** whenever the run recorded any — useful for spotting retry
amplification (see
[Fault Injection and Troubleshooting](./fault-injection-and-troubleshooting.md)).

## Latency percentiles

A single row reports **p50 / p95 / p99 latency (ms)** for the run — the
median, 95th-percentile, and 99th-percentile end-to-end latency across all
completed requests.

## Metric trends

When a run has more than one measurement interval, the metrics modal also shows latency
(p50/p95/p99) and throughput trends. An error-rate chart appears only when the run recorded
errors. The dashed **Playback** marker follows the recorded visual playback position, so you
can relate a moment on the canvas to the corresponding measurement without changing the
simulation. Very long series are reduced for drawing while preserving their first and final
measurements; this affects only chart density, never the stored result.

## Utilization

The **Components** table's **Peak utilization** column reports, per
component, the highest utilization it reached during the run (instance
count × per-instance capacity, adjusted for health and any active fault).
This is the same value that drives a node's healthy/warning/degraded/failed
status on the canvas.

Rows are ordered by peak utilization and include a matching utilization bar. Select a row with a
pointer, `Enter`, or `Space` to focus that component on the canvas.

## Queue depth and consumer lag

The same table's **Queue / lag** column reports peak queue depth, peak
consumer lag, and/or peak replica lag for any component that produced them —
for example a Message Queue, Event Topic subscriber group, Read Replica, or
NoSQL Database.

## Cache hit ratio

The table's **Cache hit** column reports a Cache or CDN node's observed hit
ratio for the run, when applicable.

## Database pressure and replication lag

Peak replica lag (relational Read Replicas) and replication-lag-derived
staleness (NoSQL Databases under eventual/quorum consistency) are visible in
the same **Queue / lag** column, and any resulting stale reads are reflected
in the component's metrics and in findings raised for the run.

## Observed availability

When available, the modal reports **Observed availability**: completed
successful root requests divided by all completed root requests (excluding
explicitly cancelled ones). This is a measured result of the specific run —
not a guaranteed SLA and not a theoretical availability computed from static
topology.

## Educational cost estimates

If the run produced a cost figure, the modal reports **Estimated cost /
hour**, computed only from your components' configured cost-per-hour values
and logical usage during the run. It is explicitly an educational estimate,
not real provider billing.

## Finding toast notifications

When a run finishes, any findings it raised appear as **toasts** stacked in a
corner of the screen — up to three at once, with additional ones counted
behind a **"N more findings"** link. Each toast shows a severity mark and
label (⛔ Critical, ⚠ Warning, ℹ Information, or ★ Recommendation — never
color alone), a title, detail text, the affected component's name when
relevant, a summarized metric, and a suggested action when the engine has
one. Toasts never auto-dismiss — you close them explicitly with their **×**
button or **Dismiss all** — and a critical toast automatically receives
keyboard focus so it can't be missed. Each toast offers **View Metrics**
(jumps to that component's row in the metrics modal) and, when it names a
component, **Focus component** (selects it on the canvas).

Dismissing a toast only hides it; it does not delete the underlying finding.
Choose **Findings** in the toolbar (its count reflects everything raised this
session) to open the **Notification Centre**, which lists every finding
raised so far — including previously dismissed ones — until you explicitly
**Clear history**.

## Architecture warnings versus observed results versus recommendations

Every finding has a **source** that tells you where it came from:

- **Architecture warning** — a structural risk visible from the graph itself
  (for example, a single point of failure), independent of what the run
  actually measured.
- **Observed result** — a fact this specific run measured (for example, a
  component saturated, or a request path timed out).
- **Recommendation** — a suggested improvement, shown with its own
  **★ Recommendation** styling even though the engine stores it at
  informational severity.

## Stale-result status

If you edit the architecture, its traffic profile, or its fault scenarios
after a run, the metrics modal shows a **"Stale — architecture changed since
this run"** badge: the numbers you're looking at no longer describe the
current graph. Repositioning a node on the canvas does **not** mark a result
stale, since only the architecture's structure and configuration count
toward its signature. Rerun the simulation to clear the stale badge.
