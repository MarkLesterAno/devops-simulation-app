# Building an Architecture

> The simulator is offline and deterministic: adding, connecting, or
> configuring components never contacts a real network or provisions real
> infrastructure.

## Adding components from the palette

The **Components** panel on the left lists every component type, grouped by
category (Entry, Compute, Data, Messaging, Performance, Reliability,
Operations, Identity, External) and searchable by name. The catalog includes:

| Component | Category | What it represents |
| --- | --- | --- |
| Client | Entry | Generates synchronous requests that enter the system. |
| CDN | Entry | Serves cached content at the edge or forwards to origin. |
| Load Balancer | Entry | Routes work among healthy targets using a declared algorithm. |
| API Gateway | Entry | Edge routing with optional authentication delegation and rate limiting. |
| DNS / Traffic Manager | Entry | Resolves traffic to targets with a TTL and a failover/weighted/latency/geo policy. |
| Server | Compute | Hosts backend APIs; processes and forwards synchronous requests. |
| Worker | Compute | Consumes asynchronous messages from a queue or topic. |
| Cache | Performance | Reads and writes cached values and forwards misses to an origin. |
| Relational Database | Data | Serves reads and primary writes. |
| Read Replica | Data | Serves reads with modeled replication lag. |
| NoSQL Database | Data | Key-value/document/wide-column/time-series/graph/vector store with configurable consistency and partitioning. |
| Object Storage | Data | Stores and retrieves large binary objects such as files, media, and backups. |
| Message Queue | Messaging | Buffers messages for asynchronous consumers. |
| Event Topic | Messaging | Publish/subscribe fan-out with independent subscriber groups. |
| Dead-Letter Queue | Messaging | Retains messages that exceed processing attempts. |
| Circuit Breaker | Reliability | Protects downstream calls after a failure threshold is crossed. |
| Autoscaler | Reliability | Changes component instance counts after configured delays. |
| Identity & Auth Service | Identity | Authentication/authorization with token caching and a fail-open/fail-closed mode. |
| External Service | External | Represents a third-party dependency with its own latency and rate limit; cannot be autoscaled. |
| Observability | Operations | Collects metrics, logs, and traces emitted by other components. |

Click a palette entry to drop a new node onto the canvas at a default
position, or drag it onto the canvas to place it exactly where you drop it.

## Connecting components with valid edge types

Drag from a node's output handle to another node's input handle to create a
connection. The simulator infers the most sensible connection kind for the
pair of components you connect, and rejects a connection that neither
component supports with an explanatory error message (for example, "Load
Balancer does not support outgoing 'event' connections"). The supported
connection kinds are:

- **Synchronous request** (`request`) — a call that expects a response, e.g.
  Client → Load Balancer → Server.
- **Response** (`response`) — the return path for a request.
- **Asynchronous event** (`event`) — fire-and-forget delivery, e.g. Server →
  Message Queue/Event Topic → Worker.
- **Replication** (`replication`) — data flow from a primary store to a read
  replica.
- **Failover** (`failover`) — a standby path used when a primary target is
  unavailable.
- **Observability** (`observability`) — telemetry sent from any component to
  an Observability node.

Each component type declares which kinds it can send and receive; the canvas
draws each kind with a distinct color and dash pattern and labels the edge
with its kind so the wiring stays legible at a glance.

## Configuring nodes through the configuration modal

Double-click a node (or select it and press **Enter**, or right-click it and
choose **Configure**) to open its configuration modal. Non-client components
have two tabs:

- **Implementation** — select a real-world technology or keep the component
  generic (see below).
- **Inspector** — the component's numeric and categorical settings: display
  name, region, overflow behavior, instance count, per-instance capacity,
  base latency, jitter, timeout, error rate, max queue depth, retries/backoff,
  and estimated cost per hour, plus component-specific fields such as cache
  hit ratio, API gateway auth mode and rate limit, DNS TTL and resolution
  policy, NoSQL consistency/partitioning, event topic retention/partitioning,
  identity token TTL/cache/fail mode, and external-service SLA latency and
  call mode. Client nodes only expose the Inspector tab (there is no
  technology to assign to a request origin).

The same inspector fields are also available in the collapsible **Context**
panel when a node is selected, so you do not need to open the modal for quick
edits. On compact screens, use the modal because the docked panel becomes a
reduced rail.

## Selecting implementation technologies

Open a node's **Implementation** tab to search and filter the technology
catalog by name, provider, or deployment model, and choose a product (or
**Generic / Custom Implementation** to clear the assignment). Selecting a
technology that is not listed as compatible with the component type, or that
is marked legacy/deprecated, shows a warning but does not block the
selection. Selecting a technology never performs a network call or requires
credentials — it is metadata only.

Above the complete catalog, **Recommended for this component** shows a bounded
local-only ranking of compatible technologies. It considers the component role,
the active scenario's workload and difficulty, connected assignments, and your
open-source/managed-service preferences. Each card shows rationale, strengths,
trade-offs, use cases, warnings, and preset availability. It is educational
guidance, not a vendor endorsement: choosing **Use this technology** still
requires your explicit selection and never applies a preset automatically.

## Applying and reviewing technology presets

If the selected technology offers a **simulation preset**, an **Apply
simulation preset** button appears. It opens a dialog listing every field the
preset would change (current value → suggested value) with a checkbox per
field; uncheck any field you don't want changed, then **Apply selected**.
Presets are explicitly labeled as educational defaults for teaching
trade-offs, not vendor benchmarks or performance guarantees.

## Using generic/custom component configurations

You can always ignore the technology catalog entirely and tune a component's
Inspector fields by hand — this is the default state for every new node.
Assigning, changing, or resetting a technology never overwrites values you
have already tuned unless you explicitly apply a preset field.

## Duplicating and deleting nodes safely

Right-click a node to open its context menu:

- **Configure** — opens the configuration modal.
- **Duplicate** — creates a copy with a new ID, offset position, and a
  "… copy" suffix on its name. Connections are **not** copied, since a
  duplicated component's wiring is rarely what you want automatically.
- **Delete** — removes the node. If the node has connections or is referenced
  by a fault scenario, a confirmation dialog lists the number of connections
  that will also be removed and names any fault scenario that targets it,
  before you confirm.

An edge can be removed by selecting it and pressing **Delete**/**Backspace**,
or via the canvas's built-in edge controls.

## Validating an architecture before simulation

The architecture is continuously validated as you edit. Two kinds of issues
are surfaced:

- **Errors** block a simulation until repaired, including missing request
  origins/terminal paths, request-routing cycles, invalid replication paths,
  and required route/subscriber targets.
- **Warnings** explain model or resilience risks without forcing one design:
  disconnected components, single points of failure, queue consumers, multiple
  consumer semantics, questionable regional failover, and absent multi-region
  recovery routes.

- **Errors** (block simulation) — for example, no Client node exists, no
  reachable path exists from a Client to a terminal-capable component, a
  Load Balancer has no outgoing target, an API Gateway has no route (or
  delegates authentication without an Identity & Auth Service target), a DNS
  component has no resolvable target, an Event Topic has no subscriber, or a
  NoSQL Database requests strong consistency while declaring non-zero
  replication lag.
- **Warnings** (do not block simulation) — for example, a Message Queue has
  no consumer (its depth will accumulate unread), a node is disconnected from
  every edge, a single-instance Server or Worker has no redundancy, an
  External Service has no Circuit Breaker protecting callers, or an Identity
  & Auth Service is a fail-closed single instance in the critical path.

The toolbar's **Run** control is disabled while any blocking error exists and
shows **Blocked: fix errors**; once resolved it shows **Ready to run**.
