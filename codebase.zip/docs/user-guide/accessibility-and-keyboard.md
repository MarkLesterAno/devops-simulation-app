# Accessibility and Keyboard Controls

## Keyboard navigation

Press **?** or **F1** outside a form field to open the in-app **Keyboard shortcuts** reference.
The dialog uses the same focus management as other application modals and lists the available
global, selection, and context-menu commands.

Global shortcuts work anywhere in the application except while a text input,
select, or textarea has focus (for the shortcuts marked below):

| Shortcut | Action |
| --- | --- |
| **Ctrl/Cmd+S** | Save the current project. |
| **Ctrl/Cmd+Z** | Undo the last change. |
| **Ctrl/Cmd+Y** or **Ctrl/Cmd+Shift+Z** | Redo. |
| **Ctrl/Cmd+M** | Open the metrics modal (**View Metrics**). |
| **Enter** (with a node selected) | Open that node's configuration modal. |
| **Delete** or **Backspace** (with a node or edge selected) | Remove the selected node or edge. |
| **Shift+F10** (with a node selected) | Open that node's context menu, anchored to the node — the keyboard equivalent of right-clicking it. |
| **?** or **F1** | Open the keyboard shortcut reference. |

**Enter** and **Delete/Backspace** are ignored while focus is inside an
input, select, or textarea, so they never interfere with typing a value.
While a tutorial panel is open, all global shortcuts in the table are blocked
so keyboard input cannot mutate the canvas behind tutorial instructions.
Controls inside the tutorial panel remain keyboard accessible, and
**Escape** exits the tutorial.

## Canvas keyboard controls

Once a node or edge is focused/selected on the canvas (via click or normal
tab/arrow navigation), the shortcuts above operate on it directly: **Enter**
opens its configuration, **Shift+F10** opens its context menu, and
**Delete**/**Backspace** removes it. The canvas also provides the underlying
graph library's standard pan/zoom controls in its corner (rendered
controls, not a custom keyboard scheme documented here).

## Context-menu keyboard access

A node's context menu (opened via right-click or **Shift+F10**) is a proper
`menu` with `menuitem` entries (**Configure**, **Duplicate**, **Delete**).
When it opens, keyboard focus moves to its first item automatically. Use
**ArrowUp**/**ArrowDown** to move cyclically between actions, or **Home**/**End** to jump
to the first/last action. **Escape** closes the menu and returns focus to the node that
opened it; clicking outside it also closes and restores focus. Opening **Configure** transfers
focus to the configuration dialog instead.

## Focus management in modals

Every modal (node configuration, metrics, request composer, scenario
gallery, notification centre) shares the same accessible shell:

- It is marked as an `aria-modal="true"` dialog with a label matching its
  title.
- Opening a modal moves focus to its first focusable element (or the dialog
  itself if it has none), and closing it restores focus to whatever element
  had focus before the modal opened.
- **Tab** and **Shift+Tab** cycle focus among the modal's focusable elements
  only, wrapping from the last back to the first (and vice versa) — focus
  can never escape into the page behind it while the modal is open.
- **Escape** closes the modal from anywhere inside it.
- Tabbed modals (for example the node configuration modal's Implementation /
  Inspector tabs) use a proper `tablist`/`tab`/`tabpanel` structure; with a
  tab focused, **Left/Right arrow keys** move between tabs.

The tutorial is a non-modal dialog rather than a trapped modal because its
instructions require learners to inspect the canvas and activate toolbar
controls such as **Run** and **View Metrics**. Opening it moves focus to the
panel; normal Tab navigation can then reach the simulator controls. Its
progress indicator and automatic-step status are exposed to assistive
technology, and manual steps use labeled checkboxes.

## Reduced-motion preferences

The application respects your operating system's `prefers-reduced-motion:
reduce` setting: when it is enabled, all CSS animations and transitions in
the app are disabled globally, including the request-flow particle animation
during playback. Independently of the OS setting, a **Flow animation**
checkbox in the toolbar lets you turn the flow-particle animation off at any
time.

## Non-color state indicators

State is never conveyed by color alone:

- A node's health status is shown as a labeled status dot **and** a text
  label (**"not run"**, **healthy**, **warning**, **degraded**, or
  **failed**) plus its numeric utilization percentage.
- Nodes at or above 85% utilization also show a **⚠ High utilization warning**
  glyph and a highlighted border. When zooming out, secondary text is hidden
  before the utilization bar, so the most important state remains visible.
- Finding severity is shown with both a distinct glyph and a text label:
  ⛔ Critical, ⚠ Warning, ℹ Information, ★ Recommendation.
- Edges are distinguished by both color and dash pattern per connection kind,
  and are labeled with their kind; the canvas's flow legend pairs each flow
  class's color with its text label.
