# System Design Simulator — User Guide

The System Design Simulator is an **offline, deterministic, educational** tool for
designing distributed-system architectures on a canvas, running logical traffic
against them, injecting faults, and reviewing the resulting metrics. It does not
provision real infrastructure, does not make real HTTP or network calls, and does
not require or use cloud credentials of any kind. "Technology" assignments (for
example, choosing Redis for a cache node) are educational metadata and simulation
presets only — they never trigger provisioning or contact a real product.

This guide covers everything you need to use the application. For a library of
ready-to-open example architectures with their own teaching notes, see the
[Scenario Library](../scenarios/README.md).

## Contents

1. [Getting Started](./getting-started.md) — what the app is, creating/opening
   projects, templates, the canvas, saving/exporting/importing, generic vs.
   technology-assigned components.
2. [Building Architectures](./building-architectures.md) — the component
   palette, connecting nodes with valid edge types, the node configuration
   modal, technology selection and presets, duplicating/deleting nodes, and
   validating an architecture.
3. [Configuring Simulation Behavior](./configuring-simulation.md) — traffic
   profiles, capacity and concurrency, latency/jitter/timeouts/retries, cache
   behavior, replication lag, queues and dead-letter queues, routing, and
   fault scenarios.
4. [Manual Requests](./manual-requests.md) — the request composer, scenario
   request exercises, HTTP-like methods, read/write classification, request
   count and dispatch rate, payload sizes, origins, seeds, and how manual
   batches differ from real HTTP traffic.
5. [Running and Playback](./running-and-playback.md) — starting, cancelling,
   and rerunning simulations; the difference between logical simulation and
   visual playback; playback speed and transport controls; reduced motion;
   and how to read node/edge runtime states.
6. [Understanding Results](./understanding-results.md) — the metrics modal,
   per-run and per-component metrics, findings and toast notifications, and
   stale-result status.
7. [Fault Injection and Troubleshooting](./fault-injection-and-troubleshooting.md) —
   the fault model, fault types, how faults compose, and how to use findings
   to spot bottlenecks, retry amplification, and cascading failure.
8. [Accessibility and Keyboard Controls](./accessibility-and-keyboard.md) —
   keyboard navigation, canvas and context-menu keyboard access, modal focus
   management, reduced-motion behavior, and non-color state indicators.
9. [Data, Privacy, and Security](./data-privacy-and-security.md) — local
   project storage, offline-first behavior, import validation, technology
   metadata, and the privacy/telemetry policy.

When a scenario is active, use **Tutorial** in the toolbar for a local-only,
step-by-step walkthrough. Tutorial progress never changes a project or its
simulation results.

See also: [Scenario Library](../scenarios/README.md) for a catalogue of
example projects you can open directly from the in-app Templates gallery.
