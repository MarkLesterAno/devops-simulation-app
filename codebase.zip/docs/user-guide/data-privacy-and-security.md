# Data, Privacy, and Security

## Local project storage

Projects are plain JSON documents that you explicitly save, open, and export
via native file dialogs (or, in a plain-browser development context, your
browser's own file picker/download). The application does not upload,
sync, or otherwise transmit your project files anywhere.

## Offline-first behavior

The System Design Simulator is offline-first and does not require an internet
connection for normal use. Simulation, playback, metrics, and findings are
all computed locally by the application; no part of running a simulation
depends on network access.

## No cloud credentials or real deployments

Nothing in the application requests, stores, or uses cloud provider
credentials, API keys, or account access. Assigning a real-world technology
to a component (see [Getting Started](./getting-started.md)) is educational
metadata plus an optional simulation-parameter preset — it never provisions,
configures, deploys, or contacts a real service. Simulation results describe
a documented, simplified model of behavior; they are not production
guarantees or measurements of any real cloud provider.

## Imported-project validation

Every project you open — whether via **Open**, a recovered autosave draft, or
loading a scenario template — is validated against the application's project
schema before it replaces the current document. A file that is malformed,
fails schema validation, or otherwise can't be parsed is rejected with an
error message, and the project you were already working on is left
unchanged.

Autosave/recovery drafts are written to an application-owned local directory
rather than beside your own files, are size-bounded, and are likewise
validated through the same project schema before being restored. See the
recovery banner behavior described in
[Getting Started](./getting-started.md).

## Technology logos and license notices

The technology catalog used by the **Implementation** tab displays each
product's name, provider, and (where available) a link to its official
public documentation. Technology entries are informational metadata only —
selecting one never downloads, bundles, executes, or contacts anything
related to that product.

## Privacy and telemetry policy

The application collects no telemetry, analytics, usage data, cloud
credentials, or user identifiers. Your projects remain entirely local unless
you explicitly export or share them yourself. No external network request is
required for normal use of the simulator.
