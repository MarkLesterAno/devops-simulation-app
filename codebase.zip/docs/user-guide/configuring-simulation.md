# Configuring Simulation Behavior

> All simulation behavior described here is computed locally by a deterministic
> engine. No real network calls, provisioning, or infrastructure changes ever
> occur, regardless of how a component or fault is configured.

## Traffic profiles

A project carries one or more **traffic profiles**: a total duration plus a
list of intervals, each with a schedule kind (`constant`, `step`, `ramp`, or
`burst`), a start/end time, and a start/end requests-per-second value. A
profile also declares a read/write ratio, a concurrent-user count, and default
request/response payload sizes.

- A brand-new project starts with a default profile: **constant 100 RPS for
  30 seconds**, so **Run** is never blocked purely for lack of traffic.
- Scenario templates from the [Scenario Library](../scenarios/README.md) each
  ship with their own tailored profile (visible as "Default traffic" in the
  scenario gallery's detail pane).
- The toolbar's simulation controls let you set the **seed** and the **run
  duration** for the active run; the traffic profile itself is currently set
  by which template you opened (or the default profile on a new project) —
  editing individual traffic intervals is done by exporting the project JSON,
  editing its `trafficProfiles` array to the shape described above, and
  reopening it, which re-validates the document against the same schema the
  application uses internally.

## Capacity and concurrency

Each component's Inspector tab exposes:

- **Instance count** — how many parallel instances serve traffic.
- **Per-instance capacity** — requests per second one instance can sustain.
- **Overflow behavior** — `queue`, `reject`, `shed-load`, or `penalty`, applied
  once offered work exceeds instance count × per-instance capacity (adjusted
  for health and any active fault capacity factor).
- **Max queue depth** — the ceiling before queuing itself starts rejecting or
  penalizing further work.

A component's traffic-profile concurrent-user setting shapes how much read
traffic converges on shared dependencies such as caches and databases.

## Latency, jitter, timeouts, and retries

Also on the Inspector tab:

- **Base latency (ms)** and **Jitter (ms)** — the component's baseline
  processing delay and the random spread added around it. Jitter of 0
  disables randomness for that component.
- **Timeout (ms)** — the deadline a request travelling through this component
  must meet; exceeding it produces a terminal timeout rather than a slow
  success.
- **Max retries** and **Retry backoff (ms)** — how many additional attempts a
  failed request may make, and the delay before each retry. Retries are
  counted in the run's metrics and can amplify load on a struggling
  downstream dependency (see
  [Fault Injection and Troubleshooting](./fault-injection-and-troubleshooting.md)).

## Cache hit/miss behavior and TTL

A Cache or CDN node exposes a **Hit ratio** field in its Inspector tab: the
share of reads served from cache without reaching the origin. A cache also
carries a TTL and eviction policy in its underlying configuration (defaulted
when the node is created, and adjustable via a technology preset or by
editing the project file); these are not yet exposed as separate Inspector
controls in this release. On a miss, the configured origin path is called and
counted accordingly in per-component metrics.

## Database replication and replica lag

A **Read Replica** node models asynchronous replication from its primary
**Relational Database** with a configured replica-lag value: while lag is
non-zero, reads from the replica may return stale data, which is reflected in
its metrics. A **NoSQL Database** node's Inspector tab exposes a
**Consistency** field (`eventual`, `quorum`, or `strong`) and a
**Replication lag (ms)** field directly: eventual reads may be stale while lag
is non-zero, quorum reads add latency proportional to lag without going
stale, and strong consistency requires zero lag — the architecture validator
blocks a run if you declare strong consistency with non-zero lag.

## Queue throughput, retention, consumer lag, and dead-letter queues

A **Message Queue** or **Event Topic** buffers asynchronous work for one or
more **Worker** consumers. Each outgoing worker connection from an Event
Topic is an independent subscriber group with its own lag, so a slow consumer
group falls behind without affecting others. Messages older than the topic's
retention window are dropped and counted as data loss. A queue's **Max queue
depth** (Inspector tab) is the point past which its overflow behavior
applies; **queue depth** and **consumer lag** are reported live during
playback and in the metrics modal. Connect a queue or topic's `failover` edge
to a **Dead-Letter Queue** node to route messages that exceed their
processing-attempt budget.

## Load-balancing strategies

A Load Balancer (or any node fanning requests out to multiple targets) routes
using a declared strategy — round robin, weighted, least active, random, or
conditional — with unhealthy targets excluded automatically. The engine
defaults new connections to round robin; scenario templates may declare a
different strategy on a connection. There is no dedicated strategy picker in
the Inspector in this release; a non-default strategy is set when a template
authors it, or by editing the relevant edge's `routingStrategy` field in the
exported project JSON.

## Health checks, circuit breakers, failover, and autoscaling

These behaviors are modeled by dedicated components you add from the
palette, rather than as checkboxes on other nodes:

- **Load Balancer** — excludes unhealthy targets from routing automatically.
- **Circuit Breaker** — protects a downstream call after a configured rolling
  failure threshold is crossed, cycling `closed → open → half-open → closed`.
- **Autoscaler** — observes a metric on its connected component and schedules
  instance-count changes after a cooldown and provisioning delay; scaling is
  never instantaneous.
- **DNS / Traffic Manager** — fails over to the next healthy target according
  to its resolution policy, bounded by its configured TTL (a cached answer
  keeps pointing at an unhealthy target until the entry expires).

## Fault scenarios and fault scheduling

Fault scenarios — outages, latency/error injection, capacity reductions,
network failures, traffic spikes, and more — are fully modeled by the engine
and used throughout the [Scenario Library](../scenarios/README.md)'s
templates. See
[Fault Injection and Troubleshooting](./fault-injection-and-troubleshooting.md)
for the full fault model, the fault types available, and an important note
about how fault scenarios are currently authored and applied in this build.

Use the **Faults** checkboxes in the toolbar to arm one or more fault scenarios for the next run.
The adjacent count confirms how many scenarios are armed. Selecting or clearing faults changes only
the next simulation input: it does not edit the project, create undo history, or persist a hidden
fault selection. Scenario templates can therefore safely declare multiple default fault exercises.
