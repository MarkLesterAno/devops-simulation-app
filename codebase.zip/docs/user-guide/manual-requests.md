# Manual Requests

## Scenario request exercises

When you open a scenario template, the **Send requests** dialog offers seven
deterministic request exercises before the normal composer fields:

- **Baseline request flow** reflects the template's nominal traffic.
- **Read path** and **Write path** make the request classification explicit
  for comparing modeled paths.
- **Burst load** sends a brief overload burst.
- **Sustained load** runs nominal load for one logical minute and is paired
  with scenario fault exercises.
- **Capacity boundary** stays below the narrowest modeled capacity.
- **Capacity overload** exceeds that capacity to make saturation observable.

Selecting an exercise only fills the composer. Review or edit the values and
choose **Queue batch** to include it in the next simulation. These batches are
session-only and do not alter the project template.

## The request composer

Choose **Send requests** in the toolbar to open the request composer. It lets
you define one or more **batches** of requests to dispatch alongside (or
instead of) the traffic profile's normal load, then queues them to be
included the next time you run a simulation. A note in the composer states
plainly: requests are simulated inside the deterministic engine, and **no
network traffic leaves the application**.

If your project has no Client component yet, the composer tells you to add
one — a batch always needs a Client node as its origin.

## HTTP-like request methods

Each batch specifies one HTTP-like method: `GET`, `POST`, `PUT`, `PATCH`,
`DELETE`, `HEAD`, or `OPTIONS`. This is descriptive simulation metadata that
shapes routing and classification — the engine never issues a real HTTP call
of any kind.

## Read/write classification

A batch is classified as a **Read**, **Write**, or **Requires
authentication** request class. Leaving this as **Infer from method** derives
the class from the HTTP method: `GET`, `HEAD`, and `OPTIONS` are treated as
reads, and everything else as a write, unless you explicitly override it.

## Request count and dispatch rate

- **Number of requests** — how many requests the batch contains (1 up to
  1,000,000).
- **Dispatch rate (req/s)** — how quickly they are issued (up to 1,000,000
  req/s). Arrivals are spaced evenly, so a batch of 1,000 requests at 100
  req/s occupies exactly 10 simulated seconds.
- **Start at (ms)** — the simulated time, relative to the run's start, at
  which the batch begins dispatching.

The composer previews the resulting duration ("This will dispatch **N**
method requests over **D** simulated seconds…") before you queue the batch.

## Logical payload sizes

Optional **Payload size (bytes)** and **Response size (bytes)** fields let you
override the request/response size used for this batch's logical bandwidth
accounting; leaving them blank falls back to the traffic profile's or
component's default. An optional **Timeout (ms)** field overrides the
client's default deadline for this batch only.

## Request origin selection

The **Origin** field selects which Client node on the canvas the batch is
issued from. If more than one Client exists, choose the one relevant to the
scenario you're testing (for example, a mobile client versus a web client).

## Deterministic seed selection

An optional **Seed override** lets a batch draw its own random values (for
example, any per-request jitter) independently of the run's overall seed,
while leaving the rest of the run's seeded sequence unaffected. Leaving it
blank uses the run's seed.

## How manual requests differ from real HTTP requests

A manual batch is converted into logical arrival events inside the
deterministic engine, exactly like traffic-profile load is. Sending "1,000
PUT requests" means simulating 1,000 PUT arrivals against your architecture —
it never opens a socket, contacts a server, or requires any credentials.
Manual batches also consume no random draws for their method or read/write
class (those are declared explicitly), so queuing a batch never shifts the
seeded random sequence used by ordinary profile-generated traffic.

You may also check **Dispatch only these batches (suppress traffic-profile
load)** to run a simulation containing *only* your manual batches, with no
profile-generated traffic at all — useful for isolating the effect of a
specific request pattern.

Queued batches are listed with their dispatch rate and duration and can be
removed individually. Before running, make sure the run **Duration (ms)** in
the simulation controls is at least as long as the longest queued batch needs
to finish dispatching — the composer reports the minimum required duration,
and the toolbar flags a queued batch with **"run duration too short"** if the
current duration would truncate it.

## How manual request batches appear in metrics and visual playback

Manual batches are dispatched alongside profile traffic in the same run and
are indistinguishable from it in the canvas's live playback — they use the
same flow-class colors and animation as any other traffic. After a run, the
[metrics modal](./understanding-results.md) lists a **Manual request batches**
section naming which batch IDs were included, so their contribution to the
run's totals stays traceable.
