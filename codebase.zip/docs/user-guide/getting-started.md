# Getting Started

## Choosing a scenario learning mode

The Scenario Library offers three starting states:

- **Guided Tour** opens the scenario reference solution for walkthrough and
  measurement.
- **Build** opens an intentionally incomplete starting state. Use the
  scenario objectives and constraints to decide which components and
  connections to add.
- **Challenge** opens an empty canvas with the scenario's traffic and fault
  definitions available for independent design work.

Different topology is not treated as an error. Compare results using the same
traffic profile, request exercise, fault, duration, and seed rather than
trying to reproduce the reference graph.

## What this application is

The System Design Simulator is an **offline-first, deterministic, educational**
desktop application for designing system architectures and studying how they
behave under simulated traffic and failure conditions. Everything you see —
requests, latency, errors, queue depth, replication lag, cost estimates — is
computed by a local simulation engine running in a Web Worker. The application:

- Never makes real HTTP requests or opens real network sockets to simulate traffic.
- Never provisions, configures, or contacts real cloud infrastructure.
- Never requires cloud credentials, API keys, or an internet connection to run
  a simulation.
- Produces the same result every time for the same architecture, traffic
  profile, and seed — the engine is deterministic.

Assigning a "technology" (for example, PostgreSQL, Redis, or Kafka) to a
component is **educational metadata and an optional simulation-parameter
preset only**. It never creates, contacts, or configures the real product; the
simulation behaves the same whether or not a technology is assigned, except
for whichever numeric defaults (latency, capacity, etc.) a preset chooses to
fill in for you.

## First time here?

On the first launch, the **Welcome** screen summarizes these model boundaries
and offers three safe starting routes:

- **Start guided beginner scenario** loads the Basic Web Application reference
  solution and starts its local tutorial.
- **Browse scenarios** opens the scenario library, where you can choose Guided
  Tour, Build, or Challenge mode.
- **Build from scratch** dismisses the screen and leaves the blank project
  unchanged.

The choice is stored as a local display preference only. Use **Help** in the
toolbar whenever you want to reopen the welcome screen; it never modifies,
saves, or exports the current project.

## Creating a project

Choose **New** in the toolbar to start a blank, untitled architecture. A new
project starts with no components and a default constant 100 requests/second,
30-second traffic profile already attached so a run is never blocked purely
for lack of traffic configuration.

## Opening an existing project

Choose **Open** in the toolbar to load a previously saved project file from
disk (via the native file dialog when running as a desktop app, or a browser
file picker in a plain web/dev context). Opened files are validated against
the application's project schema before they replace the current document; a
malformed or unrecognized file is rejected with an error message and the
current project is left untouched.

## Starting from a template

Choose **Templates** in the toolbar to open the scenario gallery. It lists the
example architectures from the [Scenario Library](../scenarios/README.md),
searchable by name/tag/objective and filterable by difficulty. Opening a
scenario creates a **new, unsaved copy** of that template on the canvas —
editing or saving it never modifies the shipped template, and if your current
project has unsaved changes you are asked to confirm before it is replaced.

Every shipped scenario also has a local walkthrough. Select a scenario and
choose **Start tutorial** to open it and begin immediately, or use
**Tutorial** in the toolbar after a scenario is open. The Basic Web
Application tutorial provides the full pilot walkthrough; the other scenarios
provide lightweight overviews limited to supported actions: observing the
architecture, running configured traffic, opening metrics, and acknowledging
what you reviewed. Use **Back**, **Next**, **Restart**, or **Exit** in the
floating tutorial panel. Tutorial progress is stored locally in application
storage and is never added to or saved with a project document.

## Understanding the canvas

The canvas (center of the window) is where you build an architecture:

- Drag a component from the **Components** palette on the left onto the
  canvas, or click a palette entry to drop it at a default position.
- Components render as node cards showing their type, name, assigned
  technology (if any), a run-status indicator, and — after a simulation has
  run — a compact readout of key metrics (latency, error rate, cache hit
  ratio, queue depth/consumer lag, and similar values relevant to that
  component type).
- Drag from a node's right-hand handle to another node's left-hand handle to
  create a connection (edge).
- A minimap and pan/zoom controls (bottom corners) let you navigate large
  architectures; below a certain zoom level, per-node detail rows are hidden
  automatically to keep the canvas readable.

See [Building Architectures](./building-architectures.md) for how to add,
connect, configure, and validate components in detail.

## Saving, exporting, and importing projects

- **Save** writes the current project to its file (prompting for a location
  the first time, or when using the browser fallback, which downloads a
  `.json` file).
- **Export JSON** writes a copy of the project document to a location you
  choose, independent of the file the project is currently saved to.
- **Open** (see above) is how a previously saved or exported project file is
  imported back in; imported documents are always validated against the
  project schema first.
- The toolbar's **Unsaved changes / Saved** indicator shows whether the
  in-memory document differs from what was last saved. A separate autosave
  indicator (**Autosaving… / Draft saved / Autosave failed**) shows the status
  of a local, application-owned recovery draft that is written automatically
  as you work; autosave never writes to your project file and never affects
  the Save/Unsaved indicator. If a recovery draft is found on launch, a banner
  offers to **Keep** or **Discard** it. See
  [Data, Privacy, and Security](./data-privacy-and-security.md) for where
  these files live and how they're validated.

## Generic components versus selected technology implementations

Every component starts out as a **generic / custom implementation** — a set of
plain numeric parameters (capacity, latency, error rate, timeouts, and so on)
you configure directly. From a node's **Implementation** tab you may instead
select a real-world **technology** (for example, Amazon S3 for object
storage, or Kafka for an event topic) from a searchable, filterable catalog.
Selecting one:

- Attaches display metadata (name, provider, and — where available — a link
  to the product's official documentation) to the node.
- Optionally offers a **simulation preset**: a reviewable, field-by-field set
  of suggested parameter values (for example, typical latency or capacity)
  that you can accept or reject per field before it is applied.
- Never performs a network call, provisioning action, or credential prompt of
  any kind — a technology assignment is metadata plus optional preset values,
  nothing more.

You can reset a node to **Generic / Custom Implementation** at any time
without losing any values you have tuned by hand.
