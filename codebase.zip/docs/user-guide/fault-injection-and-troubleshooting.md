# Fault Injection and Troubleshooting

> Every fault described here is a deterministic, offline model computed by the
> simulation engine. Injecting a fault never causes a real outage, a real
> network failure, or any effect outside this application.

## The fault model

A **fault scenario** is a named collection of **scheduled faults**, each with:

- a **target** — one or more node IDs, edge IDs, or a region name;
- a **type** (see below);
- a **start time** and optional **end time**, in simulated milliseconds; and
- type-specific effect settings, such as a capacity multiplier, additional
  latency, additional error rate, or a traffic multiplier.

Multiple active faults compose deterministically:

- **Availability** — any outage-type fault makes its target unavailable.
- **Capacity** — active capacity multipliers multiply together (never
  producing a negative result).
- **Latency** — additive latency faults sum.
- **Error rate** — independent error probabilities combine as
  `1 − product(1 − errorRate)` across active faults.
- **Network faults** affect only the edge they target.
- **Regional outages** affect every node and edge assigned to that region.

When a fault ends, only its own effects are removed — the component returns
to whatever state its remaining faults and recovery configuration imply.

## Fault types

| Fault type | Simulates |
| --- | --- |
| `node-outage` | The targeted component becomes fully unavailable. |
| `degradation` | The targeted component runs in a degraded health state. |
| `latency-increase` | Additional latency added to the target. |
| `error-rate-increase` | Additional error probability added to the target. |
| `capacity-reduction` | A capacity multiplier below 1 applied to the target. |
| `network-failure` | An edge fails or degrades independently of its endpoints. |
| `traffic-spike` | A traffic multiplier temporarily increases offered load. |
| `cache-failure` | The targeted cache stops serving hits. |
| `database-primary-failure` | The primary database becomes unavailable. |
| `queue-consumer-failure` | Consumers stop draining a queue or topic. |
| `regional-outage` | Every node/edge in a region is affected at once. |
| `quota-exhaustion` | An API gateway's rate limit is driven to rejecting traffic. |
| `stale-dns-record` | A DNS/traffic-manager entry keeps resolving to an unhealthy target until its TTL expires. |
| `partition-hotspot` | A NoSQL database's partition skew is driven up, throttling below aggregate capacity. |
| `subscriber-group-stall` | One event-topic subscriber group falls behind independently of others. |
| `credential-store-unavailable` | An identity/auth service becomes unavailable, exercising its fail-open/fail-closed behavior. |
| `provider-throttling` | An external service starts rejecting calls above its provider rate limit. |

These types are used throughout the [Scenario Library](../scenarios/README.md)'s
templates to teach specific failure modes (see each scenario's "Recommended
simulation scenarios" for how it uses them).

## Current authoring and run behavior

Fault scenarios are fully modeled by the simulation engine and are part of
every project's saved document (`faultScenarios`), and scenario templates
ship with their own pre-authored fault scenarios that you can inspect by
choosing **Export JSON** after opening a template. **In this release, the
toolbar's ▶ Run control does not yet include a picker for selecting which
fault scenario to activate, so a toolbar-triggered run always executes with
no active fault scenario**, even if the current project's document contains
one. There is no in-app timeline editor for authoring new fault scenarios
either. Treat the fault types and composition rules above as the model that
scenario templates and the engine itself follow, rather than as toolbar
controls you operate directly today.

## Reading fault timelines

When a fault scenario is active in a run (as scenario-template authors and
automated checks exercise it), each scheduled fault's start and end are
recorded as significant events in the run's **event timeline**, visible in
the metrics modal alongside routing, timeout, and circuit-breaker
transitions, each with a simulated timestamp and a short message. Faults are
also the highest-priority event class at a shared timestamp, so a fault's
start or end is always ordered before the request activity it affects in the
same instant.

## Identifying bottlenecks

Regardless of whether a fault is active, the same signals point at a
bottleneck:

- A component's **Peak utilization** in the metrics modal approaching 95%+
  (shown as **failed** status on its canvas card) means it saturated during
  the run.
- Rising **Queue depth** or **consumer lag** on a queue/topic component means
  its consumers can't keep up with arrivals.
- A widening gap between **p50** and **p95/p99 latency** suggests a subset of
  requests are queuing or retrying behind a slow or saturated dependency.

## Understanding retry amplification and cascading failure

The metrics modal's **Retries** and **Timeouts** counts (see
[Understanding Results](./understanding-results.md)) are the first place to
look: a high retry count relative to total requests means failed attempts
against a struggling dependency are generating additional load on top of the
original traffic — which can itself push that dependency further into
overload, a classic cascading-failure pattern. Findings raised as
**Observed result** toasts will often name the specific component and
explain what was measured; an **External Service** with
`idempotencySupported` set to false additionally surfaces a finding when its
retried calls would produce duplicate side effects.

## Using findings to improve an architecture

Toasts and the Notification Centre distinguish **architecture warnings**
(structural risk visible from the graph, such as a single point of failure or
a Message Queue with no consumer), **observed results** (what a specific run
actually measured), and **recommendations** (a suggested change). Each
finding may include a **suggested action** — read it, make the corresponding
change (add redundancy, add a Circuit Breaker, increase capacity, shorten a
retry budget, etc.), and rerun the simulation to confirm the metric you were
chasing improved. Remember that changing the architecture marks the previous
result **stale** until you rerun.
