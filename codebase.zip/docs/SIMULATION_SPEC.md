# Simulation Specification

## Purpose

This specification defines the deterministic behavior of the Ultimate System Design Simulator. It establishes what the engine models, what it intentionally simplifies, and how requests, events, failures, and metrics are calculated.

The simulator is educational. Its results describe behavior under documented assumptions; they are not production guarantees or direct measurements of a cloud provider.

Current `ENGINE_VERSION`: `0.3.0`.

## Core principles

- A simulation runs from an immutable snapshot of a valid project, traffic profile, fault schedule, settings, and seed.
- Equal inputs and seed must produce equal outputs.
- Simulation state is isolated from persisted project configuration.
- Time is logical milliseconds, not wall-clock time.
- The engine records aggregated metrics and bounded diagnostic events rather than unlimited per-request traces.
- Each result exposes the component versions and simulation assumptions used to produce it.

## Simulation input

```ts
interface SimulationInput {
  projectSnapshot: ProjectDocument;
  trafficProfileId: string;
  faultScenarioIds: string[];
  durationMs: number;
  seed: number;
  settings: SimulationSettings;
  manualRequests?: ManualRequestDefinition[];
  suppressProfileTraffic?: boolean;
}

interface SimulationSettings {
  metricIntervalMs: number;
  maxRecordedEvents: number;
  maxEventsProcessed: number;
  maxHopCount: number;
  samplingRate: number;
}
```

Runs must reject inputs that are invalid, reference absent project entities, exceed configured engine safeguards, or contain unresolved validation errors.

Current validation additionally blocks request-routing cycles and replication edges that do not
connect data components. It warns about missing queue consumers, simplified multi-consumer
semantics, questionable cross-region failover, and multi-region graphs without an explicit
recovery route. These checks describe model boundaries; they do not require users to reproduce a
single reference architecture.

## Time and event ordering

The engine uses a stable, time-ordered priority queue. Events sort by:

1. Scheduled logical time in ascending order.
2. Event-priority class in ascending order.
3. Monotonic sequence number in ascending order.

At a shared timestamp, events use the following priority:

1. Fault start and fault end.
2. Autoscaling completion and health-state changes.
3. Timeout and circuit-breaker transition.
4. Component completion and asynchronous consumer work.
5. Request arrival, forwarding, and retry.
6. Metric snapshots.

The engine adds a sequence number when an event is created. It must not depend on browser timing, object iteration order, or non-seeded randomness.

## Request model and routing

Each generated request has a unique run-scoped identifier, root identifier, attempt number, creation timestamp, deadline, request class, read/write classification, and hop count. Engine version `0.3.0` adds optional HTTP-like request metadata: method, origin node id, manual batch id, path, logical payload size, and logical response size. These fields are descriptive simulation inputs only; they never cause real network I/O.

### Request lifecycle

```text
created -> arrived -> admitted | queued | rejected
admitted -> processing -> forwarded | completed | failed | timed out
queued -> admitted | rejected | timed out
failed -> retry scheduled | terminal failure
```

### Routing rules

- A synchronous request starts at a configured client or request-origin node.
- It follows outgoing `request` edges.
- A component selects a route using its declared routing strategy.
- A terminal component completes a request when it emits a response or satisfies the component-specific completion contract.
- An edge contributes its latency and failure behavior before the target receives the request.
- A `response` edge is optional visual metadata in MVP; latency on a synchronous dependency is represented by the relevant request/dependency path. A later fidelity tier may model separate return paths.
- `event` edges create asynchronous messages and do not block the source request unless the source explicitly uses synchronous publish semantics.
- `replication`, `failover`, and `observability` edges are not ordinary request routes.

### Branching

- A node with multiple normal request targets must use a declared strategy: weighted distribution, round robin, least active, random, or conditional path.
- The initial MVP supports weighted distribution, round robin, least active, and deterministic seeded random selection.
- Conditional routing is valid only when a supported predicate is declared; unsupported predicates block the run.
- Fan-out must declare whether all targets are required or whether the first successful response completes the operation.
- Fan-in only completes after its declared join rule is met.

### Loop protection

- The validator rejects request-routing cycles.
- Every request has a `maxHopCount`; exceeding it causes a terminal `routing-loop` failure.
- Retries increment attempt count but do not reset hop count or deadline.

## Component runtime state

Each component has isolated runtime state:

```ts
interface ComponentRuntimeState {
  health: "healthy" | "degraded" | "unavailable" | "recovering";
  instanceCount: number;
  activeWork: number;
  queuedWork: number;
  circuitState?: "closed" | "open" | "half-open";
  appliedFaults: RuntimeFault[];
}
```

Persistent configuration is never mutated during a run.

### Effective capacity

```text
effective capacity =
instance count × per-instance capacity × health factor × fault capacity factor
```

If offered work exceeds capacity, a component follows its configured overflow behavior: queue, reject, shed load, or apply an overload latency/error penalty. Components must declare their supported overflow behavior.

## Latency and deadline behavior

Request latency is the sum of edge transit delay, queue wait, component processing delay, downstream dependency delay, and retry delay.

Each request has a deadline. A request that reaches its deadline before completion becomes a terminal timeout. Work that completes after the deadline must not turn a timed-out request into a success, though it may still have a component side effect if the modeled operation is non-cancellable. That side effect must be recorded in diagnostics.

Base latency, jitter, and overload penalties use the seeded random source. Jitter is disabled when configured to zero.

## Traffic generation

The MVP supports these deterministic traffic schedules:

| Schedule | Definition |
|---|---|
| Constant | Fixed RPS for a defined interval. |
| Step | Changes from one fixed RPS level to another at defined times. |
| Ramp | Interpolates linearly between two RPS levels. |
| Burst | Adds a fixed or percentage increase for a defined interval. |

Arrival generation uses deterministic evenly distributed arrivals by default. A seeded stochastic arrival mode may be enabled later and must identify its distribution in result metadata.

Read/write ratios are assigned by seeded sampling. A profile must either total exactly 100% or be normalized with a user-visible warning.

### Manual request batches

`SimulationInput.manualRequests` may add user-composed request batches after profile traffic has
been generated. `suppressProfileTraffic` allows a run to use only those manual batches. A
`ManualRequestDefinition` contains `id`, `sourceNodeId`, `method` (`GET`, `POST`, `PUT`, `PATCH`,
`DELETE`, `HEAD`, or `OPTIONS`), `requestCount` (1..1,000,000), `dispatchRateRps`
(0.001..1,000,000), `startAtMs`, optional `path`, `requestClass`
(`read`, `write`, or `auth-required`),
payload and response sizes, timeout, seed, and label.

Manual arrivals are evenly spaced:

```text
arrivalTimeMs = startAtMs + index × (1000 / dispatchRateRps)
```

The engine computes each arrival by multiplication rather than repeated addition, so floating-point
drift cannot accumulate. A batch of 1,000 requests at 100 RPS creates exactly 1,000 arrivals over 10
logical seconds.

Manual batches consume no random draws: the method and read/write class are user-declared. Adding a
batch therefore cannot shift the seeded generator sequence used by profile traffic; unchanged
profile requests keep the same sampled classes and observed availability. Manual arrivals are
scheduled after profile arrivals, so at an identical timestamp pre-existing profile events keep
their original sequence numbers.

Manual request batches are logical arrivals only; no network activity of any kind occurs.

## Component semantics

### Load balancer

The MVP supports round robin, weighted round robin, least active, and seeded random selection. Unhealthy targets are excluded. If no healthy target exists, the request fails with `no-healthy-target`.

### Cache

A cache lookup yields a hit, miss, expired entry, eviction, or unavailable result. On a hit, the configured cache latency is applied and the origin is not called. On a miss, the configured origin path is called. Cache writes happen only when explicitly configured. The initial model does not guarantee cache-coherency behavior beyond configured TTL and invalidation events.

### Database and replica

The initial relational database model supports primary writes and replica reads. Writes addressed to a replica fail validation unless the component explicitly represents a multi-primary or writable replica mode.

Replication is asynchronous by default. A replica may return stale data while replication lag is non-zero. The MVP does not model row-level locks, query planners, transaction isolation anomalies, or conflict resolution.

### Queue and worker

Queues model depth, maximum depth, retention time, producer throughput, consumer throughput, concurrency, and optional dead-letter routing.

The MVP queue is at-least-once at the logical message level: a configured failed processing attempt may lead to retry and duplicate delivery. Strict ordering, partitions, visibility timeouts, and exactly-once processing are deferred unless a queue component explicitly supports them.

### Circuit breaker

A circuit breaker tracks a configured rolling failure threshold. It transitions:

```text
closed -> open -> half-open -> closed
```

Open circuits fail fast. Half-open circuits allow only the configured probe volume. State transitions are emitted as simulation events.

### Autoscaler

An autoscaler observes a configured metric at the configured interval. It schedules scale actions after cooldown and provisioning delay. Autoscaling does not instantly increase capacity.

### API gateway

The gateway applies `policyLatencyMs`, evaluates its rate-limit bucket, optionally authenticates, and then selects one of its configured routes by seeded weighted choice. Over-quota requests fail with `quota-exceeded`; requests failing authentication fail with `unauthenticated`. Both outcomes are counted as failed root requests with distinct reason codes and are never silently dropped.

Rate limiting is modeled per gateway node. Distributed quota coordination is represented only when the gateway is connected to a cache component, which then absorbs the counter load.

### DNS and traffic manager

Resolution maps a name to a target and caches the answer for `ttlSeconds`. The first resolution pays `resolutionLatencyMs`; cached resolutions are free and do **not** re-evaluate target health. A cached answer pointing at an unhealthy target keeps failing until the entry expires, which is the primary mechanism by which DNS TTL sets a floor on observed recovery time.

Policies are `weighted` (seeded weighted choice), `latency` (lowest modeled base latency), `failover` (first healthy target in declared order), and `geo` (region match, falling back to declared order).

### NoSQL database

Each operation selects a partition by seeded draw biased by `hotPartitionSkew`. Capacity is enforced per partition, so a skewed key space throttles well below aggregate capacity.

Under `eventual` consistency a read may return stale data while `replicationLagMs` is non-zero, and is counted as a stale read. Under `quorum` a read adds latency proportional to replication lag but is not stale. `strong` consistency requires `replicationLagMs` to be zero and is rejected by validation otherwise.

### Event topic

A publish creates one logical delivery per subscriber group. Each group drains independently at its configured concurrency, so a slow group accumulates lag without affecting other groups. Messages older than `retentionMs` are dropped and recorded as data loss. Failed deliveries route to a dead-letter queue over a `failover` edge when configured.

Fan-out amplification is reported as published events multiplied by subscriber-group count. Ordering is modeled only within a partition; partition rebalancing, consumer-group coordination protocols, and exactly-once semantics are not modeled.

### Identity and auth service

`local-jwt` validation costs only `verificationLatencyMs` at the caller and produces no network hop. `introspection` forwards a request to the identity component and is subject to its capacity, latency, and health. Validated tokens are cached until `tokenTtlMs` expires.

When the component is unavailable, `fail-closed` rejects dependent requests with `auth-unavailable` while `fail-open` admits them and records a security-posture finding. Cryptography, token formats, and OAuth/OIDC flow steps are not modeled.

### External service

Third-party dependencies apply `slaLatencyMs` and `errorRate`, and reject calls above `providerRateLimitRps` with `provider-throttled`. They never autoscale, and autoscaler edges to them are rejected by validation — the inability to scale a third party is the lesson.

When `idempotencySupported` is false, retried calls are counted as duplicate side effects and surfaced as a finding. The component performs no real I/O and holds no credentials; `providerLabel` is display metadata only.

## Retry behavior

Retries require a declared maximum attempt count, retry budget, retryable failure classes, and backoff strategy. Retry eligibility is evaluated before scheduling the next attempt.

Retries preserve the root request identifier and add attempt metadata. Retry traffic is included in component load and metrics. A retry is rejected when its next attempt would exceed the request deadline, maximum attempts, or retry budget.

## Fault model and precedence

Faults have a target, type, start time, optional end time, and configuration. Multiple active faults compose deterministically.

Fault type identifiers are append-only. Beyond the initial set, Priority 1 components add `quota-exhaustion`, `stale-dns-record`, `partition-hotspot`, `subscriber-group-stall`, `credential-store-unavailable`, and `provider-throttling`. Each composes under the rules below with no special cases.

Runtime health precedence is:

```text
unavailable > degraded > recovering > healthy
```

Fault effects combine as follows:

- Availability: any outage fault makes the target unavailable.
- Capacity: active capacity multipliers multiply together; the result cannot be negative.
- Latency: additive latency faults sum.
- Error rate: independent error probabilities combine as `1 - product(1 - errorRate)`.
- Network edge faults affect only the targeted edge.
- Regional outages affect every node and edge assigned to that region.

When a fault ends, only its effects are removed. The component returns to the highest-precedence state implied by any remaining fault and recovery configuration.

## Availability and cost

`Observed availability` equals completed successful root requests divided by all completed root requests, excluding explicitly cancelled requests. It is a result of the simulation run, not an SLA.

Topology warnings may identify redundancy risks, but the MVP must not calculate a guaranteed theoretical availability percentage from static topology. Any future topology-derived estimate must be separately labeled and document its independence assumptions.

Cost is optional and educational. It is calculated from configured component units and logical simulation usage only; it does not represent provider billing.

## Result contract

A result includes:

- Input and seed.
- Engine and component-model version.
- Run status: completed, cancelled, invalid, or failed.
- System and component metric time series.
- Aggregated request outcomes.
- Bounded significant-event log.
- Simulation assumptions and limitations.
- Findings with source evidence.

`SimulationResult` version `0.3.0` may also include optional `flowTimeline`,
`methodDistribution`, `manualBatchIds`, `retryCount`, and `timeoutCount` fields. These fields are
optional for backward compatibility: earlier results that lack them must still load, render, and
compare under the normal engine/component-version rules.

Editing a graph, traffic profile, or fault scenario after a run marks its displayed result as stale until rerun. Staleness is derived by comparing an architecture signature that excludes node positions, so repositioning a node on the canvas does not invalidate a result.

The signature includes full node configuration, complete edge objects, traffic profiles, and fault
scenarios. A result is also stale when its engine or component-model version differs from the
currently loaded simulation model.

Each finding also carries a `severity` (`critical`, `warning`, or `info`) and an optional `suggestedAction`. Both fields are additive: `severity` defaults to `info` when absent, so results written by earlier engine versions load and render without migration.

### Recorded flow timeline

The engine records request-flow telemetry for playback as a completed result field. The flow timeline
is still strictly presentational:

- It is recorded while processing the deterministic run, but never feeds back into simulation input or runtime decisions.
- It cannot affect determinism. Two runs with identical input and seed produce identical results whether playback is paused, scrubbed, sped up, skipped, disabled, or never opened.
- It is aggregated into buckets at `metricIntervalMs`, so output size scales with edges, flow classes, and buckets rather than request count.
- `FlowClass` values are `read`, `write`, `auth`, `async-event`, and `replication`.
- Each bucket contains `EdgeFlowSample` records with `edgeId`, `flowClass`, `count`, `failureCount`, and `retryCount`; buckets are emitted in ascending time order and samples in insertion order.
- Sparse quiet periods produce no bucket. Playback sampling must locate the bucket for a logical instant by binary search.
- When several classes traverse one edge in a bucket, the busiest class determines the visual treatment while the displayed count reports the edge total.

Request-flow playback replays recorded telemetry and cannot change a calculated result.
The UI labels playback as **Recorded telemetry replay**. It is a visualization of completed
logical events, not a real-time network trace or a claim of operational fidelity.

Component-specific metrics are added alongside their components. Priority 1 contributes `quotaRejectionCount`, per-route RPS and latency, `authLatencyShareMs`, `authBlockedCount`, `dnsCacheHitRatio`, `timeToFailoverMs`, `staleResolutionCount`, `partitionUtilization[]`, `hotPartitionThrottleCount`, `staleReadCount`, per-subscriber-group lag and depth, `fanOutFactor`, `retentionDropCount`, and `externalProviderThrottleCount`.

`Observed availability` is unaffected by these additions because quota, authentication, and provider-throttle rejections are already counted as completed failed root requests.

## Determinism addendum

The seeded random generator's draw order is part of the engine contract, not an implementation
detail. Two runs with identical input and seed must issue identical draws in identical order.

- New random consumers must append to the end of the per-event draw sequence.
- Every runtime map introduced by a component must be iterated in insertion order or by a stable
  sorted key. Iteration over an unordered structure is a determinism defect.
- Weighted selection (gateway routes, DNS targets, NoSQL partitions) must normalize weights and
  resolve ties by declared order, never by floating-point comparison alone.
- Results record the engine version and component-model version. Results from different versions are
  marked stale and refused for comparison.

## Fidelity limitations

The MVP does not model real packet-level networking, operating-system scheduling, actual database execution plans, tenant-level cloud quotas, live cloud outages, cryptography cost, exact provider pricing, or every proprietary managed-service behavior. These omissions must be shown in the UI wherever users interpret a result.

The metrics view explicitly labels output as deterministic educational modeling rather than live
infrastructure measurement or a production capacity guarantee. Capacity is an abstraction of
configured component admission/service behavior, not a benchmarked provider RPS commitment.

Component-specific boundaries:

- **DNS** is TTL arithmetic on the logical clock. No resolver hierarchy, negative caching, anycast, BGP, or client-side resolver behavior.
- **API gateway** does not model request or response transformation, payload inspection, or schema validation.
- **NoSQL consistency** is a lag window, not a formal consistency model. No conflict resolution, vector clocks, compaction, or secondary-index maintenance cost.
- **Event topics** do not model partition rebalancing, consumer-group coordination protocols, exactly-once delivery, or log compaction.
- **Identity** models latency, capacity, and failure semantics only. No cryptography, key material, token formats, OAuth/OIDC flow steps, or session-fixation behavior.
- **External services** perform no real I/O and hold no credentials. SLA values are user-entered educational inputs, not published provider commitments.
- **Service mesh** is represented as edge policy. Sidecar CPU, memory, and per-hop resource cost are not modeled.

### Edge-kind semantics

The five flow kinds are deliberately distinct and must not be conflated:

| Kind | Meaning |
|---|---|
| `request` | Synchronous call. Contributes to end-to-end latency and to the caller's outcome. |
| `event` | Asynchronous delivery. Decouples caller outcome from consumer processing. |
| `replication` | Data propagation between stores. Not an ordinary request route. |
| `failover` | Standby or error path. Traversed only on a failure or promotion decision. |
| `observability` | Telemetry emission to a terminal sink. Never carries user traffic. |

`response` edges are **visual metadata only** in the MVP. They are rendered and persisted but carry
no routing, latency, or capacity semantics, and the engine ignores them. Any future activation must
be an explicit versioned change.
