# Technology Catalog

The simulator models **generic components** (Cache, Relational Database, Load Balancer, …). The
technology catalog lets you additionally tag each component with the **real-world product** you
intend to implement it with — Redis, PostgreSQL, Amazon S3, Kafka, and so on.

## Generic component vs. real-world implementation

| | Generic component | Selected technology |
|---|---|---|
| What it is | The simulated building block | A label describing the intended implementation |
| Affects simulation | **Yes** — capacity, latency, error rate, queueing | **No** — never read by the engine |
| Source of behaviour | The node's own configuration fields | None |
| Purpose | Modelling and analysis | Learning, documentation, communication |

The simulation engine is deliberately **provider-agnostic**. Two identical graphs produce
byte-identical results whether one is tagged "Redis" and the other left generic. This is enforced
by a regression test in [tests/unit/technologyCatalog.test.ts](../tests/unit/technologyCatalog.test.ts).

## Selections are informational only

Choosing a technology **never**:

- creates, provisions, or configures real infrastructure,
- contacts a vendor API, requests credentials, or performs any network call,
- implies an endorsement, partnership, or recommendation of that product.

Everything stays local to your project file.

## Contextual recommendations

The **Implementation** tab displays a bounded deterministic shortlist when a compatible technology
catalog exists for the selected component. Ranking uses only local catalog and architecture data:
component compatibility, selected scenario workload/difficulty, connected-node assignments, local
deployment preferences, and simulation-preset availability.

Each recommendation shows its match score, rationale, deployment model, strengths, trade-offs,
typical use cases, and relevant legacy/deprecation advisories. The list is educational guidance,
not vendor endorsement or procurement advice. It never applies a technology or preset
automatically: **Use this technology** follows the same explicit selection and preset-confirmation
workflow as the complete catalog, and **Generic / Custom Implementation** remains available.

Recommendation preferences (open-source, managed-service, and preferred-provider choices) are
local UI preferences, not project data.

## Catalog contents

201 curated entries across nine modules in
[src/domain/technology/catalog/](../src/domain/technology/catalog):

| Module | Entries | Primary component roles |
|---|---|---|
| `cdn.ts` | 15 | CDN, edge security |
| `loadBalancing.ts` | 23 | Load Balancer, API gateways |
| `compute.ts` | 29 | Server, Worker (runtimes and application frameworks) |
| `databases.ts` | 37 | Relational Database (incl. non-relational and analytical stores) |
| `caching.ts` | 17 | Cache |
| `messaging.ts` | 26 | Message Queue, Worker |
| `storage.ts` | 17 | Object Storage |
| `observability.ts` | 23 | Observability |
| `operations.ts` | 14 | Autoscaler, Circuit Breaker |

The **Client** component has no technology selector — it represents request origin, not a
deployable system.

## Simulation presets

Some entries carry a `simulationPreset`: a small set of suggested starting values (capacity,
latency, timeout, error rate, hit ratio, cost). Presets are:

- **Educational defaults, not vendor benchmarks, SLAs, or performance guarantees.** Real
  performance depends entirely on instance size, data shape, network topology, and tuning.
- **Opt-in.** Applying a preset opens a confirmation dialog listing every field that would change,
  with its current and proposed value. You may accept fields selectively.
- **Versioned.** Each entry carries a `modelVersion`; the catalog as a whole carries
  `TECHNOLOGY_CATALOG_VERSION` (see [schema.ts](../src/domain/technology/schema.ts)).
- **Never applied automatically.** Selecting a technology alone changes no simulation value.

Because presets are just a patch to the node's ordinary configuration, any value you have already
tuned by hand is shown in the diff before it is overwritten.

## Multi-role technologies

Several products legitimately fill more than one architectural role. Rather than duplicating them,
a single entry lists every role in `componentTypes` and may narrow its `capabilities` and
`advisories` per role via `roleCapabilities`:

- **Redis** — Cache, Relational Database (as a data store), Message Queue
- **NGINX** — Load Balancer, Server, Cache
- **Kubernetes** — Server, Worker, Autoscaler
- **Istio / Linkerd** — Circuit Breaker, Load Balancer
- **Azure Front Door** — CDN, Load Balancer
- **Cloudflare Workers** — CDN, Server

The inspector shows only the capabilities and advisories relevant to the role the node actually
plays, so a Redis-tagged Cache does not advertise queueing semantics.

## Advisories

Advisories are scoped caveats shown alongside a selection, used where a product does not map
cleanly onto a generic component:

- **Non-relational data model** — MongoDB, DynamoDB, Cassandra, Couchbase and peers are mapped to
  the Relational Database component (the simulator's only OLTP datastore) and flagged accordingly.
- **Analytical / OLAP workload** — Redshift, BigQuery, Snowflake are not transactional stores.
- **Application framework, not infrastructure** — Django, Rails, Spring Boot etc. describe what
  runs on a Server rather than the platform itself.
- **Block / file storage** — EBS, EFS, Azure Files are mapped to Object Storage but do not offer
  object semantics.
- **Workflow orchestration** — Temporal, Airflow, Prefect, Dagster schedule work rather than act as
  a plain queue.
- **API gateway responsibilities** — gateways add authorization and throttling beyond load balancing.

## Deprecated, renamed, and unknown technologies

- Entries have a `status` of `current`, `legacy`, or `deprecated`. Legacy and deprecated entries
  (Classic ELB, Riak KV, Hystrix) remain selectable so existing projects stay readable, and the
  inspector displays a warning.
- Renames are handled by `aliases` (matched by search) and by the `TECHNOLOGY_ID_MIGRATIONS` map,
  which transparently redirects an old id to its replacement on load.
- If a project references an id that is not in the catalog at all, the assignment is **preserved
  verbatim** and the inspector shows an "unknown technology" warning. The component continues to
  simulate normally using its generic configuration — an unrecognised label never blocks a run.
- If a saved technology is known but not listed as compatible with the node's component type
  (for example after a component was retyped), the selection is kept and flagged rather than
  silently dropped.

## Maintenance

Catalog integrity is enforced at module load: `buildCatalog()` validates every entry against the
Zod schema and throws on invalid data, duplicate ids, or duplicate provider/product pairs. A
malformed catalog therefore fails fast rather than degrading at runtime.

To add a technology, append an entry to the appropriate module in
[src/domain/technology/catalog/](../src/domain/technology/catalog) with a stable kebab-case `id`,
at least one component type, a description, capabilities, and a `modelVersion`. Never reuse or
repurpose an existing id — saved projects reference it.
