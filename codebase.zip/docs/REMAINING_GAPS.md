# Remaining Gaps for the System Design Simulator

## Overview

This report records the current evidence-based gaps in the System Design Simulator. The application
is a deterministic, offline-first educational MVP. It is not presented as a production capacity
planner, provider runtime, or fully verified desktop release.

## Remediated

- **Cancellation lifecycle:** `SimulationWorkerClient` terminates an active worker and settles a
  valid `cancelled` result, with no unsafe partial metrics. The contract is covered by
  `SimulationWorkerClient.test.ts`.
- **Result freshness:** the canonical architecture signature covers node configuration, complete
  edge properties, traffic profiles, fault scenarios, and engine/component-model versions. Canvas
  positions are deliberately excluded.
- **Topology safeguards:** request-routing cycles and invalid replication paths block a run.
  Regional failover-role/region issues, missing multi-region recovery, and simplified
  multi-consumer behavior are visible warnings.
- **Findings and visualization honesty:** availability guidance points to observed saturation when
  available, otherwise to faults, timeouts, and dependencies. Metrics and playback identify
  deterministic educational modeling and recorded telemetry, not live infrastructure measurement.
- **First-run learning route:** the welcome experience explains these limits and offers a Basic Web
  Application Guided Tour, scenario browsing, or a blank canvas. Its seen state is local-only and
  cannot dirty or export a project.
- **Security regression evidence:** tests assert the local-only CSP, renderer isolation,
  disabled Node integration, and sandbox configuration. This complements, but does not replace,
  packaged-build validation.

## Remaining gaps

### 1. Cooperative partial cancellation is advanced scope

Cancellation is correct and explicit, but it terminates the worker. Preserving partial metrics would
require a cooperative checkpoint protocol and defined consistency semantics. The current product
intentionally returns no partial metrics rather than presenting an unsafe snapshot.

### 2. Advanced topology proof remains intentionally bounded

The validator catches structural contradictions but does not prove retry-budget termination, quorum
availability, replication conflict safety, or arbitrary failover correctness. Those require runtime
models the engine does not currently execute.

### 3. Simulation realism remains educational

Capacity, routing, latency, fault, and replication behavior are deterministic abstractions. The
engine does not model packets, sockets, operating-system scheduling, database query plans, real
provider quotas, cryptography cost, or live outages. Results are useful for learning trade-offs, not
production readiness decisions or guarantees.

### 4. Some advanced catalog semantics remain conceptual or partial

Autoscaling, health checking, multi-region promotion, service-mesh execution, advanced consistency,
consumer groups, ordering, exactly-once delivery, and conflict resolution need further behavior,
metrics, faults, validation, and tests before they can be represented as fully modeled.

### 5. Causal diagnosis is bounded by available runtime evidence

The current findings are explainable and model-based, but richer root-cause guidance depends on the
advanced runtime telemetry and semantics above. Findings must continue to distinguish observation,
architecture warning, and recommendation.

### 6. Release-grade desktop verification is incomplete

The repository has unit, browser smoke, worker-cancellation, and static security-boundary coverage.
It still lacks broad browser/Electron end-to-end workflows, packaged-app smoke tests, IPC-handler
integration tests against a running Electron process, dependency scanning in CI, and measured
100-node performance evidence.

### 7. Packaging and distribution are not release-proven

No signed installer, notarized package, release artifact checksum, or supported-platform validation
evidence has been produced. These are release gates, not capabilities that should be implied by the
development build.

### 8. Documentation requires ongoing fidelity review

Documentation now distinguishes modeled behavior, conceptual catalog roles, and advanced scope. Any
new engine behavior must be documented with its tests and limitations before it is described as
delivered.

## Assessment

The simulator is ready for educational local use: users can build, validate, save, simulate,
inspect, replay, recover, and learn from deterministic scenarios. The remaining work is advanced
simulation fidelity and release-engineering evidence—not basic workflow correctness.
