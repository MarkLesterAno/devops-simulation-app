# Design Brief

## Product experience objective

Create a professional but approachable desktop experience that makes distributed-system behavior observable. The user should be able to construct an architecture, run an experiment, see the consequences, understand why they occurred, and try an improvement without leaving the application.

## Design principles

1. **Learn by building:** Users discover system behavior through direct experimentation.
2. **Make invisible behavior visible:** Surface request flow, latency, retries, queue growth, cache outcomes, and fault propagation.
3. **Prioritize clarity:** Favor readable diagrams and explainable data over visual novelty.
4. **Progressively disclose complexity:** Provide useful defaults for beginners and advanced controls when required.
5. **Explain causality:** Every significant finding should identify its source and consequence.
6. **Be honest about fidelity:** Clearly separate simulation measurements, inferred warnings, assumptions, and recommendations.

## Primary layout

```text
Menu: File | Edit | View | Simulation | Help
Toolbar: Select | Connect | Pan | Undo | Redo | Validate | Run | Pause | Reset
────────────────────────────────────────────────────────────────────────────
Component Palette          Architecture Canvas                    Inspector
Search                     Node graph with directed flows         Selected node/
Categories                 status overlays and minimap            edge properties
────────────────────────────────────────────────────────────────────────────
Simulation Timeline: state | current RPS | error rate | p95 latency
────────────────────────────────────────────────────────────────────────────
Metrics Dashboard: charts | event log | bottlenecks | recommendations
```

## Key screens

### Welcome

On first launch, present an accessible welcome dialog explaining that the application is a local,
deterministic educational model rather than a live-infrastructure tool. It offers **Start guided
beginner scenario**, **Browse scenarios**, and **Build from scratch**. The guided action explicitly
loads the Basic Web Application Guided Tour and its tutorial; the other actions do not modify the
current project. A **Help** toolbar action reopens this guidance. The seen state is local-only and
never saved with a project.

### Architecture editor

The editor includes a searchable component palette, interactive canvas, toolbar, collapsible
context panel, validation summary, and simulation controls. A new project must show a helpful empty
state and offer a starter architecture or template.

### Node configuration modal

Node configuration is detail on demand. Opening a node — by double-click, by `Enter` on a focused
node, by the context-menu **Configure** action, or from the docked context panel — raises a tabbed
modal dialog:

- **Implementation:** the technology assignment for the node, including provider, product, version, and the preset the assignment applies. This is the default tab because choosing an implementation is the first decision a learner makes about a node.
- **Inspector:** the full configuration form described below.

Client nodes have no technology assignment, so their modal renders the configuration form directly without tabs.

The docked context panel exposes the same inspector fields on wide screens; compact screens use the
modal fallback. The modal traps focus, restores focus to the trigger on close, closes on `Escape`
or an outside click, and never dirties the project simply by being opened.

### Node context menu

Right-click (or `Shift+F10`) on a node opens a menu offering **Configure**, **Duplicate**, and **Delete**. Duplicate copies a node's configuration but deliberately does not copy its connections, because cloned wiring silently produces topologies the user did not design. Delete states its consequences — the number of connections that will be removed — before it is confirmed.

### Simulation results modal

Completed runs do not auto-open results. **View Metrics** opens the Metrics context-panel tab on wide
screens and a metrics-only modal on compact screens. Findings are shown as accessible toasts and
remain available through the Findings context-panel tab or notification centre. When the
architecture is edited after a run, results are marked stale rather than discarded. Flow animation
is a local toolbar preference; recorded playback never changes metrics or findings.

### Inspector

The selected node or edge inspector uses progressive tabs:

- **General:** name, description, region, tags.
- **Capacity:** RPS, concurrency, workers, throughput, storage.
- **Performance:** latency, jitter, timeout, cache behavior.
- **Reliability:** health, errors, retry, failover, availability assumptions.
- **Cost:** units, instances, and optional estimated usage.

### Simulation controls

Users select a traffic profile, duration, speed, seed, and fault scenario. They can start, pause, resume, reset, and rerun. Invalid designs display actionable messages before execution.

### Observability dashboard

Show RPS; successes and failures; error rate; latency percentiles; node utilization; queue depth and lag; cache ratio; database traffic; replica lag; retries; and major simulation events. Selecting a metric or event must focus the relevant graph node or edge.

### Findings panel

Organize results into Critical Bottlenecks, Failure Analysis, Architecture Warnings, Recommendations, Trade-offs, and Simulation Assumptions.

## Visual language

| Meaning | Visual treatment |
|---|---|
| Healthy | Green with explicit healthy indicator |
| Informational | Blue |
| Near capacity | Amber |
| Degraded | Orange |
| Failed | Red with status icon |
| Inactive | Gray |
| Request flow | Solid blue directed edge |
| Async event flow | Dotted purple directed edge |
| Replication | Dashed teal directed edge |
| Failover | Dashed orange directed edge |

Color must never be the only status signal. Pair it with text, iconography, and edge patterns.

Nodes surface concise status during a run, for example:

```text
Application Service
Status: Overloaded
Utilization: 97%
Latency: 680 ms
Errors: 8.2%
```

Each node card also carries a category glyph and, once a technology is assigned, a provider-tinted badge showing the product name. The simulator ships no third-party brand assets; the badge falls back to a provider-tinted monogram, and an approved local logo can be dropped into the icon registry later without any other change. Below a zoom threshold the cards shed their metric lines so a large architecture stays readable.

Edges carry a presentation-only flow overlay: a dotted particle path whose speed scales with relative traffic volume and whose color encodes health, plus a badge when retries or drops were attributed to that connection. The overlay is derived from simulation output, honours `prefers-reduced-motion`, and can be switched off entirely.

## Interaction requirements

- Valid connection handles highlight during link creation.
- Invalid connections are blocked with a specific explanation.
- Dropping a node on an edge may offer to insert it into the connection flow.
- Request-flow animation is proportional to traffic but must not create visual noise.
- Clicking an event focuses the affected graph element and its metrics.
- Users can pause at significant events.
- Canvas selection, movement, connection, simulation controls, and inspector editing must be keyboard accessible.

## Accessibility

The interface must provide keyboard navigation, visible focus states, semantic labels for canvas controls and charts, reduced-motion support, WCAG AA text contrast, and non-color indicators for every important state.
