# Component Catalog and Modeling Policy

## Purpose

This catalog defines the initial component set, its modeling boundaries, and configuration expectations. Components represent educational abstractions, not direct replicas of vendor-managed services.

Components may additionally be tagged with the real-world product intended to implement them. That
tagging is purely informational and never affects simulation — see
[TECHNOLOGY_CATALOG.md](./TECHNOLOGY_CATALOG.md).

## Common component contract

Every component definition declares:

- Type, display name, category, icon, and version.
- Allowed incoming and outgoing edge kinds.
- Default configuration and validation rules.
- Capacity and latency model.
- Health and fault behavior.
- Metrics emitted.
- Simulation-fidelity level and documented limitations.

## Planned component catalog

The following table is the approved initial catalog. Its phased delivery is defined by [IMPLEMENTATION_PLAN.md](./IMPLEMENTATION_PLAN.md): the editor MVP starts with the core routing, compute, cache, database, queue, and worker components; circuit breakers, autoscalers, and metrics services are delivered in later phases.

Components added after the initial catalog are listed under [Catalog expansion](#catalog-expansion). Concepts that are deliberately *not* components are listed under [Represented as configuration, not a node](#represented-as-configuration-not-a-node).

| Component | Category | Primary behavior | Key configuration |
|---|---|---|---|
| Client | Entry | Generates synchronous requests. | Request class, timeout, origin role. |
| CDN | Entry | Serves cached content or forwards to origin. | Hit ratio, edge latency, origin. |
| Load Balancer | Entry | Routes work among healthy targets. | Algorithm, weights, health interval. |
| Server | Compute | Hosts backend APIs; processes and forwards synchronous requests. | Instances, RPS, concurrency, latency, overflow behavior. |
| Worker | Compute | Consumes asynchronous messages. | Concurrency, throughput, processing failure behavior. |
| Cache | Performance | Reads/writes cached values and forwards misses. | Capacity, TTL, hit ratio, latency, eviction policy. |
| Relational Database | Data | Serves reads and primary writes. | Read/write RPS, latency, primary/replica role, replica lag. |
| Read Replica | Data | Serves reads with modeled replication lag. | Read RPS, latency, lag, health. |
| Object Storage | Data | Stores and retrieves large binary objects (files, media, backups). | Instances, RPS, latency, overflow behavior. |
| Message Queue | Messaging | Buffers messages for consumers. | Producer/consumer RPS, maximum depth, retention, DLQ. |
| Dead-Letter Queue | Messaging | Retains messages exceeding processing attempts. | Retention, capacity. |
| Circuit Breaker | Reliability | Protects downstream calls after failures. | Threshold, rolling window, recovery interval. |
| Autoscaler | Reliability | Changes component instances after configured delays. | Min/max, threshold, cooldown, provisioning delay. |
| Observability | Operations | Receives emitted metric/observability events from other components. | Ingestion capacity, latency. |

## Catalog expansion

The initial catalog covers synchronous routing, stateless compute, look-aside caching, relational
persistence, point-to-point messaging, and basic reliability primitives. A 2024 architecture review
identified six structural gaps that cannot be expressed as configuration of an existing component:
policy enforcement, name resolution, non-relational consistency, fan-out messaging, identity, and
third-party egress.

Expansion components are grouped by delivery priority. Priority 1 is specified in full below.
Priority 2 and 3 are approved in principle and must each complete the
[component expansion process](#component-expansion-process) before implementation.

### Priority 1 components

| Component | Category | Fidelity | Primary behavior | Key configuration |
|---|---|---|---|---|
| API Gateway | Entry | Behavioral | Enforces routing, authentication, and quota policy between the edge and backend services. | Routes, auth mode, rate limit, policy latency. |
| DNS / Traffic Manager | Entry | Behavioral | Resolves a name to a target and caches the answer for a TTL. | TTL, resolution latency, policy, targets. |
| NoSQL Database | Data | Behavioral | Partitioned key-value/document/wide-column store with tunable consistency. | Model, consistency, partitions, skew, replication lag. |
| Event Topic | Messaging | Behavioral | Publishes each event to every subscriber group independently. | Subscriber groups, partitions, retention, ordering scope. |
| Identity & Auth Service | Identity | Behavioral | Validates credentials or tokens as an in-path dependency. | Mode, token TTL, validation mode, fail mode. |
| External Service | External | Behavioral | Models a third-party dependency you neither scale nor repair. | Provider label, SLA latency, provider rate limit, error rate. |

#### API Gateway

**Role.** The policy-enforcement hop between edge traffic and backend services. Distinct from a load
balancer because it makes *per-route* decisions and may call an identity component before
forwarding.

**Configuration.** `routes[] { id, pathWeight, targetNodeId, timeoutMs }`, `authMode`
(`none | validate-local | delegate`), `authProviderNodeId`,
`rateLimit { algorithm: token-bucket | fixed-window, limitRps, burst }`, `policyLatencyMs`.

**Edges.** Incoming `request`. Outgoing `request`, `observability`.

**Runtime behavior.** On arrival the gateway adds `policyLatencyMs`, evaluates the rate-limit bucket,
optionally performs an authentication step, then selects a route by seeded weighted choice among
configured routes. Over-quota requests fail fast with reason `quota-exceeded`; unauthenticated
requests fail with `unauthenticated`. Both are counted as failures, never silently dropped.

**Metrics.** Accepted and rejected RPS, quota-rejection count, per-route RPS and latency,
auth-delegation latency share, utilization.

**Faults.** `node-outage`, `latency-increase`, `capacity-reduction`, `quota-exhaustion`.

**Validation.** Error `gateway-no-routes` when no route target is reachable. Error
`auth-delegation-missing` when `authMode` is `delegate` and no identity component is reachable.

**Limitations.** Request/response transformation, payload inspection, and schema validation are not
modeled. Rate limiting is a per-node bucket; distributed quota coordination is only represented if
the gateway is connected to a cache component.

#### DNS / Traffic Manager

**Role.** Name resolution with TTL-bounded caching. This is the component that explains *why failover
is slow*: a cached answer keeps sending traffic to a dead target until its TTL expires.

**Configuration.** `ttlSeconds`, `resolutionLatencyMs`, `policy`
(`weighted | latency | failover | geo`), `targets[] { nodeId, weight, region }`,
`healthCheckIntervalMs`.

**Edges.** Incoming `request`. Outgoing `request`, `failover`, `observability`.

**Runtime behavior.** The first request for a name pays `resolutionLatencyMs` and caches the selected
target until `ttlSeconds` elapses. Subsequent requests reuse the cached answer without re-evaluating
target health. When the cached target is unhealthy, requests fail until the entry expires and
resolution reselects. `failover` policy prefers the first healthy target in declared order;
`weighted` uses seeded weighted choice; `latency` picks the lowest modeled base latency; `geo`
matches the request region and falls back to declared order.

**Metrics.** Resolution count, cache-hit ratio, per-target traffic share, time-to-failover, stale
resolution count.

**Faults.** `node-outage`, `latency-increase`, `stale-dns-record`.

**Validation.** Error `dns-no-targets`. Warning `dns-ttl-exceeds-rto` when `ttlSeconds` exceeds a
connected failover controller's promotion delay.

**Limitations.** No resolver hierarchy, negative caching, anycast, BGP, or client-side resolver
behavior. TTL is modeled as simple arithmetic on the logical clock.

#### NoSQL Database

**Role.** Partitioned non-relational persistence with tunable consistency. The only place in the
catalog where eventual consistency, partition-key skew, and hot partitions are observable.

**Configuration.** `model` (`key-value | document | wide-column | vector`), `consistency`
(`strong | eventual | quorum`), `partitionCount`, `hotPartitionSkew` (0–1), `replicationLagMs`,
`readCapacityRps`, `writeCapacityRps`.

**Edges.** Incoming `request`, `replication`. Outgoing `replication`, `observability`.

**Runtime behavior.** Each operation selects a partition by seeded draw biased by
`hotPartitionSkew`; capacity is enforced per partition, so skew produces throttling well below
aggregate capacity. Reads under `eventual` consistency may return stale data while
`replicationLagMs` is nonzero and are counted as stale reads. `quorum` reads pay additional latency
proportional to replication lag but do not return stale data. `strong` consistency requires
`replicationLagMs` to be zero.

**Metrics.** Read/write RPS split, per-partition utilization, hot-partition throttle count, stale-read
count, replication lag.

**Faults.** `node-outage`, `capacity-reduction`, `latency-increase`, `partition-hotspot`,
`replica-lag-increase`.

**Validation.** Error `nosql-invalid-consistency` when `consistency` is `strong` and
`replicationLagMs` is greater than zero. Warning `no-backup-for-stateful-store`.

**Limitations.** No formal consistency model, conflict resolution, vector clocks, compaction, or
secondary-index maintenance cost. Consistency is lag-window arithmetic only.

#### Event Topic

**Role.** Fan-out messaging. Architecturally distinct from a message queue: one publish is delivered
to *every* subscriber group, and each group keeps an independent offset and lag.

**Configuration.** `subscriberGroups[] { id, consumerNodeId, concurrency, deliveryGuarantee }`,
`partitionCount`, `retentionMs`, `orderingScope` (`none | partition`).

**Edges.** Incoming `event`, `request`. Outgoing `event`, `failover`, `observability`.

**Runtime behavior.** A publish enqueues one logical copy per subscriber group. Each group drains at
its own configured concurrency, so a slow group accumulates lag without affecting other groups.
Groups exceeding `retentionMs` drop messages and record data loss. Failed deliveries route to a
dead-letter queue over a `failover` edge when one is configured.

**Metrics.** Publish RPS, per-group consume RPS, per-group lag and depth, fan-out amplification
factor, retention-drop count.

**Faults.** `node-outage`, `queue-consumer-failure` (targetable per group), `capacity-reduction`,
`subscriber-group-stall`.

**Validation.** Error `topic-no-subscribers` — unlike a queue's missing-consumer *warning*, a topic
with zero subscriber groups is always a modeling mistake. Warning
`subscriber-group-underprovisioned` when a group's consume capacity is below the publish rate.

**Limitations.** No partition rebalancing, consumer-group coordination protocol, exactly-once
semantics, or log compaction. Ordering is modeled only at partition scope.

#### Identity & Auth Service

**Role.** Authentication and authorization as an in-path critical dependency. Fills the previously
empty Identity category.

**Configuration.** `mode` (`authn | authz | both`), `tokenTtlMs`, `validationMode`
(`local-jwt | introspection`), `cacheHitRatio`, `verificationLatencyMs`, `failMode`
(`fail-closed | fail-open`).

**Edges.** Incoming `request`. Outgoing `request`, `observability`.

**Runtime behavior.** `local-jwt` validation is performed by the caller and costs only
`verificationLatencyMs` without a network hop. `introspection` forwards a request to this component
and is subject to its capacity, latency, and health. Cached tokens are reused until `tokenTtlMs`
expires. When the component is unavailable, `fail-closed` rejects dependent requests with
`auth-unavailable` while `fail-open` admits them and records a security-posture finding.

**Metrics.** Auth RPS, token cache hit ratio, auth-induced latency share, auth failure count,
downstream requests blocked by auth.

**Faults.** `node-outage`, `latency-increase`, `error-rate-increase`,
`credential-store-unavailable`.

**Validation.** Warning `auth-single-point-of-failure` when a single fail-closed identity component
sits in the critical path.

**Limitations.** No cryptography cost, key material, token format, OAuth/OIDC flow steps, or
session-fixation semantics. Authorization decisions are modeled as a latency and failure rate, not a
policy evaluation.

#### External Service

**Role.** One generic egress dependency replacing payment gateways, email/SMS/push gateways,
notification providers, content moderation, and any other SaaS API. Teaches the dependency you
cannot scale, retry away, or repair.

**Configuration.** `providerLabel`, `slaLatencyMs`, `providerRateLimitRps`, `errorRate`,
`idempotencySupported`, `callMode` (`sync | async-callback`).

**Edges.** Incoming `request`, `event`. Outgoing `observability`.

**Runtime behavior.** Calls above `providerRateLimitRps` are rejected with `provider-throttled`.
The component never autoscales and ignores autoscaler edges by design — that is the lesson. When
`idempotencySupported` is false, retried calls are counted as duplicate side effects and surfaced as
a finding.

**Metrics.** Outbound RPS, provider throttle count, provider error rate, latency contribution, retry
amplification toward the provider.

**Faults.** `node-outage`, `latency-increase`, `error-rate-increase`, `provider-throttling`.

**Validation.** Warning `external-service-no-circuit-breaker` when a third-party dependency has
neither a circuit breaker nor a finite timeout on its inbound path.

**Limitations.** Never performs real I/O, never contacts a real provider, and carries no credentials.
`providerLabel` is display metadata only. Provider SLAs are user-entered educational values, not
published commitments.

### Priority 2 components (approved, not yet specified)

| Component | Category | Distinct behavior it teaches |
|---|---|---|
| Search Index | Data | Asynchronous indexing lag causing read-your-writes violations. |
| Stream Processor | Compute | Windowed continuous processing with checkpoint/restart recovery. |
| Scheduler / Cron | Compute | A second arrival source; thundering herd and batch-window overload. |
| Service Discovery Registry | Reliability | Routing to stale endpoints via registration TTL and propagation delay. |
| Configuration & Feature Flag Service | Operations | Fail-open versus fail-closed on a control-plane dependency. |
| Secrets & Key Management Service | Identity | Startup-blocking dependency, secret caching, rotation stalls. |
| Distributed Lock / Coordination Service | Reliability | Contention as a hard throughput ceiling independent of instance count. |

### Priority 3 components (advanced, aligned to Phase 8)

| Component | Category | Distinct behavior it teaches |
|---|---|---|
| Workflow Orchestrator | Compute | Multi-step sagas with compensation and long-lived state. |
| Change Data Capture | Data | The bridge from replication flow into event flow. |
| Analytical Store | Data | OLTP/OLAP separation and batch-ingest freshness windows. |
| Model Serving Endpoint | Compute | Cold start, dynamic batching, and low-concurrency accelerators. |
| Deployment Controller | Operations | Progressive traffic shifting and automated rollback. |
| Failover Controller | Reliability | Executable failover edges and measured RTO. |
| Backup & Restore Service | Operations | Measured RPO/RTO and backup load competing with production. |

## Represented as configuration, not a node

A concept becomes a component only when it changes a routing, capacity, or timing decision the
engine can branch on. Everything below is more clearly and more compactly expressed as
configuration, and must **not** be added as a canvas node.

| Concept | Representation |
|---|---|
| Reverse proxy | `load-balancer` with layer-7 path routing. |
| Rate limiter / quota manager | `rateLimit` policy on `api-gateway`, `cdn`, or `load-balancer`; optional `request` edge to a `cache` for the distributed counter. |
| Web application firewall | `wafEnabled`, `inspectionLatencyMs`, `blockRate`, `falsePositiveRate` on `cdn` or `api-gateway`, plus the `malicious-traffic-surge` fault. |
| DDoS protection layer | Edge absorption configuration plus a traffic-profile attack overlay. |
| Service mesh / sidecar proxy | Per-edge policy: `mtls`, `perHopTimeoutMs`, `perHopRetries`, `circuitBreakThreshold`. One sidecar per service would double node count without adding insight. |
| Session store | `cache` with `role: session`, plus `stickySessions` on the load balancer. |
| Health check | `healthCheck { intervalMs, unhealthyThreshold, healthyThreshold, probeTimeoutMs }` on the load balancer and its targets, plus the `health-probe` engine event. |
| Logging / metrics / tracing / alerting services | `observability` with `role: logs \| metrics \| traces \| alerts`. |
| Audit log service | `observability` with `role: audit`, `retentionDays`, `immutable`. |
| Policy decision point / authorization engine | `identity-auth-service` with `mode: authz`. |
| Certificate authority / certificate manager | `secrets-kms` with `mode: kms`, plus the `certificate-expiry` fault. |
| Batch-processing service | `worker` with `batchSize` and `batchWindowMs`, driven by `scheduler-cron`. |
| Inference queue | `message-queue` feeding a `model-serving` component. |
| Vector database / vector search index | `nosql-database` with `model: vector`, or `search-index` with a vector query type. |
| Feature store | `cache` for the online store and `analytical-store` for the offline store. |
| Time-series database / graph database | `nosql-database` with `model: time-series \| graph` plus a technology assignment. |
| Data lake | `object-storage` with `role: data-lake`. |
| ETL / ELT pipeline | `worker` or `stream-processor` writing into an `analytical-store`. |
| Schema registry / data validation | `validationMode` and `schemaCompatibility` on `event-topic`, plus a schema-incompatibility fault. |
| CI/CD pipeline, container registry, artifact repository | Project metadata and technology assignments. These carry no request, event, replication, or failover flow and therefore cannot produce a deterministic simulation effect. |
| Network firewall, NAT gateway, VPN gateway, private endpoint, bastion host | Edge properties (`networkBoundary`, `encryptedInTransit`, `privateLink`) and node `accessScope`, plus the `network-failure` fault. |
| Content-moderation service | `external-service`, or `model-serving` when self-hosted. |
| TLS termination, compression, connection pooling | Node and edge properties (`tlsTermination`, `compressionRatio`, `poolSize`, `poolWaitMs`). |
| Retry strategy, timeout policy, load-balancing algorithm, cache eviction policy, index type, consistency level, autoscaling thresholds | Existing node configuration fields. |
| Deployment region, availability zone | Node `region` and `availabilityZone`, plus `regional-outage` and `zone-outage` faults. |
| Encryption at rest / in transit | Node and edge metadata surfaced in a security-posture finding. Cryptographic cost is out of fidelity scope. |
| Network latency, packet loss, bandwidth | Edge properties plus the `network-failure` fault. |
| Instance type and other provider-specific details | Technology-assignment metadata, which the engine ignores. |

## Fidelity labels

Each component must display one of the following labels in its help content:

| Label | Meaning |
|---|---|
| Conceptual | Models the core architectural role only. |
| Behavioral | Models core capacity, latency, and failure behavior. |
| Advanced | Models a documented set of advanced runtime semantics. |

The initially implemented components are typically **Behavioral**. Availability of a field in configuration UI must not imply that all real implementation details are simulated.

### Delivered-fidelity clarification

Behavioral components model the documented logical capacity, latency, queueing, routing, and fault
effects that the deterministic engine currently executes. They do **not** imply production-equivalent
protocols, control planes, consumer-group coordination, automated failover orchestration, quorum
consensus, packet behavior, or provider-specific execution.

The validator makes several of these boundaries visible before a run: it blocks request-routing
cycles and non-data replication edges; it warns when multiple consumers rely on semantics the model
does not implement, when a multi-region design has no explicit recovery route, and when regional
failover targets are questionable. See [SIMULATION_SPEC.md](./SIMULATION_SPEC.md) and
[REMAINING_GAPS.md](./REMAINING_GAPS.md) for the authoritative limitations.

## Icon and logo policy

Every component type maps to one of a fixed set of locally authored category glyphs, held in the renderer's icon registry. The glyph communicates the component's architectural role and is always rendered alongside its text label, never as the sole indicator.

Technology assignments are displayed as a badge showing the product name, tinted with a colour associated with the provider. **The application ships no third-party brand assets.** The registry holds a deliberately empty map of approved local logo assets (`LOGO_ASSETS`); until an asset is added for a technology, the badge renders a provider-tinted monogram derived from the product name.

Adding a real logo is therefore a licensing decision, not an engineering one: once a vendor's mark has cleared the licensing, attribution, and update policy in [Calibration policy](#calibration-policy), the asset is placed under a local renderer assets folder and registered in `LOGO_ASSETS` against its stable technology id. Each entry must record source, license, and trademark/usage metadata in documentation or license notices. The registry will then prefer the local asset over the monogram with no other UI change.

Assets must be bundled locally — icons are never fetched from a network at runtime, which would violate the offline-first guarantee. The simulator must not use a logo in a way that implies vendor endorsement, affiliation, or certification.

## Calibration policy

- Defaults are educational presets, not provider benchmarks.
- Each preset records a model version and optional source/reference note.
- User changes always override presets.
- A simulation result records the chosen preset and model version.
- Provider-specific names, branding, and pricing must not be represented as authoritative unless licensing, attribution, and update policy have been approved.

## Component expansion process

A new component cannot be added until it defines:

1. Configuration schema and safe defaults.
2. Valid input/output edge kinds.
3. Runtime behavior and metrics.
4. Fault interactions.
5. Validation rules.
6. Unit-test scenarios for nominal, overload, and failure behavior.
7. User-facing explanation, limitations, and trade-offs.

Before step 1, a candidate must also pass the **configuration-first test**: if the concept can be
expressed as a property of an existing node, an edge property, a fault, a traffic-profile setting, an
engine rule, or a technology assignment, it must be represented that way instead. Record the outcome
in [Represented as configuration, not a node](#represented-as-configuration-not-a-node).
