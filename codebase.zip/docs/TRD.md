# Technical Requirements Document

## Technology stack

| Layer | Technology |
|---|---|
| Desktop runtime | Electron |
| User interface | React and TypeScript |
| Build tooling | Vite |
| Graph canvas | React Flow or an equivalent mature library |
| State management | Zustand or Redux Toolkit |
| Charts | Recharts, ECharts, or equivalent |
| Forms | React Hook Form |
| Runtime validation | Zod |
| Local persistence | Versioned JSON project files; SQLite or Electron Store for preferences and recents |
| Unit tests | Vitest |
| UI tests | React Testing Library |
| End-to-end tests | Playwright where Electron support is suitable |
| Code quality | ESLint and Prettier |

## Architecture

The Electron main process owns window lifecycle, native menus, user-authorized file operations, and validated IPC. A narrow preload bridge exposes allowed operations to the renderer. The React renderer owns the editor, node configuration modal, metrics modal, notification centre, playback controls, and application state. A Web Worker executes simulation work so the UI remains responsive.

```text
Electron Main Process
  ├─ Window and application lifecycle
  ├─ Native file dialogs and authorized file I/O
  └─ Validated IPC handlers
          │
          └─ Secure preload API
                    │
React Renderer
  ├─ Canvas editor and node configuration modal
  ├─ Project and graph state
  ├─ Metrics modal, notification centre, and playback UI
  └─ Simulation Web Worker client
                    │
Simulation Web Worker
  ├─ Event scheduler
  ├─ Component behavior registry
  ├─ Fault runtime state
  └─ Metric aggregation
```

## Electron security

The application must:

- Enable `contextIsolation`.
- Disable `nodeIntegration` in renderer windows.
- Enable sandboxing where compatible.
- Expose only allowlisted APIs through a preload script.
- Never expose raw `ipcRenderer`.
- Validate all IPC payloads with Zod before use.
- Restrict file access to paths selected through native dialogs or explicitly approved project locations.
- Use a restrictive Content Security Policy.
- Avoid remote content in production.
- Never execute user-provided JavaScript, shell commands, or cloud actions.

## Domain model

Core persisted entities are:

- `ProjectDocument`
- `ArchitectureNode`
- `ArchitectureEdge`
- `TrafficProfile`
- `FaultScenario`
- `SimulationRun`
- `SimulationResult`
- `MetricSnapshot`
- `Finding`

Every component type is registered by a component definition containing metadata, permitted connection kinds, defaults, configuration validation, and a factory for its simulation behavior. This avoids hard-coding a fixed catalog into the simulation orchestration layer.

```ts
interface ComponentDefinition<TConfig> {
  type: ComponentType;
  displayName: string;
  category: ComponentCategory;
  allowedIncomingConnections: ConnectionKind[];
  allowedOutgoingConnections: ConnectionKind[];
  defaultConfiguration: TConfig;
  validateConfiguration(configuration: TConfig): ValidationIssue[];
  createSimulationBehavior(node: ArchitectureNode): SimulationComponentBehavior;
  /** True when the component can originate traffic without an inbound edge. */
  isArrivalSource?: boolean;
}
```

Component configuration is a discriminated union layered over the shared base configuration. The base
schema is permissive (`passthrough`) so documents written by an older catalog version continue to
load, while each component type narrows and validates its own fields.

Edges carry optional transport and policy properties: `networkLatencyMs`, `packetLossRate`,
`bandwidthMbps`, `encryptedInTransit`, `perHopTimeoutMs`, `perHopRetries`, `weight`, and
`routeCondition`. Service-mesh semantics are represented through these edge properties rather than
as sidecar nodes.

`ComponentType` and `FaultType` are **append-only** enumerations. Values are persisted by string in
project documents and fault scenarios, so they must never be reordered, renamed, or removed.

## Deterministic simulation

The engine must use discrete-event simulation. A run receives an immutable graph snapshot, traffic profile, scheduled faults, simulation settings, and a fixed random seed. The same input must produce the same result.

The engine must:

1. Generate request arrivals from the traffic profile.
2. Append any user-composed manual request arrivals after profile arrivals without consuming random draws.
3. Store runtime actions in a time-ordered priority queue.
4. Process the next chronological event.
5. Update runtime node and edge state.
6. Record aggregated metrics, request-flow telemetry, and notable events.
7. Schedule downstream work such as forwarding, retry, timeout, scaling, or message consumption.
8. Stop after the event queue is exhausted or the logical duration ends.

Implemented event types cover deterministic arrivals, completion, timeout checks, queued pulls,
metric ticks, and fault boundaries. The catalog may describe advanced concepts such as autoscaling,
health probes, circuit transitions, or orchestrated promotion, but those become runtime event types
only when their behavior is implemented and versioned.

Manual request batches are logical arrivals only. They never perform HTTP requests, open sockets,
resolve DNS, or contact local or remote services. A batch records its method, class, origin client,
path, sizes, timeout, seed, and label on the simulated request so metrics, findings, and playback can
explain it without introducing provider-specific or network behavior.

```ts
interface ManualRequestDefinition {
  id: string;
  sourceNodeId: string;
  method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE" | "HEAD" | "OPTIONS";
  requestCount: number;
  dispatchRateRps: number;
  startAtMs: number;
  path?: string;
  requestClass: "read" | "write" | "auth-required";
  payloadSizeBytes?: number;
  responseSizeBytes?: number;
  timeoutMs?: number;
  seed?: number;
  label?: string;
}
```

Components added after the initial catalog contribute additional event types, each of which must be
assigned to one of the existing priority classes so ordering stays total and deterministic:

| Event | Priority class | Component |
|---|---|---|
| `dns-resolution`, `dns-cache-expiry` | arrival | DNS / Traffic Manager |
| `policy-evaluated`, `quota-rejected` | forward | API Gateway |
| `auth-validated`, `token-cache-expiry` | forward | Identity & Auth Service |
| `topic-published`, `subscriber-group-consume`, `offset-commit` | forward | Event Topic |
| `partition-selected`, `hot-partition-throttle` | forward | NoSQL Database |
| `external-call-throttled` | forward | External Service |
| `health-probe` | autoscale/health | Health-check configuration |
| `scheduled-trigger`, `schedule-skipped` | arrival | Scheduler / Cron |
| `failover-detected`, `promotion-completed` | fault | Failover Controller |

## Simulation rules

Total request latency is calculated as:

```text
network latency
+ queue wait
+ component processing time
+ dependency latency
+ retry delay
```

Capacity is derived from instance count, per-instance capacity, and health factor. Excess work must cause queueing, overload penalties, load shedding, errors, or timeouts according to each component configuration.

Retries must be bounded by max attempts and retry budget, support backoff and jitter, and be visible as additional traffic in results. Queue behavior must model producer rate, consumer rate, concurrency, retention, maximum depth, consumer lag, and optional dead-letter routing. Faults must modify only isolated runtime state, never the saved configuration.

## Graph validation

The product must block a simulation for errors such as no request origin, no reachable terminal path, incompatible or invalid edges, missing required settings, load balancer without targets, cache without valid origin behavior, queue without a consumer, invalid replica write paths, and invalid retry configuration.

It must warn about disconnected nodes, single points of failure, missing health checks, missing monitoring, no dead-letter queue for error-prone asynchronous work, caches with no expiry, databases lacking redundancy or backup, and retry loops or amplification risk.

Priority 1 components add the following rules. Errors: `gateway-no-routes`,
`auth-delegation-missing`, `dns-no-targets`, `topic-no-subscribers`, and
`nosql-invalid-consistency`. Warnings: `auth-single-point-of-failure`,
`external-service-no-circuit-breaker`, `subscriber-group-underprovisioned`, and
`no-backup-for-stateful-store`.

## Versioning and migration

`ProjectDocument` carries a schema version and every `SimulationResult` carries both an engine
version and a component-model version.

- Catalog changes are additive. New configuration fields must be optional or defaulted so existing
  projects load with no user action.
- A schema-version increase requires a forward migration that fills new fields with defaults.
- Technology assignments are denormalized and must survive migration unchanged.
- Results produced under a different component-model version must be marked stale and refused for
  comparison. The determinism guarantee is scoped to a fixed engine and component-model version.
- The seeded random generator's draw order is part of the engine contract. New consumers must append
  to the end of the per-event draw sequence; any change that reorders draws requires a deliberate
  test re-baseline and a version bump.

## Project persistence

Project files use a versioned JSON schema. The app must validate data on load and provide schema migrations as formats evolve. Preferences and recent-project metadata may be kept separately. Simulation result retention must be bounded so large result sets cannot cause unbounded project-file or memory growth.

## Canvas interaction implementation

### State separation

Persistent design data lives in the project store and participates in undo/redo and autosave. Ephemeral interaction state — which node's configuration modal is open and on which tab, the context-menu anchor, metrics-modal visibility and focus target, queued manual request batches, finding-toast visibility, notification-centre history, playback state, and the flow-animation preference — lives in separate UI stores. Opening a modal or menu, queueing or removing a request batch, dismissing a toast, or scrubbing playback must never dirty the project or create an undo entry.

Scenario mode, active scenario identity, tutorial progress/hints, technology recommendation
preferences, and first-run welcome visibility follow the same separation. Scenario mode and welcome
visibility are UI state; tutorial progress and recommendation preferences persist only in local
browser/Electron preference storage. None are embedded in a project document, undo history, JSON
export, or simulation signature.

The welcome experience is rendered through the standard accessible modal shell. Its guided action
resets session-only request/playback state, loads the Basic Web Application in Guided Tour mode,
sets the active scenario, and starts the matching tutorial. Its browse and dismissal actions leave
the project document unmodified.

Result staleness is derived, not stored as a flag: the project store records an architecture signature when a result is set, and compares it to the current signature to decide whether results are stale. The signature deliberately excludes node positions so that moving a node does not invalidate a run.

The signature includes all node configuration, complete edge data (including weights and routing
strategy), traffic profiles, and fault scenarios. Results are also stale when their engine or
component-model version differs from the current model.

On wide workspaces, the docked metrics context tab and the metrics modal share one peak-rollup
helper so both report identical maximum utilization and latency values. Component labels resolve
through the current document and fall back to an id only for a node removed after the run. The
context tab also uses the same result-freshness check as the modal. On compact workspaces
(`max-width: 1280px`), no narrow context rail is rendered; toolbar actions retain metrics-modal,
notification-centre, and configuration-modal access.

The full metrics modal derives chart data from completed `systemMetrics` only. It retains first
and final samples and down-samples longer series to at most 500 display points. Charts subscribe
to `currentLogicalTimeMs` only to render a reference marker; they never invoke a playback or
simulation-store mutator. Per-component rows use the shared peak-rollup helper, threshold
utilization styling, and the existing canvas-selection action.

The playback transport presents its logical position as a native range control rather than a
read-only progress indicator. Seeking clamps to the finished telemetry duration and pauses on the
chosen timestamp. It changes only `playbackStore.currentLogicalTimeMs`; the simulation result,
findings, metrics, seed, and project document remain untouched.

The node context menu follows the ARIA menu interaction model: it focuses the first action on
open, supports cyclic arrow navigation and Home/End navigation, and restores focus to its
originating React Flow node on Escape or outside dismissal. Actions that open a modal defer focus
ownership to that modal's existing focus-management contract.

### Scenario, tutorial, and recommendation architecture

Scenario templates are version-controlled domain data. A template contains a reference blueprint;
`getScenarioStartingState()` derives the Guided Tour (complete), Build (origin-only or partial), or
Challenge (empty) canvas without treating the reference as an answer key. Scenario request and
fault teaching presets are derived from validated reference configuration and loaded into
session-only request state.

Tutorial definitions are schema-validated and use only deterministic predicates already exposed by
the UI: selected scenario loaded, simulation completed, and metrics opened. The current framework
supports manual acknowledgement, restart, back/next, local progress persistence, progressive
hints, keyboard isolation, and an explicit confirmed “Show reference” action.

Technology recommendations are a pure deterministic domain function. They filter to compatible
catalog entries, rank with workload, topology, scenario, difficulty, local preference, and preset
signals, and return a bounded explainable list. UI selection uses the existing explicit
technology/preset confirmation path; recommendations never mutate the project themselves.

### Icon registry

A local registry maps every component type to one of a fixed set of locally authored category glyphs, and maps technology entries to an optional bundled asset. No third-party brand assets are shipped, no icon package such as `simple-icons` is bundled, and the shipped `LOGO_ASSETS` map is deliberately empty. When no approved asset exists the UI renders a provider-tinted monogram, so adding a licensed logo later is a single registry entry with no downstream changes. Icons carry `aria-hidden` because they always accompany a text label.

If a project later chooses to bundle a technology logo, the asset must be stored locally in the app,
registered in `LOGO_ASSETS` by stable technology id, and documented with source, license, and
trademark/usage notes. The registry may prefer that local asset over the monogram, but it must never
fetch icons from the network at runtime.

### React Flow node ownership

React Flow owns the node array in component state, synchronised from the project document whenever document-derived fields change. Node changes reported by React Flow are applied with `applyNodeChanges` so the dimensions it measures survive re-renders; edge routing depends on those measurements, so rebuilding the array from the document on every render would leave connections undrawable.

### Modal accessibility

The node configuration modal and metrics modal share a single shell that applies `role="dialog"` with `aria-modal`, traps focus within the dialog, restores focus to the triggering element on close, and closes on `Escape` or an outside click. Form controls generate ids with React `useId()` so reusable form content can render without duplicate ids or doubled accessible names.

### Findings notifications

Run findings are raised as session-scoped toasts instead of being hosted in a persistent results
panel. At most three are visible at once, sorted by severity (`critical`, `warning`,
`recommendation`, `info`), with overflow represented by a notification-centre link. Informational
findings whose source is `recommendation` display with the distinct recommendation severity. The
toast dedupe key is `findingId|relatedNodeIds|relatedEdgeIds`, intentionally independent of run id,
so an unchanged rerun increments a repeat count instead of stacking duplicates. Critical toasts use
`role="alert"` and `aria-live="assertive"` and receive focus; other severities use `role="status"`
and `aria-live="polite"`. Toast UI state is never persisted in the project document.

### Animation performance

The engine computes a full run in the Web Worker as fast as it can and records bucketed request-flow telemetry. Visual playback then replays that finished recording over visible time; it is read-only and cannot mutate calculated metrics, findings, or result status.

Flow telemetry is bucketed at `metricIntervalMs` by edge and flow class, so rendering cost scales with `edges × classes × buckets`, not request count. Buckets are emitted in ascending time order and samples in insertion order for byte-identical output across equal runs. `sampleTimelineAt()` finds sparse buckets by binary search rather than deriving an array index from a timestamp; quiet stretches may have no bucket.

The canvas samples playback with a `requestAnimationFrame` loop throttled to 30 fps because the underlying data changes only once per bucket. The loop stops entirely whenever playback is not running, so an idle canvas has no playback sampling cost. Very short runs are stretched to a minimum visible wall-clock duration, while longer runs are not compressed at 1× speed. Reduced motion or disabled flow animation replaces particles with directional markers, class labels, counters, and node processing marks.

Node-card density is zoom-adaptive: below the detail threshold, secondary technology, status, and
metric text is hidden while the utilization bar remains. High utilization (`>= 85%`) adds a warning
glyph and highlighted border in addition to the textual/numeric status at readable zoom. The global
keyboard handler opens a shared shortcut-reference dialog with **?** or **F1** outside editable
controls; it is disabled while tutorials own keyboard interaction.

## Performance requirements

| Area | Requirement |
|---|---|
| Application launch | Under 5 seconds on a typical development machine |
| Canvas interaction | Responsive with at least 100 nodes |
| Standard simulation start | Under 2 seconds |
| Logical simulation length | 1 to 5 minutes typical |
| Renderer responsiveness | Maintained during simulation |
| Playback sampling | At most 30 frames per second while running; no sampling loop while idle |
| Typical project load | Under 2 seconds |
| Event/metric retention | Bounded and aggregated; flow telemetry scales by edge, class, and bucket |

## Validation and test requirements

Unit tests must cover graph validation, event ordering, traffic generation, routing, capacity saturation, queue behavior, cache behavior, retry and timeout logic, circuit breakers, failover, autoscaling, fault recovery, metric aggregation, and schema migration.

Integration tests must cover creating an architecture, connecting and configuring nodes, configuring traffic, running a simulation, injecting faults, saving/reopening, and exporting. Security tests must prove renderer isolation, IPC validation, controlled file access, and safe rejection of malformed projects.
