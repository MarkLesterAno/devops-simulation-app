# Ultimate System Design Simulator

## Architecture Gap Report

**Review date:** 2026-09-28  
**Review scope:** Source code, domain model, simulation engine, persistence/Electron boundary, documentation, automated tests, and live execution at `http://localhost:5173/`.

## Executive assessment

The simulator is a strong MVP foundation. It already provides:

- Architecture canvas and component palette.
- Scenario templates and guided learning flows.
- Deterministic discrete-event simulation with seeded randomness.
- Web Worker execution.
- Fault injection and findings.
- Playback telemetry and flow visualization.
- Project persistence and autosave.
- Schema validation and migration support.
- Good unit-test coverage for core domain behavior.

The live run was successful:

- The Basic Web Application scenario loaded correctly.
- 3,000 requests were generated over 30 seconds.
- 3,000 requests succeeded and 0 failed.
- p50/p95/p99 latency was reported as 68/74/76 ms.
- Playback showed request flow across the graph.
- A single-point-of-failure finding was raised for the application server.

The principal remaining gaps are in simulation fidelity, architectural validation depth, result correctness, user-facing explanations, performance validation, and release hardening.

## Priority summary

| Priority | Area | Impact |
|---|---|---|
| P0 | Cancellation semantics and result lifecycle | Cancellation does not fully meet the documented cancelled-result contract. |
| P0 | Result invalidation/version compatibility | Results can appear current after behavior-affecting changes. |
| P0 | Diagram image export | A documented MVP capability is not implemented. |
| P1 | Simulation capacity model | RPS, concurrency, queueing, and utilization can be misinterpreted. |
| P1 | Architecture validation | Invalid or misleading distributed-system designs can still run. |
| P1 | Metrics and findings depth | Important component-specific behavior is not surfaced clearly. |
| P1 | Test strategy | Unit coverage is good, but browser, Electron, performance, and packaging tests are missing. |
| P2 | Component fidelity | Autoscaling, observability, replication, multi-region behavior, and operational controls are incomplete. |
| P2 | Performance and packaging | The production bundle is large and release benchmarks/automation are incomplete. |
| P2 | Security hardening | Electron isolation is good, but CSP and packaged-app security verification should be formalized. |

## Implementation status

The following Phase 0 remediation items have been implemented after this review:

- Cancelling a worker-backed run now settles the pending run with a valid `cancelled` result instead of leaving callers pending. Because a synchronous worker can only be force-stopped between messages, a force-stopped run explicitly reports that no partial metrics were returned.
- The architecture signature now uses canonical serialization and includes every persisted edge field, including `routingStrategy` and `weight`.
- Result freshness now also compares the stored engine and component-model versions, so metrics produced under an older model are clearly marked stale.
- The toolbar now includes **Export PNG**, which renders the persisted diagram with edges, component labels, and technology badges without exporting canvas controls or minimap UI.

## 1. Critical implementation gaps

### 1.1 Cancellation does not produce a cancelled simulation result

`SimulationWorkerClient.cancel()` terminates the worker directly. The original `Promise<SimulationResult>` is not resolved or rejected, so callers can remain pending and the UI does not consistently receive a `cancelled` result with partial metrics.

#### Recommended remediation

Implement an explicit active-run lifecycle:

1. Send a cancellation message to the worker where possible.
2. Stop scheduling new events.
3. Flush completed metric intervals.
4. Return a result with `status: "cancelled"`.
5. Preserve completed metrics, events, retry counts, and timeout counts.
6. Use worker termination only as a final safety mechanism.

Add tests for cancellation during:

- Startup.
- A long event queue.
- Playback preparation.
- Active playback.

### 1.2 Result staleness omits behavior-affecting edge fields

The architecture signature includes edge identity, endpoints, kind, and latency, but does not include fields such as:

- `routingStrategy`
- `weight`

Changing weighted routing can therefore leave the previous result appearing current even though load distribution and metrics would change.

#### Recommended remediation

Use a canonical stable serializer and include every behavior-affecting field in the signature. Add regression tests for:

- Routing strategy changes.
- Weight changes.
- Fault changes.
- Traffic profile changes.
- Node configuration changes.
- Node position changes remaining non-invalidating.

### 1.3 Engine/model version compatibility is not enforced in the UI

Results contain `engineVersion` and `componentModelVersion`, but result display staleness is primarily based on the architecture signature. Results generated by a different simulation model can therefore be presented as current.

#### Recommended remediation

Compare stored versions with current engine/model versions when loading and displaying results. Show a clear message such as:

> Results were generated by an older simulation model. Re-run to compare metrics.

Do not silently present incompatible metrics as current.

### 1.4 Diagram image export is missing

The acceptance criteria require export of the current diagram as an image. The UI exposes JSON export, but no clear PNG/SVG export path exists in the canvas, renderer, or Electron IPC layer.

#### Recommended remediation

Add:

- Export diagram as PNG.
- Optionally export diagram as SVG.

The export should:

1. Compute graph bounds.
2. Render nodes and edges at a deterministic scale.
3. Include labels and technology badges.
4. Exclude interactive controls and the minimap.
5. Use an Electron save dialog in desktop mode.
6. Use a browser download fallback in web mode.

## 2. Simulation-model gaps

### 2.1 Capacity semantics are potentially misleading

The metrics modal correctly states that capacity is modeled as concurrent in-flight request slots rather than literal RPS ceilings. However, configuration and results can still lead users to interpret capacity as RPS.

#### Recommended remediation

Expose both concepts:

- Arrival rate.
- Service rate.
- Concurrent work.
- Concurrency utilization.
- Estimated sustainable RPS.
- Queueing delay.
- Saturation status.

Use explicit labels such as `Per-instance concurrency capacity` and `Observed concurrency utilization`.

### 2.2 Queueing and saturation explanations are insufficient

The engine models queueing and overflow, but results do not clearly explain:

- Arrival rate versus service rate.
- Queue wait contribution.
- Time to saturation.
- Backlog growth rate.
- Drain time after a spike.
- Failure cause.

#### Recommended remediation

Add per-component metrics for:

- Arrival RPS.
- Service RPS.
- Admission rate.
- Rejection rate.
- Queue wait p50/p95/p99.
- Current and maximum queue depth.
- Backlog growth rate.
- Recovery/drain time.
- Saturation start timestamp.

### 2.3 No explicit closed-loop client behavior

Traffic is primarily modeled as logical arrivals. Client concurrency, connection limits, think time, and client-side retry behavior are not represented as a separate load model.

#### Recommended remediation

Support optional traffic modes:

1. Open loop: fixed arrival schedule.
2. Closed loop: fixed virtual users or clients.
3. Adaptive loop: clients react to latency and failures.

Expose virtual users, client concurrency, client timeout, retry policy, think time, and connection-pool size.

### 2.4 Response-path and fan-out semantics are incomplete

Response edges are largely visual metadata in the MVP. This limits accurate modeling of aggregators, partial fan-out, hedged requests, and compensation workflows.

#### Recommended remediation

Add explicit completion policies:

- `single-target`
- `all-targets`
- `quorum`
- `first-success`
- `best-effort`

Track dependency completion state per request.

### 2.5 Distributed consistency and replication are shallow

The simulator has replication and NoSQL consistency fields, but does not fully represent:

- Primary/replica promotion.
- Write acknowledgement policies.
- Replica election.
- Split brain.
- Quorum loss.
- Cross-region replication.
- Conflict resolution.
- Read-your-writes guarantees.

#### Recommended remediation

Introduce a replication model with topology, read/write quorum, failure domains, lag distributions, promotion time, conflict policy, and consistency-versus-availability findings.

### 2.6 Autoscaling and observability are mostly non-behavioral

The component catalog includes autoscaler and observability nodes, but their effect on runtime behavior appears limited.

#### Recommended remediation

For autoscaling, model:

- Target utilization.
- Scale thresholds.
- Minimum/maximum instances.
- Provisioning delay.
- Warm-up time.
- Cooldown.
- Scaling failure.
- Cost impact.

For observability, model:

- Telemetry overhead.
- Sampling rate.
- Collector capacity.
- Drop rate.
- Alert delay.
- Diagnostic coverage.

If they remain conceptual, label them explicitly as conceptual in the palette, canvas, documentation, and results.

## 3. Architecture validation gaps

### 3.1 Validation is strong for basic cases but shallow for advanced designs

Current validation covers missing origins, missing terminal paths, load balancer targets, queue consumers, disconnected nodes, and selected catalog rules. Additional checks are needed for:

- Cyclic request paths.
- Retry loops.
- Unbounded fan-out.
- Fan-in without aggregation semantics.
- Invalid replication paths.
- Failover edges without valid primaries.
- Writes routed to read replicas.
- Dead-letter queues without source queues.
- Circuit breakers not protecting a dependency.
- Autoscalers without scalable targets.
- Invalid observability paths.
- Cross-region paths without explicit latency.

#### Recommended remediation

Implement a rule-based validation engine with graph analysis phases for:

- Reachability.
- Strongly connected components.
- Request-path topology.
- Data-flow topology.
- Failure domains.
- Dependency fan-out/fan-in.
- Control-plane relationships.

Each issue should include severity, evidence, affected graph elements, explanation, and a suggested repair.

### 3.2 Single-point-of-failure detection is too narrow

The current warning focuses mainly on single-instance server and worker nodes. Other possible single points of failure include:

- Single database primary.
- Single cache.
- Single broker.
- Single DNS provider.
- Single identity provider.
- Single region.
- Single load balancer.
- Single external provider.

#### Recommended remediation

Add failure-domain analysis for node, zone, region, provider, data durability, control-plane, and recovery-path redundancy.

## 4. Metrics and findings gaps

### 4.1 Specialized metrics are not all visible

The engine tracks values such as DNS stale resolutions, hot-partition throttles, stale reads, provider throttles, authentication blocks, fan-out factor, subscriber queues, and duplicate side effects. The metrics UI primarily presents generic component rows.

#### Recommended remediation

Add component-specific metric cards:

| Component | Metrics |
|---|---|
| API Gateway | Quota rejections, auth blocks, route distribution |
| DNS | Cache hit ratio, stale resolutions, failover delay |
| NoSQL | Partition utilization, hot-key throttles, stale reads |
| Event Topic | Publish rate, fan-out, subscriber lag, retention drops |
| External Service | Provider throttles, duplicate side effects, SLA latency |
| Queue | Enqueue rate, consume rate, backlog, oldest-message age |
| Database | Read/write rate, connection utilization, replication lag |

### 4.2 Findings need stronger causal explanations

Findings identify architectural risks, but should also show observed impact when available:

- Requests affected.
- Failure period.
- Availability reduction.
- Latency increase.
- Whether the issue was topology-only or fault-induced.
- Recommended design alternative.

### 4.3 Percentile calculation should be documented and tested

The percentile implementation uses a simple indexed selection. This is acceptable for an MVP, but the method should be documented and tested for small samples and boundary cases. Consider nearest-rank, linear interpolation, HDR histogram, or t-digest depending on scale.

## 5. Persistence and project lifecycle gaps

The persistence architecture is sound: versioned documents, Zod validation, migrations, Electron IPC validation, and autosave are present.

Additional integration tests should cover:

- Truncated or partially written JSON.
- Invalid schema versions.
- Interrupted writes.
- Atomic replacement failures.
- Read-only directories.
- Permission errors.
- Recovery drafts newer and older than the saved project.
- Future schema versions.
- Safe handling of oversized project files.

The Electron layer exposes recent-project functionality, but the visible product flow should provide a clear recent-project UI with missing-file handling and removal/clear actions.

## 6. Testing and verification gaps

The existing test suite is a strong baseline:

- 14 test files.
- 159 tests passed.
- TypeScript typecheck passed.
- Production build passed.
- ESLint passed.

Missing coverage includes:

### Browser integration

- Scenario loading.
- Node configuration.
- Edge creation and rejection.
- Keyboard navigation.
- Modal focus trapping.
- Simulation run/cancel.
- Playback controls.
- Metrics and findings workflows.
- Stale-result behavior.
- Diagram export.
- Reduced-motion behavior.

### Electron integration

- Context isolation.
- IPC allowlisting.
- File validation.
- Autosave.
- Atomic writes.
- External-link restrictions.
- Packaged startup.

### Performance

Benchmarks should cover:

- 100-node canvas.
- 500-node canvas.
- High-volume traffic.
- Long-duration playback.
- Large event queues.
- Large flow timelines.

Measure simulation duration, peak memory, worker responsiveness, frame rate, modal rendering time, and project serialization size.

## 7. Performance and packaging gaps

The production build succeeded, but Vite reported a main JavaScript bundle of approximately 692 KB minified, above the configured 500 KB warning threshold.

#### Recommended remediation

Use code splitting for:

- Scenario gallery.
- Metrics modal.
- Request composer.
- Recharts.
- Technology catalog.
- Electron-only integration.

The release documentation also requires packaged smoke tests, signing, release automation, version metadata, artifact publication, and manual update discovery. These should be implemented before stable release.

## 8. Security and privacy gaps

Electron isolation is well configured:

- `contextIsolation: true`
- `nodeIntegration: false`
- `sandbox: true`
- Restricted preload API.
- Zod validation for IPC payloads.
- HTTPS-only external navigation.

Formalize security hardening with:

- A strict Content Security Policy.
- Navigation regression tests.
- External protocol rejection tests.
- Malformed IPC payload tests.
- Path traversal and symlink tests.
- Oversized project-file tests.
- Packaged-app security verification.

## 9. Product and learning-experience gaps

### 9.1 Assumptions should be contextual

Assumptions currently appear in the metrics view, which is useful, but they should also appear where decisions are made:

- Component configuration.
- Scenario objectives.
- Findings.
- Affected metric rows.
- A model-fidelity panel.

### 9.2 Add model-fidelity indicators

Different components have different simulation depth. Add explicit labels:

| Fidelity | Meaning |
|---|---|
| Conceptual | Visual/topological only |
| Behavioral | Simplified runtime behavior is modeled |
| Advanced | Faults, limits, and specialized metrics are modeled |
| Experimental | Model is incomplete or approximate |

## Recommended implementation roadmap

### Phase 0 — Correctness blockers

1. Return a real cancelled result.
2. Include all behavior-affecting fields in architecture signatures.
3. Enforce engine/model version compatibility.
4. Implement diagram image export.
5. Add regression tests for all four items.

### Phase 1 — Simulation credibility

1. Clarify or redesign RPS versus concurrency semantics.
2. Add queue-wait and saturation metrics.
3. Add explicit failure-cause accounting.
4. Add component-specific metric panels.
5. Improve findings with observed evidence.
6. Add optional closed-loop traffic.

### Phase 2 — Distributed-systems depth

1. Add cycle and retry-loop validation.
2. Add failure-domain analysis.
3. Add replication and quorum semantics.
4. Add fan-out completion policies.
5. Add autoscaler behavior.
6. Add external-dependency and control-plane warnings.

### Phase 3 — Product hardening

1. Add browser end-to-end tests.
2. Add Electron persistence and IPC integration tests.
3. Add 100-node and high-volume benchmarks.
4. Reduce bundle size through code splitting.
5. Add CSP and security regression tests.
6. Complete packaging, signing, release, and update workflows.

## Final conclusion

The simulator is already beyond a basic canvas prototype. Its strongest capabilities are deterministic simulation, seeded reproducibility, scenario-driven learning, fault modeling, worker-based execution, structured persistence, and disciplined unit testing.

The highest risks are contract mismatches and misleading simulation interpretation:

1. Cancellation does not currently satisfy the documented lifecycle.
2. Results can remain apparently current after routing or model changes.
3. Diagram export is documented but absent.
4. Capacity/utilization terminology can confuse learners.
5. Specialized engine behavior is not fully visible in the metrics UI.
6. Distributed-system validation is not yet deep enough for advanced architectures.
7. Integration, performance, Electron, and packaging verification remain incomplete.

Addressing the P0 and P1 items will make the simulator substantially more trustworthy as an educational and design-analysis tool.
