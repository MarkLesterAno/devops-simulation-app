# UI/UX Evaluation & Technical Remediation Specification

**Document type:** Agent-executable engineering specification
**Verification timestamp:** 2026-09-28T10:41+08:00
**Target repository:** `c:\Users\mark.lester.j.ano\Desktop\System Design Simulator Tool`
**Verification method:** Live interaction at `http://localhost:5173/` (Playwright-driven: empty state, scenario library, scenario load, simulation run, playback scrub, metrics, node config, request composer, 1440×900 reflow) cross-referenced against source reads and a full `vitest run`.
**Baseline test state at verification:** `15 files / 163 tests passed`, `npm run typecheck` clean.

> ⚠️ **This document was written against a moving tree.** During review, remediation was landing concurrently — `ScenarioBrief.tsx` 404'd mid-HMR while being rewritten. Every claim below was re-verified against source immediately before writing. **Re-run the Section 1 verification probes before starting work.** If a probe disagrees with this document, trust the probe.

> **Remediation update (2026-09-29):** The historical implementation notes below are retained for
> traceability, but they no longer describe the current tree in full. The following defects are now
> remediated and regression-tested: D-1 peak aggregation, D-2 display-name resolution, D-3
> non-hijacking context selection, D-5 compact context-rail removal, D-6 multi-fault arming, and
> D-8 stale-result visibility. Shared `rollupComponentMetrics()` is used by both metrics surfaces;
> compact workspaces use modal/notification fallbacks instead of rendering an inert context rail.
> The active remaining UX priorities are bounded run comparison, inspector restructuring
> (including specialty-field validation), richer toolbar/overlay behavior, and release-grade
> browser/Electron coverage.

---

## 0. Agent execution contract

### 0.1 Environment facts

| Property | Value |
|---|---|
| Stack | React 18.3 · TypeScript 5.6 · Vite 5.4 · Zustand 5.0 · Zod 3.23 · `@xyflow/react` 12.3 · Electron 33.2 |
| Path alias | `@/` → `./src/` (`tsconfig.app.json` + `vite.config.ts` — must stay in sync) |
| Test stack | Vitest 2.1 · `@testing-library/react` 16 · jsdom 25 · setup at `tests/setup.ts` |
| Styling | **One** global stylesheet: `src/app/styles/global.css` (~1240 lines). No CSS modules, no CSS-in-JS, no Tailwind. |
| Forms | `react-hook-form@^7.53` — already a dependency, used by `NodeConfigForm` |
| Charts | **`recharts@^2.13.3` is in `dependencies` with ZERO imports repo-wide** (grep-verified). Use it. Do not add a charting library. |
| State | 5 Zustand stores: `projectStore`, `uiStore`, `playbackStore`, `requestStore`, `toastStore` |

### 0.2 Commands

```bash
npm run dev        # Vite dev server → :5173
npm run typecheck  # tsc -b --noEmit
npm run lint       # eslint .
npm run test       # vitest run  (~75s cold)
npm run build      # tsc -b && vite build
```

> **PowerShell blocker (verified):** `npm.ps1` fails with
> `File C:\Program Files\nodejs\npm.ps1 cannot be loaded because running scripts is disabled on this system.`
> **Workaround — route through `cmd.exe`:**
> ```powershell
> & $env:ComSpec /c "npm run test"
> & $env:ComSpec /c "npx vitest run tests/unit/projectStore.test.ts"
> ```
> `git` is **not on PATH** in this shell. Do not rely on git for state comparison; use the Section 1 probes.

### 0.3 Architectural invariants — violating any of these is a defect

| # | Invariant | Enforcement rationale |
|---|---|---|
| **I-1** | **Never modify `src/simulation-engine/**` or `src/domain/**` to satisfy a UI need.** | The engine is correct and tested. All tasks here are presentation-layer. If a UI change appears to need an engine change, stop and flag it. |
| **I-2** | **Determinism is a product guarantee.** No UI state may influence seeding, event ordering, or results. | `SeededRandom` + `EventQueue` guarantee identical output for identical input. Playback reads a *finished* `SimulationResult`. |
| **I-3** | **UI state never enters `ProjectDocument`.** | `projectStore` mutations push undo history and set `isDirty`. Panel/tab/checkbox state in the document would corrupt undo and mark projects dirty on view changes. Put it in `uiStore`. |
| **I-4** | **Never widen `ProjectDocument` without a migration + round-trip test.** | `projectPersistence` parses saved files through Zod. An unmigrated field breaks every existing save. |
| **I-5** | **Derive UI bounds from Zod schemas, never hardcode.** | Hardcoded `min`/`max` silently drift from validation. Read `baseComponentConfigSchema`. |
| **I-6** | **Preserve existing ARIA.** | `role="toolbar" / "menuitem" / "progressbar" / "status" / "tablist"` and `aria-label` are in place throughout. Extend, never strip. |
| **I-7** | **Styling in `global.css` using existing custom properties.** | Inline `style={{}}` is acceptable only for computed dynamic values (e.g. a bar width percentage). |
| **I-8** | **React Flow `nodeTypes` / `edgeTypes` must be module-scope constants.** | Currently correct at `ArchitectureCanvas.tsx:107,116`. Moving them inside the component triggers a full remount every render. See **D-7**. |

### 0.4 Definition of done — per task, not per batch

```bash
& $env:ComSpec /c "npm run typecheck"   # must be clean
& $env:ComSpec /c "npm run lint"        # must be clean
& $env:ComSpec /c "npm run test"        # must stay ≥163 passing
```
Plus: the task's own acceptance criteria checked, and its named test file added and passing.

### 0.5 Status legend

| Symbol | Meaning |
|---|---|
| ✅ `DONE` | Verified present in source. **Do not redo.** |
| ⚠️ `PARTIAL` | Landed but incomplete or defective. Only the stated delta remains. |
| 🔧 `OPEN` | Not implemented. |
| 🐞 `DEFECT` | Implemented incorrectly. Regression risk. Fix before building on it. |

---

## 1. Verification probes — run these first

Re-establish ground truth before any work. Expected values are as of the verification timestamp.

```powershell
cd 'c:\Users\mark.lester.j.ano\Desktop\System Design Simulator Tool'

# P-1  alert() call sites           → expected 7 (T-04 open)
(Select-String -Path (Get-ChildItem -Recurse src -Include *.ts,*.tsx).FullName -Pattern 'alert\(').Count

# P-2  recharts imports             → expected 0 (T-05 open)
(Select-String -Path (Get-ChildItem -Recurse src -Include *.ts,*.tsx).FullName -Pattern 'recharts').Count

# P-3  run history                  → expected 0 (T-06 open)
(Select-String -Path (Get-ChildItem -Recurse src -Include *.ts,*.tsx).FullName -Pattern 'runHistory').Count

# P-4  feature components present
Get-ChildItem -Recurse src\features -Filter *.tsx | Select-Object -ExpandProperty Name

# P-5  defect D-1: last-vs-peak     → presence of `latestByNode` = defect unfixed
Select-String -Path src\features\context-panel\ContextPanel.tsx -Pattern 'latestByNode|Component peaks'

# P-6  defect D-6: fault multi-select → `faultScenarioIds[0]` = still single-select
Select-String -Path src\features\simulation\SimulationControls.tsx -Pattern 'faultScenarioIds\[0\]'

# P-7  test count baseline          → expected 163
& $env:ComSpec /c "npx vitest run 2>&1" | Select-String "Tests "
```

---

## 2. Current state matrix

### 2.1 Resolved — verified, do not redo

| ID | Original finding | Verified resolution |
|---|---|---|
| ✅ C1 | Validation computed but never rendered; `Blocked: fix errors` was a dead end | `src/features/validation/ValidationSummary.tsx` renders each `ValidationIssue` as a `<button>` calling `selectNode(issue.nodeIds[0])`. Empty canvas (`nodeCount === 0`) now returns an onboarding state, not an error. Pill text changed to `Review issues below`. |
| ✅ C5 | Canvas did not frame content on load | `fitView` prop on `<ReactFlow>` — `ArchitectureCanvas.tsx:374` |
| ✅ H1 | Inert `File/Edit/View/Simulation/Help` spans | `App.tsx:170` — replaced with product title + tagline. No false affordance remains. |
| ✅ H2 | No primary action in a 13-button toolbar | `.toolbar .primary-action` (`global.css:95`) applied to `▶ Run` (`SimulationControls.tsx`) |
| ✅ H6 | Config modal defaulted to the inert Implementation tab | `uiStore.ts` — `configTab: "inspector"` as both initial value and per-node reset default |
| ✅ M7 | Palette click-to-add undiscoverable | `Palette.tsx` now renders *"Click to add to the canvas, or drag to choose a position."* |
| ✅ C3 | Insight locked in modals | `src/features/context-panel/ContextPanel.tsx` + `.main-layout` 3-column grid (`global.css:161`) with `min-height: 0` correctly applied and a `@media (max-width: 1280px)` rail fallback |
| ✅ C4 | Scenario objectives discarded on open | `uiStore.activeScenarioId` + `src/features/scenarios/ScenarioBrief.tsx` re-resolving via `getScenarioTemplate()` |
| ✅ H7a | Traffic profile hardcoded to `[0]` | Toolbar `<select aria-label="Traffic profile">`; verified live showing *Steady 100 RPS* / *Lunchtime peak* |
| ✅ H7b | `faultScenarioIds: []` hardcoded | Now wired to state and pre-armed from `scenario.metadata.defaultFaultScenarioIds`. Verified live: *None / Application server outage / Database slowdown*. **See D-6 for the remaining array defect.** |
| ⚠️ C2 | No live node metrics | `ArchitectureNodeView` renders `node-utilization` (`role="progressbar"`), `status-dot`, and `node-metrics`. Remaining delta → **T-07**. |

### 2.2 Outstanding work

| ID | Sev | Title | Task |
|---|---|---|---|
| D-4, D-7 | 🐞 | Remaining review follow-up | **§3** |
| H8 | 🟠 High | 7 `alert()` call sites | T-04 |
| M3 | 🟡 Med | Metrics text-only; time series discarded | T-05 |
| M4 | 🟡 Med | No run-over-run comparison | T-06 |
| C2Δ | 🟡 Med | Node metrics need broader playback interaction coverage | T-07 |
| M1/M2 | 🟡 Med | Inspector flat 13-field list, no bounds or guidance | T-08 |
| H3 | 🟡 Med | Toolbar reflow; findings count shifts siblings | T-09 |
| H4/H5 | 🟡 Med | Toast/minimap/playback collision; no auto-dismiss | T-10 |
| — | 🟡 Med | **Zero tests for any newly-landed UI** | T-14 |
| M5/M8 | ⚪ Low | Unexplained Seed/Duration and tier badges | T-11 |
| M9 | ⚪ Low | Design tokens colour-only | T-12 |
| M10 | ⚪ Low | Shortcut reference and model onboarding delivered | T-13 |

---

## 3. Defects in newly-landed code — fix before building further

Remediation landed fast and introduced correctness and UX regressions. **These take priority over new features**, because T-05/T-06 build directly on `ContextPanel`.

### ✅ D-1 — `ContextPanel` labels last-sample data as "Component peaks" *(remediated)*

**File:** `src/features/context-panel/ContextPanel.tsx:76-80`

```ts
function latestByNode(snapshots: {...}[]): Array<[string, {...}]> {
  const latest = new Map<string, {...}>();
  for (const snapshot of snapshots) latest.set(snapshot.nodeId, snapshot); // ← overwrite
  return [...latest.entries()].sort(([, l], [, r]) => r.utilization - l.utilization);
}
```

`Map.set` overwrites, so this yields the **chronologically last** snapshot per node — yet line 62 renders it under the heading **`<h3>Component peaks</h3>`**.

**Why this matters pedagogically:** a node that saturates to 98% mid-run and drains to 3% by the end will be reported as **3%**. This teaches the exact opposite of the intended lesson and silently contradicts `MetricsModal`, which reports the true peak for the same run. Two surfaces, same data, different numbers.

**Correct implementation already exists** — `MetricsModal.tsx:248` `rollupByNode()`:

```ts
current.peakUtilization = Math.max(current.peakUtilization, snapshot.utilization);
current.peakLatencyMs   = Math.max(current.peakLatencyMs,   snapshot.latencyMs);
```

**Delivered:** `rollupComponentMetrics()` is shared by the context panel and metrics modal. It
reports peak utilization/latency and sorts components by peak utilization. Regression coverage
includes a high middle interval followed by a low final interval.

---

### ✅ D-2 — `ContextPanel` renders raw node IDs *(remediated)*

**File:** `ContextPanel.tsx:62`

```tsx
<li key={nodeId}>{nodeId}: {(metric.utilization*100).toFixed(0)}% utilisation · …</li>
```

`nodeId` is generated by `projectStore.generateNodeId()` as `` `${type}-${counter}-${Date.now().toString(36)}` `` → e.g. **`server-4-lx8s2f`**. The learner sees an opaque token instead of *"Application Server"*.

**Correct pattern exists** — `MetricsModal.tsx:56`:

```ts
const nameById = useMemo(() => {
  const map = new Map<string, string>();
  for (const node of document_.nodes) map.set(node.id, node.config.displayName);
  return map;
}, [document_.nodes]);
```

**Delivered:** context metrics resolve `config.displayName`, retaining node-id fallback only when a
node no longer exists in the current document.

---

### ✅ D-3 — Node selection hijacks the panel tab *(remediated)*

**File:** `ContextPanel.tsx:29-31`

```tsx
useEffect(() => {
  if (selectedNodeId) openPanel("inspector");
}, [selectedNodeId, openPanel]);
```

`openContextPanel` sets `{ contextPanelOpen: true, contextPanelTab: tab }` (`uiStore.ts:124`). Two consequences:

1. A learner reading **Metrics** who clicks a node to locate it is yanked to **Inspector**, losing their place — the precise comparison workflow T-05/T-06 depend on.
2. A **deliberately collapsed** panel is force-reopened by a canvas click, overriding an explicit user choice.

**Delivered:** selection switches Objectives to Inspector only when the panel is already open. It
does not take learners away from Metrics or Findings and never reopens a deliberately collapsed
panel.

```tsx
useEffect(() => {
  if (!selectedNodeId) return;
  const { contextPanelOpen, contextPanelTab, setContextPanelTab } = useUiStore.getState();
  if (contextPanelOpen && contextPanelTab === "objectives") setContextPanelTab("inspector");
}, [selectedNodeId]);
```

---

### 🐞 D-4 — Objectives duplicated across two surfaces *(IA)*

`ScenarioBrief` (banner) renders `learningObjectives` + `simplifications`. `ContextPanel` **objectives** tab renders `learningObjectives` + `simplifications`. Same data, two places, competing for attention — and the banner consumes permanent vertical space above the canvas.

**Fix — assign distinct jobs:**
- **`ScenarioBrief`** → one-line identity strip only: name · difficulty · estimated minutes · a *"View objectives"* button calling `openContextPanel("objectives")`. Drop both `<details>` blocks.
- **`ContextPanel` objectives tab** → the single home for objectives, model limits, prerequisites, and `challenges`.

---

### ✅ D-5 — Collapse control contradicts itself below 1280px *(remediated)*

`global.css:255-272` hides the panel body at `max-width: 1280px` **via CSS only**, while `contextPanelOpen` remains `true`. The header therefore still shows **`›` "Collapse context panel"** on an already-collapsed panel; pressing it sets `open:false`, rendering the `‹` expand rail — which at that width cannot expand. Two states render identically; the control is a no-op trap.

**Delivered:** `ContextPanel` observes the breakpoint with `matchMedia` and returns no panel below
1280px. The compact grid is two columns, while the existing toolbar/modal/notification-centre
surfaces supply metrics, findings, and node configuration without an inert expand control.

---

### ✅ D-6 — Fault selection is plural in type, singular in UI *(remediated)*

**File:** `SimulationControls.tsx:113-114`

```tsx
value={faultScenarioIds[0] ?? ""}
onChange={(e) => setFaultScenarioIds(e.target.value ? [e.target.value] : [])}
```

State is `string[]`, the worker accepts `faultScenarioIds: string[]`, and `scenario.metadata.defaultFaultScenarioIds` is an **array** — but a single `<select>` truncates to one. A scenario declaring two default faults silently arms only the first, so the run diverges from the template's documented intent with no warning.

**Delivered:** the toolbar renders one checkbox per fault scenario, preserves all selected ids, and
shows an accessible `N armed` count using the warning colour. The pure selection helper has
regression coverage for add, remove, and duplicate selection.

---

### 🐞 D-7 — React Flow `nodeTypes` remount warning *(performance)*

Observed in console at verification:

```
[React Flow]: It looks like you've created a new nodeTypes or edgeTypes object.
If this wasn't on purpose please define the nodeTypes/edgeTypes outside of the
component or memoize them. Help: https://reactflow.dev/error#002
```

`ArchitectureCanvas.tsx:107,116` **do** define both at module scope, which is correct — so the warning indicates another `<ReactFlow>` instance, or an object identity broken by a wrapper/HMR artifact. Every occurrence forces a full node remount, which will visibly stutter playback.

**Fix:** reproduce on a cold load (not HMR). If it persists, locate the offending instance. Guard with **I-8**.

---

### ✅ D-8 — `ContextPanel` ignores result staleness *(remediated)*

`MetricsModal` computes `resultFreshness(result, document_, lastResultSignature)` and renders a **"Stale — architecture changed since this run"** badge. `ContextPanel`'s metrics tab reads `lastResult` with no freshness check.

A learner who edits `instanceCount` after a run sees stale metrics presented as current — directly defeating the change→measure→compare loop that T-06 formalises.

**Delivered:** the context metrics tab reuses `resultFreshness()` and displays architecture/model
staleness before run metrics.

---

## 4. Task specifications

### T-04 — Replace `alert()` with in-app notifications ✅ DONE

**Resolves:** H8 · **Probe:** P-1 (expect 7 → 0) · **Dependencies:** none

#### Call sites (all 7, verified)

| File | Message |
|---|---|
| `src/app/App.tsx` | `Could not open project: ${result.error}` |
| `src/app/App.tsx` | `Could not save project: ${result.error}` |
| `src/app/App.tsx` | `Could not export project: ${result.error}` |
| `src/app/App.tsx` | `Could not export diagram: ${error.message}` |
| `src/features/scenarios/ScenarioGallery.tsx` | `alert(result.error)` |
| `src/features/scenarios/ScenarioGallery.tsx` | `Wait for the current simulation to finish or cancel it before opening a scenario.` |
| `src/features/simulation/SimulationControls.tsx` | `Simulation failed` |

`alert()` is synchronous and blocking — under Electron it halts the renderer, is unstyled, and its text cannot be copied, which is hostile when the payload is a persistence error a user needs to report.

#### Store contract — extend `src/stores/toastStore.ts`

```ts
export interface AppNotification {
  id: string;
  severity: "error" | "warning" | "info" | "success";
  title: string;
  /** Raw underlying error. Must render selectable so users can copy it. */
  detail?: string;
  action?: { label: string; run(): void };
}

notify(notification: Omit<AppNotification, "id">): void;
dismissNotification(id: string): void;
```

#### Behaviour

- `error` → **never** auto-dismisses; explicit dismissal only.
- `info` / `success` → auto-dismiss at 6000ms.
- `warning` → auto-dismiss at 8000ms.
- Render through the existing toast stack container so exactly one toast region exists (coordinate with T-10).
- **Out of scope:** the `window.confirm` in the autosave recovery banner (`App.tsx`) is a genuine destructive confirmation — leave it.

#### Acceptance criteria

- [ ] P-1 returns `0`.
- [ ] Failed save shows a non-blocking error toast containing the original error text, selectable.
- [ ] Simulation failure shows an error toast **and** leaves `isSimulating === false` and playback reset.
- [ ] Error toasts survive a 30s timer advance.

#### Tests — `tests/unit/notifications.test.ts`

```ts
// vi.useFakeTimers()
// 1. notify({severity:"error"}) → still present after advanceTimersByTime(30_000)
// 2. notify({severity:"info"})  → absent after advanceTimersByTime(6_000)
// 3. spy = vi.spyOn(window, "alert"); trigger failed save; expect(spy).not.toHaveBeenCalled()
```

---

### T-05 — Metrics as an instrument, not a report ✅ DELIVERED

**Resolves:** M3 · **Probe:** P-2 (expect 0 → >0) · **Depends on:** D-1, D-2, D-8 fixed

#### The core waste

`simulationResultSchema` already carries **full time series** that the UI collapses to a single number:

```ts
systemMetrics: SystemMetricSnapshot[]     // timestampMs, rps, errorRate, latency{p50,p95,p99}
componentMetrics: ComponentMetricSnapshot[] // per node per timestamp: utilization, queuedWork,
                                            // latencyMs, errorRate, cacheHitRatio, queueDepth,
                                            // consumerLagMs, replicaLagMs, partitionUtilization…
```

The schema comment on `summary` is explicit:

> *"`systemMetrics` remains available as a time series for trend/graphing use cases."*

**The engine records the shape of the run; the UI renders only its endpoint.** A learner cannot see *when* latency spiked or *whether* a queue drained — which is the entire lesson. **No engine work is required to fix this.**

#### A. Charts — use `recharts` (already a dependency)

| Chart | Series | X axis | Render condition |
|---|---|---|---|
| Latency | `latency.p50`, `p95`, `p99` | `timestampMs` | `systemMetrics.length > 1` |
| Throughput | `rps` | `timestampMs` | `systemMetrics.length > 1` |
| Error rate | `errorRate` | `timestampMs` | any `errorRate > 0` |

- Add a `<ReferenceLine x={currentLogicalTimeMs} />` bound to `playbackStore`.
- **Read-only coupling (I-2):** the chart subscribes to playback; it must never call `advance`, `setSpeed`, or any playback mutator.
- Render an explicit empty state pre-run — never an axis with no domain.
- Downsample above ~500 points (stride sampling) to protect render cost.

#### B. Component table

- Inline utilisation bar per row, reusing `.node-utilization` styling for visual consistency with the canvas.
- **Sort by `peakUtilization` descending** — the bottleneck must be row 1.
- Thresholds, using existing tokens:

| Range | Token |
|---|---|
| `< 0.70` | `--color-healthy` |
| `0.70 – 0.85` | `--color-warning` |
| `0.85 – 0.95` | `--color-degraded` |
| `> 0.95` | `--color-failed` |

- Row click → `selectNode(nodeId)`, highlighting it on the still-visible canvas.
- Resolve names via `nameById` (**D-2**).

#### C. Preserve the assumptions disclosure

`result.assumptions` (*"Capacity is modeled as concurrent in-flight request slots, not literal RPS ceilings"*, etc.) is a genuine product strength and an honesty guarantee. Keep it visible — not behind a toggle.

#### Delivered behavior

- The metrics modal imports the already-installed `recharts` package and renders p50/p95/p99
  latency and throughput whenever at least two samples exist; error rate is shown only when
  a sample contains an error.
- A read-only `ReferenceLine` tracks `currentLogicalTimeMs`. The chart has no playback
  mutators, so inspecting or scrubbing trends cannot alter a completed result.
- Source series are bounded to 500 display points while retaining the first and final
  samples. Peak-sorted component rows include threshold-coloured utilization bars and are
  keyboard/click selectable on the canvas.
- Empty or single-sample results render an explanatory trend empty state. Existing
  assumptions and deterministic-model disclosures remain visible.

#### Tests — `tests/unit/metricsPanel.test.tsx`

```ts
// 1. rollupByNode() peak vs last: feed [0.9, 0.1] → expect 0.9  (guards D-1)
// 2. threshold class boundaries: 0.69 | 0.70 | 0.85 | 0.95
// 3. rows sorted by peakUtilization desc
// 4. systemMetrics: [] → empty state, no throw
// 5. row renders displayName, not raw nodeId                     (guards D-2)
```

---

### T-06 — Run-over-run comparison 🔧 OPEN

**Resolves:** M4 · **Probe:** P-3 · **Depends on:** T-05

#### Problem

`projectStore.setResult` overwrites `lastResult`. The core learning loop — *"add a cache → did it help?"* — has no before/after anywhere in the product.

#### A. Bounded history — **memory-critical**

> ⚠️ **Do not store 10 full `SimulationResult` objects.** Each carries `events: SimulationEvent[]`, `componentMetrics[]`, and `flowTimeline` — for a 30s/3000-request run this is thousands of objects. Ten of them will bloat the heap and slow autosave serialisation.

Store a **reduced** record:

```ts
export interface RunSummaryRecord {
  runId: string;
  seed: number;
  status: RunStatus;
  completedAt: string;
  /** Guards comparability — see below. */
  componentModelVersion?: string;
  engineVersion: string;
  summary?: SystemMetricSnapshot;
  observedAvailability?: number;
  estimatedCost?: number;
  /** nodeId → peak utilisation/latency only. No time series. */
  nodePeaks: Record<string, { utilization: number; latencyMs: number }>;
}

// projectStore
runHistory: RunSummaryRecord[];   // newest first, cap 10
```

Keep the full object only in `lastResult`. In `setResult`: unshift the reduced record, `slice(0, 10)`.

#### B. Comparison UI

- Baseline picker defaulting to the immediately previous run.
- Delta on summary metrics: `p95 480ms → 92ms ▼ 81%`.
- **Direction-aware colouring — do not colour by raw sign:**

| Metric | Improvement |
|---|---|
| latency p50/p95/p99 | ↓ lower |
| errorRate | ↓ lower |
| rps / throughput | ↑ higher |
| observedAvailability | ↑ higher |
| estimatedCost | ↓ lower (annotate; cheaper is not always better) |

- **Comparability guard.** `simulationResultSchema` documents `componentModelVersion` as *"results from different values are incomparable."* If it differs between runs, **suppress deltas** and show a warning. Same for `engineVersion`.
- **Seed guard.** Different seeds → annotate *"Different seeds — some variance is noise, not signal."*

#### Acceptance criteria

- [ ] Two runs make a comparison available.
- [ ] Improved p95 → downward/green; regressed → upward/red.
- [ ] Higher `rps` → green (opposite direction to latency).
- [ ] `runHistory.length === 10` after 12 runs.
- [ ] No history entry contains an `events` key.
- [ ] Mismatched `componentModelVersion` suppresses deltas + warns.
- [ ] `newProject()` clears history.

#### Tests — extend `tests/unit/projectStore.test.ts`

```ts
// 1. 12× setResult → runHistory.length === 10, newest first
// 2. expect(Object.keys(runHistory[0])).not.toContain("events")
// 3. delta direction: latency down = improvement; rps up = improvement
// 4. componentModelVersion mismatch → comparable === false
// 5. newProject() → runHistory === []
```

---

### T-07 — Zoom-adaptive, saturation-emphasised node metrics ✅ DELIVERED

**Resolves:** C2 delta

`ArchitectureNodeView` renders `node-utilization`, `status-dot`, and `node-metrics`. The canvas
already applies a zoom-detail threshold that hides technology, status text, and metric rows while
retaining the utilization bar. High utilization (`>=85%`) now adds a warning glyph and degraded
border, while status text and numeric utilization remain available at readable zoom levels.

The remaining follow-up is to add browser-level coverage for utilization changing during forward
and backward playback scrubs; it is not a reason to withhold the delivered readability behavior.

#### Acceptance criteria

- [ ] Zooming below 0.6 hides metric lines, retains the bar.
- [ ] A `>0.85` node is distinguishable in a greyscale screenshot.
- [ ] Scrubbing backward lowers a saturated node's displayed utilisation.

---

### T-08 — Restructure the inspector by simulation impact 🔧 OPEN

**Resolves:** M1, M2

#### Problem

13 flat, equally-weighted fields. `instanceCount` — which drives the entire bottleneck and single-point-of-failure lesson — is visually identical to `region`, which is cosmetic. Full-width inputs for 1–3 character numbers. No units, no bounds, no explanation. `errorRate = 0` is ambiguous: fraction, percent, or per-mille?

#### Authoritative bounds — `src/domain/architecture/schema.ts:88-105` (**I-5**)

```ts
export const baseComponentConfigSchema = z.object({
  displayName:          z.string().min(1).max(80),
  region:               z.string().min(1).max(40).default("local"),
  instanceCount:        z.number().int().min(1).max(1000).default(1),
  perInstanceCapacityRps: z.number().min(0).default(100),
  baseLatencyMs:        z.number().min(0).default(5),
  jitterMs:             z.number().min(0).default(0),
  timeoutMs:            z.number().min(1).default(2000),
  errorRate:            z.number().min(0).max(1).default(0),   // ← FRACTION 0–1
  overflowBehavior:     overflowBehaviorSchema.default("queue"),
  maxQueueDepth:        z.number().int().min(0).default(1000),
  estimatedCostPerHour: z.number().min(0).default(0),
  maxRetries:           z.number().int().min(0).max(10).default(0),
  retryBackoffMs:       z.number().min(0).default(100)
});
```

`overflowBehaviorSchema = z.enum(["queue","reject","shed-load","penalty"])`

> **`errorRate` is a 0–1 fraction.** Display it as a percentage, but convert **only at the UI boundary**. The stored domain value must remain the fraction (**I-1**). Guard the round-trip with a test — `0.07 → "7%" → 0.07` must not drift through float error.

#### Grouping

| Order | Group | Fields | Default |
|---|---|---|---|
| 1 | **Capacity** | `instanceCount`, `perInstanceCapacityRps` | Expanded, accent label, larger control |
| 2 | **Latency** | `baseLatencyMs`, `jitterMs`, `timeoutMs` | Expanded |
| 3 | **Resilience** | `overflowBehavior`, `maxQueueDepth`, `maxRetries`, `retryBackoffMs`, `errorRate` | Collapsed |
| 4 | **Identity** | `displayName`, `region` | Collapsed |
| 5 | **Cost** | `estimatedCostPerHour` | Collapsed |

#### Field requirements

- Numeric inputs sized to content, not full width.
- Unit suffixes rendered in-field: `ms`, `req/s`, `%`, `$/hr`.
- `min` / `max` / `step` **read from the Zod schema**, never literals.
- Out-of-range → inline validation message, **not** a silent clamp.
- One-line `ⓘ` per field stating simulation effect, e.g. *"Instances multiply total capacity. A single instance is a single point of failure."*

#### Acceptance criteria

- [ ] Capacity is first and visually dominant.
- [ ] Bounds match `baseComponentConfigSchema` exactly.
- [ ] `errorRate` round-trips `0.07 → 7% → 0.07` with no drift.
- [ ] Out-of-range shows inline error, no clamp.
- [ ] Help text reachable by keyboard and screen reader.
- [ ] Edit → save → reload preserves all values.

---

### T-09 — Stabilise toolbar layout 🔧 OPEN

**Resolves:** H3. Note the toolbar has **grown** since first review (Traffic + Faults selects added), worsening reflow.

- `Findings (N)` changes width as the count changes, shifting every sibling horizontally — a moving-target hit area mid-interaction. Reserve a fixed slot: `min-width` + `font-variant-numeric: tabular-nums`.
- `.toolbar` uses `flex-wrap: wrap` (`global.css:~110`) and now wraps to 2–3 rows. Group into segments — **File · Edit · Run · Inspect** — with separators, and collapse `Export JSON` + `Export PNG` into one `Export ▾`.
- Keep exactly one `.primary-action`.

**Acceptance:** findings count 0→1→10 shifts no sibling; single row at ≥1280px; all actions keyboard reachable.

---

### T-10 — Fix overlay layering 🔧 OPEN

**Resolves:** H4, H5

Verified collisions: the toast stack overlaps the `30.2s / 30.2s` playback readout and completely covers the minimap; findings never auto-dismiss, permanently occluding the bottom-right quadrant.

1. Apply the z-index scale from T-12 — no ad-hoc values.
2. Reserve bottom-right exclusively for the minimap; dock toasts **above** the playback bar.
3. Auto-dismiss `info`/`warning` at 8s; `critical` persists (align with T-04 timings).
4. The Findings tab is the permanent record, so toasts can safely become transient.
5. Give the minimap a visible border + raised background — it is currently dark-on-dark and effectively invisible (M6).

**Acceptance:** with 3 toasts visible, playback readout and minimap remain fully visible; non-critical toasts auto-dismiss; dismissed findings still listed in the Findings tab.

---

### T-11 — Explain jargon in place 🔧 OPEN

**Resolves:** M5, M8

- **Seed / Duration** are bare numeric inputs. Determinism is a *feature worth teaching*: add `aria-describedby` help — *"Same seed + same architecture = identical results. Change it to sample different random variation."*
- **Tier badges** (`conceptual` / `behavioral` / `advanced`) are rendered in the lowest-contrast text on each palette card, yet answer the learner's most important question — *does this node actually simulate?* Raise to WCAG AA and add a legend: **conceptual** = documentation only, no runtime behaviour · **behavioral** = fully simulated · **advanced** = simulated, assumes prior concepts.

---

### T-12 — Extend design tokens beyond colour 🔧 OPEN

**Resolves:** M9 · root cause of T-09 and T-10

`global.css:1-16` defines 13 colour tokens and a focus ring — **no** spacing, radius, type, elevation, z-index, or motion scale. Hence hardcoded `6px`/`8px`/`12px`/`16px` padding, ad-hoc `z-index: 20` (`.scenario-brief details ul`), and one-off shadows.

```css
:root {
  /* Spacing */
  --space-1: 4px;  --space-2: 8px;  --space-3: 12px;
  --space-4: 16px; --space-5: 24px; --space-6: 32px;

  /* Radius */
  --radius-sm: 4px; --radius-md: 6px; --radius-lg: 10px;

  /* Type scale */
  --text-xs: 11px; --text-sm: 12px; --text-md: 13px;
  --text-lg: 15px; --text-xl: 18px;

  /* Elevation */
  --shadow-1: 0 1px 2px rgb(0 0 0 / 0.30);
  --shadow-2: 0 4px 12px rgb(0 0 0 / 0.40);
  --shadow-3: 0 12px 32px rgb(0 0 0 / 0.50);

  /* Layering — resolves T-10 */
  --z-canvas: 0; --z-panel: 10; --z-context-menu: 20;
  --z-toast: 30; --z-modal: 40;

  /* Motion */
  --motion-fast: 120ms; --motion-base: 200ms;
  --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
}

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

Migrate hardcoded values **only within files already touched by other tasks**. Do not attempt a repo-wide restyle in one pass — the diff would be unreviewable.

**Acceptance:** tokens consumed by all new components; every overlay z-index token-derived; `prefers-reduced-motion` disables flow animation; no visual regression.

---

### T-13 — Onboarding and shortcut discovery ✅ DELIVERED

**Resolves:** M10

The first-run welcome flow gives learners a guided scenario, scenario browsing, or blank-canvas
route and explicitly describes model limits. A keyboard shortcut reference is available via **?**
or **F1** and is rendered from a shared shortcut definition. It covers save, undo/redo, metrics,
node configuration/deletion, context menus, and its own discovery keys. The Help tooltip points to
the shortcut reference without adding another toolbar action.

---

### T-14 — Test coverage for newly-landed UI 🔧 OPEN

**Critical process gap.** `ContextPanel`, `ScenarioBrief`, `ValidationSummary`, and the traffic/fault selectors shipped with **zero tests** — which is precisely why D-1 through D-8 went undetected. Test count is unchanged at 163.

#### `tests/unit/contextPanel.test.tsx`

```ts
// 1. peak vs last: componentMetrics [0.9 then 0.1] → renders 90%   (D-1)
// 2. renders config.displayName, never raw nodeId                  (D-2)
// 3. selecting a node while on "metrics" does NOT switch tab       (D-3)
// 4. selecting a node while collapsed does NOT auto-open           (D-3)
// 5. stale result renders the stale badge                          (D-8)
// 6. no lastResult → empty state, no throw
```

#### `tests/unit/simulationControls.test.tsx`

```ts
// 1. two default faults → BOTH armed                               (D-6)
// 2. traffic profile change → new id passed to worker (mock client)
// 3. same seed + same faults → identical summary                   (I-2)
```

#### `tests/unit/scenarioBrief.test.tsx`

```ts
// 1. no activeScenarioId → renders null
// 2. objectives NOT duplicated between brief and panel              (D-4)
```

---

## 5. Codebase reference appendix

### 5.1 Store map

| Store | Owns | Never put here |
|---|---|---|
| `projectStore` | `document`, `isDirty`, `filePath`, selection, `validationIssues`, `lastResult`, `lastResultSignature`, `past`/`future` undo stacks | View state — it dirties projects and pollutes undo (**I-3**) |
| `uiStore` | `configNodeId`, `configTab`, `contextMenu`, modal flags, `contextPanelOpen/Tab`, `activeScenarioId`, `flowAnimationEnabled` | Anything persisted to disk |
| `playbackStore` | `status`, `speed`, `currentLogicalTimeMs`, `timeline`, `logicalPerWallMs` | Anything a chart writes back (**I-2**) |
| `requestStore` | Manual request `batches`, `suppressProfileTraffic` | — |
| `toastStore` | Finding toasts + `history`, notification centre flag | — |

### 5.2 Undo semantics

`projectStore` snapshots **only `nodes` and `edges`** via `structuredClone`:

```ts
function snapshot(document: ProjectDocument): HistoryEntry {
  return { nodes: structuredClone(document.nodes), edges: structuredClone(document.edges) };
}
```

Changes to `trafficProfiles` or `faultScenarios` are **not** undoable. Do not add UI implying otherwise without extending `HistoryEntry`.

### 5.3 Node ID format

```ts
`${type}-${nodeCounter}-${Date.now().toString(36)}`   // e.g. "server-4-lx8s2f"
```
Never surface to users (**D-2**). Always resolve via `config.displayName`.

### 5.4 Existing colour tokens

`--color-bg #14171c` · `--color-panel #1c2027` · `--color-panel-alt #242933` · `--color-border #333a46` · `--color-text #e7eaf0` · `--color-text-dim #9aa4b2` · `--color-accent #4d8dff` · `--color-healthy #37c26b` · `--color-warning #e0a92c` · `--color-degraded #e0742c` · `--color-failed #e14b4b` · `--color-info #4d8dff` · `--focus-ring 2px solid #7db3ff`

### 5.5 Reusable helpers — import, do not reimplement

| Helper | Location | Purpose |
|---|---|---|
| `rollupByNode()` | `MetricsModal.tsx:248` | Correct peak aggregation. **Extract and share** (D-1). |
| `nameById` pattern | `MetricsModal.tsx:56` | nodeId → displayName (D-2) |
| `resultFreshness()` | `domain/architecture/projectAnalysis` | Staleness detection (D-8) |
| `hasBlockingErrors()` | `domain/validation/graphValidation` | Run gating |
| `getScenarioTemplate()` | `domain/scenarios/registry` | Scenario re-resolution by id |
| `playbackDurationMs()` | `domain/flow/playbackFrame` | Timeline duration |
| `findingsToToasts()` | `stores/toastStore` | Finding → toast mapping |

### 5.6 Grid layout (current, verified)

```css
.app-shell   { display: grid; grid-template-rows: auto auto minmax(0,1fr) auto auto; height: 100vh; }
.main-layout { display: grid; grid-template-columns: 240px minmax(0,1fr) 360px;
               min-height: 0; overflow: hidden; }
```

> `min-height: 0` and `minmax(0, 1fr)` are **load-bearing**. Removing either makes React Flow grow unbounded inside the grid track. This is the most likely way to break the canvas.

---

## 6. Execution order

```
D-1 D-2 D-3 D-8 ──► T-14 (tests lock the fixes)
      │
D-4 D-5 D-6 D-7 ──┤
      │
T-04 T-09 T-10 ───┼──► T-12   (tokens formalise the layering fixes)
      │
      └──► T-05 ──► T-06      (comparison builds on the metrics surface)
      │
      ├──► T-07
      ├──► T-08
      └──► T-11 ──► T-13      (T-13 last; references final shortcut set)
```

| Batch | Tasks | Rationale |
|---|---|---|
| **A — Stabilise** | D-1, D-2, D-3, D-8, T-14 | Correctness defects in code that T-05/T-06 build on. Ship tests with the fixes so they cannot regress. |
| **B — Finish landed work** | D-4, D-5, D-6, D-7 | Completes half-done features; low risk, no new surface area. |
| **C — Hygiene** | T-04, T-09, T-10, T-12 | Independent, no structural change; establishes tokens later work needs. |
| **D — Measurement** | T-05, T-06, T-07 | The full change → measure → compare loop. |
| **E — Depth** | T-08, T-11, T-13 | Parameter literacy and discoverability. |

Run the Section 0.4 gate after **every task**, not per batch.

---

## 7. Regression checklist

Run after each batch. These break silently.

- [ ] All 16 scenario templates open without throwing and render nodes.
- [ ] Run → playback → scrub forward/backward → skip to end; playback never mutates results (**I-2**).
- [ ] **Determinism:** same seed + same traffic profile + same faults ⇒ byte-identical `summary` across two runs.
- [ ] Save → reload → open round-trips with no Zod error.
- [ ] Autosave recovery banner still appears after a simulated crash.
- [ ] Undo/redo across node add, move, delete, and config edit.
- [ ] Export PNG and Export JSON both succeed.
- [ ] `npm run build:electron` compiles.
- [ ] **No console errors or React Flow warnings** on a cold load (**D-7**).
- [ ] Keyboard-only path: add node → configure → run → read findings.
- [ ] Test count ≥163 and rising.

---

## 8. Explicit non-goals

1. **Do not change simulation semantics.** No task may alter a computed result. If a UI change appears to require one, stop and flag it.
2. **Do not migrate `ProjectDocument`** without a migration + round-trip test (**I-4**).
3. **Do not add a component library** (MUI, Chakra, shadcn). The app is hand-rolled CSS; a framework mid-remediation would dwarf the fixes.
4. **Do not add a state library.** Zustand is sufficient.
5. **Do not add a charting library.** `recharts` is already installed and unused.
6. **Do not redesign the icon set or node visual identity.**
7. **Do not convert to a light theme.** Dark is deliberate for this tool class.
8. **Do not weaken the assumptions/limitations disclosure.** It is an honesty guarantee and a differentiator — keep it prominent.
9. **Do not refactor `simulation-engine/` for "consistency."** Out of scope.

---

## 9. Bottom line

The engine, domain model, and curriculum are excellent. The original review found them wrapped in an interface that hid results behind dialogs, discarded the lesson on load, and gave the learner no way to act on an error.

**Most of that structural criticism has now been addressed** — validation is visible and clickable, the canvas frames itself, the context panel docks insight beside the topology, scenario objectives survive the gallery, and traffic/fault selection is exposed.

**The risk has shifted from missing features to unverified ones.** Four surfaces shipped with zero tests, and that gap already produced a silent correctness bug: the context panel reports last-sample utilisation under the heading *"Component peaks"*, so a node that saturates to 98% mid-run and drains to 3% is reported as **3%** — teaching the precise opposite of the intended lesson, while `MetricsModal` reports the true peak for the same run.

**Fix Batch A before building anything further.** T-05 and T-06 — the time series the engine already records but the UI throws away, and the before/after that proves a design decision worked — are the remaining high-order bits, and both sit directly on top of the code that needs correcting first.
