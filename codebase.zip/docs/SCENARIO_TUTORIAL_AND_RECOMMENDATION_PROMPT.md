# Scenario, Tutorial, and Technology Recommendation Prompt

> **Implementation status (2026-09):** This document remains the detailed product-design
> prompt and future-scope reference. The delivered implementation includes the 16-scenario
> library; Guided Tour, Build, and Challenge starting states; deterministic request exercises
> and paired fault teaching metadata; local-only in-canvas tutorials with hints and confirmed
> reference access; and deterministic contextual technology recommendations. It deliberately
> does **not** yet implement the prompt's full estimation workflow, automatic property-based
> build/challenge assessment, complete design comparison, or advanced runtime semantics that the
> engine cannot precisely model. See [scenarios/README.md](./scenarios/README.md),
> [TECHNOLOGY_CATALOG.md](./TECHNOLOGY_CATALOG.md), and
> [REMAINING_GAPS.md](./REMAINING_GAPS.md) for current behavior and limits.

```text
Generate the complete scenario library for the System Design Simulator, organized by difficulty tier. For every scenario, produce the runnable project template, a full set of executable request definitions, a full set of fault scenarios for resilience testing, and a guided interactive tutorial. Additionally, implement a context-aware technology recommendation system that suggests appropriate real-world technologies whenever a user places or selects a component.

All work must conform to the existing offline-first Electron architecture, the deterministic discrete-event simulation engine, the versioned project schema, the provider-neutral component model, and the accessibility requirements already defined in `PRD.md`, `TRD.md`, `SIMULATION_SPEC.md`, `COMPONENT_CATALOG.md`, and `ACCEPTANCE_CRITERIA.md`.

Nothing in this work may provision real infrastructure, require cloud credentials, perform outbound network calls, or present simulated output as a production guarantee.

---

## 1. Scenario Generation by Difficulty Tier

Generate scenarios grouped into four progressive difficulty tiers. Each tier must build on the concepts introduced by the previous tier and must be independently completable.

### Tier Definitions

| Tier | Learning Focus | Required Concepts | Target Node Count |
|---|---|---|---:|
| `beginner` | Fundamental request flow and single-path architecture | Routing, capacity, latency, single points of failure, basic outages | 3–6 |
| `intermediate` | Decomposition, caching, and asynchronous processing | Caching, queues, workers, replicas, retries, rate limiting, autoscaling, observability | 6–12 |
| `advanced` | Distributed-systems behavior at scale | Multi-region routing, replication lag, consistency trade-offs, failover, backpressure, cascading failure, circuit breaking | 12–25 |
| `specialized` | Domain-specific architecture patterns | Payments, real-time systems, media delivery, search, analytics pipelines, machine-learning inference, multi-tenancy | 10–30 |

### Per-Tier Requirements

Each tier must define:

- A minimum scenario count.
- An ordered learning progression.
- Explicit prerequisite scenarios.
- Concepts introduced for the first time in that tier.
- Concepts reinforced from prior tiers.
- A tier completion objective.

A scenario may not depend on a component type, fault type, metric, or simulation behavior that has not yet been implemented in the engine. If a scenario requires unimplemented behavior, mark it as `blocked` with an explicit dependency list rather than generating an unrunnable template.

---

## 2. Scenario Template Requirements

For every scenario, produce a schema-valid project template that opens directly in the simulator without user repair.

### Template Contents

Every scenario must produce **two distinct graph artifacts**, not one. This separation is mandatory: it is what allows a user to design the architecture themselves rather than merely inspect a finished answer.

#### 2.1 Reference Solution Graph

The canonical, fully-built architecture. It is used for validation, comparison, `Guided Tour` mode, and as the baseline against which request and fault expectations are calibrated. It must contain:

- A complete node graph with stable node identifiers.
- Readable, non-overlapping node positions and deterministic layout.
- Correctly typed edges: `request`, `event`, `replication`, `failover`, and `observability`.
- Baseline configuration for every node, including capacity, latency, timeout, error rate, overflow behavior, and scaling settings.
- Default technology implementation assignments, or explicit `Generic / Custom Implementation` where a neutral component is pedagogically preferable.
- One or more default traffic profiles.
- A default manual request set.
- A default fault scenario set.
- Validation state that passes pre-simulation graph validation.

The reference solution is **one valid answer, not the only valid answer**. It must never be presented to the user as uniquely correct.

#### 2.2 Starting State Graph

The canvas the user actually begins from in `Build` and `Challenge` modes. Each scenario must define a `startingState` of one of the following kinds:

| Kind | Contents | Typical Use |
|---|---|---|
| `empty` | No nodes or edges | `Challenge` mode; advanced `Build` mode |
| `origin-only` | Client and request-origin nodes only | Beginner `Build` mode |
| `partial` | A documented subset of nodes, with explicit gaps the user must fill | Intermediate and advanced `Build` mode |
| `complete` | Identical to the reference solution | `Guided Tour` mode only |

A `partial` starting state must declare exactly which components and connections are intentionally omitted, and why omitting them is pedagogically meaningful. Do not omit components arbitrarily.

```ts
interface ScenarioStartingState {
  kind: "empty" | "origin-only" | "partial" | "complete";
  nodes: ArchitectureNode[];
  edges: ArchitectureEdge[];
  omittedComponentTypes: ComponentType[];
  omittedCapabilities: string[];
  rationale: string;
}
```

#### 2.3 Divergence Policy

A user-built graph that differs from the reference solution must be treated as potentially correct. Validation is performed against architectural properties and measured simulation outcomes, never against graph isomorphism with the reference solution. See Section 5.6.

### Template Metadata

Extend the existing metadata contract:

```ts
interface ScenarioTemplateMetadata {
  id: string;
  version: string;
  name: string;
  summary: string;
  difficulty: "beginner" | "intermediate" | "advanced" | "specialized";
  domain: string;
  tags: string[];
  learningObjectives: string[];
  conceptsIntroduced: string[];
  conceptsReinforced: string[];
  prerequisiteScenarioIds: string[];
  estimatedCompletionMinutes: number;
  workloadProfile: WorkloadCharacteristic[];
  requirementsBriefId: string;
  supportedTutorialModes: TutorialMode[];
  defaultTutorialMode: TutorialMode;
  startingState: ScenarioStartingState;
  designConstraintIds: string[];
  requestDefinitionIds: string[];
  faultScenarioIds: string[];
  tutorialId: string;
  documentationPath: string;
  engineCapabilitiesRequired: EngineCapability[];
  status: "ready" | "blocked" | "draft";
}

type TutorialMode = "guided-tour" | "build" | "challenge";

type WorkloadCharacteristic =
  | "read-heavy"
  | "write-heavy"
  | "latency-sensitive"
  | "throughput-sensitive"
  | "consistency-sensitive"
  | "availability-sensitive"
  | "bursty"
  | "long-running";
```

---

## 3. Request Definition Generation

For each scenario, generate a curated set of executable request definitions that a user can dispatch through the request composer. These are logical simulated requests processed by the deterministic engine; they must never produce real HTTP traffic.

### Required Request Coverage

Every scenario must define, at minimum:

1. **Baseline request** — nominal traffic representing normal operation.
2. **Read-path request** — exercises cache, replica, or read-optimized routes where present.
3. **Write-path request** — exercises primary datastore, queue producers, or transactional paths where present.
4. **Burst request** — a high-volume batch intended to reveal saturation.
5. **Sustained-load request** — a longer dispatch designed to reveal queue growth, replica lag, or autoscaling behavior.
6. **Boundary request** — a batch calibrated to approach a known capacity limit without exceeding it.
7. **Overload request** — a batch calibrated to exceed a known capacity limit and produce observable failure.

### Request Definition Contract

```ts
interface ScenarioRequestDefinition {
  id: string;
  scenarioId: string;
  name: string;
  description: string;
  intent: RequestIntent;
  sourceNodeId: string;
  method: HttpMethod;
  path?: string;
  requestClass: "read" | "write" | "auth" | "session-affine" | "custom";
  requestCount: number;
  dispatchRateRps: number;
  payloadSizeBytes?: number;
  responseSizeBytes?: number;
  timeoutMs?: number;
  seed: number;
  expectedOutcome: ExpectedOutcome;
  teachingNote: string;
}

type RequestIntent =
  | "baseline"
  | "read-path"
  | "write-path"
  | "burst"
  | "sustained"
  | "boundary"
  | "overload"
  | "diagnostic";

interface ExpectedOutcome {
  expectSuccess: boolean;
  expectedFailureModes: string[];
  expectedBottleneckNodeIds: string[];
  expectedFindingCategories: FindingCategory[];
  notes: string;
}
```

### Calibration Requirements

- Derive request volumes from the scenario’s configured component capacities so that boundary and overload requests produce reliable, reproducible results.
- Every request definition must specify a fixed seed to guarantee determinism.
- The `expectedOutcome` must be verified by executing the request against the template and recording actual engine output; do not assert outcomes that the engine does not produce.
- Do not define request volumes that exceed documented rendering or engine safeguards.

---

## 4. Fault Scenario Generation

For each scenario, generate a set of fault scenarios that exercise the architecture’s resilience characteristics and produce instructive failure behavior.

### Required Fault Coverage by Tier

| Tier | Minimum Required Fault Types |
|---|---|
| `beginner` | Single-node outage, traffic spike |
| `intermediate` | Node outage, latency degradation, error-rate increase, cache outage, queue-consumer outage, capacity reduction |
| `advanced` | Primary-database failure, replica lag increase, network edge failure, regional outage, dependency timeout, cascading dependency failure, circuit-breaker activation |
| `specialized` | Domain-appropriate faults such as payment-provider failure, transcoding-worker exhaustion, search-index lag, stream-partition backlog, tenant resource exhaustion |

### Fault Definition Contract

```ts
interface ScenarioFaultDefinition {
  id: string;
  scenarioId: string;
  name: string;
  description: string;
  targetNodeIds: string[];
  targetEdgeIds: string[];
  faultType: FaultType;
  startsAtMs: number;
  durationMs?: number;
  configuration: FaultConfiguration;
  pairedRequestDefinitionId?: string;
  expectedImpact: FaultExpectedImpact;
  teachingNote: string;
  remediationHint: string;
}

interface FaultExpectedImpact {
  expectedErrorRateIncrease: boolean;
  expectedLatencyIncrease: boolean;
  expectedQueueGrowth: boolean;
  expectedFailoverActivation: boolean;
  expectedCascade: boolean;
  affectedDownstreamNodeIds: string[];
  expectedRecoveryBehavior: string;
}
```

### Fault Design Rules

- Each fault must be paired with at least one request definition so its impact is observable rather than theoretical.
- Fault timing must fall within the dispatch window of its paired request.
- Composite faults must follow the precedence and composition rules defined in `SIMULATION_SPEC.md`.
- Each fault must include a `remediationHint` describing the architectural change that would mitigate it, expressed as a trade-off rather than a prescriptive answer.
- Faults must never mutate persisted template configuration.

---

## 5. Interactive Tutorial Generation

For every scenario, generate a guided, step-based interactive tutorial that runs inside the application.

The governing requirement is this: **a user must be able to construct the architecture themselves by following the tutorial, not merely observe a pre-built one.** A tutorial that only narrates a finished graph teaches the tool, not system design, and does not satisfy this specification.

### 5.1 Tutorial Modes

Every scenario must support one or more of three modes. Mode determines the starting canvas, the degree of instruction, and the validation strategy.

| Mode | Starting State | Instruction Level | User Responsibility | Validation |
|---|---|---|---|---|
| `guided-tour` | `complete` | Explicit, step-by-step | Observe, configure values, run simulations, interpret results | Action completion |
| `build` | `empty`, `origin-only`, or `partial` | Goal-directed with progressive hints | Derive requirements, estimate capacity, place and connect components, configure, validate | Property-based |
| `challenge` | `empty` | Requirements brief only | Complete independent design against measurable targets | Outcome-based |

#### Mode Assignment Rules

- `guided-tour` is permitted as the default mode for **at most one scenario per difficulty tier** — the tier's onboarding scenario. It exists to teach the interface, not the discipline.
- Every other scenario must default to `build`.
- Every scenario must additionally support `challenge` mode unless it is `blocked`.
- A user may switch modes for a scenario at any time. Switching resets the canvas to that mode's starting state after explicit confirmation.

### 5.2 Requirements Brief

Every scenario must define a requirements brief containing concrete, quantified inputs. In `build` and `challenge` modes the brief is the **only** information the user receives before designing. The architecture must be derivable from it.

```ts
interface RequirementsBrief {
  id: string;
  scenarioId: string;
  problemStatement: string;
  functionalRequirements: string[];
  nonFunctionalRequirements: NonFunctionalRequirement[];
  scaleParameters: ScaleParameter[];
  constraints: string[];
  outOfScope: string[];
}

interface NonFunctionalRequirement {
  id: string;
  category: "latency" | "availability" | "throughput" | "consistency" | "durability" | "cost";
  statement: string;
  measurable: boolean;
  targetMetric?: string;
  targetValue?: number;
  comparator?: "lte" | "gte" | "eq";
}

interface ScaleParameter {
  name: string;
  value: number;
  unit: string;
  note?: string;
}
```

A brief must supply enough numeric input for the user to perform capacity estimation. Example:

```text
Daily active users: 10,000,000
Average requests per user per day: 20
Read-to-write ratio: 100:1
Average request payload: 2 KB
Average stored record size: 500 bytes
Retention period: 5 years
Peak-to-average traffic ratio: 3x

Target p95 latency: under 200 ms
Target availability: 99.9%
Must tolerate: loss of one database node
```

Briefs must state explicitly what is out of scope so the user does not over-design.

### 5.3 Tutorial Phases

Each tutorial progresses through the phases below. Phases marked **required in build mode** must not be skipped or pre-answered when the mode is `build` or `challenge`.

| # | Phase | Purpose | Required in Build Mode |
|---:|---|---|:---:|
| 1 | `introduction` | Present the requirements brief and learning objectives | Yes |
| 2 | `estimation` | User computes QPS, storage, bandwidth, and cache sizing | Yes |
| 3 | `component-selection` | User decides which component types the requirements demand | Yes |
| 4 | `topology-construction` | User places nodes and creates typed connections | Yes |
| 5 | `configuration` | User sets capacity, latency, timeout, retry, and scaling values | Yes |
| 6 | `technology-selection` | User assigns implementation technologies with stated rationale | Yes |
| 7 | `baseline-validation` | Dispatch the baseline request and confirm nominal behavior | Yes |
| 8 | `load-exploration` | Dispatch boundary and overload requests to locate the bottleneck | Yes |
| 9 | `diagnosis` | User identifies the bottleneck and root cause from metrics, before any fix is revealed | Yes |
| 10 | `remediation` | User applies an architectural change and re-validates | Yes |
| 11 | `fault-injection` | Run fault scenarios and analyze propagation and recovery | Yes |
| 12 | `assessment` | Evaluate the design against measurable completion criteria | Yes |
| 13 | `comparison` | Contrast the user's design with the reference solution and other valid approaches | Yes |
| 14 | `extension` | Optional advanced exercises | No |

In `guided-tour` mode, phases 2 through 6 may be reduced to explanation and value-entry. In `build` and `challenge` modes they must require genuine user decisions.

### 5.4 Estimation Phase

The estimation phase is mandatory and must not be reducible to clicking through. Back-of-envelope calculation is the central skill of system design and must be exercised before any component is placed.

Each estimation step must:

- Present the relevant scale parameters from the requirements brief.
- Ask the user to compute a specific derived quantity.
- Accept a numeric answer within a documented tolerance band rather than a single exact value.
- Show the worked derivation after the user submits, regardless of correctness.
- Carry the accepted value forward as the basis for subsequent capacity configuration.

```ts
interface EstimationStep {
  id: string;
  prompt: string;
  derivedQuantity: string;
  unit: string;
  inputParameterNames: string[];
  expectedValue: number;
  tolerancePercent: number;
  workedDerivation: string;
  commonMistakes: string[];
  feedsIntoNodeIds: string[];
  feedsIntoConfigurationField: string;
}
```

Required estimations vary by scenario but must include, where applicable: average QPS, peak QPS, storage volume at retention limit, daily write volume, read throughput, cache working-set size, and required instance count at a stated per-instance capacity.

Do not accept an estimate the engine will immediately contradict. If a user's accepted estimate would make the scenario unsatisfiable, surface that as a teaching moment during `baseline-validation` rather than blocking entry.

### 5.5 Decision Points

`build` and `challenge` tutorials must include explicit decision points where more than one answer is architecturally defensible. A tutorial consisting entirely of single-answer instructions does not satisfy this specification.

```ts
interface DesignDecisionPoint {
  id: string;
  phase: TutorialPhase;
  question: string;
  context: string;
  options: DesignOption[];
  allowUserDefinedOption: boolean;
  revealComparisonAfterSimulation: boolean;
}

interface DesignOption {
  id: string;
  label: string;
  description: string;
  validity: "recommended" | "acceptable" | "suboptimal" | "incorrect";
  graphMutation: GraphMutationSpec;
  strengths: string[];
  tradeOffs: string[];
  simulatedConsequence: string;
  failsConstraintIds: string[];
}
```

Requirements:

- Each decision point must offer at least one `recommended` and one `acceptable` option so the user experiences a genuine trade-off rather than a disguised single answer.
- Options marked `suboptimal` or `incorrect` must remain selectable. The user must be permitted to proceed and observe the consequence in simulation.
- Consequences must be **demonstrated by the engine**, not merely asserted in prose. Each option's `simulatedConsequence` must be reproducible by running the scenario's request definitions against the resulting graph.
- After simulation, reveal a comparison of what each option would have produced.

Representative decision points:

| Scenario Context | Decision |
|---|---|
| Read-heavy load exceeding database capacity | Add cache, add read replica, or both |
| Slow downstream dependency in request path | Increase timeout, add circuit breaker, or make the call asynchronous |
| Write spikes exceeding datastore throughput | Introduce a queue, shard the datastore, or apply backpressure |
| Single-region deployment with availability target | Add a standby region, add zone redundancy, or accept the risk |
| Stale reads after replica introduction | Route reads to primary, accept eventual consistency, or use read-your-writes routing |

### 5.6 Property-Based Validation

Validation must confirm that the user's design satisfies architectural properties and measurable outcomes. It must never require structural equality with the reference solution.

```ts
interface DesignConstraint {
  id: string;
  scenarioId: string;
  category: "structural" | "configuration" | "measured" | "anti-pattern";
  description: string;
  severity: "required" | "recommended" | "advisory";
  predicate: ConstraintPredicate;
  satisfiedMessage: string;
  violatedMessage: string;
  remediationHint: string;
}

type ConstraintPredicate =
  | { kind: "path-exists"; fromType: ComponentType; toType: ComponentType; edgeKind: ConnectionKind }
  | { kind: "component-present"; componentType: ComponentType; minCount: number }
  | { kind: "component-on-path"; componentType: ComponentType; fromType: ComponentType; toType: ComponentType }
  | { kind: "no-single-point-of-failure"; scope: "global" | "critical-path" }
  | { kind: "no-orphan-nodes" }
  | { kind: "queue-has-consumer" }
  | { kind: "queue-has-dead-letter" }
  | { kind: "retry-is-bounded" }
  | { kind: "metric-threshold"; metric: string; comparator: "lte" | "gte"; value: number }
  | { kind: "survives-fault"; faultScenarioId: string; maxErrorRate: number }
  | { kind: "custom"; predicateId: string };
```

Validation rules:

- `structural` constraints check topology properties, such as "a cache exists on the read path between the application service and the database."
- `configuration` constraints check that settings are coherent, such as "every retry policy declares a maximum attempt count."
- `measured` constraints are evaluated only after a simulation run, against actual engine output.
- `anti-pattern` constraints detect designs that are technically valid but pedagogically harmful, such as unbounded retries or a queue with no consumer.
- A design satisfying all `required` constraints is **correct**, even if it differs substantially from the reference solution.
- Unsatisfied `recommended` constraints produce guidance, not failure.
- Never emit a message implying the user's design is wrong solely because it diverges from the reference graph.

### 5.7 Diagnosis Before Remediation

The `diagnosis` phase must precede `remediation` and must not reveal the answer.

Required behavior:

1. Run the overload or fault request and present the resulting metrics.
2. Ask the user to identify the bottleneck component, the failure mode, and the causal chain.
3. Accept the answer through structured selection — for example, selecting the node on the canvas and choosing a failure category.
4. Evaluate the answer against engine-observed evidence: utilization, queue depth, latency attribution, and error origin.
5. If incorrect, provide a progressive hint pointing toward the relevant metric rather than naming the component.
6. Only after a correct diagnosis, or after the user explicitly requests the answer, proceed to remediation.

```ts
interface DiagnosisChallenge {
  id: string;
  prompt: string;
  correctBottleneckNodeIds: string[];
  correctFailureMode: string;
  correctCausalChain: string[];
  acceptableAlternativeAnswers: string[];
  evidenceMetrics: string[];
  progressiveHints: string[];
  explanation: string;
}
```

Remediation must then be expressed as a decision point per Section 5.5, not as a single prescribed fix.

### 5.8 Tutorial Step Contract

```ts
interface TutorialStep {
  id: string;
  order: number;
  phase: TutorialPhase;
  mode: TutorialMode[];
  title: string;
  instruction: string;
  explanation: string;
  targetSelector?: CanvasTarget;
  requiredAction: TutorialAction;
  validation: TutorialValidation;
  estimationStep?: EstimationStep;
  decisionPoint?: DesignDecisionPoint;
  diagnosisChallenge?: DiagnosisChallenge;
  hints: string[];
  hintRevealAfterAttempts: number;
  allowSkip: boolean;
  successMessage: string;
}

type TutorialAction =
  | "add-node"
  | "connect-nodes"
  | "configure-node"
  | "assign-technology"
  | "estimate-capacity"
  | "select-components"
  | "make-design-decision"
  | "diagnose-bottleneck"
  | "create-request"
  | "dispatch-request"
  | "inject-fault"
  | "open-metrics"
  | "review-finding"
  | "compare-designs"
  | "observe"
  | "acknowledge";

interface TutorialValidation {
  mode: "constraint-based" | "estimation-tolerance" | "decision-recorded" | "diagnosis-match" | "action-completed" | "manual-acknowledge";
  constraintIds?: string[];
  predicateId?: string;
  failureMessage?: string;
  allowProceedOnFailure: boolean;
}
```

The same step may declare different `instruction` and `validation` behavior per mode. A step present in `guided-tour` may be absent in `challenge`.

### 5.9 Tutorial Behavior Requirements

- Highlight the relevant canvas node, edge, toolbar control, or modal field for each step.
- Validate completion programmatically where a deterministic predicate exists; otherwise require explicit acknowledgment.
- Permit free exploration without breaking tutorial state. A user who adds an unrequested component must not be blocked or silently corrected.
- Support pause, resume, restart, step navigation, mode switching, and exit.
- Persist tutorial progress, recorded decisions, and estimation answers as local user state, never as project data.
- Reveal hints progressively after `hintRevealAfterAttempts` failed attempts. Hints must escalate from pointing at evidence, to naming the affected subsystem, to stating the answer.
- Never auto-modify the user's architecture without an explicit confirmed action. Applying a `DesignOption` requires confirmation and must list every graph mutation it performs.
- Provide an explicit "show me the answer" affordance so a stuck user is never trapped.
- Meet all existing accessibility requirements: keyboard navigation, focus management, screen-reader announcements, and reduced-motion compliance.

### 5.10 Configuration Guidance

Each tutorial must explicitly teach the configuration values it sets, including:

- Instance count and per-instance capacity.
- Base latency and jitter.
- Timeout and deadline behavior.
- Retry policy, backoff, and retry budget.
- Overflow behavior: queue, reject, shed, or degrade.
- Cache TTL, hit ratio, and eviction policy where applicable.
- Queue throughput, retention, consumer concurrency, and dead-letter policy where applicable.
- Replication lag and consistency assumptions where applicable.
- Autoscaling thresholds, cooldown, and provisioning delay where applicable.

For every configured value, state why the value was chosen, how it derives from the estimation phase where applicable, and what changes if it is increased or decreased.

In `build` mode, capacity values must trace back to the user's own accepted estimates rather than being supplied as constants.

### 5.11 Design Comparison

The `comparison` phase must:

- Present the user's final graph alongside the reference solution.
- Identify structural differences without characterizing divergence as error.
- Report both designs' measured outcomes under the same request definitions and seed.
- Enumerate the trade-offs each design accepted.
- Where the user's design outperforms the reference solution on a given metric, state so explicitly.
- Record which `DesignOption` selections led to the observed differences.

---

## 6. Context-Aware Technology Recommendation Engine

Implement a recommendation system that suggests suitable technologies whenever a user adds or selects a component.

### Trigger Points

Recommendations must surface when:

- A component is dropped onto the canvas.
- A node is selected and the **Implementation** tab is opened.
- A node currently uses `Generic / Custom Implementation`.
- A tutorial reaches a technology-selection step.
- A user explicitly requests suggestions for a node.

### Recommendation Contract

```ts
interface TechnologyRecommendation {
  technologyId: string;
  displayName: string;
  provider: string;
  matchScore: number;
  rank: number;
  rationale: string;
  strengths: string[];
  tradeOffs: string[];
  typicalUseCases: string[];
  deploymentModel: DeploymentModel[];
  hasSimulationPreset: boolean;
  warnings: string[];
}

interface RecommendationContext {
  componentType: ComponentType;
  nodeConfiguration: ComponentConfiguration;
  workloadCharacteristics: WorkloadCharacteristic[];
  connectedNodeTypes: ComponentType[];
  scenarioDomain?: string;
  scenarioDifficulty?: DifficultyTier;
  existingTechnologyAssignments: string[];
  userPreferences: {
    preferOpenSource: boolean;
    preferManagedServices: boolean;
    preferredProviders: string[];
  };
}
```

### Ranking Signals

Rank recommendations using deterministic, explainable signals:

1. **Component-type compatibility** — the technology must validly represent the component role.
2. **Workload fit** — alignment with read-heavy, write-heavy, latency-sensitive, or throughput-sensitive characteristics.
3. **Topology coherence** — consistency with technologies already assigned to connected nodes.
4. **Scenario domain relevance** — suitability for the scenario’s problem domain.
5. **Difficulty appropriateness** — favor widely understood technologies at lower tiers and specialized technologies at higher tiers.
6. **Deployment-model preference** — respect user preferences for open-source or managed services.
7. **Preset availability** — favor technologies with a maintained simulation preset when the user is following a tutorial.

Ranking must be deterministic for identical context inputs. Do not use randomized ordering.

### Presentation Requirements

- Display a bounded ranked list, typically three to seven entries.
- Show the technology logo, display name, provider, and deployment model.
- Show a one-line rationale for each recommendation.
- Show trade-offs alongside strengths; never present a single technology as universally correct.
- Always expose the full catalog and the `Generic / Custom Implementation` option.
- Never auto-apply a recommendation or a preset without explicit confirmation.
- Show the existing preset confirmation dialog listing every configuration field that would change.
- Flag legacy, deprecated, analytical-only, or role-mismatched technologies with clear warnings.
- Clearly label recommendations as educational guidance, not vendor endorsement or procurement advice.

### Example Behavior

```text
Component: Cache
Workload: read-heavy, latency-sensitive
Connected to: Application Server, Relational Database

Recommendations:
1. Redis — In-memory store with rich data structures and pub/sub.
   Trade-off: requires memory sizing and eviction planning.
2. Memcached — Simple, highly efficient key-value caching.
   Trade-off: no persistence, fewer data structures.
3. Amazon ElastiCache — Managed Redis or Memcached.
   Trade-off: managed-service cost and reduced operational control.
```

---

## 7. Data Model and Storage Requirements

- Store scenario templates, request definitions, fault definitions, requirements briefs, design constraints, and tutorials in version-controlled, schema-validated data files.
- Store the reference solution graph and the starting-state graph as separate, independently validated artifacts.
- Validate every artifact with Zod against the canonical project and scenario schemas.
- Keep scenario content modular by difficulty tier and domain.
- Version tutorials alongside the scenario templates they target.
- Maintain a scenario index supporting filtering by difficulty, domain, tag, concept, workload characteristic, prerequisite, and supported tutorial mode.
- Ensure all scenario content participates in project-schema migrations.
- Store tutorial progress, recorded design decisions, estimation answers, and recommendation preferences as local user state, isolated from project documents.

Suggested structure:

```text
src/scenarios/
  beginner/
  intermediate/
  advanced/
  specialized/
  briefs/
  constraints/
  requests/
  faults/
  tutorials/
  index.ts
src/recommendations/
  scoring/
  rules/
  context/
src/tutorial-engine/
  modes/
  estimation/
  decisions/
  diagnosis/
  validation/
  progress/
```

---

## 8. Testing and Validation Requirements

Add automated coverage for:

### Scenario Templates

- Every template loads without validation errors.
- Every template passes pre-simulation graph validation.
- Every template references existing traffic profiles, requests, faults, tutorials, and documentation.
- No template requires an unimplemented engine capability unless marked `blocked`.
- Node positions produce a readable, non-overlapping layout.

### Request Definitions

- Every request dispatches successfully against its scenario.
- Baseline requests complete without unexpected failures.
- Overload requests reliably produce the documented failure mode.
- Recorded `expectedOutcome` values match actual engine output.
- Identical seeds produce identical results across repeated runs.

### Fault Definitions

- Every fault applies to a valid target.
- Fault windows intersect their paired request dispatch windows.
- Documented impacts match observed simulation behavior.
- Composite faults follow documented precedence rules.
- Faults never mutate persisted template configuration.

### Tutorials

- Every tutorial step resolves a valid canvas or UI target.
- Automatic validation predicates execute correctly.
- Progression, skipping, restarting, mode switching, and exiting behave correctly.
- Tutorials remain fully keyboard accessible and screen-reader compatible.
- Tutorial state never corrupts or silently modifies project data.

### Build-Mode Learning Integrity

These tests exist specifically to prevent regression into passive, narrated tutorials.

- Every scenario except designated tier-onboarding scenarios defaults to `build` mode.
- Every `build` and `challenge` scenario declares a `startingState` that is not `complete`.
- Every `build` tutorial includes at least one `estimation` step, one `DesignDecisionPoint`, and one `DiagnosisChallenge`.
- Every `DesignDecisionPoint` offers at least one `recommended` and one `acceptable` option.
- Selecting a `suboptimal` or `incorrect` option is permitted and produces the documented simulated consequence when the scenario's request definitions are run against the mutated graph.
- No step in `build` or `challenge` mode reveals the remediation before its paired `DiagnosisChallenge` is resolved or explicitly skipped.
- `challenge` mode presents the requirements brief without exposing the reference solution.

### Property-Based Validation

- A user-built graph that is structurally different from the reference solution but satisfies all `required` `DesignConstraint` predicates is accepted as correct.
- At least two structurally distinct valid solutions are verified as passing for every scenario that admits them.
- Violating a `required` constraint produces the documented `violatedMessage` and `remediationHint`.
- `measured` constraints are evaluated only against actual engine output, never against static assumptions.
- No validation message asserts incorrectness solely on the basis of divergence from the reference graph.

### Estimation Steps

- Every `EstimationStep` derives its `expectedValue` from the scenario's `ScaleParameter` values.
- Answers inside `tolerancePercent` are accepted; answers outside it are rejected with the worked derivation shown.
- Accepted estimates propagate to the configuration fields named in `feedsIntoConfigurationField`.
- `workedDerivation` is displayed regardless of whether the answer was correct.

### Recommendations

- Only component-compatible technologies are recommended.
- Ranking is deterministic for identical context.
- Trade-offs appear alongside every recommendation.
- Deprecated and role-mismatched technologies surface warnings.
- No recommendation or preset is applied without explicit confirmation.
- Unknown or removed technology identifiers degrade safely.

---

## 9. Documentation Updates

Update the existing documentation set to reflect this work:

- `PRD.md` — add scenario library, tutorial system, and technology recommendation requirements.
- `TRD.md` — define scenario data models, tutorial state management, recommendation scoring architecture, and storage layout.
- `SIMULATION_SPEC.md` — confirm that scenario requests and faults use the standard deterministic pipeline with no privileged behavior.
- `COMPONENT_CATALOG.md` — document recommendation-eligibility metadata and workload-fit attributes per technology.
- `ACCEPTANCE_CRITERIA.md` — add verifiable criteria for template validity, request reproducibility, fault impact, tutorial progression, and recommendation determinism.
- `IMPLEMENTATION_PLAN.md` — sequence scenario, tutorial, and recommendation delivery against existing engine phases.
- `SCENARIO_LIBRARY_AND_USER_DOCUMENTATION_PROMPT.md` — align scenario documentation structure with the generated artifacts.

---

## 10. Delivery Strategy

Deliver incrementally and verifiably:

1. Implement the scenario, starting-state, requirements-brief, design-constraint, request, fault, tutorial, and recommendation schemas with validation and tests.
2. Implement the tutorial engine: mode switching, estimation steps, decision points, diagnosis challenges, property-based validation, and progress persistence.
3. Deliver one `guided-tour` onboarding scenario to establish interface familiarity.
4. Deliver the complete beginner tier in `build` mode end to end, including reference solutions, starting states, briefs, constraints, requests, faults, tutorials, and documentation.
5. Validate the beginner tier against the live engine. Confirm that at least two structurally distinct valid solutions pass constraint validation for each scenario, and correct any mismatched expected outcomes.
6. Implement the recommendation engine and integrate it with the Implementation tab and the `technology-selection` phase.
7. Deliver the intermediate tier.
8. Deliver the advanced tier, gated on required engine capabilities.
9. Deliver the specialized tier.
10. Publish the scenario index, prerequisite graph, mode availability matrix, and documentation cross-links.

Do not generate scenario content that the engine cannot execute deterministically. Prefer a smaller, fully verified, well-documented library over a larger set of unvalidated templates. Every expected outcome documented in a scenario, request, fault, decision option, or tutorial must be confirmed against actual simulator output before it is marked `ready`.

**Final constraint.** The measure of success for this work is whether a user who has never seen the reference solution can read the requirements brief, estimate the load, choose components, build the topology, configure it, find its breaking point, diagnose the cause, fix it, and defend the trade-offs they accepted. A tutorial that walks a user through a pre-built diagram does not meet that bar and must not be marked `ready`.
```
