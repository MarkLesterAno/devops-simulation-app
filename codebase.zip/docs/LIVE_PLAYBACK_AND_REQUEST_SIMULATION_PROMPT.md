# Live Playback and Request Simulation Prompt

```text
Update the System Design Simulator user interface and runtime simulation experience to remove persistent detail panels, simplify findings presentation, add user-driven request execution, and provide continuous visual request-flow animation.

The implementation must preserve the existing offline-first Electron architecture, deterministic simulation engine, React/TypeScript type safety, accessibility requirements, and project persistence model. Do not introduce any real network calls, cloud provisioning, or live infrastructure connections.

## 1. Remove Persistent Sidebar and Bottom Results Panels

Remove the existing persistent right-side inspector sidebar and the persistent metrics/findings area below the canvas.

The main workspace should prioritize the architecture canvas and provide a less cluttered diagramming experience.

### Required Layout Changes

- Remove the persistent right-side configuration/inspector sidebar.
- Remove the persistent metrics panel below the canvas.
- Remove the persistent findings panel below the canvas.
- The canvas should expand to use the newly available workspace.
- Keep essential controls accessible through:
  - Toolbar actions
  - Context menus
  - Node configuration modal
  - Metrics modal
  - Toast notifications
- Ensure removing these panels does not remove access to configuration, validation, simulation state, metrics, or findings.

Node configuration must remain accessible through:

- Double-clicking a canvas node.
- The node context-menu `Configure` action.
- Any existing keyboard-accessible equivalent.

Metrics must remain accessible through a dedicated `View Metrics` action in the toolbar, menu, and findings toast.

---

## 2. Replace Findings Modal Tab with Findings Toast Notifications

Remove the **Findings** tab from the results modal. The results modal must contain only the **Metrics** tab.

Instead, display findings through an accessible toast-notification system.

### Findings Toast Requirements

When a simulation produces one or more findings, show toast notifications for significant findings, including:

- Critical bottlenecks
- Service failures
- Sustained overload
- High error rates
- Timeout increases
- Queue backlog growth
- Retry amplification
- Circuit-breaker activation
- Failed failover behavior
- Architecture warnings
- Recommendations generated from simulation results

Each toast must include:

- Severity indicator: critical, warning, informational, or recommendation.
- Concise title.
- Short technical summary.
- Affected component or connection name, when available.
- Optional metric summary, such as:
  - `Application Service utilization reached 98%.`
  - `Queue depth increased to 250,000 messages.`
  - `Database p95 latency exceeded 1,200 ms.`
- A **View Metrics** button placed below the finding details.
- A dismiss action.
- Optional “focus component” action when a related node or edge exists.

### View Metrics Action

The **View Metrics** button must:

- Open the metrics modal.
- Focus the most relevant metric, chart, component, or event when the finding includes a reference.
- Preserve the simulation result context.
- Clearly indicate if the result is stale because the architecture, traffic profile, or fault scenario has changed.

### Toast Behavior

- Do not display an unbounded number of toasts simultaneously.
- Group or summarize repeated findings for the same component and condition.
- Prioritize critical findings over informational recommendations.
- Queue lower-priority findings when the maximum visible-toast limit is reached.
- Do not repeatedly display the same finding unless its severity or measured value materially changes.
- Support keyboard navigation, screen-reader announcements, and dismissal.
- Respect reduced-motion preferences.
- Persist the full findings list in simulation result data even when individual toasts are dismissed.
- Provide a non-intrusive way to review previously dismissed findings, such as a toolbar notification center or simulation event log.

The toast system is a presentation layer only. It must not change simulation calculations, findings generation, or deterministic results.

---

## 3. Metrics Modal

Update the simulation results modal so that it contains a single tab:

1. **Metrics**

The modal must display only the available metrics that are relevant to the architecture and simulation run:

- Total requests
- Successful requests
- Failed requests
- Requests per second
- Request-method distribution
- Error rate
- p50, p95, and p99 latency
- Per-node utilization
- Per-node latency
- Queue depth and consumer lag
- Cache hit and miss ratio
- Database read/write load
- Replica lag
- Retry count
- Timeout count
- Autoscaling events
- Circuit-breaker transitions
- Observed availability
- Optional educational cost estimate
- Request-flow event timeline

The metrics modal must remain accessible through:

- Toolbar action
- Application menu
- Keyboard shortcut
- Findings toast `View Metrics` button
- Simulation-completion action

The modal must support cancelled, failed, and completed simulations when result data exists.

---

## 4. Technology Logo Assets

Implement proper local technology-logo support for nodes with selected technology implementations.

### Dependency and Asset Requirements

Research and select free, redistributable, and license-compatible icon sources or dependencies suitable for a desktop application. Prefer established open-source icon libraries with clear licensing, such as:

- `simple-icons`
- `react-icons`, when the underlying icon license is compatible
- Official vendor assets only when their trademark and usage terms permit bundling
- Locally maintained fallback SVG assets for generic simulator component types

Do not fetch technology logos dynamically from third-party services at runtime.

### Implementation Requirements

- Store or bundle logo assets locally.
- Create a technology-icon registry keyed by stable technology IDs.
- Map selected implementation IDs to approved local logo assets.
- Use a generic component icon if:
  - The node uses `Generic / Custom Implementation`.
  - The technology does not have an approved logo.
  - An imported project references an unknown technology ID.
- Provide accessible labels for logos.
- Do not rely on logos alone to identify a selected implementation.
- Ensure icons remain visible in light and dark themes.
- Record the source package or asset license in project documentation or license notices.
- Do not use logos in a way that falsely suggests vendor endorsement or affiliation.

Example registry shape:

```ts
interface TechnologyIconDefinition {
  technologyId: string;
  icon: React.ComponentType<{ title?: string; className?: string }>;
  source: string;
  license: string;
  fallbackComponentType: ComponentType;
}
```

---

## 5. User-Initiated Request Simulation

Add a request-triggering feature that lets users send simulated HTTP-like requests through the current architecture.

This feature represents logical traffic entering the simulation. It must not make real HTTP requests and must not call external systems.

### Request Composer

Provide a request composer accessible from the simulation toolbar or a dedicated simulation-control modal.

The composer must support:

- HTTP method:
  - `GET`
  - `POST`
  - `PUT`
  - `PATCH`
  - `DELETE`
  - `HEAD`
  - `OPTIONS`
- Request count or batch size.
- Requests per second, or dispatch duration.
- Optional request path or route name.
- Request classification:
  - Read
  - Write
  - Authentication-required
  - Session-affine
  - Custom request class
- Optional logical request payload size.
- Optional response payload size.
- Optional timeout/deadline override within validated bounds.
- Request origin/client selection when multiple client nodes exist.
- Optional random seed override for reproducible manually triggered simulations.

### Request Dispatch Behavior

When a user submits a request batch:

1. Validate the graph and selected request origin.
2. Convert the user input into deterministic request-arrival events.
3. Send the events through the same discrete-event simulation engine used by traffic profiles.
4. Preserve method, request class, payload, and read/write metadata on each simulated request.
5. Include these requests in metrics, event logs, flow visualization, and findings.
6. Display validation errors clearly if the graph cannot handle the request.
7. Never send real HTTP traffic.

For example:

```text
Method: PUT
Request count: 1,000
Dispatch rate: 100 requests per second
Target duration: 10 logical seconds
Classification: Write
```

This must create 1,000 deterministic simulated `PUT` write requests over 10 logical seconds, subject to the selected dispatch rate and simulation configuration.

---

## 6. Continuous Live Request-Flow Animation

Improve simulation playback so that request-flow visualization appears continuous and understandable rather than stopping immediately after execution begins.

The simulation engine may still process logical events faster than real time, but the UI must provide a controlled visual playback layer that makes the traffic flow observable.

### Separation of Concerns

Maintain a strict separation between:

1. **Deterministic simulation execution**
   - Calculates logical outcomes.
   - May process events rapidly in a worker.
   - Must remain reproducible.

2. **Visual playback and request-flow animation**
   - Replays or streams normalized simulation events to the canvas.
   - Must not modify calculated outcomes.
   - May use a configurable real-time playback scale.

### Required Playback Behavior

- Do not immediately stop visual activity when a simulation run completes internally.
- Use a playback timeline that replays request-flow events over visible time.
- Support playback speeds such as:
  - `0.25x`
  - `0.5x`
  - `1x`
  - `2x`
  - `4x`
  - `8x`
- Support pause, resume, restart, and reset.
- For batch requests, keep flow animation active until all normalized request-flow events have been played.
- Clearly distinguish:
  - Engine completed: all logical calculations are finished.
  - Playback active: request-flow visualization is still being shown.
- Allow the user to skip visual playback and immediately view final metrics.
- Keep animations running for a meaningful minimum duration when practical, without changing the simulated logical timestamps or results.

### Request-Flow Visualization

For every active simulated request path:

- Animate directional particles from the source node to the target node.
- Render flow direction based on the actual selected edge.
- Differentiate HTTP methods or request classes where useful:
  - `GET`: blue or read-flow marker
  - `POST` / `PUT` / `PATCH` / `DELETE`: amber or write-flow marker
  - Failed request: red marker that fades or terminates before target
  - Retried request: amber repeated pulse or retry marker
  - Asynchronous event: purple dashed event marker
  - Replication: teal slower marker
- Scale particle density from normalized or sampled request volume, not one particle per request.
- For example, 1,000 simulated `PUT` requests should produce a visible write-flow stream along the valid request path without attempting to render 1,000 separate DOM elements or particles.
- Show active node processing state while a node handles visualized work.
- Update node badges or compact metrics as playback progresses.
- Show queue buildup visually when producers outpace consumers.
- Show failed routes, retries, and failover paths when they occur.

### Performance and Accessibility

- Use event aggregation, sampling, particle pooling, throttling, Canvas rendering, SVG optimization, or equivalent techniques to preserve browser performance.
- Do not let animation block canvas interactions, graph editing, modals, keyboard controls, or context menus.
- Stop or pause animations when the user pauses, resets, cancels, or exits playback.
- Respect `prefers-reduced-motion`.
- Provide an independent user setting to disable flow animation.
- When animation is disabled or reduced motion is enabled, replace moving particles with:
  - Directional edge indicators
  - Animated-state labels only when allowed
  - Edge traffic counters
  - Updated node and edge status badges

---

## 7. State and Persistence Requirements

Update UI and simulation state models to include:

```ts
interface ManualRequestDefinition {
  id: string;
  sourceNodeId: string;
  method: HttpMethod;
  requestCount: number;
  dispatchRateRps: number;
  path?: string;
  requestClass?: string;
  payloadSizeBytes?: number;
  responseSizeBytes?: number;
  timeoutMs?: number;
  seed?: number;
}

interface SimulationPlaybackState {
  status: "idle" | "preparing" | "running" | "paused" | "completed" | "cancelled";
  speed: number;
  currentLogicalTimeMs: number;
  currentPlaybackTimeMs: number;
  engineCompleted: boolean;
  activeFlowSummaries: EdgeFlowSummary[];
}
```

Requirements:

- Manual request definitions may be saved as reusable local presets.
- A manual request batch must be traceable in simulation results.
- Existing traffic profiles must continue to function without requiring manual-request configuration.
- Existing projects must remain compatible.
- Findings toast state must not be persisted as project data; findings themselves remain part of run results.
- Animation and playback preferences should be stored as local user preferences.

---

## 8. Validation and Testing Requirements

Add or update tests covering:

### Layout and Access

- The persistent right sidebar is removed.
- The persistent bottom metrics/findings panel is removed.
- The canvas expands into available workspace.
- Node configuration remains available through double-click and context menu.
- Metrics remain available through toolbar/menu/shortcut and finding-toast action.

### Findings Toasts

- Findings create correctly classified toasts.
- A toast displays severity, title, details, and `View Metrics`.
- `View Metrics` opens the metrics modal with relevant context.
- Repeated findings are deduplicated or grouped.
- Toasts remain keyboard accessible and screen-reader compatible.
- Dismissing a toast does not delete the underlying simulation finding.

### Technology Logos

- Known technology IDs resolve to bundled local assets.
- Generic and unknown implementation assignments use safe fallback icons.
- No runtime request is made to fetch logo assets.
- License/source metadata is documented for bundled icon dependencies.

### Manual Requests

- A `GET`, `POST`, `PUT`, `PATCH`, `DELETE`, `HEAD`, or `OPTIONS` request can be configured.
- A batch of 1,000 `PUT` requests dispatched at 100 RPS creates exactly 1,000 deterministic logical request arrivals over 10 seconds.
- Manual requests contribute correctly to results, metrics, findings, and graph visualization.
- Invalid request inputs and invalid graph routes display actionable errors.
- The request composer never performs external network activity.

### Playback and Animation

- Simulation calculation remains deterministic regardless of playback speed.
- Flow animation continues until visual playback completes even if the engine has already calculated the final result.
- Pause, resume, restart, reset, skip, and cancel behave correctly.
- Write requests use the configured write-flow visual treatment.
- High-volume request batches use bounded rendering resources.
- Reduced-motion mode and the animation-disable preference prevent moving-particle animation.
- Animation state never modifies simulation outcomes.

---

## 9. Documentation Updates

Update the relevant product and technical documentation:

- `DESIGN_BRIEF.md`
  - Remove references to persistent sidebars and bottom metrics/findings areas.
  - Document finding toasts, metrics modal access, request composer, and live playback behavior.

- `PRD.md`
  - Add user requirements for user-triggered requests, request methods, findings toast notifications, metrics access, and visual playback.

- `TRD.md`
  - Document the separation between deterministic simulation and visual playback.
  - Define request-composer data models, animation performance constraints, bundled icon registry, and local asset licensing requirements.

- `SIMULATION_SPEC.md`
  - Define manual request-arrival generation, request-method metadata, and clarify that visual playback cannot modify deterministic results.

- `ACCEPTANCE_CRITERIA.md`
  - Add verifiable requirements for manual request batches, live playback, findings toasts, metrics navigation, layout removal, icon fallback, reduced-motion behavior, and rendering performance.

- `COMPONENT_CATALOG.md`
  - Document technology-to-icon mapping policy and required license/source metadata.

- `TECHNOLOGY_CATALOG_IMPLEMENTATION_PROMPT.md`
  - Add approved local icon-source policy and technology icon registry requirements.

Prioritize a clean canvas, deterministic behavior, accessible interaction, and visually understandable traffic flow. The application should feel live and interactive while remaining a fully local, offline simulation tool.
```
