# Technology Catalog Implementation Prompt

```text
Extend the System Design Simulator component catalog so that every infrastructure component—except the Client component—can be associated with one or more real-world technologies, managed services, or self-hosted software products.

The purpose is to let users represent the specific implementation they intend to use, such as Redis for caching, PostgreSQL for relational data, MongoDB for document storage, Cloudflare for CDN delivery, or AWS Application Load Balancer for request routing.

Do not imply that the simulator directly provisions, connects to, or validates live cloud services. Technology assignments are educational metadata and may optionally select an appropriate simulation preset.

## Requirements

### 1. Technology and Service Catalog

Create a structured, extensible catalog of technologies and services for each component type. Do not attempt to claim coverage of every product ever created; instead, provide a broad, curated, maintainable set of widely used and representative options.

Each catalog entry must include:

- `id`: Stable machine-readable identifier.
- `displayName`: Human-readable product or service name.
- `provider`: Vendor, organization, or `"Open Source"` where appropriate.
- `deploymentModel`: One or more of:
  - `managed-cloud`
  - `self-managed`
  - `open-source`
  - `saas`
  - `on-premises`
- `componentTypes`: The simulator component types the technology can represent.
- `description`: Concise technical explanation of its role.
- `capabilities`: Relevant supported behaviors, such as replication, auto-scaling, pub/sub, global edge delivery, SQL transactions, search indexing, or object storage.
- `simulationPreset`: Optional default simulation characteristics. These must be educational defaults, not real provider performance guarantees.
- `documentationUrl`: Optional official documentation URL.
- `modelVersion`: Version of the simulator mapping or preset definition.

Use a neutral, provider-agnostic internal component model. Provider-specific technologies must map onto generic simulator behavior rather than introducing cloud-provider-specific logic throughout the simulation engine.

Example:

```ts
interface TechnologyOption {
  id: string;
  displayName: string;
  provider: string;
  deploymentModel: DeploymentModel[];
  componentTypes: ComponentType[];
  description: string;
  capabilities: string[];
  simulationPreset?: SimulationPreset;
  documentationUrl?: string;
  modelVersion: string;
}
```

### 2. Component-to-Technology Assignment

For every supported infrastructure component except `Client`, add a Technology/Implementation field to the node configuration modal.

The field must:

- Show only catalog entries compatible with the selected component type.
- Support search, filtering, and grouping by provider or deployment model.
- Allow an explicit **Generic / Custom Implementation** option.
- Preserve the selected technology identifier in the project document.
- Continue to work when a technology is deprecated or removed from the active catalog by retaining its saved identifier, display name, and compatibility metadata.
- Show a clear warning when an imported project references an unknown or unsupported technology.
- Never require users to select a provider-specific technology before simulating a design.

Technology selection must not overwrite a user’s manually configured component values without confirmation. If a user elects to apply a technology preset, show which fields will change and allow the user to accept, cancel, or selectively apply the preset.

### 2a. Technology Icons and Local Assets

The approved shipped behavior is a local icon registry with locally authored component glyphs and
provider-tinted monogram fallbacks for technology badges. Do **not** add `simple-icons`,
`react-icons`, CDN-hosted logos, or other third-party brand assets by default. The registry's
`LOGO_ASSETS` map starts empty and unknown or unapproved technology IDs must render safely through
the monogram fallback.

If a future change bundles a technology logo, it must:

- Store the asset under a local renderer assets folder.
- Register it in `LOGO_ASSETS` keyed by the stable technology id.
- Record source, license, version/date retrieved, and trademark or usage restrictions in the docs or license notices.
- Prefer the local asset over the monogram only after that metadata is present.
- Never fetch icons from the network at runtime; the offline-first guarantee applies to branding assets.
- Avoid any presentation that implies vendor endorsement, affiliation, or certification.

#### Category-to-component mapping

Every catalog category must map to at least one component type, or be explicitly marked as
edge/configuration metadata. Categories listed in §3 map as follows:

| Catalog category | Component type(s) |
|---|---|
| DNS and Traffic Management | `dns-traffic-manager` |
| CDN, Edge, and DDoS Protection | `cdn` (DDoS and WAF entries are edge configuration metadata) |
| API Gateways and Reverse Proxies | `api-gateway`, `load-balancer` |
| Load Balancers | `load-balancer` |
| Compute and Application Hosting | `server`, `worker` |
| Relational Databases | `relational-database`, `read-replica` |
| NoSQL, Document, Key-Value, and Wide-Column Databases | `nosql-database` |
| Caches and Session Stores | `cache` |
| Messaging, Queues, Pub/Sub, and Event Streaming | `message-queue`, `event-topic`, `dead-letter-queue` |
| Search, Analytics, and Data Warehousing | `search-index`, `analytical-store` (Priority 2/3) |
| Object, File, and Block Storage | `object-storage` |
| Identity, Authentication, Authorization, and Secrets Management | `identity-auth-service`, `secrets-kms` (Priority 2) |
| Observability, Logging, Monitoring, and Alerting | `observability` |
| Networking, Service Discovery, and Service Mesh | `service-discovery` (Priority 2); service-mesh entries are edge-policy metadata |
| Backup, Disaster Recovery, and Replication | `backup-restore` (Priority 3) |
| Autoscaling and Infrastructure Operations | `autoscaler`; CI/CD, registry, and IaC entries are project metadata only |
| Third-party SaaS and provider APIs | `external-service` |

Categories whose components are not yet delivered must be withheld from the active catalog rather
than shipped as unassignable entries. A registry test must fail the build if any active technology
category has no assignable component type and is not explicitly marked as metadata.

### 3. Initial Curated Technology Catalog

Include representative technologies and services for the following categories.

#### DNS and Traffic Management

- Amazon Route 53
- Cloudflare DNS
- Google Cloud DNS
- Azure DNS
- NS1
- Akamai Edge DNS
- PowerDNS
- BIND

#### CDN, Edge, and DDoS Protection

- Cloudflare CDN
- Amazon CloudFront
- Akamai Content Delivery Network
- Fastly
- Azure Front Door
- Google Cloud CDN
- Vercel Edge Network
- Netlify Edge
- Cloudflare Workers
- AWS Global Accelerator
- AWS Shield
- Cloudflare WAF
- AWS WAF
- Google Cloud Armor
- Azure Web Application Firewall

#### API Gateways and Reverse Proxies

- Amazon API Gateway
- Kong Gateway
- Apache APISIX
- Tyk
- NGINX
- NGINX Plus
- Envoy Proxy
- Traefik Proxy
- HAProxy
- Caddy
- Azure API Management
- Google Cloud API Gateway
- Apigee
- Cloudflare API Gateway

#### Load Balancers

- AWS Application Load Balancer
- AWS Network Load Balancer
- AWS Gateway Load Balancer
- Elastic Load Balancing Classic Load Balancer, marked legacy
- Google Cloud Load Balancing
- Azure Load Balancer
- Azure Application Gateway
- Azure Front Door
- Cloudflare Load Balancing
- HAProxy
- NGINX
- Envoy Proxy
- Traefik Proxy
- F5 BIG-IP

#### Compute and Application Hosting

- Amazon EC2
- Amazon ECS
- Amazon EKS
- AWS Fargate
- AWS Lambda
- Google Compute Engine
- Google Kubernetes Engine
- Google Cloud Run
- Google Cloud Functions
- Azure Virtual Machines
- Azure Kubernetes Service
- Azure Container Apps
- Azure Functions
- Kubernetes
- Docker
- OpenShift
- HashiCorp Nomad
- Apache Tomcat
- Node.js
- Spring Boot
- .NET ASP.NET Core
- Django
- Flask
- FastAPI
- Ruby on Rails
- Laravel
- Phoenix
- Express.js
- NestJS

Separate infrastructure runtimes from application frameworks where appropriate. For example, `Kubernetes` is a compute orchestration platform, while `Spring Boot` is an application framework that may run on a compute platform.

#### Relational Databases

- PostgreSQL
- MySQL
- MariaDB
- SQLite
- Microsoft SQL Server
- Oracle Database
- IBM Db2
- CockroachDB
- YugabyteDB
- TiDB
- Amazon RDS
- Amazon Aurora
- Google Cloud SQL
- AlloyDB for PostgreSQL
- Azure SQL Database
- Azure Database for PostgreSQL
- PlanetScale
- Neon
- Supabase Postgres
- Amazon Redshift, identified as analytical/data warehouse rather than OLTP
- Google BigQuery, identified as analytical/data warehouse rather than OLTP
- Snowflake, identified as analytical/data warehouse rather than OLTP

#### NoSQL, Document, Key-Value, and Wide-Column Databases

- MongoDB
- MongoDB Atlas
- Amazon DynamoDB
- Apache Cassandra
- DataStax Astra DB
- ScyllaDB
- Apache HBase
- Google Cloud Bigtable
- Azure Cosmos DB
- Couchbase
- CouchDB
- Redis
- Amazon ElastiCache for Redis
- Amazon MemoryDB for Redis
- Google Memorystore for Redis
- Azure Cache for Redis
- Aerospike
- FoundationDB
- Riak KV
- etcd

Classify each product accurately by data model because some technologies may be valid for multiple generic components.

#### Caches and Session Stores

- Redis
- Memcached
- Dragonfly
- KeyDB
- Garnet
- Hazelcast
- Apache Ignite
- Infinispan
- Amazon ElastiCache
- Amazon MemoryDB for Redis
- Google Memorystore
- Azure Cache for Redis
- Varnish Cache
- NGINX Cache
- Cloudflare Workers KV
- Cloudflare Durable Objects
- DynamoDB Accelerator (DAX)

#### Messaging, Queues, Pub/Sub, and Event Streaming

- Apache Kafka
- Confluent Cloud
- Redpanda
- Apache Pulsar
- RabbitMQ
- ActiveMQ Artemis
- NATS
- NATS JetStream
- Redis Streams
- Amazon SQS
- Amazon SNS
- Amazon EventBridge
- Amazon MSK
- Google Pub/Sub
- Azure Service Bus
- Azure Event Hubs
- Azure Event Grid
- IBM MQ
- Solace PubSub+
- Celery
- Sidekiq
- BullMQ
- Temporal
- Apache Airflow, marked workflow orchestration rather than a queue
- Prefect, marked workflow orchestration rather than a queue
- Dagster, marked data orchestration rather than a queue

#### Search, Analytics, and Data Warehousing

- Elasticsearch
- OpenSearch
- Apache Solr
- Meilisearch
- Typesense
- Algolia
- Amazon OpenSearch Service
- Azure AI Search
- Google Vertex AI Search
- ClickHouse
- Apache Druid
- Apache Pinot
- Apache Spark
- Databricks
- Amazon Redshift
- Google BigQuery
- Snowflake
- Azure Synapse Analytics
- Trino
- Presto

#### Object, File, and Block Storage

- Amazon S3
- Amazon EBS
- Amazon EFS
- Google Cloud Storage
- Google Persistent Disk
- Google Filestore
- Azure Blob Storage
- Azure Managed Disks
- Azure Files
- Cloudflare R2
- MinIO
- Ceph
- Wasabi
- Backblaze B2
- DigitalOcean Spaces
- NetApp
- Dell EMC PowerScale

#### Identity, Authentication, Authorization, and Secrets Management

- Auth0
- Okta
- Keycloak
- Amazon Cognito
- AWS IAM
- Azure Active Directory / Microsoft Entra ID
- Google Cloud Identity
- Firebase Authentication
- Clerk
- WorkOS
- FusionAuth
- Ory Kratos
- Ory Keto
- Open Policy Agent
- Casbin
- HashiCorp Vault
- AWS Secrets Manager
- AWS Systems Manager Parameter Store
- Google Secret Manager
- Azure Key Vault
- 1Password Secrets Automation
- Doppler

#### Observability, Logging, Monitoring, and Alerting

- Prometheus
- Grafana
- Grafana Loki
- Grafana Tempo
- OpenTelemetry
- Jaeger
- Zipkin
- Elastic Stack
- Splunk
- Datadog
- New Relic
- Dynatrace
- Sentry
- Honeycomb
- AWS CloudWatch
- AWS X-Ray
- Google Cloud Operations Suite
- Azure Monitor
- PagerDuty
- Opsgenie
- VictorOps / Splunk On-Call
- Better Stack
- Elastic Observability

#### Networking, Service Discovery, and Service Mesh

- Istio
- Linkerd
- Consul
- Consul Connect
- AWS Cloud Map
- Kubernetes DNS
- CoreDNS
- Eureka
- ZooKeeper
- etcd
- AWS VPC
- Amazon VPC Lattice
- AWS PrivateLink
- Google Cloud VPC
- Azure Virtual Network
- Cilium
- Calico
- Tailscale
- WireGuard
- Cloudflare Tunnel

#### Backup, Disaster Recovery, and Replication

- AWS Backup
- AWS Elastic Disaster Recovery
- Azure Site Recovery
- Google Backup and DR
- Veeam
- Commvault
- Rubrik
- Cohesity
- Velero
- pgBackRest
- WAL-G
- Percona XtraBackup
- Debezium
- AWS Database Migration Service
- Fivetran
- Airbyte
- Qlik Replicate

#### Autoscaling and Infrastructure Operations

- Kubernetes Horizontal Pod Autoscaler
- Kubernetes Vertical Pod Autoscaler
- Karpenter
- Cluster Autoscaler
- AWS Auto Scaling
- AWS Application Auto Scaling
- Google Cloud Autoscaler
- Azure Autoscale
- HashiCorp Terraform
- OpenTofu
- Pulumi
- AWS CloudFormation
- AWS CDK
- Azure Resource Manager
- Google Cloud Deployment Manager
- Ansible
- Chef
- Puppet
- Salt
- Crossplane
- Argo CD
- Flux CD
- Jenkins
- GitHub Actions
- GitLab CI/CD
- CircleCI
- Buildkite
- Spinnaker
- Tekton
- Argo Workflows

### 4. Categorization and Accuracy Rules

- Do not classify a product solely by vendor marketing terminology.
- A technology may be assigned to more than one generic component type when that is accurate. For example:
  - Redis: cache, session store, key-value database, pub/sub, stream.
  - NGINX: reverse proxy, load balancer, web server, cache.
  - Kubernetes: compute orchestration and autoscaling integration.
  - Cloudflare: DNS, CDN, WAF, load balancing, edge compute, and object storage.
- When a product supports multiple roles, show its role-specific capabilities for the selected node type.
- Mark technologies that are legacy, deprecated, analytical-only, workflow-only, or otherwise unsuitable for a generic component role.
- Do not treat application frameworks, infrastructure runtimes, storage products, deployment tools, and observability tools as interchangeable categories.
- Use canonical names, record aliases separately, and avoid duplicate catalog entries.

### 5. UI Requirements

In the node configuration modal, add an **Implementation** section containing:

- Provider or technology selector.
- Search input.
- Component-compatible results only.
- Filters for provider, deployment model, open-source availability, and managed/self-hosted operation.
- Capability badges.
- Technology description and warnings.
- Link to official documentation, opened through a controlled external-link flow.
- Button to apply an optional simulation preset.
- A confirmation dialog that lists all configuration fields that would change before applying a preset.
- A reset option that restores the node to Generic / Custom Implementation while retaining user-configured simulation values.

Clearly label provider-specific selections as educational implementation metadata. Selecting a technology must never cause network calls, credential prompts, provisioning actions, or external service configuration.

### 6. Data and Maintenance Requirements

- Store catalog entries in version-controlled TypeScript or JSON data files.
- Validate catalog records with a Zod schema.
- Add unit tests ensuring:
  - Every catalog entry has a stable ID.
  - Every catalog entry maps to at least one supported component type.
  - Component mappings are valid.
  - Duplicate IDs and duplicate canonical provider/product combinations are rejected.
  - Entries marked as legacy or deprecated expose a warning.
  - Technology assignments survive project save/load.
  - Unknown technology assignments from imported projects display safely and do not prevent generic simulation.
- Maintain catalog version metadata and a migration strategy for renamed or deprecated technology identifiers.
- Keep the catalog modular by domain, for example:
  - `dns.ts`
  - `cdn.ts`
  - `compute.ts`
  - `databases.ts`
  - `caching.ts`
  - `messaging.ts`
  - `observability.ts`
  - `identity.ts`
  - `networking.ts`
  - `storage.ts`
  - `operations.ts`

### 7. Documentation Requirements

Update the technical documentation to explain:

- The distinction between a generic simulator component and a selected real-world implementation.
- That provider selections are informational and do not create real infrastructure.
- The source, version, and limitations of any simulation presets.
- How technologies with multiple valid roles are represented.
- How deprecated, renamed, or unknown catalog entries are handled.

Prioritize accurate classification, extensibility, deterministic simulation behavior, and a clean user experience. Do not introduce provider-specific behavior into the core simulation engine unless it is represented as an explicit, versioned preset mapped to generic component capabilities.
```
