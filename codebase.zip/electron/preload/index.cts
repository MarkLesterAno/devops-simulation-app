import { contextBridge, ipcRenderer } from "electron";

/**
 * Narrow, allowlisted preload bridge. The renderer never receives
 * ipcRenderer, Node APIs, or filesystem modules directly. Every channel
 * below has a corresponding validated handler in electron/main/index.ts.
 */
export interface ProjectApi {
  open(): Promise<{ ok: boolean; error?: string; filePath?: string; data?: unknown }>;
  save(payload: {
    filePath?: string;
    document: unknown;
  }): Promise<{ ok: boolean; error?: string; filePath?: string }>;
  exportJson(payload: { document: unknown }): Promise<{ ok: boolean; error?: string }>;
  recent(): Promise<string[]>;
}

const projectApi: ProjectApi = {
  open: () => ipcRenderer.invoke("project:open"),
  save: (payload) => ipcRenderer.invoke("project:save", payload),
  exportJson: (payload) => ipcRenderer.invoke("project:exportJson", payload),
  recent: () => ipcRenderer.invoke("project:recent")
};

export interface AutosaveApi {
  read(): Promise<{ ok: boolean; error?: string; data?: unknown }>;
  write(payload: { record: unknown }): Promise<{ ok: boolean; error?: string }>;
  clear(): Promise<{ ok: boolean; error?: string }>;
}

const autosaveApi: AutosaveApi = {
  read: () => ipcRenderer.invoke("autosave:read"),
  write: (payload) => ipcRenderer.invoke("autosave:write", payload),
  clear: () => ipcRenderer.invoke("autosave:clear")
};

export interface SimulatorBridge {
  project: ProjectApi;
  autosave: AutosaveApi;
  platform: NodeJS.Platform;
  isElectron: true;
}

const bridge: SimulatorBridge = {
  project: projectApi,
  autosave: autosaveApi,
  platform: process.platform,
  isElectron: true
};

contextBridge.exposeInMainWorld("simulator", bridge);
