import { useCallback, useEffect, useState } from "react";
import { ReactFlowProvider } from "@xyflow/react";
import { useProjectStore } from "@/stores/projectStore";
import { Palette } from "@/features/component-library/Palette";
import { ArchitectureCanvas } from "@/features/canvas/ArchitectureCanvas";
import { SimulationControls } from "@/features/simulation/SimulationControls";
import { PlaybackControls } from "@/features/simulation/PlaybackControls";
import { RequestComposer } from "@/features/simulation/RequestComposer";
import { NodeConfigModal } from "@/features/modals/NodeConfigModal";
import { MetricsModal } from "@/features/modals/MetricsModal";
import { FindingToasts } from "@/features/notifications/FindingToasts";
import { NotificationCentre } from "@/features/notifications/NotificationCentre";
import { NodeContextMenu } from "@/features/canvas/NodeContextMenu";
import { ScenarioGallery } from "@/features/scenarios/ScenarioGallery";
import { useUiStore } from "@/stores/uiStore";
import { useToastStore } from "@/stores/toastStore";
import { openProject, saveProject, exportProjectJson } from "@/persistence/projectPersistence";
import { useAutosave } from "@/persistence/useAutosave";
import { exportDiagramPng } from "@/features/canvas/diagramExport";
import { ValidationSummary } from "@/features/validation/ValidationSummary";
import { ContextPanel } from "@/features/context-panel/ContextPanel";
import { getTutorialForScenario } from "@/domain/tutorials/registry";
import { useTutorialStore } from "@/stores/tutorialStore";
import { isTutorialBlockedShortcut } from "@/features/tutorials/keyboard";
import { WelcomeExperience } from "@/features/onboarding/WelcomeExperience";
import { useWelcomeStore } from "@/stores/welcomeStore";
import { KeyboardShortcutsModal } from "@/features/shortcuts/KeyboardShortcutsModal";
import { isShortcutReferenceKey } from "@/features/shortcuts/shortcuts";

const AUTOSAVE_LABELS: Record<string, string> = {
  idle: "",
  saving: "Autosaving…",
  saved: "Draft saved",
  error: "Autosave failed"
};

function formatSavedAt(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "a moment ago";
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export function App(): JSX.Element {
  const document = useProjectStore((state) => state.document);
  const filePath = useProjectStore((state) => state.filePath);
  const isDirty = useProjectStore((state) => state.isDirty);
  const isSimulating = useProjectStore((state) => state.isSimulating);
  const setDocument = useProjectStore((state) => state.setDocument);
  const setFilePath = useProjectStore((state) => state.setFilePath);
  const markSaved = useProjectStore((state) => state.markSaved);
  const undo = useProjectStore((state) => state.undo);
  const redo = useProjectStore((state) => state.redo);
  const newProject = useProjectStore((state) => state.newProject);
  const selectedNodeId = useProjectStore((state) => state.selectedNodeId);
  const selectedEdgeId = useProjectStore((state) => state.selectedEdgeId);
  const removeNode = useProjectStore((state) => state.removeNode);
  const removeEdge = useProjectStore((state) => state.removeEdge);
  const openNodeConfig = useUiStore((state) => state.openNodeConfig);
  const openContextMenu = useUiStore((state) => state.openContextMenu);
  const openContextPanel = useUiStore((state) => state.openContextPanel);
  const openMetrics = useUiStore((state) => state.openMetrics);
  const setActiveScenario = useUiStore((state) => state.setActiveScenario);
  const openRequestComposer = useUiStore((state) => state.openRequestComposer);
  const openScenarioGallery = useUiStore((state) => state.openScenarioGallery);
  const configNodeId = useUiStore((state) => state.configNodeId);
  const metricsModalOpen = useUiStore((state) => state.metricsModalOpen);
  const requestComposerOpen = useUiStore((state) => state.requestComposerOpen);
  const scenarioGalleryOpen = useUiStore((state) => state.scenarioGalleryOpen);
  const activeScenarioId = useUiStore((state) => state.activeScenarioId);
  const activeTutorialId = useTutorialStore((state) => state.activeTutorialId);
  const startTutorial = useTutorialStore((state) => state.start);
  const exitTutorial = useTutorialStore((state) => state.exit);
  const notificationCentreOpen = useToastStore((state) => state.notificationCentreOpen);
  const openNotificationCentre = useToastStore((state) => state.openNotificationCentre);
  const findingCount = useToastStore((state) => state.history.length);
  const notify = useToastStore((state) => state.notify);
  const flowAnimationEnabled = useUiStore((state) => state.flowAnimationEnabled);
  const setFlowAnimationEnabled = useUiStore((state) => state.setFlowAnimationEnabled);
  const openWelcome = useWelcomeStore((state) => state.open);
  const autosave = useAutosave();
  const [compactWorkspace, setCompactWorkspace] = useState(() => window.innerWidth < 1280);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia("(max-width: 1279px)");
    const updateCompactWorkspace = (): void => setCompactWorkspace(mediaQuery.matches);
    updateCompactWorkspace();
    mediaQuery.addEventListener("change", updateCompactWorkspace);
    return () => mediaQuery.removeEventListener("change", updateCompactWorkspace);
  }, []);

  const showMetrics = useCallback((): void => {
    if (compactWorkspace) openMetrics();
    else openContextPanel("metrics");
  }, [compactWorkspace, openContextPanel, openMetrics]);

  const showFindings = useCallback((): void => {
    if (compactWorkspace) openNotificationCentre();
    else openContextPanel("findings");
  }, [compactWorkspace, openContextPanel, openNotificationCentre]);

  const handleOpen = useCallback(async () => {
    const result = await openProject();
    if (result.ok && result.document) {
      setDocument(result.document, result.filePath);
      setActiveScenario(undefined);
      exitTutorial();
    } else if (result.error && result.error !== "cancelled") {
      notify({ severity: "error", title: "Could not open project", detail: result.error });
    }
  }, [setDocument, setActiveScenario, exitTutorial, notify]);

  const handleSave = useCallback(async () => {
    const result = await saveProject(document, filePath);
    if (result.ok) {
      if (result.filePath) setFilePath(result.filePath);
      markSaved();
      notify({
        severity: "success",
        title: "Project saved",
        detail: result.filePath ? `Saved as ${result.filePath}.` : "Project save completed."
      });
    } else if (result.error && result.error !== "cancelled") {
      notify({ severity: "error", title: "Could not save project", detail: result.error });
    }
  }, [document, filePath, setFilePath, markSaved, notify]);

  const handleExport = useCallback(async () => {
    const result = await exportProjectJson(document);
    if (result.ok) {
      notify({
        severity: "success",
        title: "JSON exported",
        detail: result.filePath ? `Downloaded ${result.filePath}.` : "JSON export completed."
      });
    } else if (result.error && result.error !== "cancelled") {
      notify({ severity: "error", title: "Could not export project", detail: result.error });
    }
  }, [document, notify]);

  const handleDiagramExport = useCallback(async () => {
    try {
      await exportDiagramPng(document);
      notify({
        severity: "success",
        title: "PNG exported",
        detail: `Downloaded ${document.name || "architecture"}-diagram.png.`
      });
    } catch (error) {
      notify({
        severity: "error",
        title: "Could not export diagram",
        detail: error instanceof Error ? error.message : "An unknown export error occurred."
      });
    }
  }, [document, notify]);

  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent): void {
      const isMod = event.ctrlKey || event.metaKey;
      if (activeTutorialId) {
        const target = event.target instanceof Element ? event.target : undefined;
        if (target?.closest(".tutorial-panel") && event.key === "Enter") return;
        if (isTutorialBlockedShortcut(event)) event.preventDefault();
        return;
      }
      const activeTag = (window.document.activeElement?.tagName ?? "").toLowerCase();
      const isTyping = activeTag === "input" || activeTag === "select" || activeTag === "textarea";
      if (isShortcutReferenceKey(event) && !isTyping) {
        event.preventDefault();
        setShortcutsOpen(true);
        return;
      }
      const overlayOpen =
        Boolean(configNodeId) ||
        metricsModalOpen ||
        requestComposerOpen ||
        scenarioGalleryOpen ||
        notificationCentreOpen ||
        shortcutsOpen;
      if (isMod && event.key.toLowerCase() === "z" && !event.shiftKey) {
        event.preventDefault();
        undo();
      } else if (isMod && (event.key.toLowerCase() === "y" || (event.key.toLowerCase() === "z" && event.shiftKey))) {
        event.preventDefault();
        redo();
      } else if (isMod && event.key.toLowerCase() === "s") {
        event.preventDefault();
        void handleSave();
      } else if (isMod && event.key.toLowerCase() === "m") {
        event.preventDefault();
        showMetrics();
      } else if (overlayOpen) {
        // A modal owns keyboard interaction while it is open. Without this
        // guard, Delete/Enter aimed at a modal control could mutate a selected
        // canvas node behind the dialog.
        return;
      } else if (event.shiftKey && event.key === "F10" && selectedNodeId) {
        // Keyboard equivalent of right-click, anchored to the selected node.
        event.preventDefault();
        const element = window.document.querySelector(`[data-id="${selectedNodeId}"]`);
        const rect = element?.getBoundingClientRect();
        openContextMenu({
          nodeId: selectedNodeId,
          x: rect ? rect.left + rect.width / 2 : 120,
          y: rect ? rect.top + rect.height / 2 : 120
        });
      } else if (event.key === "Enter" && selectedNodeId) {
        if (isTyping) return;
        event.preventDefault();
        openNodeConfig(selectedNodeId);
      } else if (event.key === "Delete" || event.key === "Backspace") {
        if (isTyping) return;
        if (selectedNodeId) removeNode(selectedNodeId);
        else if (selectedEdgeId) removeEdge(selectedEdgeId);
      }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [
    undo,
    redo,
    handleSave,
    selectedNodeId,
    selectedEdgeId,
    removeNode,
    removeEdge,
    openContextMenu,
    openNodeConfig,
    showMetrics,
    configNodeId,
    metricsModalOpen,
    requestComposerOpen,
    scenarioGalleryOpen,
    notificationCentreOpen,
    activeTutorialId,
    shortcutsOpen
  ]);

  return (
    <div className="app-shell">
      <div className="menu-bar">
        <strong>Ultimate System Design Simulator</strong>
        <span>Build, simulate, and learn from distributed architectures.</span>
      </div>
      <div className="toolbar" role="toolbar" aria-label="Main toolbar">
        <button
          onClick={() => {
            newProject();
            setActiveScenario(undefined);
            exitTutorial();
          }}
        >
          New
        </button>
        <button
          type="button"
          disabled={isSimulating}
          onClick={openScenarioGallery}
          title="Open a scenario template"
        >
          Templates
        </button>
        <button
          type="button"
          disabled={!activeScenarioId || isSimulating}
          onClick={() => {
            const tutorial = activeScenarioId
              ? getTutorialForScenario(activeScenarioId)
              : undefined;
            if (tutorial) startTutorial(tutorial.id);
          }}
          title={
            activeScenarioId
              ? "Start or resume this scenario's tutorial"
              : "Open a scenario to use its tutorial"
          }
        >
          Tutorial
        </button>
        <button
          type="button"
          onClick={openWelcome}
          title="Show getting-started guidance. Press ? or F1 for keyboard shortcuts."
        >
          Help
        </button>
        <button onClick={() => void handleOpen()}>Open</button>
        <button onClick={() => void handleSave()}>Save</button>
        <button onClick={() => void handleExport()}>Export JSON</button>
        <button onClick={() => void handleDiagramExport()}>Export PNG</button>
        <button onClick={undo}>Undo</button>
        <button onClick={redo}>Redo</button>
        <span className="spacer" />
        <SimulationControls />
        <button type="button" onClick={openRequestComposer}>
          Send requests
        </button>
        <button type="button" onClick={showMetrics} title="View Metrics (Ctrl+M)">
          View Metrics
        </button>
        <button type="button" onClick={showFindings}>
          Findings{findingCount > 0 ? ` (${findingCount})` : ""}
        </button>
        <label className="toolbar-toggle">
          <input
            type="checkbox"
            checked={flowAnimationEnabled}
            onChange={(event) => setFlowAnimationEnabled(event.target.checked)}
          />
          Flow animation
        </label>
        <span className="status-pill">{isDirty ? "Unsaved changes" : "Saved"}</span>
        {autosave.status !== "idle" && (
          <span
            className={`autosave-pill${autosave.status === "error" ? " autosave-pill-error" : ""}`}
            title={
              autosave.lastSavedAt
                ? `Recovery draft last written at ${formatSavedAt(autosave.lastSavedAt)}`
                : undefined
            }
          >
            {AUTOSAVE_LABELS[autosave.status]}
          </span>
        )}
      </div>
      <div className="recovery-slot">
        {autosave.recovered && (
          <div className="recovery-banner" role="status">
            <span>
              Recovered unsaved work from {formatSavedAt(autosave.recovered.savedAt)}. Use Save to
              write it to a project file.
            </span>
            <span className="spacer" />
            <div className="recovery-actions">
              <button type="button" onClick={autosave.dismissRecovery}>
                Keep
              </button>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm("Discard the recovered work and start a new project?")) {
                    autosave.discardRecovery();
                  }
                }}
              >
                Discard
              </button>
            </div>
          </div>
        )}
      </div>
      <div className="main-layout">
        <Palette />
        <ReactFlowProvider>
          <ArchitectureCanvas />
        </ReactFlowProvider>
        <ContextPanel />
      </div>
      <ValidationSummary />
      <div className="playback-bar">
        <PlaybackControls />
      </div>
      <NodeContextMenu />
      <NodeConfigModal />
      <MetricsModal />
      <RequestComposer />
      <ScenarioGallery />
      <WelcomeExperience />
      {shortcutsOpen && <KeyboardShortcutsModal onClose={() => setShortcutsOpen(false)} />}
      <NotificationCentre />
      <FindingToasts />
    </div>
  );
}
