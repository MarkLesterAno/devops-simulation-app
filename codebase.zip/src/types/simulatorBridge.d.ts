/**
 * Renderer-side type mirror of electron/preload/index.ts's exposed bridge.
 * Duplicated (not imported) so the renderer's tsconfig never needs to pull
 * in Electron/Node main-process types.
 */
export interface ProjectApi {
  open(): Promise<{ ok: boolean; error?: string; filePath?: string; data?: unknown }>;
  save(payload: {
    filePath?: string;
    document: unknown;
  }): Promise<{ ok: boolean; error?: string; filePath?: string }>;
  exportJson(payload: { document: unknown }): Promise<{ ok: boolean; error?: string }>;
  recent(): Promise<string[]>;
}

export interface AutosaveApi {
  read(): Promise<{ ok: boolean; error?: string; data?: unknown }>;
  write(payload: { record: unknown }): Promise<{ ok: boolean; error?: string }>;
  clear(): Promise<{ ok: boolean; error?: string }>;
}

export interface SimulatorBridge {
  project: ProjectApi;
  autosave: AutosaveApi;
  platform: string;
  isElectron: true;
}

declare global {
  interface Window {
    simulator?: SimulatorBridge;
  }
}

export {};
