import { useState } from "react";
import type { TechnologyRecommendation } from "@/domain/recommendations/types";
import { GENERIC_TECHNOLOGY_ID } from "@/domain/technology/schema";

function formatDeploymentModel(model: string): string {
  return model.replace(/-/g, " ");
}

interface RecommendationPanelProps {
  recommendations: TechnologyRecommendation[];
  preferOpenSource: boolean;
  preferManagedServices: boolean;
  onTogglePreferOpenSource(value: boolean): void;
  onTogglePreferManagedServices(value: boolean): void;
  onSelect(technologyId: string): void;
  fieldId(key: string): string;
}

/**
 * "Recommended for this component" section of the Implementation tab.
 *
 * Surfaces a short, ranked, explainable shortlist drawn entirely from the
 * existing technology catalog (docs/SCENARIO_TUTORIAL_AND_RECOMMENDATION_PROMPT.md
 * section 6). Selecting a card only pre-fills the manual picker below via the
 * same `onSelect` path a user clicking the dropdown would take — nothing here
 * applies a technology or a simulation preset on its own.
 */
export function RecommendationPanel({
  recommendations,
  preferOpenSource,
  preferManagedServices,
  onTogglePreferOpenSource,
  onTogglePreferManagedServices,
  onSelect,
  fieldId
}: RecommendationPanelProps): JSX.Element | null {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  if (recommendations.length === 0) return null;

  return (
    <section className="tech-recommendations" aria-label="Recommended technologies">
      <div className="tech-recommendations-header">
        <h4 className="tech-recommendations-heading">Recommended for this component</h4>
        <p className="tech-note">
          Educational guidance ranked from the catalog above, not a vendor endorsement or
          procurement advice. Nothing is applied until you choose it explicitly.
        </p>
      </div>

      <div className="tech-preferences" role="group" aria-label="Recommendation preferences">
        <label>
          <input
            id={fieldId("pref-open-source")}
            type="checkbox"
            checked={preferOpenSource}
            onChange={(event) => onTogglePreferOpenSource(event.target.checked)}
          />
          <span>Prefer open-source</span>
        </label>
        <label>
          <input
            id={fieldId("pref-managed")}
            type="checkbox"
            checked={preferManagedServices}
            onChange={(event) => onTogglePreferManagedServices(event.target.checked)}
          />
          <span>Prefer managed services</span>
        </label>
      </div>

      <ol className="tech-recommendation-list">
        {recommendations.map((recommendation) => {
          const isExpanded = expandedId === recommendation.technologyId;
          return (
            <li className="tech-recommendation-card" key={recommendation.technologyId}>
              <div className="tech-recommendation-header">
                <span className="tech-recommendation-rank">#{recommendation.rank}</span>
                <span className="tech-recommendation-name">
                  {recommendation.displayName} — {recommendation.provider}
                </span>
                <span className="tech-recommendation-score" title="Contextual match score">
                  {recommendation.matchScore}% match
                </span>
              </div>

              <p className="tech-recommendation-rationale">{recommendation.rationale}</p>

              <div className="tech-badges">
                {recommendation.deploymentModel.map((model) => (
                  <span className="tech-badge tech-badge-deployment" key={model}>
                    {formatDeploymentModel(model)}
                  </span>
                ))}
                {recommendation.hasSimulationPreset && (
                  <span className="tech-badge">has simulation preset</span>
                )}
              </div>

              {recommendation.warnings.map((warning) => (
                <p className="tech-warning" role="status" key={warning}>
                  ⚠ {warning}
                </p>
              ))}

              <div className="tech-actions">
                <button type="button" onClick={() => onSelect(recommendation.technologyId)}>
                  Use this technology
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setExpandedId(isExpanded ? null : recommendation.technologyId)
                  }
                  aria-expanded={isExpanded}
                >
                  {isExpanded ? "Hide details" : "Strengths & trade-offs"}
                </button>
              </div>

              {isExpanded && (
                <div className="tech-recommendation-details">
                  <p className="tech-recommendation-subheading">Strengths</p>
                  <ul>
                    {recommendation.strengths.map((strength) => (
                      <li key={strength}>{strength}</li>
                    ))}
                  </ul>
                  <p className="tech-recommendation-subheading">Trade-offs</p>
                  <ul>
                    {recommendation.tradeOffs.map((tradeOff) => (
                      <li key={tradeOff}>{tradeOff}</li>
                    ))}
                  </ul>
                  <p className="tech-recommendation-subheading">Typical use cases</p>
                  <ul>
                    {recommendation.typicalUseCases.map((useCase) => (
                      <li key={useCase}>{useCase}</li>
                    ))}
                  </ul>
                </div>
              )}
            </li>
          );
        })}
      </ol>

      <button type="button" onClick={() => onSelect(GENERIC_TECHNOLOGY_ID)} className="tech-note">
        None of these — keep Generic / Custom Implementation
      </button>
    </section>
  );
}