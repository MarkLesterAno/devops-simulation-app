import { useId, useMemo, useState } from "react";
import type { ArchitectureNode } from "@/domain/architecture/schema";
import { useProjectStore } from "@/stores/projectStore";
import { useRecommendationPreferencesStore } from "@/stores/recommendationPreferencesStore";
import {
  getConnectedNodeTypes,
  getExistingTechnologyAssignments
} from "@/domain/recommendations/context";
import { recommendTechnologies } from "@/domain/recommendations/engine";
import { getScenarioTemplate } from "@/domain/scenarios/registry";
import { useUiStore } from "@/stores/uiStore";
import { RecommendationPanel } from "@/features/inspector/RecommendationPanel";
import {
  filterTechnologies,
  getAdvisoriesForRole,
  getCapabilitiesForRole,
  getProviders,
  getTechnologiesForComponentType,
  resolveTechnologyAssignment,
  toTechnologyAssignment
} from "@/domain/technology/registry";
import {
  GENERIC_TECHNOLOGY_ID,
  deploymentModelSchema,
  type DeploymentModel,
  type SimulationPreset,
  type TechnologyOption
} from "@/domain/technology/schema";
import { buildPresetPatch, diffPreset, type PresetFieldChange } from "@/domain/technology/presets";

const DEPLOYMENT_MODELS = deploymentModelSchema.options;

const STATUS_LABELS: Record<string, string> = {
  legacy: "Legacy",
  deprecated: "Deprecated"
};

function formatDeploymentModel(model: DeploymentModel): string {
  return model.replace(/-/g, " ");
}

/**
 * "Implementation" section of the node inspector.
 *
 * Lets the user tag a component with the real-world product they intend to use.
 * This is educational metadata: nothing here performs network calls, credential
 * prompts, or provisioning, and simulation runs identically whether or not a
 * technology is selected.
 */
export function TechnologySelector({ node }: { node: ArchitectureNode }): JSX.Element {
  const setNodeTechnology = useProjectStore((state) => state.setNodeTechnology);
  const updateNodeConfig = useProjectStore((state) => state.updateNodeConfig);

  // The selector can be mounted in the sidebar and the configuration modal at
  // the same time, so field ids must be unique per instance.
  const instanceId = useId();
  const fieldId = (key: string): string => `${instanceId}-${key}`;

  const [search, setSearch] = useState("");
  const [provider, setProvider] = useState("");
  const [deploymentModel, setDeploymentModel] = useState<"" | DeploymentModel>("");
  const [pendingPreset, setPendingPreset] = useState<{
    option: TechnologyOption;
    changes: PresetFieldChange[];
    accepted: Set<keyof SimulationPreset>;
  } | null>(null);

  const document = useProjectStore((state) => state.document);
  const activeScenarioId = useUiStore((state) => state.activeScenarioId);
  const scenario = activeScenarioId ? getScenarioTemplate(activeScenarioId) : undefined;
  const preferOpenSource = useRecommendationPreferencesStore((state) => state.preferOpenSource);
  const preferManagedServices = useRecommendationPreferencesStore(
    (state) => state.preferManagedServices
  );
  const preferredProviders = useRecommendationPreferencesStore((state) => state.preferredProviders);
  const setPreferOpenSource = useRecommendationPreferencesStore((state) => state.setPreferOpenSource);
  const setPreferManagedServices = useRecommendationPreferencesStore(
    (state) => state.setPreferManagedServices
  );

  // Recommendations reuse the same catalog as the manual picker below; they
  // never add or auto-apply a technology, they only reorder and annotate it.
  const recommendations = useMemo(
    () =>
      recommendTechnologies({
        componentType: node.type,
        nodeConfiguration: node.config,
        workloadCharacteristics: scenario?.metadata.workloadShapes ?? [],
        connectedNodeTypes: getConnectedNodeTypes(document, node.id),
        existingTechnologyAssignments: getExistingTechnologyAssignments(document, node.id),
        scenarioDomain: scenario?.metadata.tags.join(" "),
        scenarioDifficulty: scenario?.metadata.difficulty,
        userPreferences: { preferOpenSource, preferManagedServices, preferredProviders }
      }),
    [
      node.type,
      node.config,
      node.id,
      document,
      scenario,
      preferOpenSource,
      preferManagedServices,
      preferredProviders
    ]
  );

  const compatibleOptions = useMemo(
    () => getTechnologiesForComponentType(node.type),
    [node.type]
  );
  const providers = useMemo(() => getProviders(compatibleOptions), [compatibleOptions]);
  const visibleOptions = useMemo(
    () =>
      filterTechnologies(compatibleOptions, {
        search,
        provider: provider || undefined,
        deploymentModel: deploymentModel || undefined
      }),
    [compatibleOptions, search, provider, deploymentModel]
  );

  const assignment = node.config.technology;
  const resolution = resolveTechnologyAssignment(assignment, node.type);
  const selectedId = assignment?.id ?? GENERIC_TECHNOLOGY_ID;

  // A saved selection can fall outside the active filters; keep it listed so the
  // dropdown never silently appears to lose the user's choice.
  const selectableOptions = useMemo(() => {
    if (resolution.state !== "known") return visibleOptions;
    if (visibleOptions.some((option) => option.id === resolution.option.id)) return visibleOptions;
    return [resolution.option, ...visibleOptions];
  }, [visibleOptions, resolution]);

  function handleSelect(nextId: string): void {
    setPendingPreset(null);
    if (nextId === GENERIC_TECHNOLOGY_ID) {
      setNodeTechnology(node.id, undefined);
      return;
    }
    const option = compatibleOptions.find((entry) => entry.id === nextId);
    if (!option) return;
    setNodeTechnology(node.id, toTechnologyAssignment(option));
  }

  function handleOpenPreset(option: TechnologyOption): void {
    if (!option.simulationPreset) return;
    const changes = diffPreset(node.config, option.simulationPreset);
    setPendingPreset({
      option,
      changes,
      accepted: new Set(changes.map((change) => change.key))
    });
  }

  function handleApplyPreset(): void {
    if (!pendingPreset?.option.simulationPreset) return;
    const patch = buildPresetPatch(
      pendingPreset.option.simulationPreset,
      [...pendingPreset.accepted]
    );
    if (Object.keys(patch).length > 0) {
      updateNodeConfig(node.id, patch);
    }
    setPendingPreset(null);
  }

  function togglePresetField(key: keyof SimulationPreset): void {
    setPendingPreset((current) => {
      if (!current) return current;
      const accepted = new Set(current.accepted);
      if (accepted.has(key)) accepted.delete(key);
      else accepted.add(key);
      return { ...current, accepted };
    });
  }

  const activeOption = resolution.state === "known" ? resolution.option : undefined;
  const roleCapabilities = activeOption
    ? getCapabilitiesForRole(activeOption, node.type)
    : [];
  const roleAdvisories = activeOption ? getAdvisoriesForRole(activeOption, node.type) : [];

  return (
    <section className="tech-section" aria-label="Implementation">
      <h3 className="tech-heading">Implementation</h3>
      <p className="tech-note">
        Educational metadata only — selecting a product never creates or contacts real
        infrastructure, and simulation results are unaffected.
      </p>

      <RecommendationPanel
        recommendations={recommendations}
        preferOpenSource={preferOpenSource}
        preferManagedServices={preferManagedServices}
        onTogglePreferOpenSource={setPreferOpenSource}
        onTogglePreferManagedServices={setPreferManagedServices}
        onSelect={handleSelect}
        fieldId={fieldId}
      />

      <div className="field">
        <label htmlFor={fieldId("tech-search")}>Search technologies</label>
        <input
          id={fieldId("tech-search")}
          value={search}
          placeholder="Search by name, provider, or capability…"
          onChange={(event) => setSearch(event.target.value)}
        />
      </div>

      <div className="tech-filters">
        <div className="field">
          <label htmlFor={fieldId("tech-provider")}>Provider</label>
          <select
            id={fieldId("tech-provider")}
            value={provider}
            onChange={(event) => setProvider(event.target.value)}
          >
            <option value="">All providers</option>
            {providers.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>
        <div className="field">
          <label htmlFor={fieldId("tech-deployment")}>Deployment</label>
          <select
            id={fieldId("tech-deployment")}
            value={deploymentModel}
            onChange={(event) => setDeploymentModel(event.target.value as "" | DeploymentModel)}
          >
            <option value="">All models</option>
            {DEPLOYMENT_MODELS.map((model) => (
              <option key={model} value={model}>
                {formatDeploymentModel(model)}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="field">
        <label htmlFor={fieldId("tech-select")}>Technology</label>
        <select
          id={fieldId("tech-select")}
          value={selectedId}
          onChange={(event) => handleSelect(event.target.value)}
        >
          <option value={GENERIC_TECHNOLOGY_ID}>Generic / Custom Implementation</option>
          {selectableOptions.map((option) => (
            <option key={option.id} value={option.id}>
              {option.displayName} — {option.provider}
              {option.status !== "current" ? ` (${STATUS_LABELS[option.status]})` : ""}
            </option>
          ))}
        </select>
        <span className="tech-count">
          {visibleOptions.length} of {compatibleOptions.length} compatible
        </span>
      </div>

      {resolution.state === "unknown" && (
        <p className="tech-warning" role="status">
          ⚠ This project references an unknown technology
          {` "${resolution.assignment.displayName}"`} that is not in the current catalog. The
          component still simulates using its generic configuration.
        </p>
      )}

      {resolution.state === "known" && !resolution.compatible && (
        <p className="tech-warning" role="status">
          ⚠ {resolution.option.displayName} is not listed as compatible with this component
          type. The saved selection has been preserved.
        </p>
      )}

      {activeOption && (
        <div className="tech-details">
          <p className="tech-description">{activeOption.description}</p>

          {activeOption.status !== "current" && (
            <p className="tech-warning" role="status">
              ⚠ {STATUS_LABELS[activeOption.status]} technology.
            </p>
          )}

          {roleAdvisories.map((advisory) => (
            <p className="tech-advisory" key={advisory.message}>
              ⚠ {advisory.message}
            </p>
          ))}

          <div className="tech-badges">
            {activeOption.deploymentModel.map((model) => (
              <span className="tech-badge tech-badge-deployment" key={model}>
                {formatDeploymentModel(model)}
              </span>
            ))}
            {roleCapabilities.map((capability) => (
              <span className="tech-badge" key={capability}>
                {capability.replace(/-/g, " ")}
              </span>
            ))}
          </div>

          <div className="tech-actions">
            {activeOption.simulationPreset && (
              <button type="button" onClick={() => handleOpenPreset(activeOption)}>
                Apply simulation preset
              </button>
            )}
            <button type="button" onClick={() => handleSelect(GENERIC_TECHNOLOGY_ID)}>
              Reset to generic
            </button>
            {activeOption.documentationUrl && (
              <a
                className="tech-doc-link"
                href={activeOption.documentationUrl}
                target="_blank"
                rel="noreferrer noopener"
              >
                Official documentation ↗
              </a>
            )}
          </div>
        </div>
      )}

      {pendingPreset && (
        <div className="tech-preset-dialog" role="dialog" aria-label="Confirm simulation preset">
          <h4>Apply preset from {pendingPreset.option.displayName}</h4>
          <p className="tech-note">
            Educational defaults for teaching trade-offs — not vendor benchmarks or performance
            guarantees. Preset model version {pendingPreset.option.modelVersion}.
          </p>
          {pendingPreset.changes.length === 0 ? (
            <p className="tech-note">
              This preset matches the current configuration; nothing would change.
            </p>
          ) : (
            <ul className="tech-preset-changes">
              {pendingPreset.changes.map((change) => (
                <li key={change.key}>
                  <label>
                    <input
                      type="checkbox"
                      checked={pendingPreset.accepted.has(change.key)}
                      onChange={() => togglePresetField(change.key)}
                    />
                    <span>
                      {change.label}: {change.currentValue} → <strong>{change.nextValue}</strong>
                    </span>
                  </label>
                </li>
              ))}
            </ul>
          )}
          <div className="tech-actions">
            <button
              type="button"
              onClick={handleApplyPreset}
              disabled={pendingPreset.accepted.size === 0}
            >
              Apply selected
            </button>
            <button type="button" onClick={() => setPendingPreset(null)}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
