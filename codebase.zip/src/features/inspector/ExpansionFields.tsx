import { useId } from "react";
import type { ArchitectureNode, ComponentType } from "@/domain/architecture/schema";

/**
 * Inspector controls for the Priority 1 catalog expansion. Declared as data so
 * every control stays keyboard-operable and renders through the same markup as
 * the shared fields (AC-AX-01).
 */

interface NumberField {
  kind: "number";
  key: string;
  label: string;
  min?: number;
  max?: number;
  step?: number;
  fallback: number;
  hint?: string;
}

interface SelectField {
  kind: "select";
  key: string;
  label: string;
  options: Array<{ value: string; label: string }>;
  fallback: string;
  hint?: string;
}

interface TextField {
  kind: "text";
  key: string;
  label: string;
  fallback: string;
  hint?: string;
}

interface BooleanField {
  kind: "boolean";
  key: string;
  label: string;
  fallback: boolean;
  hint?: string;
}

type ExpansionField = NumberField | SelectField | TextField | BooleanField;

const FIELDS_BY_TYPE: Partial<Record<ComponentType, ExpansionField[]>> = {
  "api-gateway": [
    { kind: "number", key: "policyLatencyMs", label: "Policy latency (ms)", min: 0, fallback: 3 },
    {
      kind: "select",
      key: "authMode",
      label: "Authentication mode",
      fallback: "none",
      hint: "Delegate requires an outgoing edge to an Identity & Auth Service.",
      options: [
        { value: "none", label: "None" },
        { value: "validate-local", label: "Validate locally" },
        { value: "delegate", label: "Delegate to identity service" }
      ]
    },
    {
      kind: "number",
      key: "rateLimitRps",
      label: "Rate limit (RPS)",
      min: 0,
      fallback: 0,
      hint: "0 disables quota enforcement."
    },
    { kind: "number", key: "rateLimitBurst", label: "Rate limit burst", min: 0, fallback: 0 }
  ],
  "dns-traffic-manager": [
    {
      kind: "number",
      key: "ttlSeconds",
      label: "TTL (seconds)",
      min: 0,
      fallback: 60,
      hint: "A cached answer is reused for its TTL, which sets a floor on failover time."
    },
    { kind: "number", key: "resolutionLatencyMs", label: "Resolution latency (ms)", min: 0, fallback: 20 },
    {
      kind: "select",
      key: "policy",
      label: "Resolution policy",
      fallback: "failover",
      options: [
        { value: "failover", label: "Failover (first healthy target)" },
        { value: "weighted", label: "Weighted" },
        { value: "latency", label: "Lowest latency" },
        { value: "geo", label: "Geographic" }
      ]
    }
  ],
  "nosql-database": [
    {
      kind: "select",
      key: "model",
      label: "Data model",
      fallback: "key-value",
      options: [
        { value: "key-value", label: "Key-value" },
        { value: "document", label: "Document" },
        { value: "wide-column", label: "Wide column" },
        { value: "time-series", label: "Time series" },
        { value: "graph", label: "Graph" },
        { value: "vector", label: "Vector" }
      ]
    },
    {
      kind: "select",
      key: "consistency",
      label: "Consistency",
      fallback: "eventual",
      hint: "Strong consistency requires zero replication lag.",
      options: [
        { value: "eventual", label: "Eventual (reads may be stale)" },
        { value: "quorum", label: "Quorum (slower, not stale)" },
        { value: "strong", label: "Strong (no lag permitted)" }
      ]
    },
    { kind: "number", key: "partitionCount", label: "Partition count", min: 1, fallback: 4 },
    {
      kind: "number",
      key: "hotPartitionSkew",
      label: "Hot partition skew",
      min: 0,
      max: 1,
      step: 0.05,
      fallback: 0,
      hint: "Share of operations forced onto a single partition. 0 is uniform."
    },
    { kind: "number", key: "replicationLagMs", label: "Replication lag (ms)", min: 0, fallback: 50 }
  ],
  "event-topic": [
    {
      kind: "number",
      key: "retentionMs",
      label: "Retention (ms)",
      min: 0,
      fallback: 3_600_000,
      hint: "Each outgoing worker edge is an independent subscriber group."
    },
    { kind: "number", key: "partitionCount", label: "Partition count", min: 1, fallback: 1 },
    {
      kind: "select",
      key: "orderingScope",
      label: "Ordering scope",
      fallback: "none",
      options: [
        { value: "none", label: "None" },
        { value: "partition", label: "Per partition" }
      ]
    }
  ],
  "identity-auth-service": [
    {
      kind: "select",
      key: "mode",
      label: "Mode",
      fallback: "authn",
      options: [
        { value: "authn", label: "Authentication" },
        { value: "authz", label: "Authorization" },
        { value: "both", label: "Both" }
      ]
    },
    {
      kind: "select",
      key: "validationMode",
      label: "Validation mode",
      fallback: "local-jwt",
      options: [
        { value: "local-jwt", label: "Local token validation" },
        { value: "introspection", label: "Remote introspection" }
      ]
    },
    { kind: "number", key: "tokenTtlMs", label: "Token TTL (ms)", min: 0, fallback: 300_000 },
    { kind: "number", key: "cacheHitRatio", label: "Token cache hit ratio", min: 0, max: 1, step: 0.01, fallback: 0.9 },
    { kind: "number", key: "verificationLatencyMs", label: "Verification latency (ms)", min: 0, fallback: 8 },
    {
      kind: "select",
      key: "failMode",
      label: "Fail mode",
      fallback: "fail-closed",
      hint: "Fail-open admits unverified requests when this component is down and records a security finding.",
      options: [
        { value: "fail-closed", label: "Fail closed (reject when unavailable)" },
        { value: "fail-open", label: "Fail open (admit when unavailable)" }
      ]
    }
  ],
  "external-service": [
    {
      kind: "text",
      key: "providerLabel",
      label: "Provider label",
      fallback: "Third-party provider",
      hint: "Display metadata only. Never used to contact anything."
    },
    { kind: "number", key: "slaLatencyMs", label: "Provider latency (ms)", min: 0, fallback: 250 },
    {
      kind: "number",
      key: "providerRateLimitRps",
      label: "Provider rate limit (RPS)",
      min: 0,
      fallback: 0,
      hint: "0 disables provider-side throttling."
    },
    { kind: "boolean", key: "idempotencySupported", label: "Idempotent retries supported", fallback: false },
    {
      kind: "select",
      key: "callMode",
      label: "Call mode",
      fallback: "sync",
      options: [
        { value: "sync", label: "Synchronous" },
        { value: "async-callback", label: "Asynchronous callback" }
      ]
    }
  ]
};

export function ExpansionFields({
  node,
  onChange
}: {
  node: ArchitectureNode;
  onChange: (nodeId: string, patch: Record<string, unknown>) => void;
}): JSX.Element | null {
  const fields = FIELDS_BY_TYPE[node.type];
  const instanceId = useId();
  if (!fields) return null;
  const config = node.config as Record<string, unknown>;
  const fieldId = (key: string): string => `${instanceId}-${key}`;

  return (
    <>
      {fields.map((field) => (
        <div className="field" key={field.key}>
          <label htmlFor={fieldId(field.key)}>{field.label}</label>
          {field.kind === "number" ? (
            <input
              id={fieldId(field.key)}
              type="number"
              min={field.min}
              max={field.max}
              step={field.step ?? 1}
              value={Number(config[field.key] ?? field.fallback)}
              onChange={(event) => onChange(node.id, { [field.key]: Number(event.target.value) })}
            />
          ) : null}
          {field.kind === "select" ? (
            <select
              id={fieldId(field.key)}
              value={String(config[field.key] ?? field.fallback)}
              onChange={(event) => onChange(node.id, { [field.key]: event.target.value })}
            >
              {field.options.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          ) : null}
          {field.kind === "text" ? (
            <input
              id={fieldId(field.key)}
              value={String(config[field.key] ?? field.fallback)}
              onChange={(event) => onChange(node.id, { [field.key]: event.target.value })}
            />
          ) : null}
          {field.kind === "boolean" ? (
            <input
              id={fieldId(field.key)}
              type="checkbox"
              checked={Boolean(config[field.key] ?? field.fallback)}
              onChange={(event) => onChange(node.id, { [field.key]: event.target.checked })}
            />
          ) : null}
          {field.hint ? (
            <p style={{ fontSize: 11, color: "var(--color-text-dim)", margin: "2px 0 0" }}>
              {field.hint}
            </p>
          ) : null}
        </div>
      ))}
    </>
  );
}
