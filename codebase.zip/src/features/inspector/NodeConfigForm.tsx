import { useEffect, useId, useState } from "react";
import { useProjectStore } from "@/stores/projectStore";
import { TechnologySelector } from "@/features/inspector/TechnologySelector";
import { ExpansionFields } from "@/features/inspector/ExpansionFields";
import {
  baseComponentConfigSchema,
  type ArchitectureNode
} from "@/domain/architecture/schema";

const NUMERIC_FIELDS: Array<{
  key: string;
  label: string;
  min?: number;
  max?: number;
  step?: number;
}> = [
  { key: "instanceCount", label: "Instance count", min: 1 },
  { key: "perInstanceCapacityRps", label: "Per-instance capacity (req/s)", min: 0 },
  { key: "baseLatencyMs", label: "Base latency (ms)", min: 0 },
  { key: "jitterMs", label: "Jitter (ms)", min: 0 },
  { key: "timeoutMs", label: "Timeout (ms)", min: 1 },
  { key: "errorRate", label: "Error rate (0–1)", min: 0, max: 1, step: 0.01 },
  { key: "maxQueueDepth", label: "Max queue depth", min: 0 },
  { key: "maxRetries", label: "Max retries", min: 0, max: 10 },
  { key: "retryBackoffMs", label: "Retry backoff (ms)", min: 0 },
  { key: "estimatedCostPerHour", label: "Estimated cost / hour ($)", min: 0 }
];

/**
 * The editable configuration form for one node.
 *
 * Shared by the persistent sidebar inspector and the node configuration
 * modal's Inspector tab so both always expose exactly the same fields.
 * Field ids are namespaced per instance because both surfaces can be mounted
 * at once and duplicate ids would break label association.
 */
export function NodeConfigForm({
  node,
  includeTechnology = true
}: {
  node: ArchitectureNode;
  includeTechnology?: boolean;
}): JSX.Element {
  const updateNodeConfig = useProjectStore((state) => state.updateNodeConfig);
  const instanceId = useId();
  const fieldId = (key: string): string => `${instanceId}-${key}`;
  const [draftValues, setDraftValues] = useState<Record<string, string>>({});
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    setDraftValues({});
    setFieldErrors({});
  }, [node.id]);

  function updateValidatedField(key: string, rawValue: string, value: unknown): void {
    setDraftValues((current) => ({ ...current, [key]: rawValue }));
    if (rawValue.trim() === "") {
      setFieldErrors((current) => ({ ...current, [key]: "A value is required." }));
      return;
    }

    const result = baseComponentConfigSchema.safeParse({ ...node.config, [key]: value });
    const issue = result.success
      ? undefined
      : result.error.issues.find((candidate) => candidate.path[0] === key);
    if (issue) {
      setFieldErrors((current) => ({ ...current, [key]: issue.message }));
      return;
    }

    setDraftValues((current) => {
      const next = { ...current };
      delete next[key];
      return next;
    });
    setFieldErrors((current) => {
      const next = { ...current };
      delete next[key];
      return next;
    });
    updateNodeConfig(node.id, { [key]: value });
  }

  return (
    <>
      <div className="field">
        <label htmlFor={fieldId("displayName")}>Display name</label>
        <input
          id={fieldId("displayName")}
          value={draftValues.displayName ?? String(node.config.displayName)}
          aria-invalid={Boolean(fieldErrors.displayName)}
          aria-describedby={fieldErrors.displayName ? `${fieldId("displayName")}-error` : undefined}
          onChange={(event) =>
            updateValidatedField("displayName", event.target.value, event.target.value)
          }
        />
        {fieldErrors.displayName && <p id={`${fieldId("displayName")}-error`} className="field-error" role="alert">{fieldErrors.displayName}</p>}
      </div>
      <div className="field">
        <label htmlFor={fieldId("region")}>Region</label>
        <input
          id={fieldId("region")}
          value={draftValues.region ?? String(node.config.region)}
          aria-invalid={Boolean(fieldErrors.region)}
          aria-describedby={fieldErrors.region ? `${fieldId("region")}-error` : undefined}
          onChange={(event) => updateValidatedField("region", event.target.value, event.target.value)}
        />
        {fieldErrors.region && <p id={`${fieldId("region")}-error`} className="field-error" role="alert">{fieldErrors.region}</p>}
      </div>
      <div className="field">
        <label htmlFor={fieldId("overflowBehavior")}>Overflow behavior</label>
        <select
          id={fieldId("overflowBehavior")}
          value={String(node.config.overflowBehavior)}
          onChange={(event) => updateNodeConfig(node.id, { overflowBehavior: event.target.value })}
        >
          <option value="queue">Queue</option>
          <option value="reject">Reject</option>
          <option value="shed-load">Shed load</option>
          <option value="penalty">Penalty</option>
        </select>
      </div>
      {NUMERIC_FIELDS.map((field) => (
        <div className="field" key={field.key}>
          <label htmlFor={fieldId(field.key)}>{field.label}</label>
          <input
            id={fieldId(field.key)}
            type="number"
            min={field.min}
            max={field.max}
            step={field.step ?? 1}
            value={draftValues[field.key] ?? String(node.config[field.key] ?? 0)}
            aria-invalid={Boolean(fieldErrors[field.key])}
            aria-describedby={fieldErrors[field.key] ? `${fieldId(field.key)}-error` : undefined}
            onChange={(event) => {
              const rawValue = event.target.value;
              updateValidatedField(field.key, rawValue, Number(rawValue));
            }}
          />
          {fieldErrors[field.key] && <p id={`${fieldId(field.key)}-error`} className="field-error" role="alert">{fieldErrors[field.key]}</p>}
        </div>
      ))}
      {node.type === "cache" || node.type === "cdn" ? (
        <div className="field">
          <label htmlFor={fieldId("hitRatio")}>Hit ratio</label>
          <input
            id={fieldId("hitRatio")}
            type="number"
            min={0}
            max={1}
            step={0.01}
            value={Number(node.config["hitRatio"] ?? 0.8)}
            onChange={(event) => updateNodeConfig(node.id, { hitRatio: Number(event.target.value) })}
          />
        </div>
      ) : null}
      <ExpansionFields node={node} onChange={updateNodeConfig} />
      {includeTechnology && node.type !== "client" ? <TechnologySelector node={node} /> : null}
    </>
  );
}
