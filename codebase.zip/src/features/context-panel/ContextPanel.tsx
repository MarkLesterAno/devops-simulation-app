import { useEffect, useState } from "react";
import { useProjectStore } from "@/stores/projectStore";
import { useUiStore, type ContextPanelTab } from "@/stores/uiStore";
import { getScenarioTemplate } from "@/domain/scenarios/registry";
import { NodeConfigForm } from "@/features/inspector/NodeConfigForm";
import { useToastStore } from "@/stores/toastStore";
import { resultFreshness } from "@/domain/architecture/projectAnalysis";
import { rollupComponentMetrics } from "@/features/metrics/componentRollup";

const TABS: Array<{ id: ContextPanelTab; label: string }> = [
  { id: "objectives", label: "Objectives" },
  { id: "inspector", label: "Inspector" },
  { id: "metrics", label: "Metrics" },
  { id: "findings", label: "Findings" }
];

function useCompactContext(): boolean {
  const [compact, setCompact] = useState(
    () =>
      typeof window.matchMedia === "function" &&
      window.matchMedia("(max-width: 1280px)").matches
  );

  useEffect(() => {
    if (typeof window.matchMedia !== "function") return;
    const mediaQuery = window.matchMedia("(max-width: 1280px)");
    const update = (): void => setCompact(mediaQuery.matches);
    update();
    mediaQuery.addEventListener("change", update);
    return () => mediaQuery.removeEventListener("change", update);
  }, []);

  return compact;
}

/** Persistent, non-modal learning context so evidence stays beside topology. */
export function ContextPanel(): JSX.Element | null {
  const open = useUiStore((state) => state.contextPanelOpen);
  const tab = useUiStore((state) => state.contextPanelTab);
  const setTab = useUiStore((state) => state.setContextPanelTab);
  const openPanel = useUiStore((state) => state.openContextPanel);
  const closePanel = useUiStore((state) => state.closeContextPanel);
  const scenarioId = useUiStore((state) => state.activeScenarioId);
  const scenarioMode = useUiStore((state) => state.activeScenarioMode);
  const selectedNodeId = useProjectStore((state) => state.selectedNodeId);
  const document_ = useProjectStore((state) => state.document);
  const node = document_.nodes.find((item) => item.id === selectedNodeId);
  const result = useProjectStore((state) => state.lastResult);
  const lastResultSignature = useProjectStore((state) => state.lastResultSignature);
  const findings = useToastStore((state) => state.history);
  const scenario = scenarioId ? getScenarioTemplate(scenarioId) : undefined;
  const compact = useCompactContext();
  const freshness = resultFreshness(result, document_, lastResultSignature);

  useEffect(() => {
    if (selectedNodeId && open && tab === "objectives") setTab("inspector");
  }, [selectedNodeId, open, tab, setTab]);

  // Compact workspaces use toolbar/modal and notification-centre fallbacks.
  // Rendering no narrow rail avoids a control that looks expandable but has no body.
  if (compact) return null;

  if (!open) {
    return (
      <aside className="context-panel context-panel-collapsed" aria-label="Open context panel">
        <button type="button" onClick={() => openPanel(tab)} aria-label="Open context panel">
          ‹
        </button>
      </aside>
    );
  }

  return (
    <aside className="context-panel" aria-label="Architecture context panel">
      <header>
        <strong>Context</strong>
        <button type="button" onClick={closePanel} aria-label="Collapse context panel">
          ›
        </button>
      </header>
      <div className="context-tabs" role="tablist" aria-label="Context panel">
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            role="tab"
            aria-selected={tab === item.id}
            onClick={() => setTab(item.id)}
          >
            {item.label}
          </button>
        ))}
      </div>
      <div className="context-body">
        {tab === "objectives" &&
          (scenario ? (
            <>
              <h2>{scenario.metadata.name}</h2>
              <p>{scenario.metadata.summary}</p>
              <h3>{scenarioMode === "guided-tour" ? "Learning objectives" : "Build brief"}</h3>
              {scenarioMode === "guided-tour" ? (
                <ul>
                  {scenario.metadata.learningObjectives.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              ) : (
                <>
                  <p>
                    Build a valid architecture that can meet the selected traffic profile and explain
                    its trade-offs. The reference solution is one example, not the only correct design.
                  </p>
                  <h4>Constraints</h4>
                  <ul>
                    {scenario.metadata.modelledProperties.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                  <h4>Out of scope</h4>
                  <ul>
                    {scenario.metadata.simplifications.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </>
              )}
              <h3>Model limits</h3>
              <ul>
                {scenario.metadata.simplifications.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </>
          ) : (
            <p className="empty-state">
              Open a scenario to keep its objectives and model limits beside the canvas.
            </p>
          ))}
        {tab === "inspector" &&
          (node ? (
            <>
              <h2>{node.config.displayName}</h2>
              <NodeConfigForm node={node} />
            </>
          ) : (
            <p className="empty-state">Select a component to configure its simulation settings.</p>
          ))}
        {tab === "metrics" &&
          (result?.summary ? (
            <>
              <h2>Run summary</h2>
              {freshness !== "current" && (
                <span className="stale-badge" role="status">
                  {freshness === "simulation-model-changed"
                    ? "Stale — simulation model changed"
                    : "Stale — architecture changed since this run"}
                </span>
              )}
              <Metric label="Requests" value={result.summary.requestCount.toLocaleString()} />
              <Metric label="p95 latency" value={`${result.summary.latency.p95.toFixed(0)} ms`} />
              <Metric label="Error rate" value={`${(result.summary.errorRate * 100).toFixed(1)}%`} />
              <h3>Component peaks</h3>
              <ul>
                {rollupComponentMetrics(result.componentMetrics).map((metric) => (
                  <li key={metric.nodeId}>
                    {document_.nodes.find((item) => item.id === metric.nodeId)?.config.displayName ??
                      metric.nodeId}
                    : {(metric.peakUtilization * 100).toFixed(0)}% utilisation ·{" "}
                    {metric.peakLatencyMs.toFixed(0)} ms
                  </li>
                ))}
              </ul>
            </>
          ) : (
            <p className="empty-state">Run a simulation to see metrics without hiding the architecture.</p>
          ))}
        {tab === "findings" &&
          (findings.length > 0 ? (
            <ul className="context-findings">
              {findings.map((finding) => (
                <li key={finding.id}>
                  <strong>{finding.title}</strong>
                  <span>{finding.detail}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="empty-state">Run a simulation to see findings and recommendations.</p>
          ))}
      </div>
    </aside>
  );
}

function Metric({ label, value }: { label: string; value: string }): JSX.Element {
  return (
    <div className="metric-row">
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}
