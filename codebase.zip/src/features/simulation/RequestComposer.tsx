import { useMemo, useState } from "react";
import { useProjectStore } from "@/stores/projectStore";
import { useUiStore } from "@/stores/uiStore";
import { requiredDurationMs, useRequestStore } from "@/stores/requestStore";
import {
  batchDurationMs,
  httpMethodSchema,
  requestClassSchema,
  MAX_MANUAL_DISPATCH_RPS,
  MAX_MANUAL_REQUEST_COUNT,
  type HttpMethod,
  type ManualRequestDefinition,
  type RequestClass
} from "@/domain/simulation/manualRequest";
import { ModalShell } from "@/features/modals/ModalShell";
import { getScenarioRequestPresets } from "@/domain/scenarios/registry";
import { toManualRequestDefinition, type ScenarioRequestPreset } from "@/domain/scenarios/requestPresets";

const METHODS = httpMethodSchema.options;
const CLASSES = requestClassSchema.options;

const CLASS_LABELS: Record<RequestClass, string> = {
  read: "Read",
  write: "Write",
  "auth-required": "Requires authentication"
};

/**
 * Manual request composer, per
 * LIVE_PLAYBACK_AND_REQUEST_SIMULATION_PROMPT.md section 5.
 *
 * Nothing here touches the network. A batch is translated into logical arrival
 * events inside the deterministic engine, exactly as traffic-profile load is,
 * so "send 1,000 PUTs" means "simulate 1,000 PUT arrivals".
 */
export function RequestComposer(): JSX.Element | null {
  const open = useUiStore((state) => state.requestComposerOpen);
  const close = useUiStore((state) => state.closeRequestComposer);
  const document_ = useProjectStore((state) => state.document);
  const batches = useRequestStore((state) => state.batches);
  const addBatch = useRequestStore((state) => state.addBatch);
  const removeBatch = useRequestStore((state) => state.removeBatch);
  const suppressProfileTraffic = useRequestStore((state) => state.suppressProfileTraffic);
  const setSuppressProfileTraffic = useRequestStore((state) => state.setSuppressProfileTraffic);
  const activeScenarioId = useUiStore((state) => state.activeScenarioId);

  const origins = useMemo(
    () => document_.nodes.filter((node) => node.type === "client"),
    [document_.nodes]
  );

  const [sourceNodeId, setSourceNodeId] = useState("");
  const [method, setMethod] = useState<HttpMethod>("GET");
  const [requestCount, setRequestCount] = useState(100);
  const [dispatchRateRps, setDispatchRateRps] = useState(50);
  const [startAtMs, setStartAtMs] = useState(0);
  const [path, setPath] = useState("");
  const [requestClass, setRequestClass] = useState<RequestClass | "">("");
  const [payloadSizeBytes, setPayloadSizeBytes] = useState("");
  const [responseSizeBytes, setResponseSizeBytes] = useState("");
  const [timeoutMs, setTimeoutMs] = useState("");
  const [seed, setSeed] = useState("");
  const scenarioPresets = useMemo(
    () => (activeScenarioId ? getScenarioRequestPresets(activeScenarioId) : []),
    [activeScenarioId]
  );

  if (!open) return null;

  const effectiveSource = sourceNodeId || origins[0]?.id || "";
  const error = validate({
    origins: origins.length,
    requestCount,
    dispatchRateRps,
    startAtMs
  });

  const durationSeconds =
    dispatchRateRps > 0 ? (requestCount / dispatchRateRps).toFixed(2) : "—";

  function handleQueue(): void {
    if (error) return;
    const batch: ManualRequestDefinition = {
      id: `batch-${Date.now().toString(36)}-${batches.length}`,
      sourceNodeId: effectiveSource,
      method,
      requestCount,
      dispatchRateRps,
      startAtMs,
      path: path.trim() || undefined,
      requestClass: requestClass || undefined,
      payloadSizeBytes: numberOrUndefined(payloadSizeBytes),
      responseSizeBytes: numberOrUndefined(responseSizeBytes),
      timeoutMs: numberOrUndefined(timeoutMs),
      seed: numberOrUndefined(seed),
      label: `${method} ${path.trim() || "/"} ×${requestCount}`
    };
    addBatch(batch);
  }

  function loadPreset(preset: ScenarioRequestPreset): void {
    const request = toManualRequestDefinition(preset);
    setSourceNodeId(request.sourceNodeId);
    setMethod(request.method);
    setRequestCount(request.requestCount);
    setDispatchRateRps(request.dispatchRateRps);
    setStartAtMs(request.startAtMs);
    setRequestClass(request.requestClass ?? "");
    setPayloadSizeBytes(request.payloadSizeBytes?.toString() ?? "");
    setResponseSizeBytes(request.responseSizeBytes?.toString() ?? "");
    setTimeoutMs(request.timeoutMs?.toString() ?? "");
    setSeed(request.seed?.toString() ?? "");
  }

  const queuedDurationMs = requiredDurationMs(batches);

  return (
    <ModalShell title="Send requests" className="request-composer" onClose={close}>
      <div className="modal-body">
        <p className="metric-note">
          Requests are simulated inside the deterministic engine. No network traffic leaves this
          application.
        </p>

        {origins.length === 0 && (
          <p className="run-status-note" role="status">
            Add a Client component to the canvas before sending requests — a batch needs an origin.
          </p>
        )}
        {scenarioPresets.length > 0 && (
          <section className="scenario-request-presets" aria-label="Scenario request exercises">
            <h3>Scenario request exercises</h3>
            <p className="metric-note">
              Load a deterministic exercise, review or adjust it below, then queue it for the next
              simulation. Presets never modify the scenario project.
            </p>
            <div className="scenario-preset-actions">
              {scenarioPresets.map((preset) => (
                <button type="button" key={preset.id} onClick={() => loadPreset(preset)}>
                  {preset.name}
                </button>
              ))}
            </div>
          </section>
        )}

        <div className="composer-grid">
          <label className="field">
            Origin
            <select
              value={effectiveSource}
              onChange={(event) => setSourceNodeId(event.target.value)}
              disabled={origins.length === 0}
            >
              {origins.map((node) => (
                <option key={node.id} value={node.id}>
                  {node.config.displayName}
                </option>
              ))}
            </select>
          </label>

          <label className="field">
            Method
            <select
              value={method}
              onChange={(event) => setMethod(event.target.value as HttpMethod)}
            >
              {METHODS.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </label>

          <label className="field">
            Path
            <input
              type="text"
              value={path}
              placeholder="/api/orders"
              onChange={(event) => setPath(event.target.value)}
            />
          </label>

          <label className="field">
            Number of requests
            <input
              type="number"
              min={1}
              max={MAX_MANUAL_REQUEST_COUNT}
              value={requestCount}
              onChange={(event) => setRequestCount(Number(event.target.value))}
            />
          </label>

          <label className="field">
            Dispatch rate (req/s)
            <input
              type="number"
              min={0.001}
              max={MAX_MANUAL_DISPATCH_RPS}
              value={dispatchRateRps}
              onChange={(event) => setDispatchRateRps(Number(event.target.value))}
            />
          </label>

          <label className="field">
            Start at (ms)
            <input
              type="number"
              min={0}
              step={100}
              value={startAtMs}
              onChange={(event) => setStartAtMs(Number(event.target.value))}
            />
          </label>

          <label className="field">
            Request class
            <select
              value={requestClass}
              onChange={(event) => setRequestClass(event.target.value as RequestClass | "")}
            >
              <option value="">Infer from method</option>
              {CLASSES.map((option) => (
                <option key={option} value={option}>
                  {CLASS_LABELS[option]}
                </option>
              ))}
            </select>
          </label>

          <label className="field">
            Payload size (bytes)
            <input
              type="number"
              min={0}
              value={payloadSizeBytes}
              placeholder="profile default"
              onChange={(event) => setPayloadSizeBytes(event.target.value)}
            />
          </label>

          <label className="field">
            Response size (bytes)
            <input
              type="number"
              min={0}
              value={responseSizeBytes}
              placeholder="component default"
              onChange={(event) => setResponseSizeBytes(event.target.value)}
            />
          </label>

          <label className="field">
            Timeout (ms)
            <input
              type="number"
              min={1}
              value={timeoutMs}
              placeholder="client default"
              onChange={(event) => setTimeoutMs(event.target.value)}
            />
          </label>

          <label className="field">
            Seed override
            <input
              type="number"
              value={seed}
              placeholder="run seed"
              onChange={(event) => setSeed(event.target.value)}
            />
          </label>
        </div>

        <p className="composer-preview" role="status">
          This will dispatch <strong>{requestCount.toLocaleString()}</strong> {method} request
          {requestCount === 1 ? "" : "s"} over <strong>{durationSeconds}</strong> simulated seconds
          {startAtMs > 0 ? `, starting at ${startAtMs} ms` : ""}.
        </p>

        {error && (
          <p className="run-status-note" role="alert">
            {error}
          </p>
        )}

        <label className="toolbar-toggle">
          <input
            type="checkbox"
            checked={suppressProfileTraffic}
            onChange={(event) => setSuppressProfileTraffic(event.target.checked)}
          />
          Dispatch only these batches (suppress traffic-profile load)
        </label>

        {batches.length > 0 && (
          <section aria-label="Queued request batches">
            <h3>Queued batches</h3>
            <ul className="batch-list">
              {batches.map((batch) => (
                <li key={batch.id}>
                  <span>
                    {batch.label ?? batch.id} · {batch.dispatchRateRps} req/s ·{" "}
                    {(batchDurationMs(batch) / 1000).toFixed(2)} s
                  </span>
                  <button
                    type="button"
                    className="link-button"
                    onClick={() => removeBatch(batch.id)}
                    aria-label={`Remove batch ${batch.label ?? batch.id}`}
                  >
                    Remove
                  </button>
                </li>
              ))}
            </ul>
            <p className="metric-note">
              Run duration must be at least {(queuedDurationMs / 1000).toFixed(2)} s for every
              queued batch to finish dispatching.
            </p>
          </section>
        )}
      </div>
      <footer className="modal-footer">
        <button type="button" className="secondary" onClick={close}>
          Close
        </button>
        <button type="button" onClick={handleQueue} disabled={Boolean(error)}>
          Queue batch
        </button>
      </footer>
    </ModalShell>
  );
}

function numberOrUndefined(value: string): number | undefined {
  if (value.trim() === "") return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function validate(input: {
  origins: number;
  requestCount: number;
  dispatchRateRps: number;
  startAtMs: number;
}): string | undefined {
  if (input.origins === 0) return "No Client component is available to originate requests.";
  if (!Number.isInteger(input.requestCount) || input.requestCount < 1) {
    return "Number of requests must be a whole number of at least 1.";
  }
  if (input.requestCount > MAX_MANUAL_REQUEST_COUNT) {
    return `Number of requests must not exceed ${MAX_MANUAL_REQUEST_COUNT.toLocaleString()}.`;
  }
  if (!(input.dispatchRateRps > 0)) return "Dispatch rate must be greater than zero.";
  if (input.dispatchRateRps > MAX_MANUAL_DISPATCH_RPS) {
    return `Dispatch rate must not exceed ${MAX_MANUAL_DISPATCH_RPS.toLocaleString()} req/s.`;
  }
  if (input.startAtMs < 0) return "Start time cannot be negative.";
  return undefined;
}
