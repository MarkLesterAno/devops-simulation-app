/** Adds or removes one fault id while preserving all other armed scenarios. */
export function toggleFaultScenario(
  selectedIds: string[],
  faultId: string,
  selected: boolean
): string[] {
  if (selected) {
    return selectedIds.includes(faultId) ? selectedIds : [...selectedIds, faultId];
  }
  return selectedIds.filter((id) => id !== faultId);
}
