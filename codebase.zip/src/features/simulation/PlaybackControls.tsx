import { usePlaybackStore, PLAYBACK_SPEEDS, type PlaybackSpeed } from "@/stores/playbackStore";
import { playbackDurationMs } from "@/domain/flow/playbackFrame";

/**
 * Playback transport, per LIVE_PLAYBACK_AND_REQUEST_SIMULATION_PROMPT.md
 * section 6.
 *
 * These controls only change how the recorded run is replayed on screen. The
 * simulation itself already finished in the worker, so pausing or changing
 * speed can never alter a metric — which is exactly what makes the playback
 * trustworthy as a teaching aid.
 */
export function PlaybackControls(): JSX.Element | null {
  const status = usePlaybackStore((state) => state.status);
  const speed = usePlaybackStore((state) => state.speed);
  const timeline = usePlaybackStore((state) => state.timeline);
  const currentLogicalTimeMs = usePlaybackStore((state) => state.currentLogicalTimeMs);
  const pause = usePlaybackStore((state) => state.pause);
  const resume = usePlaybackStore((state) => state.resume);
  const restart = usePlaybackStore((state) => state.restart);
  const skipToEnd = usePlaybackStore((state) => state.skipToEnd);
  const seek = usePlaybackStore((state) => state.seek);
  const setSpeed = usePlaybackStore((state) => state.setSpeed);

  if (status === "idle" || !timeline) return null;

  const durationMs = playbackDurationMs(timeline);
  const progress = durationMs > 0 ? Math.min(1, currentLogicalTimeMs / durationMs) : 1;

  return (
    <div className="playback-controls" role="group" aria-label="Playback controls">
      <span className="playback-model-note" role="status">
        Recorded telemetry replay
      </span>
      {status === "running" ? (
        <button type="button" onClick={pause} aria-label="Pause playback">
          ⏸ Pause
        </button>
      ) : (
        <button
          type="button"
          onClick={status === "paused" ? resume : restart}
          aria-label={status === "paused" ? "Resume playback" : "Replay run"}
        >
          {status === "paused" ? "▶ Resume" : "↻ Replay"}
        </button>
      )}
      <button type="button" onClick={skipToEnd} aria-label="Skip to end of playback">
        ⏭ Skip
      </button>
      <label className="toolbar-toggle">
        Speed
        <select
          value={speed}
          onChange={(event) => setSpeed(Number(event.target.value) as PlaybackSpeed)}
          aria-label="Playback speed"
        >
          {PLAYBACK_SPEEDS.map((option) => (
            <option key={option} value={option}>
              {option}×
            </option>
          ))}
        </select>
      </label>
      <label className="playback-progress">
        <span className="visually-hidden">Playback position</span>
        <input
          type="range"
          min={0}
          max={Math.round(durationMs)}
          step={Math.max(1, Math.round(durationMs / 500))}
          value={Math.round(currentLogicalTimeMs)}
          onChange={(event) => seek(Number(event.target.value))}
          aria-valuetext={`${(currentLogicalTimeMs / 1000).toFixed(1)} of ${(durationMs / 1000).toFixed(1)} simulated seconds`}
        />
        <span className="playback-progress-fill" style={{ width: `${progress * 100}%` }} />
      </label>
      <span className="status-pill">
        {(currentLogicalTimeMs / 1000).toFixed(1)}s / {(durationMs / 1000).toFixed(1)}s
      </span>
    </div>
  );
}
