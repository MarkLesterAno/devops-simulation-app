import { useEffect, useState } from "react";
import { useProjectStore } from "@/stores/projectStore";
import { useRequestStore, requiredDurationMs } from "@/stores/requestStore";
import { usePlaybackStore } from "@/stores/playbackStore";
import { findingsToToasts, useToastStore } from "@/stores/toastStore";
import { SimulationWorkerClient } from "@/simulation-engine/worker/SimulationWorkerClient";
import { defaultSimulationSettings } from "@/domain/simulation/simulationInput";
import { hasBlockingErrors } from "@/domain/validation/graphValidation";
import { getScenarioTemplate } from "@/domain/scenarios/registry";
import { useUiStore } from "@/stores/uiStore";
import { toggleFaultScenario } from "./faultSelection";

const workerClient = new SimulationWorkerClient();

/**
 * Toolbar-level simulation controls: pick a traffic profile, duration, and
 * seed, then run/cancel a simulation in the Web Worker per TRD.md.
 *
 * When a run finishes it hands the recorded flow telemetry to the playback
 * store and raises the run's findings as toasts. The engine always computes
 * the whole run first and playback is a replay of that finished result, so
 * what the user watches can never disagree with the metrics.
 */
export function SimulationControls(): JSX.Element {
  const document = useProjectStore((state) => state.document);
  const activeScenarioId = useUiStore((state) => state.activeScenarioId);
  const validationIssues = useProjectStore((state) => state.validationIssues);
  const isSimulating = useProjectStore((state) => state.isSimulating);
  const setSimulating = useProjectStore((state) => state.setSimulating);
  const setResult = useProjectStore((state) => state.setResult);
  const batches = useRequestStore((state) => state.batches);
  const suppressProfileTraffic = useRequestStore((state) => state.suppressProfileTraffic);
  const startPlayback = usePlaybackStore((state) => state.start);
  const resetPlayback = usePlaybackStore((state) => state.reset);
  const cancelPlayback = usePlaybackStore((state) => state.cancel);
  const publishToasts = useToastStore((state) => state.publish);
  const notify = useToastStore((state) => state.notify);
  const [seed, setSeed] = useState(42);
  const [durationMs, setDurationMs] = useState(30_000);
  const [trafficProfileId, setTrafficProfileId] = useState("");
  const [faultScenarioIds, setFaultScenarioIds] = useState<string[]>([]);

  const blocked = hasBlockingErrors(validationIssues);
  const trafficProfile = document.trafficProfiles.find((profile) => profile.id === trafficProfileId)
    ?? document.trafficProfiles[0];
  // A batch that would still be dispatching when the run ends is a silent
  // truncation, so it is called out before the user runs rather than after.
  const batchDurationShortfall = requiredDurationMs(batches) > durationMs;

  useEffect(() => {
    const scenario = activeScenarioId ? getScenarioTemplate(activeScenarioId) : undefined;
    setTrafficProfileId(scenario?.metadata.defaultTrafficProfileId ?? document.trafficProfiles[0]?.id ?? "");
    setFaultScenarioIds(
      (scenario?.metadata.defaultFaultScenarioIds ?? []).filter((id) =>
        document.faultScenarios.some((fault) => fault.id === id)
      )
    );
  }, [document.id, document.trafficProfiles, document.faultScenarios, activeScenarioId]);

  async function handleRun(): Promise<void> {
    if (!trafficProfile || blocked) return;
    resetPlayback();
    setSimulating(true);
    try {
      const result = await workerClient.run({
        projectSnapshot: document,
        trafficProfileId: trafficProfile.id,
        faultScenarioIds,
        durationMs,
        seed,
        settings: defaultSimulationSettings(),
        manualRequests: batches.length > 0 ? batches : undefined,
        suppressProfileTraffic: suppressProfileTraffic && batches.length > 0
      });
      setResult(result);
      startPlayback(result.flowTimeline);
      publishToasts(
        findingsToToasts(
          result.findings,
          (nodeId) => document.nodes.find((node) => node.id === nodeId)?.config.displayName
        )
      );
    } catch (error) {
      setSimulating(false);
      resetPlayback();
      notify({
        severity: "error",
        title: "Simulation failed",
        detail: error instanceof Error ? error.message : "An unknown simulation error occurred."
      });
    }
  }

  function handleCancel(): void {
    workerClient.cancel();
    setSimulating(false);
    cancelPlayback();
  }

  return (
    <>
      <label className="field" style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
        Traffic
        <select
          aria-label="Traffic profile"
          value={trafficProfile?.id ?? ""}
          onChange={(event) => setTrafficProfileId(event.target.value)}
        >
          {document.trafficProfiles.map((profile) => (
            <option key={profile.id} value={profile.id}>{profile.name}</option>
          ))}
        </select>
      </label>
      {document.faultScenarios.length > 0 && (
        <fieldset className="toolbar-faults" aria-label="Fault scenarios">
          <legend>Faults</legend>
          <div className="toolbar-fault-options">
            {document.faultScenarios.map((scenario) => (
              <label key={scenario.id}>
                <input
                  type="checkbox"
                  checked={faultScenarioIds.includes(scenario.id)}
                  onChange={(event) =>
                    setFaultScenarioIds(
                      toggleFaultScenario(faultScenarioIds, scenario.id, event.target.checked)
                    )
                  }
                />
                {scenario.name}
              </label>
            ))}
          </div>
          <span className="toolbar-fault-count" role="status">
            {faultScenarioIds.length} armed
          </span>
        </fieldset>
      )}
      <label className="field" style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
        Seed
        <input
          type="number"
          value={seed}
          onChange={(event) => setSeed(Number(event.target.value))}
          style={{ width: 70 }}
        />
      </label>
      <label className="field" style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
        Duration (ms)
        <input
          type="number"
          min={1000}
          step={1000}
          value={durationMs}
          onChange={(event) => setDurationMs(Number(event.target.value))}
          style={{ width: 90 }}
        />
      </label>
      {!isSimulating ? (
        <button className="primary-action" onClick={() => void handleRun()} disabled={blocked || !trafficProfile}>
          ▶ Run
        </button>
      ) : (
        <button onClick={handleCancel}>■ Cancel</button>
      )}
      <span className={`status-pill${blocked ? " status-pill-warn" : ""}`}>
        {blocked ? "Review issues below" : "Ready to run"}
      </span>
      {batches.length > 0 && (
        <span className={`status-pill${batchDurationShortfall ? " status-pill-warn" : ""}`}>
          {batches.length} queued batch{batches.length === 1 ? "" : "es"}
          {batchDurationShortfall ? " · run duration too short" : ""}
        </span>
      )}
    </>
  );
}
