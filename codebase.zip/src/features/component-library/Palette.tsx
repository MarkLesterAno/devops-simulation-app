import { useMemo, useState } from "react";
import { componentDefinitions } from "@/domain/components/registry";
import { useProjectStore } from "@/stores/projectStore";
import type { ComponentType } from "@/domain/architecture/schema";

/**
 * Searchable component palette per DESIGN_BRIEF.md. Clicking an item places a
 * new node on the canvas at a default offset; drag-and-drop is layered on top
 * via native HTML5 DnD in ArchitectureCanvas.
 */
export function Palette(): JSX.Element {
  const [query, setQuery] = useState("");
  const addNode = useProjectStore((state) => state.addNode);
  const nodeCount = useProjectStore((state) => state.document.nodes.length);

  const grouped = useMemo(() => {
    const entries = Object.values(componentDefinitions).filter((definition) =>
      definition.displayName.toLowerCase().includes(query.toLowerCase())
    );
    const byCategory = new Map<string, typeof entries>();
    for (const definition of entries) {
      const list = byCategory.get(definition.category) ?? [];
      list.push(definition);
      byCategory.set(definition.category, list);
    }
    return byCategory;
  }, [query]);

  function handleAdd(type: ComponentType): void {
    const offset = nodeCount * 24;
    addNode(type, { x: 80 + (offset % 400), y: 80 + Math.floor(offset / 400) * 120 });
  }

  return (
    <div className="panel palette" aria-label="Component palette">
      <h2>Components</h2>
      <p className="palette-help">Click to add to the canvas, or drag to choose a position.</p>
      <input
        className="palette-search"
        placeholder="Search components…"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        aria-label="Search components"
      />
      {[...grouped.entries()].map(([category, definitions]) => (
        <div className="palette-category" key={category}>
          <h3>{category}</h3>
          {definitions.map((definition) => (
            <button
              key={definition.type}
              className="palette-item"
              draggable
              onDragStart={(event) => {
                event.dataTransfer.setData("application/x-component-type", definition.type);
              }}
              onClick={() => handleAdd(definition.type)}
              title={definition.description}
            >
              <span>{definition.displayName}</span>
              <span className="fidelity">{definition.fidelity}</span>
            </button>
          ))}
        </div>
      ))}
    </div>
  );
}
