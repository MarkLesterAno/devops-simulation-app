import type { SystemMetricSnapshot } from "@/domain/metrics/schema";

export const MAX_METRICS_CHART_POINTS = 500;

/**
 * Keeps charts responsive for unusually long runs while preserving both the
 * opening and final measurements that define the observed trend.
 */
export function downsampleSystemMetrics(
  snapshots: readonly SystemMetricSnapshot[],
  maximumPoints = MAX_METRICS_CHART_POINTS
): SystemMetricSnapshot[] {
  if (snapshots.length <= maximumPoints) return [...snapshots];

  const stride = Math.ceil((snapshots.length - 1) / (maximumPoints - 1));
  const sampled = snapshots.filter((_, index) => index % stride === 0);
  const last = snapshots[snapshots.length - 1]!;
  if (sampled[sampled.length - 1] !== last) sampled.push(last);
  return sampled;
}

export type UtilizationState = "healthy" | "warning" | "degraded" | "failed";

export function utilizationState(utilization: number): UtilizationState {
  if (utilization > 0.95) return "failed";
  if (utilization >= 0.85) return "degraded";
  if (utilization >= 0.7) return "warning";
  return "healthy";
}
