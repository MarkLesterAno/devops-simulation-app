import type { ComponentMetricSnapshot } from "@/domain/metrics/schema";

export interface ComponentMetricRollup {
  nodeId: string;
  peakUtilization: number;
  peakLatencyMs: number;
  peakQueueDepth?: number;
  peakConsumerLagMs?: number;
  peakReplicaLagMs?: number;
  cacheHitRatio?: number;
}

/**
 * Reduces interval metrics to one learner-facing row per component. Peaks are
 * intentional: short saturation or latency spikes are the relevant signal.
 */
export function rollupComponentMetrics(
  snapshots: readonly ComponentMetricSnapshot[]
): ComponentMetricRollup[] {
  const byNode = new Map<string, ComponentMetricRollup>();
  for (const snapshot of snapshots) {
    const current = byNode.get(snapshot.nodeId) ?? {
      nodeId: snapshot.nodeId,
      peakUtilization: 0,
      peakLatencyMs: 0
    };
    current.peakUtilization = Math.max(current.peakUtilization, snapshot.utilization);
    current.peakLatencyMs = Math.max(current.peakLatencyMs, snapshot.latencyMs);
    if (snapshot.queueDepth !== undefined) {
      current.peakQueueDepth = Math.max(current.peakQueueDepth ?? 0, snapshot.queueDepth);
    }
    if (snapshot.consumerLagMs !== undefined) {
      current.peakConsumerLagMs = Math.max(current.peakConsumerLagMs ?? 0, snapshot.consumerLagMs);
    }
    if (snapshot.replicaLagMs !== undefined) {
      current.peakReplicaLagMs = Math.max(current.peakReplicaLagMs ?? 0, snapshot.replicaLagMs);
    }
    if (snapshot.cacheHitRatio !== undefined) current.cacheHitRatio = snapshot.cacheHitRatio;
    byNode.set(snapshot.nodeId, current);
  }
  return [...byNode.values()].sort(
    (left, right) => right.peakUtilization - left.peakUtilization
  );
}
