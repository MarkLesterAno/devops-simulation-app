import { KEYBOARD_SHORTCUTS } from "./shortcuts";
import { ModalShell } from "@/features/modals/ModalShell";

export function KeyboardShortcutsModal({ onClose }: { onClose: () => void }): JSX.Element {
  return (
    <ModalShell title="Keyboard shortcuts" onClose={onClose} className="keyboard-shortcuts-modal">
      <div className="modal-body">
        <p className="modal-hint">
          Shortcuts do not run while typing in a form field or while a tutorial owns keyboard
          interaction.
        </p>
        <dl className="keyboard-shortcut-list">
          {KEYBOARD_SHORTCUTS.map((shortcut) => (
            <div key={shortcut.keys}>
              <dt>
                <kbd>{shortcut.keys}</kbd>
              </dt>
              <dd>{shortcut.action}</dd>
            </div>
          ))}
        </dl>
      </div>
    </ModalShell>
  );
}
