export interface KeyboardShortcut {
  keys: string;
  action: string;
}

export const KEYBOARD_SHORTCUTS: readonly KeyboardShortcut[] = [
  { keys: "Ctrl/Cmd+S", action: "Save the current project" },
  { keys: "Ctrl/Cmd+Z", action: "Undo the last design edit" },
  { keys: "Ctrl/Cmd+Y or Ctrl/Cmd+Shift+Z", action: "Redo the last design edit" },
  { keys: "Ctrl/Cmd+M", action: "Open metrics" },
  { keys: "Enter", action: "Configure the selected node" },
  { keys: "Delete or Backspace", action: "Delete the selected node or edge" },
  { keys: "Shift+F10", action: "Open the selected node's context menu" },
  { keys: "?", action: "Show this keyboard shortcut reference" },
  { keys: "F1", action: "Show this keyboard shortcut reference" }
];

export function isShortcutReferenceKey(event: {
  key: string;
  ctrlKey: boolean;
  metaKey: boolean;
  altKey: boolean;
}): boolean {
  return !event.ctrlKey && !event.metaKey && !event.altKey && (event.key === "?" || event.key === "F1");
}
