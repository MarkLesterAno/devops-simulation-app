import { useToastStore } from "@/stores/toastStore";
import { useUiStore } from "@/stores/uiStore";
import { ModalShell } from "@/features/modals/ModalShell";
import { SEVERITY_LABELS, SEVERITY_MARKS } from "./severity";

/**
 * Notification centre, per LIVE_PLAYBACK_AND_REQUEST_SIMULATION_PROMPT.md
 * section 2.
 *
 * Dismissing a toast hides it, it does not delete the finding. This modal is
 * where every finding raised this session remains reachable, so a user who
 * clears the stack to see the canvas has not lost anything.
 */
export function NotificationCentre(): JSX.Element | null {
  const open = useToastStore((state) => state.notificationCentreOpen);
  const close = useToastStore((state) => state.closeNotificationCentre);
  const history = useToastStore((state) => state.history);
  const clearHistory = useToastStore((state) => state.clearHistory);
  const openMetrics = useUiStore((state) => state.openMetrics);

  if (!open) return null;

  return (
    <ModalShell title="Findings" className="notification-centre" onClose={close}>
      <div className="modal-body">
        {history.length === 0 ? (
          <p className="empty-state">No findings have been raised in this session.</p>
        ) : (
          <ul className="notification-list">
            {history.map((toast) => (
              <li key={toast.id} className={`notification notification-${toast.severity}`}>
                <div className="notification-head">
                  <strong>{toast.title}</strong>
                  <span className="notification-severity">
                    <span aria-hidden="true">{SEVERITY_MARKS[toast.severity]}</span>{" "}
                    {SEVERITY_LABELS[toast.severity]}
                  </span>
                </div>
                {toast.subjectLabel && (
                  <div className="toast-subject">{toast.subjectLabel}</div>
                )}
                <p className="toast-detail">{toast.detail}</p>
                {toast.metricSummary && <p className="toast-metric">{toast.metricSummary}</p>}
                <button
                  type="button"
                  className="link-button"
                  onClick={() => {
                    close();
                    openMetrics(toast.focusNodeId);
                  }}
                >
                  View Metrics
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
      <footer className="modal-footer">
        <button type="button" className="secondary" onClick={clearHistory}>
          Clear history
        </button>
        <button type="button" onClick={close}>
          Close
        </button>
      </footer>
    </ModalShell>
  );
}
