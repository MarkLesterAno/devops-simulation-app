import type { ToastSeverity } from "@/stores/toastStore";

export const SEVERITY_LABELS: Record<ToastSeverity, string> = {
  critical: "Critical",
  warning: "Warning",
  info: "Information",
  recommendation: "Recommendation"
};

/** Non-colour indicator, so severity never depends on hue alone. */
export const SEVERITY_MARKS: Record<ToastSeverity, string> = {
  critical: "⛔",
  warning: "⚠",
  info: "ℹ",
  recommendation: "★"
};
