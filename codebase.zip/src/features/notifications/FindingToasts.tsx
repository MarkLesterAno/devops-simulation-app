import { useEffect, useRef } from "react";
import {
  useToastStore,
  type AppNotification,
  type FindingToast
} from "@/stores/toastStore";
import { useUiStore } from "@/stores/uiStore";
import { useProjectStore } from "@/stores/projectStore";
import { SEVERITY_LABELS, SEVERITY_MARKS } from "./severity";

/**
 * Findings toast stack, per LIVE_PLAYBACK_AND_REQUEST_SIMULATION_PROMPT.md
 * section 2.
 *
 * Critical findings are announced assertively so a screen reader interrupts
 * for them; everything else is announced politely. Toasts never auto-dismiss:
 * an unread finding is not noise to be cleaned up, and timed disappearance is
 * hostile to anyone reading at their own pace.
 */
export function FindingToasts(): JSX.Element | null {
  const visible = useToastStore((state) => state.visible);
  const queued = useToastStore((state) => state.queued);
  const dismiss = useToastStore((state) => state.dismiss);
  const dismissAll = useToastStore((state) => state.dismissAll);
  const openNotificationCentre = useToastStore((state) => state.openNotificationCentre);
  const appNotifications = useToastStore((state) => state.appNotifications);
  const dismissAppNotification = useToastStore((state) => state.dismissAppNotification);

  if (visible.length === 0 && appNotifications.length === 0) return null;

  return (
    <div className="toast-stack" aria-label="Simulation findings">
      {visible.map((toast) => (
        <ToastCard key={toast.id} toast={toast} onDismiss={() => dismiss(toast.id)} />
      ))}
      {appNotifications.map((notification) => (
        <AppNotificationCard
          key={notification.id}
          notification={notification}
          onDismiss={() => dismissAppNotification(notification.id)}
        />
      ))}
      <div className="toast-stack-actions">
        {queued.length > 0 && (
          <button type="button" className="link-button" onClick={openNotificationCentre}>
            {queued.length} more finding{queued.length === 1 ? "" : "s"}
          </button>
        )}
        <button type="button" className="link-button" onClick={dismissAll}>
          Dismiss all
        </button>
      </div>
    </div>
  );
}

function AppNotificationCard({
  notification,
  onDismiss
}: {
  notification: AppNotification;
  onDismiss: () => void;
}): JSX.Element {
  useEffect(() => {
    if (notification.severity === "error") return;
    const timeout = window.setTimeout(onDismiss, 6000);
    return () => window.clearTimeout(timeout);
  }, [notification.severity, onDismiss]);

  return (
    <div
      className={`toast app-notification app-notification-${notification.severity}`}
      role={notification.severity === "error" ? "alert" : "status"}
      aria-live={notification.severity === "error" ? "assertive" : "polite"}
    >
      <div className="toast-header">
        <span className="toast-severity">{notification.severity}</span>
        <button type="button" className="toast-dismiss" onClick={onDismiss} aria-label={`Dismiss notification: ${notification.title}`}>×</button>
      </div>
      <strong className="toast-title">{notification.title}</strong>
      {notification.detail && <p className="toast-detail">{notification.detail}</p>}
    </div>
  );
}

function ToastCard({
  toast,
  onDismiss
}: {
  toast: FindingToast;
  onDismiss: () => void;
}): JSX.Element {
  const openContextPanel = useUiStore((state) => state.openContextPanel);
  const selectNode = useProjectStore((state) => state.selectNode);
  const cardRef = useRef<HTMLDivElement | null>(null);

  // Move focus to a critical finding so keyboard users reach it immediately
  // rather than having to hunt for it after the run.
  useEffect(() => {
    if (toast.severity === "critical") cardRef.current?.focus();
  }, [toast.severity]);

  return (
    <div
      ref={cardRef}
      className={`toast toast-${toast.severity}`}
      role={toast.severity === "critical" ? "alert" : "status"}
      aria-live={toast.severity === "critical" ? "assertive" : "polite"}
      tabIndex={-1}
    >
      <div className="toast-header">
        <span className="toast-severity">
          <span aria-hidden="true">{SEVERITY_MARKS[toast.severity]}</span>{" "}
          {SEVERITY_LABELS[toast.severity]}
        </span>
        <button
          type="button"
          className="toast-dismiss"
          onClick={onDismiss}
          aria-label={`Dismiss finding: ${toast.title}`}
        >
          ×
        </button>
      </div>
      <strong className="toast-title">{toast.title}</strong>
      {toast.subjectLabel && <div className="toast-subject">{toast.subjectLabel}</div>}
      <p className="toast-detail">{toast.detail}</p>
      {toast.metricSummary && <p className="toast-metric">{toast.metricSummary}</p>}
      {toast.suggestedAction && <p className="toast-action">{toast.suggestedAction}</p>}
      {toast.repeatCount > 0 && (
        <p className="toast-repeat">Reported {toast.repeatCount + 1} times.</p>
      )}
      <div className="toast-buttons">
        <button type="button" onClick={() => openContextPanel("metrics")}>
          View Metrics
        </button>
        {toast.focusNodeId && (
          <button
            type="button"
            className="secondary"
            onClick={() => {
              selectNode(toast.focusNodeId);
              onDismiss();
            }}
          >
            Focus component
          </button>
        )}
      </div>
    </div>
  );
}
