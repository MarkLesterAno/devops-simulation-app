import type { FlowClass } from "@/domain/metrics/flowTimeline";

/**
 * Visual language for request-flow classes, per
 * LIVE_PLAYBACK_AND_REQUEST_SIMULATION_PROMPT.md section 6.
 *
 * Kept out of the edge component so the same mapping can drive a legend
 * without importing a React component, and so colour is never the only cue:
 * every consumer also renders the label.
 */
export const FLOW_CLASS_COLORS: Record<FlowClass, string> = {
  read: "#4d8dff",
  write: "#e0a12c",
  auth: "#d76bd7",
  "async-event": "#9b6bff",
  replication: "#33b7a8"
};

export const FLOW_CLASS_LABELS: Record<FlowClass, string> = {
  read: "read",
  write: "write",
  auth: "auth",
  "async-event": "event",
  replication: "replication"
};

/** Colour used for any flow with recorded failures, overriding its class. */
export const FLOW_FAILURE_COLOR = "#e05a5a";
