import { BaseEdge, EdgeLabelRenderer, getBezierPath, type EdgeProps } from "@xyflow/react";
import type { LiveEdgeFlow } from "@/domain/flow/playbackFrame";
import type { FlowClass } from "@/domain/metrics/flowTimeline";
import { FLOW_CLASS_COLORS, FLOW_CLASS_LABELS, FLOW_FAILURE_COLOR } from "./flowVisuals";

export interface FlowEdgeData extends Record<string, unknown> {
  /** Live traffic on this edge at the current playback instant. */
  flow?: LiveEdgeFlow;
  animate: boolean;
  /** Cumulative traversals recorded for the whole run, shown as a counter. */
  totalCount: number;
}

const MIN_DURATION_S = 0.6;
const MAX_DURATION_S = 3.2;

/**
 * Edge renderer that overlays live request flow on the base connection.
 *
 * Particle speed encodes volume, hue encodes the class of traffic, and
 * failures recolour the overlay. Animation is decorative only: with motion
 * disabled the same information stays readable through the overlay width, the
 * directional marker, and the traversal counter, so the moving picture is
 * never the only channel carrying meaning.
 */
export function FlowEdge({
  id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  style,
  markerEnd,
  data
}: EdgeProps): JSX.Element {
  const [path, labelX, labelY] = getBezierPath({
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition,
    targetPosition
  });

  const edgeData = data as FlowEdgeData | undefined;
  const flow = edgeData?.flow;
  const intensity = flow?.intensity ?? 0;
  const count = flow?.count ?? 0;
  const failureCount = flow?.failureCount ?? 0;
  const retryCount = flow?.retryCount ?? 0;
  const totalCount = edgeData?.totalCount ?? 0;
  const active = count > 0;
  const flowClass: FlowClass = flow?.flowClass ?? "read";
  const animate = Boolean(edgeData?.animate) && active;
  const durationS = MAX_DURATION_S - intensity * (MAX_DURATION_S - MIN_DURATION_S);

  const overlayClass = [
    "flow-particles",
    `flow-${flowClass}`,
    failureCount > 0 ? "failing" : "",
    retryCount > 0 ? "retrying" : "",
    animate ? "animated" : ""
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <>
      <BaseEdge id={id} path={path} style={style} markerEnd={markerEnd} />
      {active ? (
        <path
          className={overlayClass}
          d={path}
          fill="none"
          stroke={failureCount > 0 ? FLOW_FAILURE_COLOR : FLOW_CLASS_COLORS[flowClass]}
          strokeWidth={1.5 + intensity * 3}
          style={{ animationDuration: `${durationS.toFixed(2)}s` }}
        />
      ) : null}
      {active || totalCount > 0 ? (
        <EdgeLabelRenderer>
          <div
            className={`flow-edge-badge${failureCount > 0 ? " failing" : ""}`}
            style={{ transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)` }}
          >
            <span aria-hidden="true">→</span> {FLOW_CLASS_LABELS[flowClass]}
            {active ? ` · ${count}` : ` · ${totalCount} total`}
            {failureCount > 0 ? ` · ${failureCount} failed` : ""}
            {retryCount > 0 ? ` · ${retryCount} retried` : ""}
          </div>
        </EdgeLabelRenderer>
      ) : null}
    </>
  );
}
