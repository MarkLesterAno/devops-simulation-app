import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { useProjectStore } from "@/stores/projectStore";
import { useUiStore } from "@/stores/uiStore";
import { describeDeletionImpact } from "@/domain/architecture/projectAnalysis";

const MENU_MARGIN = 8;

/**
 * Right-click menu for a canvas node.
 *
 * Rendered at the document level rather than inside the node so it is never
 * clipped by the canvas viewport, and clamped to stay fully on screen.
 */
export function NodeContextMenu(): JSX.Element | null {
  const target = useUiStore((state) => state.contextMenu);
  const closeContextMenu = useUiStore((state) => state.closeContextMenu);
  const openNodeConfig = useUiStore((state) => state.openNodeConfig);
  const document_ = useProjectStore((state) => state.document);
  const duplicateNode = useProjectStore((state) => state.duplicateNode);
  const removeNode = useProjectStore((state) => state.removeNode);

  const menuRef = useRef<HTMLDivElement>(null);
  const menuItemRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const restoreNodeFocus = useCallback((nodeId: string): void => {
    const nodeElement = document.querySelector<HTMLElement>(
      `.react-flow__node[data-id="${nodeId.replace(/"/g, '\\"')}"]`
    );
    nodeElement?.focus();
  }, []);

  const dismiss = useCallback((restoreFocus = true): void => {
    if (restoreFocus && target) restoreNodeFocus(target.nodeId);
    closeContextMenu();
  }, [closeContextMenu, restoreNodeFocus, target]);

  useLayoutEffect(() => {
    if (!target || !menuRef.current) return;
    const rect = menuRef.current.getBoundingClientRect();
    setPosition({
      x: Math.min(target.x, window.innerWidth - rect.width - MENU_MARGIN),
      y: Math.min(target.y, window.innerHeight - rect.height - MENU_MARGIN)
    });
  }, [target]);

  useEffect(() => {
    if (!target) return;
    menuRef.current?.querySelector<HTMLButtonElement>("button")?.focus();
  }, [target]);

  useEffect(() => {
    if (!target) return;
    const onPointerDown = (event: MouseEvent): void => {
      if (!menuRef.current?.contains(event.target as Node)) dismiss();
    };
    window.addEventListener("mousedown", onPointerDown);
    return () => {
      window.removeEventListener("mousedown", onPointerDown);
    };
  }, [target, dismiss]);

  if (!target) return null;
  const node = document_.nodes.find((candidate) => candidate.id === target.nodeId);
  if (!node) return null;

  const impact = describeDeletionImpact(document_, target.nodeId);

  const confirmDelete = (): void => {
    if (impact.requiresConfirmation) {
      const parts = [`Delete "${node.config.displayName}"?`];
      if (impact.edgeCount > 0) {
        parts.push(`${impact.edgeCount} connection(s) will also be removed.`);
      }
      if (impact.faultScenarioNames.length > 0) {
        parts.push(`Referenced by fault scenario(s): ${impact.faultScenarioNames.join(", ")}.`);
      }
      if (!window.confirm(parts.join("\n\n"))) return;
    }
    removeNode(target.nodeId);
    dismiss(false);
  };

  const moveFocus = (fromIndex: number, offset: number): void => {
    const items = menuItemRefs.current.filter(
      (item): item is HTMLButtonElement => item !== null
    );
    if (items.length === 0) return;
    items[(fromIndex + offset + items.length) % items.length]?.focus();
  };

  const handleMenuKeyDown = (event: React.KeyboardEvent<HTMLDivElement>): void => {
    const items = menuItemRefs.current.filter(
      (item): item is HTMLButtonElement => item !== null
    );
    const currentIndex = items.indexOf(document.activeElement as HTMLButtonElement);
    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        moveFocus(currentIndex < 0 ? -1 : currentIndex, 1);
        break;
      case "ArrowUp":
        event.preventDefault();
        moveFocus(currentIndex < 0 ? 1 : currentIndex, -1);
        break;
      case "Home":
        event.preventDefault();
        items[0]?.focus();
        break;
      case "End":
        event.preventDefault();
        items[items.length - 1]?.focus();
        break;
      case "Escape":
        event.preventDefault();
        event.stopPropagation();
        dismiss();
        break;
    }
  };

  return (
    <div
      ref={menuRef}
      className="context-menu"
      role="menu"
      aria-label={`Actions for ${node.config.displayName}`}
      style={{ left: position.x, top: position.y }}
      onKeyDown={handleMenuKeyDown}
    >
      <button
        ref={(element) => {
          menuItemRefs.current[0] = element;
        }}
        type="button"
        role="menuitem"
        onClick={() => {
          openNodeConfig(target.nodeId);
        }}
      >
        Configure
      </button>
      <button
        ref={(element) => {
          menuItemRefs.current[1] = element;
        }}
        type="button"
        role="menuitem"
        onClick={() => {
          duplicateNode(target.nodeId);
          dismiss(false);
        }}
      >
        Duplicate
      </button>
      <button
        ref={(element) => {
          menuItemRefs.current[2] = element;
        }}
        type="button"
        role="menuitem"
        className="danger"
        onClick={confirmDelete}
      >
        Delete
      </button>
    </div>
  );
}
