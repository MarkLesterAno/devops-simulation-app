import type { ProjectDocument } from "@/domain/architecture/projectDocument";
import type { ArchitectureNode } from "@/domain/architecture/schema";
import { componentDefinitions } from "@/domain/components/registry";

const NODE_WIDTH = 220;
const NODE_HEIGHT = 112;
const PADDING = 48;

interface DiagramBounds {
  minX: number;
  minY: number;
  width: number;
  height: number;
}

function escapeXml(value: string): string {
  return value.replace(/[<>&'"]/g, (character) => {
    const entities: Record<string, string> = {
      "<": "&lt;",
      ">": "&gt;",
      "&": "&amp;",
      "'": "&apos;",
      '"': "&quot;"
    };
    return entities[character]!;
  });
}

function boundsFor(nodes: readonly ArchitectureNode[]): DiagramBounds {
  if (nodes.length === 0) return { minX: 0, minY: 0, width: 2 * PADDING, height: 2 * PADDING };
  const minX = Math.min(...nodes.map((node) => node.position.x));
  const minY = Math.min(...nodes.map((node) => node.position.y));
  const maxX = Math.max(...nodes.map((node) => node.position.x + NODE_WIDTH));
  const maxY = Math.max(...nodes.map((node) => node.position.y + NODE_HEIGHT));
  return {
    minX,
    minY,
    width: maxX - minX + 2 * PADDING,
    height: maxY - minY + 2 * PADDING
  };
}

/** Creates an export-only SVG that reflects the persisted architecture, not UI state. */
export function createDiagramSvg(document: ProjectDocument): string {
  const bounds = boundsFor(document.nodes);
  const positionById = new Map(document.nodes.map((node) => [node.id, node.position]));
  const transformX = PADDING - bounds.minX;
  const transformY = PADDING - bounds.minY;
  const edges = document.edges
    .map((edge) => {
      const source = positionById.get(edge.sourceNodeId);
      const target = positionById.get(edge.targetNodeId);
      if (!source || !target) return "";
      const x1 = source.x + NODE_WIDTH + transformX;
      const y1 = source.y + NODE_HEIGHT / 2 + transformY;
      const x2 = target.x + transformX;
      const y2 = target.y + NODE_HEIGHT / 2 + transformY;
      return `<path d="M ${x1} ${y1} L ${x2} ${y2}" stroke="#7f8da3" stroke-width="2" fill="none" marker-end="url(#arrow)"/><text x="${(x1 + x2) / 2}" y="${(y1 + y2) / 2 - 6}" text-anchor="middle" class="edge-label">${escapeXml(edge.kind)}</text>`;
    })
    .join("");
  const nodes = document.nodes
    .map((node) => {
      const x = node.position.x + transformX;
      const y = node.position.y + transformY;
      const type = componentDefinitions[node.type]?.displayName ?? node.type;
      const technology = node.config.technology?.displayName;
      return `<g transform="translate(${x} ${y})"><rect width="${NODE_WIDTH}" height="${NODE_HEIGHT}" rx="10" fill="#1c2330" stroke="#4d8dff" stroke-width="2"/><text x="16" y="28" class="type">${escapeXml(type)}</text><text x="16" y="55" class="name">${escapeXml(node.config.displayName)}</text>${technology ? `<rect x="16" y="70" width="188" height="24" rx="12" fill="#24344d"/><text x="28" y="87" class="technology">${escapeXml(technology)}</text>` : ""}</g>`;
    })
    .join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${bounds.width}" height="${bounds.height}" viewBox="0 0 ${bounds.width} ${bounds.height}" role="img" aria-label="${escapeXml(document.name)} architecture diagram"><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#7f8da3"/></marker><style>.type{font:600 12px Arial,sans-serif;fill:#9bbcff}.name{font:600 16px Arial,sans-serif;fill:#f4f7fb}.technology{font:12px Arial,sans-serif;fill:#d8e6ff}.edge-label{font:11px Arial,sans-serif;fill:#b9c5d5}</style></defs><rect width="100%" height="100%" fill="#12161f"/>${edges}${nodes}</svg>`;
}

export async function exportDiagramPng(document: ProjectDocument): Promise<void> {
  const svg = createDiagramSvg(document);
  const blob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
  const imageUrl = URL.createObjectURL(blob);
  try {
    const image = await loadImage(imageUrl);
    const scale = 2;
    const canvas = window.document.createElement("canvas");
    canvas.width = image.width * scale;
    canvas.height = image.height * scale;
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Your browser could not create an image export canvas.");
    context.scale(scale, scale);
    context.drawImage(image, 0, 0);
    const png = await new Promise<Blob>((resolve, reject) =>
      canvas.toBlob((result) => (result ? resolve(result) : reject(new Error("Could not encode PNG export."))), "image/png")
    );
    downloadBlob(png, `${safeFileName(document.name)}-diagram.png`);
  } finally {
    URL.revokeObjectURL(imageUrl);
  }
}

function loadImage(source: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Could not render the diagram for export."));
    image.src = source;
  });
}

function safeFileName(name: string): string {
  return (
    Array.from(name.trim())
      .map((character) =>
        character.charCodeAt(0) < 32 || '<>:"/\\|?*'.includes(character) ? "-" : character
      )
      .join("") || "architecture"
  );
}

function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = window.document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}
