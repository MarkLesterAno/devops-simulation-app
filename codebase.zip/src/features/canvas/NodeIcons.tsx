import type { ComponentType, TechnologyAssignment } from "@/domain/architecture/schema";
import {
  GLYPH_PATHS,
  glyphForComponentType,
  technologyIconFor,
  type ComponentGlyph
} from "@/domain/icons/iconRegistry";

export function ComponentIcon({
  type,
  size = 18,
  title
}: {
  type: ComponentType;
  size?: number;
  title?: string;
}): JSX.Element {
  const glyph: ComponentGlyph = glyphForComponentType(type);
  return (
    <svg
      className="component-icon"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      role={title ? "img" : "presentation"}
      aria-hidden={title ? undefined : true}
      aria-label={title}
      focusable="false"
    >
      {title ? <title>{title}</title> : null}
      {GLYPH_PATHS[glyph].map((d) => (
        <path key={d} d={d} />
      ))}
    </svg>
  );
}

/**
 * Visual identity for a node's assigned technology.
 *
 * Renders an approved local logo when one exists and a provider-tinted monogram
 * otherwise. The badge is never the sole indicator of the assignment — callers
 * also render the product name — so this stays decorative for screen readers
 * unless an explicit label is requested.
 */
export function TechnologyIcon({
  assignment,
  size = 18,
  labelled = false
}: {
  assignment: TechnologyAssignment;
  size?: number;
  labelled?: boolean;
}): JSX.Element {
  const icon = technologyIconFor(assignment.id, assignment.displayName, assignment.provider);
  const label = assignment.provider
    ? `${assignment.displayName} by ${assignment.provider}`
    : assignment.displayName;

  if (icon.assetPath) {
    return (
      <img
        className="technology-icon"
        src={icon.assetPath}
        width={size}
        height={size}
        alt={labelled ? label : ""}
        aria-hidden={labelled ? undefined : true}
      />
    );
  }

  return (
    <span
      className="technology-icon technology-monogram"
      style={{ width: size, height: size, background: icon.accent, fontSize: size * 0.46 }}
      role={labelled ? "img" : "presentation"}
      aria-label={labelled ? label : undefined}
      aria-hidden={labelled ? undefined : true}
      title={labelled ? undefined : label}
    >
      {icon.monogram}
    </span>
  );
}
