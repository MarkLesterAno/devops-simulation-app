import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  Panel,
  MiniMap,
  Handle,
  Position,
  type Connection,
  type Edge,
  type EdgeTypes,
  type Node,
  type NodeTypes,
  type OnConnect,
  type NodeChange,
  type EdgeChange,
  applyNodeChanges
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { useProjectStore } from "@/stores/projectStore";
import { useUiStore } from "@/stores/uiStore";
import { componentDefinitions } from "@/domain/components/registry";
import type { ComponentMetricSnapshot } from "@/domain/metrics/schema";
import type { FlowTimeline } from "@/domain/metrics/flowTimeline";
import { usePlaybackFrame } from "./usePlaybackFrame";
import type {
  ComponentType,
  ConnectionKind,
  TechnologyAssignment
} from "@/domain/architecture/schema";
import { ComponentIcon, TechnologyIcon } from "./NodeIcons";
import { FlowEdge, type FlowEdgeData } from "./FlowEdge";
import { FLOW_CLASS_COLORS, FLOW_CLASS_LABELS } from "./flowVisuals";
import { useToastStore } from "@/stores/toastStore";
import { TutorialPanel } from "@/features/tutorials/TutorialPanel";

interface NodeMetricLine {
  label: string;
  value: string;
}

interface ArchitectureNodeData extends Record<string, unknown> {
  label: string;
  type: ComponentType;
  typeLabel: string;
  selected: boolean;
  technology?: TechnologyAssignment;
  metrics: NodeMetricLine[];
  utilization?: number;
  status?: "healthy" | "warning" | "degraded" | "failed" | "inactive";
  saturated: boolean;
  /** True while requests are arriving at this node during playback. */
  processing: boolean;
}

function ArchitectureNodeView({ data }: { data: ArchitectureNodeData }): JSX.Element {
  return (
    <div
      className={`node-card${data.selected ? " selected" : ""}${data.processing ? " processing" : ""}${data.saturated ? " saturated" : ""}`}
    >
      <Handle type="target" position={Position.Left} className="node-handle" />
      <div className="node-header">
        <ComponentIcon type={data.type} />
        <span className="node-type">{data.typeLabel}</span>
        {data.processing ? (
          <span className="node-processing" title="Processing requests">
            ●
          </span>
        ) : null}
        {data.saturated ? (
          <span className="node-saturation-warning" role="img" aria-label="High utilization warning">
            ⚠
          </span>
        ) : null}
      </div>
      <div className="node-name">{data.label}</div>
      {data.technology ? (
        <div className="node-technology">
          <TechnologyIcon assignment={data.technology} size={14} />
          <span className="node-technology-name">{data.technology.displayName}</span>
        </div>
      ) : (
        <div className="node-technology node-technology-empty">No technology assigned</div>
      )}
      <div className="node-status">
        <span className={`status-dot ${data.status ?? "inactive"}`} />
        {data.status && data.status !== "inactive" ? data.status : "not run"}
        {data.utilization !== undefined ? ` · ${(data.utilization * 100).toFixed(0)}%` : ""}
      </div>
      {data.utilization !== undefined ? (
        <div
          className={`node-utilization ${data.status ?? "inactive"}`}
          role="progressbar"
          aria-label={`${data.label} utilization`}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Math.round(data.utilization * 100)}
        >
          <span style={{ width: `${Math.min(data.utilization * 100, 100)}%` }} />
        </div>
      ) : null}
      {data.metrics.length > 0 ? (
        <dl className="node-metrics">
          {data.metrics.map((metric) => (
            <div key={metric.label} className="node-metric">
              <dt>{metric.label}</dt>
              <dd>{metric.value}</dd>
            </div>
          ))}
        </dl>
      ) : null}
      <Handle type="source" position={Position.Right} className="node-handle" />
    </div>
  );
}

const nodeTypes: NodeTypes = { architecture: ArchitectureNodeView };
const edgeTypeStyles: Record<string, Edge["style"]> = {
  request: { stroke: "#4d8dff" },
  response: { stroke: "#4d8dff", strokeDasharray: "2 2" },
  event: { stroke: "#9b6bff", strokeDasharray: "4 3" },
  replication: { stroke: "#33b7a8", strokeDasharray: "6 3" },
  failover: { stroke: "#e0742c", strokeDasharray: "6 3" },
  observability: { stroke: "#9aa4b2", strokeDasharray: "1 3" }
};
const edgeTypes: EdgeTypes = { flow: FlowEdge };

/** Below this zoom, node text is too small to read, so detail rows are hidden. */
const ZOOM_DETAIL_THRESHOLD = 0.65;

/**
 * Builds the compact at-a-glance readout shown on a node card. Only metrics
 * that are meaningful for the component are included, so a cache shows its hit
 * ratio while a queue shows depth and consumer lag.
 */
function nodeMetricLines(snapshot: ComponentMetricSnapshot | undefined): NodeMetricLine[] {
  if (!snapshot) return [];
  const lines: NodeMetricLine[] = [
    { label: "p50", value: `${snapshot.latencyMs.toFixed(0)} ms` },
    { label: "err", value: `${(snapshot.errorRate * 100).toFixed(1)}%` }
  ];
  if (snapshot.cacheHitRatio !== undefined) {
    lines.push({ label: "hit", value: `${(snapshot.cacheHitRatio * 100).toFixed(0)}%` });
  }
  if (snapshot.queueDepth !== undefined && snapshot.queueDepth > 0) {
    lines.push({ label: "depth", value: snapshot.queueDepth.toFixed(0) });
  }
  if (snapshot.consumerLagMs !== undefined && snapshot.consumerLagMs > 0) {
    lines.push({ label: "lag", value: `${snapshot.consumerLagMs.toFixed(0)} ms` });
  }
  if (snapshot.quotaRejectionCount !== undefined && snapshot.quotaRejectionCount > 0) {
    lines.push({ label: "rejected", value: snapshot.quotaRejectionCount.toFixed(0) });
  }
  return lines;
}


/**
 * Picks a connection kind supported by both the source's outgoing and the
 * target's incoming edge kinds, so dragging a connection between, e.g., a
 * Server and the Observability component produces an "observability" edge
 * instead of always defaulting to "request". Falls back to "request" (and
 * lets the store's validation surface a clear error) when the node types
 * are unknown or share no compatible kind.
 */
function inferConnectionKind(
  sourceType: ComponentType | undefined,
  targetType: ComponentType | undefined
): ConnectionKind {
  if (!sourceType || !targetType) return "request";
  const outgoing = componentDefinitions[sourceType]?.allowedOutgoingConnections ?? [];
  const incoming = componentDefinitions[targetType]?.allowedIncomingConnections ?? [];
  const shared = outgoing.filter((kind) => incoming.includes(kind));
  const firstShared = shared[0];
  if (!firstShared) return "request";
  return shared.includes("request") ? "request" : firstShared;
}

function latestUtilizationByNode(
  snapshots: ComponentMetricSnapshot[] | undefined
): Map<string, ComponentMetricSnapshot> {
  const map = new Map<string, ComponentMetricSnapshot>();
  for (const snapshot of snapshots ?? []) {
    map.set(snapshot.nodeId, snapshot);
  }
  return map;
}

/**
 * Run totals per edge, used so a connection that carried traffic still shows a
 * counter once playback has finished and the live buckets are empty.
 */
function totalCountsByEdge(timeline: FlowTimeline | undefined): Map<string, number> {
  const totals = new Map<string, number>();
  for (const bucket of timeline?.buckets ?? []) {
    for (const sample of bucket.samples) {
      totals.set(sample.edgeId, (totals.get(sample.edgeId) ?? 0) + sample.count);
    }
  }
  return totals;
}

export function ArchitectureCanvas(): JSX.Element {
  const document = useProjectStore((state) => state.document);
  const selectedNodeId = useProjectStore((state) => state.selectedNodeId);
  const selectedEdgeId = useProjectStore((state) => state.selectedEdgeId);
  const selectNode = useProjectStore((state) => state.selectNode);
  const selectEdge = useProjectStore((state) => state.selectEdge);
  const moveNode = useProjectStore((state) => state.moveNode);
  const addNode = useProjectStore((state) => state.addNode);
  const addEdge = useProjectStore((state) => state.addEdge);
  const removeNode = useProjectStore((state) => state.removeNode);
  const removeEdge = useProjectStore((state) => state.removeEdge);
  const lastResult = useProjectStore((state) => state.lastResult);
  const openNodeConfig = useUiStore((state) => state.openNodeConfig);
  const openContextMenu = useUiStore((state) => state.openContextMenu);
  const closeContextMenu = useUiStore((state) => state.closeContextMenu);
  const flowAnimationEnabled = useUiStore((state) => state.flowAnimationEnabled);
  const notify = useToastStore((state) => state.notify);
  const [zoom, setZoom] = useState(1);

  const utilizationByNode = useMemo(
    () => latestUtilizationByNode(lastResult?.componentMetrics),
    [lastResult]
  );

  const flowFrame = usePlaybackFrame(document);

  const totalsByEdge = useMemo(
    () => totalCountsByEdge(lastResult?.flowTimeline),
    [lastResult]
  );

  const derivedNodes: Node<ArchitectureNodeData>[] = useMemo(
    () =>
      document.nodes.map((node) => {
        const metric = utilizationByNode.get(node.id);
        const status: ArchitectureNodeData["status"] = !lastResult
          ? "inactive"
          : metric === undefined
            ? "inactive"
            : metric.utilization >= 0.95
              ? "failed"
              : metric.utilization >= 0.8
                ? "degraded"
                : metric.utilization >= 0.6
                  ? "warning"
                  : "healthy";
        return {
          id: node.id,
          type: "architecture",
          position: node.position,
          data: {
            label: node.config.displayName,
            type: node.type,
            typeLabel: componentDefinitions[node.type]?.displayName ?? node.type,
            technology: node.config.technology,
            metrics: nodeMetricLines(metric),
            selected: node.id === selectedNodeId,
            utilization: metric?.utilization,
            status,
            saturated: (metric?.utilization ?? 0) >= 0.85,
            processing: flowFrame.activeNodeIds.has(node.id)
          }
        };
      }),
    [document.nodes, selectedNodeId, utilizationByNode, lastResult, flowFrame]
  );

  /**
   * React Flow owns the node array so the sizes it measures survive re-renders.
   * Those measurements are what edge routing depends on, so rebuilding the
   * array from the document on every render would leave every connection
   * undrawable. Document-derived fields are merged in whenever they change.
   */
  const [nodes, setNodes] = useState<Node<ArchitectureNodeData>[]>(derivedNodes);
  useEffect(() => {
    setNodes((current) => {
      const measuredById = new Map(current.map((node) => [node.id, node]));
      return derivedNodes.map((node) => {
        const existing = measuredById.get(node.id);
        return existing ? { ...existing, ...node } : node;
      });
    });
  }, [derivedNodes]);

  const edges: Edge[] = useMemo(
    () =>
      document.edges.map((edge) => {
        const data: FlowEdgeData = {
          flow: flowFrame.edges.get(edge.id),
          animate: flowAnimationEnabled,
          totalCount: totalsByEdge.get(edge.id) ?? 0
        };
        return {
          id: edge.id,
          type: "flow",
          source: edge.sourceNodeId,
          target: edge.targetNodeId,
          style: edgeTypeStyles[edge.kind],
          selected: edge.id === selectedEdgeId,
          label: edge.kind,
          data
        };
      }),
    [document.edges, selectedEdgeId, flowFrame, totalsByEdge, flowAnimationEnabled]
  );

  const onNodesChange = useCallback(
    (changes: NodeChange<Node<ArchitectureNodeData>>[]) => {
      setNodes((current) => applyNodeChanges(changes, current));
      for (const change of changes) {
        if (change.type === "position" && change.position) {
          moveNode(change.id, change.position);
        }
        if (change.type === "remove") {
          removeNode(change.id);
        }
      }
    },
    [moveNode, removeNode]
  );

  const onConnect: OnConnect = useCallback(
    (connection: Connection) => {
      if (!connection.source || !connection.target) return;
      const sourceNode = document.nodes.find((node) => node.id === connection.source);
      const targetNode = document.nodes.find((node) => node.id === connection.target);
      const kind = inferConnectionKind(sourceNode?.type, targetNode?.type);
      const result = addEdge(connection.source, connection.target, kind);
      if (!result.ok && result.error) {
        notify({ severity: "warning", title: "Could not create connection", detail: result.error });
      }
    },
    [addEdge, document.nodes, notify]
  );

  const onEdgesChange = useCallback(
    (changes: EdgeChange[]) => {
      for (const change of changes) {
        if (change.type === "remove") {
          removeEdge(change.id);
        }
      }
    },
    [removeEdge]
  );

  return (
    <div
      className={`canvas-wrapper${zoom < ZOOM_DETAIL_THRESHOLD ? " zoomed-out" : ""}`}
      onDragOver={(event) => event.preventDefault()}
      onDrop={(event) => {
        const type = event.dataTransfer.getData("application/x-component-type") as ComponentType;
        if (!type || !componentDefinitions[type]) return;
        const bounds = event.currentTarget.getBoundingClientRect();
        addNode(type, { x: event.clientX - bounds.left, y: event.clientY - bounds.top });
      }}
    >
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeClick={(_, node) => selectNode(node.id)}
        onNodeDoubleClick={(_, node) => {
          selectNode(node.id);
          openNodeConfig(node.id);
        }}
        onNodeContextMenu={(event, node) => {
          event.preventDefault();
          selectNode(node.id);
          openContextMenu({ nodeId: node.id, x: event.clientX, y: event.clientY });
        }}
        onEdgeClick={(_, edge) => selectEdge(edge.id)}
        onPaneClick={() => {
          closeContextMenu();
          selectNode(undefined);
          selectEdge(undefined);
        }}
        onMoveStart={() => closeContextMenu()}
        onMove={(_, viewport) => setZoom(viewport.zoom)}
        fitView
        minZoom={0.2}
        maxZoom={2}
        colorMode="dark"
      >
        <Background gap={24} />
        <Panel position="top-left" className="tutorial-canvas-panel">
          <TutorialPanel />
        </Panel>
        <Controls />
        <MiniMap
          pannable
          zoomable
          bgColor="#12161f"
          maskColor="rgba(15, 18, 25, 0.7)"
          nodeColor="#4d8dff"
          nodeStrokeColor="#1c2330"
        />
      </ReactFlow>
      <ul className="flow-legend" aria-label="Request flow legend">
        {(Object.keys(FLOW_CLASS_LABELS) as Array<keyof typeof FLOW_CLASS_LABELS>).map((key) => (
          <li key={key}>
            <span
              className="flow-legend-swatch"
              style={{ background: FLOW_CLASS_COLORS[key] }}
              aria-hidden="true"
            />
            {FLOW_CLASS_LABELS[key]}
          </li>
        ))}
      </ul>
    </div>
  );
}
