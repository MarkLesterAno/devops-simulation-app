import { useEffect, useMemo, useRef, useState } from "react";
import { usePlaybackStore } from "@/stores/playbackStore";
import {
  EMPTY_FRAME,
  sampleTimelineAt,
  type PlaybackFrame
} from "@/domain/flow/playbackFrame";
import type { ProjectDocument } from "@/domain/architecture/projectDocument";

/** Frames per second the playback layer samples at. */
const TARGET_FPS = 30;
const FRAME_BUDGET_MS = 1000 / TARGET_FPS;

/**
 * Drives visual playback from `requestAnimationFrame` and returns the frame to
 * render.
 *
 * Sampling is throttled to {@link TARGET_FPS} rather than running on every
 * animation frame: the underlying data only changes once per bucket, so
 * re-deriving it 60 times a second would burn CPU for no visible benefit. The
 * loop stops entirely when playback is not running, so an idle canvas costs
 * nothing.
 */
export function usePlaybackFrame(document: ProjectDocument): PlaybackFrame {
  const status = usePlaybackStore((state) => state.status);
  const timeline = usePlaybackStore((state) => state.timeline);
  const advance = usePlaybackStore((state) => state.advance);
  const [frame, setFrame] = useState<PlaybackFrame>(EMPTY_FRAME);

  const edgeTargets = useMemo(() => {
    const map = new Map<string, string>();
    for (const edge of document.edges) map.set(edge.id, edge.targetNodeId);
    return map;
  }, [document.edges]);

  const lastFrameAt = useRef<number | undefined>(undefined);

  useEffect(() => {
    if (status !== "running") {
      lastFrameAt.current = undefined;
      // Settle on the final instant so a paused or completed run keeps showing
      // meaningful edge state instead of going blank.
      const logicalTime = usePlaybackStore.getState().currentLogicalTimeMs;
      setFrame(
        status === "idle"
          ? EMPTY_FRAME
          : sampleTimelineAt(timeline, logicalTime, edgeTargets)
      );
      return;
    }

    let handle = 0;
    let lastSampledAt = 0;

    const tick = (now: number): void => {
      const previous = lastFrameAt.current ?? now;
      lastFrameAt.current = now;
      advance(now - previous);

      if (now - lastSampledAt >= FRAME_BUDGET_MS) {
        lastSampledAt = now;
        const logicalTime = usePlaybackStore.getState().currentLogicalTimeMs;
        setFrame(sampleTimelineAt(timeline, logicalTime, edgeTargets));
      }
      handle = requestAnimationFrame(tick);
    };

    handle = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(handle);
  }, [status, timeline, advance, edgeTargets]);

  // The frame always drives counters and status badges; whether particles
  // actually move is decided by the edge renderer, so disabling animation
  // still leaves live traffic counts visible.
  return frame;
}
