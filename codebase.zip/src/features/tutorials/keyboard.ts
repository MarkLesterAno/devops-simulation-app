export function isTutorialBlockedShortcut(event: {
  key: string;
  ctrlKey: boolean;
  metaKey: boolean;
  shiftKey: boolean;
}): boolean {
  const key = event.key.toLowerCase();
  const isMod = event.ctrlKey || event.metaKey;
  return (
    (isMod && ["m", "s", "y", "z"].includes(key)) ||
    event.key === "Delete" ||
    event.key === "Backspace" ||
    event.key === "Enter" ||
    (event.shiftKey && event.key === "F10")
  );
}
