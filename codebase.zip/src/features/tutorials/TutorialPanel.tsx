import { useEffect, useRef } from "react";
import { getTutorial } from "@/domain/tutorials/registry";
import type { TutorialPredicate } from "@/domain/tutorials/schema";
import { useProjectStore } from "@/stores/projectStore";
import { useTutorialStore } from "@/stores/tutorialStore";
import { useUiStore } from "@/stores/uiStore";
import { buildScenarioDocument } from "@/domain/scenarios/builder";
import { getScenarioTemplate } from "@/domain/scenarios/registry";

function usePredicate(predicate: TutorialPredicate | undefined, scenarioId: string): boolean {
  const activeScenarioId = useUiStore((state) => state.activeScenarioId);
  const metricsModalOpen = useUiStore((state) => state.metricsModalOpen);
  const contextPanelOpen = useUiStore((state) => state.contextPanelOpen);
  const contextPanelTab = useUiStore((state) => state.contextPanelTab);
  const lastResult = useProjectStore((state) => state.lastResult);
  const isSimulating = useProjectStore((state) => state.isSimulating);

  if (predicate === "scenario-loaded") return activeScenarioId === scenarioId;
  if (predicate === "simulation-complete") return Boolean(lastResult) && !isSimulating;
  if (predicate === "metrics-open") {
    return metricsModalOpen || (contextPanelOpen && contextPanelTab === "metrics");
  }
  return false;
}

export function TutorialPanel(): JSX.Element | null {
  const panelRef = useRef<HTMLElement>(null);
  const activeTutorialId = useTutorialStore((state) => state.activeTutorialId);
  const progressByTutorial = useTutorialStore((state) => state.progressByTutorial);
  const acknowledge = useTutorialStore((state) => state.acknowledge);
  const next = useTutorialStore((state) => state.next);
  const back = useTutorialStore((state) => state.back);
  const restart = useTutorialStore((state) => state.restart);
  const exit = useTutorialStore((state) => state.exit);
  const revealHint = useTutorialStore((state) => state.revealHint);
  const loadTemplateDocument = useProjectStore((state) => state.loadTemplateDocument);
  const setActiveScenario = useUiStore((state) => state.setActiveScenario);
  const tutorial = activeTutorialId ? getTutorial(activeTutorialId) : undefined;
  const progress = activeTutorialId ? progressByTutorial[activeTutorialId] : undefined;
  const stepIndex = progress?.currentStepIndex ?? 0;
  const step = tutorial?.steps[stepIndex];
  const predicateComplete = usePredicate(
    step?.completion.kind === "automatic" ? step.completion.predicate : undefined,
    tutorial?.scenarioId ?? ""
  );
  const manuallyComplete =
    step?.completion.kind === "manual" &&
    Boolean(progress?.acknowledgedStepIds.includes(step.id));
  const canContinue = predicateComplete || manuallyComplete;
  const visibleHints = step?.hints.slice(0, progress?.revealedHintCount ?? 0) ?? [];

  useEffect(() => {
    if (!tutorial) return;
    panelRef.current?.focus();
  }, [tutorial]);

  useEffect(() => {
    if (!tutorial) return;
    const handleKeyDown = (event: KeyboardEvent): void => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      event.stopPropagation();
      exit();
    };
    window.addEventListener("keydown", handleKeyDown, true);
    return () => window.removeEventListener("keydown", handleKeyDown, true);
  }, [tutorial, exit]);

  if (!tutorial || !step) return null;
  const scenarioId = tutorial.scenarioId;

  function showReference(): void {
    const scenario = getScenarioTemplate(scenarioId);
    if (!scenario) return;
    if (
      window.confirm(
        "Show the reference solution? This replaces the current canvas. Your current project changes will be lost unless you save or export first."
      )
    ) {
      loadTemplateDocument(buildScenarioDocument(scenario, { mode: "guided-tour" }));
      setActiveScenario(scenario.metadata.id, "guided-tour");
    }
  }

  return (
    <aside
      ref={panelRef}
      className="tutorial-panel"
      role="dialog"
      aria-modal="false"
      aria-labelledby="tutorial-title"
      aria-describedby="tutorial-step-body"
      tabIndex={-1}
    >
      <header>
        <div>
          <p className="tutorial-eyebrow">
            Step {stepIndex + 1} of {tutorial.steps.length}
          </p>
          <h2 id="tutorial-title">{tutorial.title}</h2>
        </div>
        <button type="button" aria-label="Exit tutorial" onClick={exit}>
          ×
        </button>
      </header>
      <progress
        value={stepIndex + 1}
        max={tutorial.steps.length}
        aria-label={`Tutorial progress: step ${stepIndex + 1} of ${tutorial.steps.length}`}
      />
      <div className="tutorial-content">
        <p className="tutorial-action">{step.action.replace("-", " ")}</p>
        <h3>{step.title}</h3>
        <p id="tutorial-step-body">{step.body}</p>
        {step.completion.kind === "manual" ? (
          <label className="tutorial-acknowledgement">
            <input
              type="checkbox"
              checked={manuallyComplete}
              onChange={(event) => acknowledge(step.id, event.target.checked)}
            />
            {step.completion.label}
          </label>
        ) : (
          <p className={`tutorial-status${predicateComplete ? " complete" : ""}`} role="status">
            {predicateComplete ? "Step requirement complete." : "Waiting for this action…"}
          </p>
        )}
        {visibleHints.length > 0 && (
          <ol className="tutorial-hints" aria-label="Tutorial hints">
            {visibleHints.map((hint) => <li key={hint}>{hint}</li>)}
          </ol>
        )}
      </div>
      <footer>
        <button type="button" onClick={back} disabled={stepIndex === 0}>
          Back
        </button>
        <button type="button" onClick={restart}>
          Restart
        </button>
        {step.hints.length > visibleHints.length && (
          <button type="button" onClick={revealHint}>
            Show hint
          </button>
        )}
        <span className="spacer" />
        <button type="button" onClick={showReference}>
          Show reference
        </button>
        <button type="button" onClick={exit}>
          Exit
        </button>
        <button type="button" className="primary" onClick={next} disabled={!canContinue}>
          {stepIndex === tutorial.steps.length - 1 ? "Finish" : "Next"}
        </button>
      </footer>
    </aside>
  );
}
