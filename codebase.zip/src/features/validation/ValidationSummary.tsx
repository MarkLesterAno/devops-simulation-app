import { useMemo } from "react";
import { useProjectStore } from "@/stores/projectStore";
import { hasBlockingErrors } from "@/domain/validation/graphValidation";

/**
 * Keeps graph validation visible at the point where learners need to act on it.
 * Empty workspaces are an onboarding state, not an invalid architecture.
 */
export function ValidationSummary(): JSX.Element | null {
  const issues = useProjectStore((state) => state.validationIssues);
  const nodeCount = useProjectStore((state) => state.document.nodes.length);
  const selectNode = useProjectStore((state) => state.selectNode);
  const errors = useMemo(() => issues.filter((issue) => issue.severity === "error"), [issues]);

  if (nodeCount === 0) {
    return (
      <aside className="validation-summary empty-workspace" aria-label="Getting started">
        <strong>Start an architecture</strong>
        <span>Choose a template, or add a Client and connect it to a component from the palette.</span>
      </aside>
    );
  }
  if (issues.length === 0) return null;

  return (
    <aside
      className={`validation-summary${hasBlockingErrors(issues) ? " validation-errors" : ""}`}
      aria-label="Architecture validation"
    >
      <strong>{errors.length > 0 ? `${errors.length} issue${errors.length === 1 ? "" : "s"} to fix before running` : "Architecture guidance"}</strong>
      <ul>
        {issues.map((issue) => {
          const nodeId = issue.nodeIds?.[0];
          return (
            <li key={`${issue.severity}-${issue.code}-${nodeId ?? ""}`}>
              {nodeId ? (
                <button type="button" onClick={() => selectNode(nodeId)}>
                  {issue.message}
                </button>
              ) : (
                <span>{issue.message}</span>
              )}
            </li>
          );
        })}
      </ul>
    </aside>
  );
}
