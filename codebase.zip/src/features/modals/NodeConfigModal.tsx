import { useProjectStore } from "@/stores/projectStore";
import { useUiStore, type NodeModalTab } from "@/stores/uiStore";
import { componentDefinitions } from "@/domain/components/registry";
import { NodeConfigForm } from "@/features/inspector/NodeConfigForm";
import { TechnologySelector } from "@/features/inspector/TechnologySelector";
import { ComponentIcon, TechnologyIcon } from "@/features/canvas/NodeIcons";
import { ModalShell, ModalTabs } from "./ModalShell";

const TABS: Array<{ id: NodeModalTab; label: string }> = [
  { id: "inspector", label: "Simulation settings" },
  { id: "implementation", label: "Implementation" }
];

/**
 * Focused, tabbed editor for a single node, opened by double-click or the
 * canvas context menu. Simulation settings lead because they are the values
 * that influence a run; implementation remains educational metadata.
 */
export function NodeConfigModal(): JSX.Element | null {
  const configNodeId = useUiStore((state) => state.configNodeId);
  const configTab = useUiStore((state) => state.configTab);
  const setConfigTab = useUiStore((state) => state.setConfigTab);
  const closeNodeConfig = useUiStore((state) => state.closeNodeConfig);
  const node = useProjectStore((state) =>
    state.document.nodes.find((candidate) => candidate.id === configNodeId)
  );

  if (!configNodeId || !node) return null;
  const definition = componentDefinitions[node.type];
  const technology = node.config.technology;
  const isClient = node.type === "client";
  const activeTab: NodeModalTab = isClient ? "inspector" : configTab;

  return (
    <ModalShell
      title={`Configure ${node.config.displayName}`}
      className="node-config-modal"
      onClose={closeNodeConfig}
      headerExtra={
        <span className="modal-subtitle">
          <ComponentIcon type={node.type} size={16} />
          {definition.displayName}
          {technology ? (
            <>
              <span aria-hidden="true">·</span>
              <TechnologyIcon assignment={technology} size={14} />
              {technology.displayName}
            </>
          ) : null}
        </span>
      }
    >
      {isClient ? null : (
        <ModalTabs tabs={TABS} active={activeTab} onSelect={setConfigTab} idPrefix="node-config" />
      )}
      <div className="modal-body">
        {activeTab === "implementation" ? (
          <div
            role="tabpanel"
            id="node-config-panel-implementation"
            aria-labelledby="node-config-tab-implementation"
          >
            <TechnologySelector node={node} />
          </div>
        ) : (
          <div
            role="tabpanel"
            id="node-config-panel-inspector"
            aria-labelledby="node-config-tab-inspector"
          >
            <p className="modal-hint">{definition.description}</p>
            <form onSubmit={(event) => event.preventDefault()}>
              <NodeConfigForm node={node} includeTechnology={false} />
            </form>
          </div>
        )}
      </div>
    </ModalShell>
  );
}
