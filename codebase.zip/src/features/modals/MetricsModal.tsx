import { useEffect, useMemo, useRef } from "react";
import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";
import { useProjectStore } from "@/stores/projectStore";
import { useUiStore } from "@/stores/uiStore";
import { usePlaybackStore } from "@/stores/playbackStore";
import { resultFreshness } from "@/domain/architecture/projectAnalysis";
import type { RunStatus, SystemMetricSnapshot } from "@/domain/metrics/schema";
import {
  rollupComponentMetrics,
  type ComponentMetricRollup
} from "@/features/metrics/componentRollup";
import { downsampleSystemMetrics, utilizationState } from "@/features/metrics/metricsChart";
import { ModalShell } from "./ModalShell";

const RUN_STATUS_MESSAGES: Record<Exclude<RunStatus, "completed">, string> = {
  invalid:
    "This run could not start because the architecture is invalid. Fix the reported errors, then run again.",
  cancelled: "This run was cancelled before it finished. Metrics cover only the part that ran.",
  failed: "This run failed unexpectedly. The metrics below may be incomplete."
};

/**
 * Simulation metrics, per LIVE_PLAYBACK_AND_REQUEST_SIMULATION_PROMPT.md
 * section 3.
 *
 * Findings are no longer shown here — they are raised as toasts — so this
 * modal is a single, focused view of what the run measured. Only metrics the
 * run actually produced are rendered, so a simple architecture is not padded
 * with rows of "n/a".
 */
export function MetricsModal(): JSX.Element | null {
  const open = useUiStore((state) => state.metricsModalOpen);
  const focusNodeId = useUiStore((state) => state.metricsFocusNodeId);
  const closeMetrics = useUiStore((state) => state.closeMetrics);
  const result = useProjectStore((state) => state.lastResult);
  const document_ = useProjectStore((state) => state.document);
  const lastResultSignature = useProjectStore((state) => state.lastResultSignature);
  const selectNode = useProjectStore((state) => state.selectNode);
  const currentLogicalTimeMs = usePlaybackStore((state) => state.currentLogicalTimeMs);
  const focusRef = useRef<HTMLTableRowElement | null>(null);

  const freshness = useMemo(
    () => resultFreshness(result, document_, lastResultSignature),
    [result, document_, lastResultSignature]
  );
  const stale = freshness !== "current";

  const nodeRollups = useMemo(
    () => rollupComponentMetrics(result?.componentMetrics ?? []),
    [result]
  );
  const systemMetrics = useMemo(
    () => downsampleSystemMetrics(result?.systemMetrics ?? []),
    [result]
  );

  const nameById = useMemo(() => {
    const map = new Map<string, string>();
    for (const node of document_.nodes) map.set(node.id, node.config.displayName);
    return map;
  }, [document_.nodes]);

  useEffect(() => {
    if (open && focusNodeId) {
      focusRef.current?.scrollIntoView({ block: "center", behavior: "auto" });
    }
  }, [open, focusNodeId]);

  if (!open) return null;

  const summary = result?.summary;
  const methods = Object.entries(result?.methodDistribution ?? {}).filter(([, count]) => count > 0);

  return (
    <ModalShell
      title="Simulation metrics"
      className="metrics-modal"
      onClose={closeMetrics}
      headerExtra={
        stale ? (
          <span className="stale-badge" role="status">
            {freshness === "simulation-model-changed"
              ? "Stale — simulation model changed; re-run to compare metrics"
              : "Stale — architecture changed since this run"}
          </span>
        ) : null
      }
    >
      <div className="modal-body">
        {!result ? (
          <p className="empty-state">Run a simulation to see metrics.</p>
        ) : (
          <>
            <p className="metric-note" role="note">
              Educational deterministic model: metrics describe logical request flow, configured
              capacities, and injected faults. They are not live infrastructure measurements or
              production capacity guarantees.
            </p>
            {result.status !== "completed" && (
              <p className="run-status-note" role="status">
                {RUN_STATUS_MESSAGES[result.status]}
              </p>
            )}

            {summary && (
              <section aria-label="Request totals">
                <h3>Requests</h3>
                <MetricRow label="Total requests" value={summary.requestCount.toLocaleString()} />
                <MetricRow label="Successful" value={summary.successCount.toLocaleString()} />
                <MetricRow label="Failed" value={summary.failureCount.toLocaleString()} />
                <MetricRow label="Requests per second" value={summary.rps.toFixed(1)} />
                <MetricRow label="Error rate" value={`${(summary.errorRate * 100).toFixed(1)}%`} />
                <MetricRow
                  label="p50 / p95 / p99 latency (ms)"
                  value={`${summary.latency.p50.toFixed(0)} / ${summary.latency.p95.toFixed(0)} / ${summary.latency.p99.toFixed(0)}`}
                />
                {result.observedAvailability !== undefined && (
                  <MetricRow
                    label="Observed availability"
                    value={`${(result.observedAvailability * 100).toFixed(2)}%`}
                  />
                )}
                {result.retryCount !== undefined && result.retryCount > 0 && (
                  <MetricRow label="Retries" value={result.retryCount.toLocaleString()} />
                )}
                {result.timeoutCount !== undefined && result.timeoutCount > 0 && (
                  <MetricRow label="Timeouts" value={result.timeoutCount.toLocaleString()} />
                )}
                {result.estimatedCost !== undefined && (
                  <MetricRow
                    label="Estimated cost / hour"
                    value={result.estimatedCost.toFixed(2)}
                  />
                )}
              </section>
            )}

            <MetricsCharts
              systemMetrics={systemMetrics}
              currentLogicalTimeMs={currentLogicalTimeMs}
            />

            {methods.length > 0 && (
              <section aria-label="Request method distribution">
                <h3>Request methods</h3>
                {methods.map(([method, count]) => (
                  <MetricRow key={method} label={method} value={count.toLocaleString()} />
                ))}
              </section>
            )}

            {result.manualBatchIds && result.manualBatchIds.length > 0 && (
              <section aria-label="Manual request batches">
                <h3>Manual request batches</h3>
                <p className="metric-note">
                  This run included {result.manualBatchIds.length} user-triggered batch
                  {result.manualBatchIds.length === 1 ? "" : "es"}:{" "}
                  {result.manualBatchIds.join(", ")}.
                </p>
              </section>
            )}

            {nodeRollups.length > 0 && (
              <section aria-label="Per-component metrics">
                <h3>Components</h3>
                <table className="metrics-table">
                  <thead>
                    <tr>
                      <th scope="col">Component</th>
                      <th scope="col">Peak utilization</th>
                      <th scope="col">Peak latency</th>
                      <th scope="col">Queue / lag</th>
                      <th scope="col">Cache hit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {nodeRollups.map((rollup) => {
                      const focused = rollup.nodeId === focusNodeId;
                      return (
                        <tr
                          key={rollup.nodeId}
                          ref={focused ? focusRef : undefined}
                          className={`metrics-component-row${focused ? " metrics-row-focused" : ""}`}
                          onClick={() => selectNode(rollup.nodeId)}
                          tabIndex={0}
                          onKeyDown={(event) => {
                            if (event.key === "Enter" || event.key === " ") {
                              event.preventDefault();
                              selectNode(rollup.nodeId);
                            }
                          }}
                        >
                          <th scope="row">{nameById.get(rollup.nodeId) ?? rollup.nodeId}</th>
                          <td>
                            <div
                              className={`node-utilization ${utilizationState(
                                rollup.peakUtilization
                              )}`}
                              aria-label={`${(rollup.peakUtilization * 100).toFixed(0)}% peak utilization`}
                            >
                              <span
                                style={{
                                  width: `${Math.min(rollup.peakUtilization, 1) * 100}%`
                                }}
                              />
                            </div>
                            <span>{(rollup.peakUtilization * 100).toFixed(0)}%</span>
                          </td>
                          <td>{rollup.peakLatencyMs.toFixed(0)} ms</td>
                          <td>{formatQueueCell(rollup)}</td>
                          <td>
                            {rollup.cacheHitRatio === undefined
                              ? "—"
                              : `${(rollup.cacheHitRatio * 100).toFixed(0)}%`}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </section>
            )}

            {result.events.length > 0 && (
              <section aria-label="Request-flow event timeline">
                <h3>Event timeline</h3>
                <ol className="event-timeline">
                  {result.events.slice(0, 100).map((event) => (
                    <li key={`${event.sequence}-${event.timestampMs}`}>
                      <span className="event-time">{event.timestampMs.toFixed(0)} ms</span>
                      <span className="event-type">{event.type}</span>
                      <span>{event.message}</span>
                    </li>
                  ))}
                </ol>
                {result.events.length > 100 && (
                  <p className="metric-note">
                    Showing the first 100 of {result.events.length} recorded events.
                  </p>
                )}
              </section>
            )}

            {result.assumptions.length > 0 && (
              <section aria-label="Simulation assumptions">
                <h3>Assumptions and limitations</h3>
                <ul className="assumption-list">
                  {result.assumptions.map((assumption) => (
                    <li key={assumption}>{assumption}</li>
                  ))}
                </ul>
              </section>
            )}
          </>
        )}
      </div>
    </ModalShell>
  );
}

function MetricRow({ label, value }: { label: string; value: string }): JSX.Element {
  return (
    <div className="metric-row">
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}

function formatQueueCell(rollup: ComponentMetricRollup): string {
  const parts: string[] = [];
  if (rollup.peakQueueDepth) parts.push(`depth ${rollup.peakQueueDepth.toFixed(0)}`);
  if (rollup.peakConsumerLagMs) parts.push(`lag ${rollup.peakConsumerLagMs.toFixed(0)} ms`);
  if (rollup.peakReplicaLagMs) parts.push(`replica ${rollup.peakReplicaLagMs.toFixed(0)} ms`);
  return parts.length > 0 ? parts.join(", ") : "—";
}

interface MetricsChartsProps {
  systemMetrics: readonly SystemMetricSnapshot[];
  currentLogicalTimeMs: number;
}

function MetricsCharts({
  systemMetrics,
  currentLogicalTimeMs
}: MetricsChartsProps): JSX.Element {
  if (systemMetrics.length < 2) {
    return (
      <section aria-label="Metric trends">
        <h3>Metric trends</h3>
        <p className="empty-state">
          Run a simulation with more than one measurement interval to view trends.
        </p>
      </section>
    );
  }

  const hasErrors = systemMetrics.some((snapshot) => snapshot.errorRate > 0);
  return (
    <section className="metrics-charts" aria-label="Metric trends">
      <h3>Metric trends</h3>
      <TrendChart title="Latency" systemMetrics={systemMetrics} currentLogicalTimeMs={currentLogicalTimeMs}>
        <Line type="monotone" dataKey="latency.p50" name="p50" stroke="#4d8dff" dot={false} />
        <Line type="monotone" dataKey="latency.p95" name="p95" stroke="#e0a92c" dot={false} />
        <Line type="monotone" dataKey="latency.p99" name="p99" stroke="#e14b4b" dot={false} />
      </TrendChart>
      <TrendChart title="Throughput" systemMetrics={systemMetrics} currentLogicalTimeMs={currentLogicalTimeMs}>
        <Line type="monotone" dataKey="rps" name="Requests / second" stroke="#37c26b" dot={false} />
      </TrendChart>
      {hasErrors && (
        <TrendChart title="Error rate" systemMetrics={systemMetrics} currentLogicalTimeMs={currentLogicalTimeMs}>
          <Line
            type="monotone"
            dataKey="errorRate"
            name="Error rate"
            stroke="#e14b4b"
            dot={false}
          />
        </TrendChart>
      )}
    </section>
  );
}

interface TrendChartProps extends MetricsChartsProps {
  title: string;
  children: React.ReactNode;
}

function TrendChart({
  title,
  systemMetrics,
  currentLogicalTimeMs,
  children
}: TrendChartProps): JSX.Element {
  return (
    <section className="metric-chart" aria-label={`${title} trend`}>
      <h4>{title}</h4>
      <div className="metric-chart-canvas">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={[...systemMetrics]} margin={{ top: 8, right: 18, bottom: 4, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333a46" />
            <XAxis
              dataKey="timestampMs"
              tickFormatter={(value: number) => `${(value / 1000).toFixed(0)}s`}
              stroke="#9aa4b2"
              fontSize={11}
            />
            <YAxis
              tickFormatter={(value: number) => `${title === "Error rate" ? (value * 100).toFixed(0) + "%" : value}`}
              stroke="#9aa4b2"
              fontSize={11}
            />
            <Tooltip
              labelFormatter={(value) => `${(Number(value) / 1000).toFixed(2)} s`}
              formatter={(value, name) => {
                const numericValue = Number(value);
                return [
                  title === "Error rate"
                    ? `${(numericValue * 100).toFixed(2)}%`
                    : numericValue.toFixed(1),
                  name
                ];
              }}
            />
            <Legend />
            <ReferenceLine
              x={currentLogicalTimeMs}
              stroke="#e7eaf0"
              strokeDasharray="4 3"
              label={{ value: "Playback", fill: "#e7eaf0", fontSize: 10 }}
            />
            {children}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}
