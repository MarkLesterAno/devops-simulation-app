import { useMemo, useState } from "react";
import { useProjectStore } from "@/stores/projectStore";
import { useUiStore } from "@/stores/uiStore";
import { usePlaybackStore } from "@/stores/playbackStore";
import { useRequestStore } from "@/stores/requestStore";
import { buildScenarioDocument, getScenarioStartingState } from "@/domain/scenarios/builder";
import {
  filterScenarios,
  getScenarioTags,
  scenarioDifficultyOrder,
  scenarioTemplates
} from "@/domain/scenarios/registry";
import type { ScenarioDifficulty, TutorialMode } from "@/domain/scenarios/schema";
import { ModalShell } from "@/features/modals/ModalShell";
import { useToastStore } from "@/stores/toastStore";
import { getTutorialForScenario } from "@/domain/tutorials/registry";
import { useTutorialStore } from "@/stores/tutorialStore";

const DIFFICULTY_LABELS: Record<ScenarioDifficulty, string> = {
  beginner: "Beginner",
  intermediate: "Intermediate",
  advanced: "Advanced",
  specialized: "Specialized"
};

/**
 * Scenario gallery, per SCENARIO_LIBRARY_AND_USER_DOCUMENTATION_PROMPT.md
 * section 1.
 *
 * Opening a template builds a fresh project document rather than handing over
 * a shared one, so a learner's edits can never mutate the shipped library. The
 * detail pane leads with what the template does and does not model, because a
 * scenario that quietly approximates a component teaches the wrong lesson.
 */
export function ScenarioGallery(): JSX.Element | null {
  const open = useUiStore((state) => state.scenarioGalleryOpen);
  const close = useUiStore((state) => state.closeScenarioGallery);
  const setActiveScenario = useUiStore((state) => state.setActiveScenario);
  const loadTemplateDocument = useProjectStore((state) => state.loadTemplateDocument);
  const isDirty = useProjectStore((state) => state.isDirty);
  const isSimulating = useProjectStore((state) => state.isSimulating);
  const resetRequests = useRequestStore((state) => state.reset);
  const resetPlayback = usePlaybackStore((state) => state.reset);
  const notify = useToastStore((state) => state.notify);
  const startTutorial = useTutorialStore((state) => state.start);
  const exitTutorial = useTutorialStore((state) => state.exit);

  const [search, setSearch] = useState("");
  const [difficulty, setDifficulty] = useState<ScenarioDifficulty | "">("");
  const [tag, setTag] = useState("");
  const [selectedId, setSelectedId] = useState(scenarioTemplates[0]?.metadata.id ?? "");
  const [mode, setMode] = useState<TutorialMode>("guided-tour");

  const tags = useMemo(() => getScenarioTags(), []);

  const visible = useMemo(
    () =>
      filterScenarios(scenarioTemplates, {
        search,
        ...(difficulty ? { difficulty } : {}),
        ...(tag ? { tag } : {})
      }),
    [search, difficulty, tag]
  );

  const selected = useMemo(
    () => visible.find((template) => template.metadata.id === selectedId) ?? visible[0],
    [visible, selectedId]
  );

  if (!open) return null;

  const handleOpenTemplate = (withTutorial = false): void => {
    if (!selected) return;
    if (isSimulating) {
      notify({
        severity: "warning",
        title: "Simulation is still running",
        detail: "Wait for the simulation to finish or cancel it before opening a scenario."
      });
      return;
    }
    if (
      isDirty &&
      !window.confirm(
        "Opening a scenario replaces the current project. Unsaved changes will be lost. Continue?"
      )
    ) {
      return;
    }
    resetRequests();
    resetPlayback();
    exitTutorial();
    loadTemplateDocument(buildScenarioDocument(selected, { mode }));
    setActiveScenario(selected.metadata.id, mode);
    close();
    if (withTutorial) {
      const tutorial = getTutorialForScenario(selected.metadata.id);
      if (tutorial) startTutorial(tutorial.id);
    }
  };

  return (
    <ModalShell title="Scenario library" onClose={close} className="scenario-gallery">
      <div className="scenario-gallery-filters">
        <label>
          Search
          <input
            type="search"
            value={search}
            placeholder="Name, tag, or objective"
            onChange={(event) => setSearch(event.target.value)}
          />
        </label>
        <label>
          Difficulty
          <select
            value={difficulty}
            onChange={(event) => setDifficulty(event.target.value as ScenarioDifficulty | "")}
          >
            <option value="">All</option>
            {scenarioDifficultyOrder.map((level) => (
              <option key={level} value={level}>
                {DIFFICULTY_LABELS[level]}
              </option>
            ))}
          </select>
        </label>
        <label>
          Tag
          <select value={tag} onChange={(event) => setTag(event.target.value)}>
            <option value="">All</option>
            {tags.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </label>
        <span className="scenario-gallery-count">
          {visible.length} of {scenarioTemplates.length}
        </span>
      </div>

      <div className="scenario-gallery-body">
        <ul className="scenario-list" role="listbox" aria-label="Scenarios">
          {visible.map(({ metadata }) => (
            <li key={metadata.id}>
              <button
                type="button"
                role="option"
                aria-selected={metadata.id === selected?.metadata.id}
                className={metadata.id === selected?.metadata.id ? "active" : undefined}
                onClick={() => setSelectedId(metadata.id)}
                onDoubleClick={() => handleOpenTemplate()}
              >
                <span className="scenario-list-name">{metadata.name}</span>
                <span className="scenario-list-meta">
                  {DIFFICULTY_LABELS[metadata.difficulty]} · {metadata.estimatedCompletionMinutes}{" "}
                  min
                </span>
              </button>
            </li>
          ))}
          {visible.length === 0 && <li className="scenario-list-empty">No scenarios match.</li>}
        </ul>

        {selected && (
          <div className="scenario-detail">
            <h3>{selected.metadata.name}</h3>
            <p className="scenario-detail-summary">{selected.metadata.summary}</p>

            <ul className="scenario-tag-row">
              {selected.metadata.tags.map((entry) => (
                <li key={entry}>{entry}</li>
              ))}
            </ul>

            <dl className="scenario-detail-facts">
              <dt>Components</dt>
              <dd>{selected.blueprint.nodes.length}</dd>
              <dt>Connections</dt>
              <dd>{selected.blueprint.edges.length}</dd>
              <dt>Workload</dt>
              <dd>{selected.metadata.workloadShapes.join(", ")}</dd>
              <dt>Default traffic</dt>
              <dd>{selected.metadata.defaultTrafficProfileId}</dd>
              <dt>Prerequisites</dt>
              <dd>
                {selected.metadata.recommendedPrerequisites.length > 0
                  ? selected.metadata.recommendedPrerequisites.join(", ")
                  : "None"}
              </dd>
              <dt>Documentation</dt>
              <dd>{selected.metadata.documentationPath}</dd>
            </dl>
            <fieldset className="scenario-mode-picker">
              <legend>Learning mode</legend>
              <label>
                <input
                  type="radio"
                  name="scenario-mode"
                  checked={mode === "guided-tour"}
                  onChange={() => setMode("guided-tour")}
                />
                Guided Tour — open the reference solution
              </label>
              <label>
                <input type="radio" name="scenario-mode" checked={mode === "build"} onChange={() => setMode("build")} />
                Build — start from the documented partial canvas
              </label>
              <label>
                <input type="radio" name="scenario-mode" checked={mode === "challenge"} onChange={() => setMode("challenge")} />
                Challenge — start with an empty canvas
              </label>
              <p className="metric-note">{getScenarioStartingState(selected, mode).rationale}</p>
            </fieldset>

            <h4>Learning objectives</h4>
            <ul>
              {selected.metadata.learningObjectives.map((objective) => (
                <li key={objective}>{objective}</li>
              ))}
            </ul>

            <h4>What this models</h4>
            <ul>
              {selected.metadata.modelledProperties.map((property) => (
                <li key={property}>{property}</li>
              ))}
            </ul>

            <h4>What it does not model</h4>
            <ul>
              {selected.metadata.simplifications.map((entry) => (
                <li key={entry}>{entry}</li>
              ))}
            </ul>

            {selected.metadata.standIns.length > 0 && (
              <>
                <h4>Stand-ins</h4>
                <ul>
                  {selected.metadata.standIns.map((standIn) => (
                    <li key={standIn.concept}>
                      <strong>{standIn.concept}</strong> modelled as{" "}
                      <code>{standIn.modelledAs}</code>. {standIn.rationale}
                    </li>
                  ))}
                </ul>
              </>
            )}

            <h4>Try next</h4>
            <ul>
              {selected.metadata.challenges.map((challenge) => (
                <li key={challenge}>{challenge}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <footer className="scenario-gallery-footer">
        <span>Opening a scenario creates a new unsaved project from the template.</span>
        <span className="spacer" />
        <button type="button" onClick={close}>
          Cancel
        </button>
        <button
          type="button"
          className="primary"
          disabled={!selected || isSimulating}
          onClick={() => handleOpenTemplate()}
        >
          Open scenario
        </button>
        <button
          type="button"
          className="primary"
          disabled={!selected || isSimulating || !getTutorialForScenario(selected.metadata.id)}
          onClick={() => handleOpenTemplate(true)}
        >
          Start tutorial
        </button>
      </footer>
    </ModalShell>
  );
}
