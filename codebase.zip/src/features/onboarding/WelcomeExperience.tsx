import { buildScenarioDocument } from "@/domain/scenarios/builder";
import { getScenarioTemplate } from "@/domain/scenarios/registry";
import { getTutorialForScenario } from "@/domain/tutorials/registry";
import { ModalShell } from "@/features/modals/ModalShell";
import { usePlaybackStore } from "@/stores/playbackStore";
import { useProjectStore } from "@/stores/projectStore";
import { useRequestStore } from "@/stores/requestStore";
import { useTutorialStore } from "@/stores/tutorialStore";
import { useUiStore } from "@/stores/uiStore";
import { useWelcomeStore } from "@/stores/welcomeStore";

const STARTER_SCENARIO_ID = "basic-web-application";

/**
 * First-run guidance deliberately begins with a known runnable scenario rather
 * than a blank graph, so new learners see the simulator's modeled boundaries
 * before they begin designing independently.
 */
export function WelcomeExperience(): JSX.Element | null {
  const hasSeenWelcome = useWelcomeStore((state) => state.hasSeenWelcome);
  const isOpen = useWelcomeStore((state) => state.isOpen);
  const dismiss = useWelcomeStore((state) => state.dismiss);
  const openScenarioGallery = useUiStore((state) => state.openScenarioGallery);
  const setActiveScenario = useUiStore((state) => state.setActiveScenario);
  const loadTemplateDocument = useProjectStore((state) => state.loadTemplateDocument);
  const resetRequests = useRequestStore((state) => state.reset);
  const resetPlayback = usePlaybackStore((state) => state.reset);
  const startTutorial = useTutorialStore((state) => state.start);
  const exitTutorial = useTutorialStore((state) => state.exit);

  if (hasSeenWelcome && !isOpen) return null;

  function openStarterTutorial(): void {
    const scenario = getScenarioTemplate(STARTER_SCENARIO_ID);
    const tutorial = getTutorialForScenario(STARTER_SCENARIO_ID);
    if (!scenario || !tutorial) {
      throw new Error("The Basic Web Application starter scenario is unavailable.");
    }

    resetRequests();
    resetPlayback();
    exitTutorial();
    loadTemplateDocument(buildScenarioDocument(scenario, { mode: "guided-tour" }));
    setActiveScenario(scenario.metadata.id, "guided-tour");
    startTutorial(tutorial.id);
    dismiss();
  }

  function browseScenarios(): void {
    dismiss();
    openScenarioGallery();
  }

  return (
    <ModalShell title="Welcome to the System Design Simulator" onClose={dismiss} className="welcome-experience">
      <div className="modal-body welcome-experience-body">
        <p className="welcome-experience-lead">
          Learn by building and measuring local, deterministic architecture models.
        </p>
        <ol>
          <li>Start with a guided beginner scenario to see a request path and its metrics.</li>
          <li>Use Build or Challenge mode when you are ready to create your own topology.</li>
          <li>Compare repeatable runs with the same traffic, faults, duration, and seed.</li>
        </ol>
        <section className="welcome-experience-boundary" aria-labelledby="model-boundaries-title">
          <h3 id="model-boundaries-title">What the simulator does and does not do</h3>
          <p>
            Requests, failures, and metrics are logical local simulation inputs and outputs. The
            app never sends HTTP traffic, provisions infrastructure, contacts cloud providers, or
            guarantees production capacity, availability, cost, or security outcomes.
          </p>
        </section>
      </div>
      <footer className="modal-footer welcome-experience-footer">
        <button type="button" onClick={dismiss}>
          Build from scratch
        </button>
        <span className="spacer" />
        <button type="button" onClick={browseScenarios}>
          Browse scenarios
        </button>
        <button type="button" className="primary" onClick={openStarterTutorial}>
          Start guided beginner scenario
        </button>
      </footer>
    </ModalShell>
  );
}
