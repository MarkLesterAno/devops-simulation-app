import type { HttpMethod, RequestClass } from "@/domain/simulation/manualRequest";

export type RequestOutcome = "success" | "error" | "timeout" | "overloaded" | "routing-loop";

export type RequestStatus = "queued" | "active" | "terminal";

/**
 * A single request instance flowing through the graph, per SIMULATION_SPEC.md
 * "Request model and routing". Retries share the rootId and increment attempt
 * and hopCount but never reset the deadline.
 */
export interface SimRequest {
  id: string;
  rootId: string;
  attempt: number;
  createdAtMs: number;
  deadlineMs: number;
  isRead: boolean;
  hopCount: number;
  status: RequestStatus;
  outcome?: RequestOutcome;
  currentNodeId?: string;
  queueEnqueuedAtMs?: number;
  accumulatedLatencyMs: number;
  timeoutScheduled: boolean;
  /** Partition chosen when the request entered a partitioned data store. */
  partitionIndex?: number;
  /** True once an identity component has admitted this request. */
  authenticated?: boolean;
  /** HTTP-like method, carried for metrics and flow classification. */
  method: HttpMethod;
  /** Effective request class, resolved when the request is created. */
  requestClass: RequestClass;
  /** Client node the request originated from. */
  originNodeId: string;
  /** Manual batch this request belongs to, when it was not profile traffic. */
  manualBatchId?: string;
  /** Optional route label supplied by a manual batch. */
  path?: string;
  payloadSizeBytes?: number;
  responseSizeBytes?: number;
}

let requestSequence = 0;

export function resetRequestSequence(): void {
  requestSequence = 0;
}

export function nextRequestId(rootId: string, attempt: number): string {
  requestSequence += 1;
  return `${rootId}#${attempt}-${requestSequence}`;
}
