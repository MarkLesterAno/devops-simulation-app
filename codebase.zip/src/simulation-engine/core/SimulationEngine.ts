import type { ArchitectureEdge, ArchitectureNode } from "@/domain/architecture/schema";
import type { SimulationInput } from "@/domain/simulation/simulationInput";
import type { TrafficProfile } from "@/domain/simulation/trafficProfile";
import type { ScheduledFault } from "@/domain/simulation/faultScenario";
import type { SimulationResult, SimulationEvent } from "@/domain/metrics/schema";
import { validateGraph, hasBlockingErrors } from "@/domain/validation/graphValidation";
import { SeededRandom } from "@/simulation-engine/core/SeededRandom";
import { EventQueue, EventPriority, type SimulationEventBase } from "@/simulation-engine/events/EventQueue";
import {
  consumeToken,
  createNodeRuntime,
  effectiveCapacity,
  effectiveErrorRate,
  type NodeRuntime,
  type QueuedMessage
} from "@/simulation-engine/core/NodeRuntime";
import {
  nextRequestId,
  resetRequestSequence,
  type SimRequest
} from "@/simulation-engine/core/RequestTypes";
import { generateArrivalTimestamps } from "@/simulation-engine/core/trafficGenerator";
import {
  applyFaultsToNode,
  findActiveFaults,
  findActiveTrafficMultiplier
} from "@/simulation-engine/faults/FaultRuntime";
import { MetricAggregator } from "@/simulation-engine/metrics/MetricAggregator";
import { FlowRecorder } from "@/simulation-engine/metrics/FlowRecorder";
import type { EdgeFlowSample, FlowClass } from "@/domain/metrics/flowTimeline";
import {
  effectiveRequestClass,
  generateManualArrivalTimestamps,
  isReadRequestClass,
  type HttpMethod
} from "@/domain/simulation/manualRequest";
import { deriveFindings } from "@/simulation-engine/core/findings";

export const ENGINE_VERSION = "0.3.0";

/**
 * Component behavior model version. Bumped whenever a component's runtime
 * semantics change, because results produced under different model versions are
 * not comparable (TRD.md "Versioning and migration").
 */
export const COMPONENT_MODEL_VERSION = "2.0.0";

type EngineEventType =
  | "arrival"
  | "complete"
  | "timeout-check"
  | "queue-pull"
  | "metric-tick"
  | "fault-boundary";

interface EngineEvent extends SimulationEventBase {
  type: EngineEventType;
  nodeId?: string;
  requestId?: string;
  /** Manual batch that produced this arrival, for `__manual_arrival__` events. */
  batchId?: string;
}

const DEFAULT_REQUEST_TIMEOUT_MS = 2000;

/** Marker request ids used to distinguish the two kinds of root arrival. */
const PROFILE_ARRIVAL = "__root_arrival__";
const MANUAL_ARRIVAL = "__manual_arrival__";

export function runSimulation(input: SimulationInput): SimulationResult {
  const { projectSnapshot } = input;
  const validationIssues = validateGraph(projectSnapshot.nodes, projectSnapshot.edges);
  if (hasBlockingErrors(validationIssues)) {
    return {
      runId: crypto.randomUUID(),
      seed: input.seed,
      status: "invalid",
      engineVersion: ENGINE_VERSION,
      componentModelVersion: COMPONENT_MODEL_VERSION,
      systemMetrics: [],
      componentMetrics: [],
      events: [],
      findings: validationIssues
        .filter((issue) => issue.severity === "error")
        .map((issue, index) => ({
          id: `invalid-${index}`,
          source: "architecture-warning" as const,
          severity: "critical" as const,
          title: issue.code,
          detail: issue.message,
          evidence: [],
          relatedNodeIds: issue.nodeIds ?? [],
          relatedEdgeIds: issue.edgeIds ?? []
        })),
      assumptions: ["Simulation blocked: the graph failed validation."]
    };
  }

  const profile = projectSnapshot.trafficProfiles.find((p) => p.id === input.trafficProfileId);
  if (!profile) {
    return invalidResult(input.seed, "Referenced traffic profile was not found.");
  }
  const faultScenarios = projectSnapshot.faultScenarios.filter((scenario) =>
    input.faultScenarioIds.includes(scenario.id)
  );
  const allFaults: ScheduledFault[] = faultScenarios.flatMap((scenario) => scenario.faults);

  return new SimulationEngine(input, profile, allFaults).run();
}

function invalidResult(seed: number, message: string): SimulationResult {
  return {
    runId: crypto.randomUUID(),
    seed,
    status: "invalid",
    engineVersion: ENGINE_VERSION,
    componentModelVersion: COMPONENT_MODEL_VERSION,
    systemMetrics: [],
    componentMetrics: [],
    events: [],
    findings: [],
    assumptions: [message]
  };
}

class SimulationEngine {
  private readonly random: SeededRandom;
  private readonly queue = new EventQueue<EngineEvent>();
  private sequence = 0;
  private readonly nodeById = new Map<string, ArchitectureNode>();
  private readonly runtimeByNodeId = new Map<string, NodeRuntime>();
  private readonly requestEdgesBySource = new Map<string, ArchitectureEdge[]>();
  private readonly eventEdgesBySource = new Map<string, ArchitectureEdge[]>();
  private readonly edgeById = new Map<string, ArchitectureEdge>();
  private readonly requests = new Map<string, SimRequest>();
  private readonly aggregator: MetricAggregator;
  private readonly flowRecorder: FlowRecorder;
  private readonly diagnosticEvents: SimulationEvent[] = [];
  private eventsProcessed = 0;
  private completedRootRequests = 0;
  private successfulRootRequests = 0;
  private readonly retryCountByRoot = new Map<string, number>();
  /** Flow samples each in-flight root request has traversed, for failure attribution. */
  private readonly flowSamplesByRoot = new Map<string, EdgeFlowSample[]>();
  private readonly methodCounts = new Map<HttpMethod, number>();
  private totalRetries = 0;
  private totalTimeouts = 0;

  constructor(
    private readonly input: SimulationInput,
    private readonly profile: TrafficProfile,
    private readonly faults: ScheduledFault[]
  ) {
    this.random = new SeededRandom(input.seed);
    this.aggregator = new MetricAggregator(input.settings.metricIntervalMs);
    this.flowRecorder = new FlowRecorder(input.settings.metricIntervalMs);
    resetRequestSequence();

    for (const node of input.projectSnapshot.nodes) {
      this.nodeById.set(node.id, node);
      this.runtimeByNodeId.set(node.id, createNodeRuntime(node));
    }
    for (const edge of input.projectSnapshot.edges) {
      this.edgeById.set(edge.id, edge);
      if (edge.kind === "request") {
        const list = this.requestEdgesBySource.get(edge.sourceNodeId) ?? [];
        list.push(edge);
        this.requestEdgesBySource.set(edge.sourceNodeId, list);
      } else if (edge.kind === "event") {
        const list = this.eventEdgesBySource.get(edge.sourceNodeId) ?? [];
        list.push(edge);
        this.eventEdgesBySource.set(edge.sourceNodeId, list);
      }
    }
  }

  run(): SimulationResult {
    if (this.input.suppressProfileTraffic !== true) {
      const arrivalTimes = generateArrivalTimestamps(this.profile);
      for (const timestamp of arrivalTimes) {
        this.pushEvent({ type: "arrival", timestampMs: timestamp, priority: EventPriority.ArrivalForwardOrRetry, nodeId: undefined, requestId: PROFILE_ARRIVAL }, timestamp);
      }
    }
    // Manual batches are scheduled after profile traffic so that, at an
    // identical timestamp, profile arrivals keep their existing sequence
    // numbers. Adding a batch therefore cannot reorder pre-existing events.
    for (const batch of this.input.manualRequests ?? []) {
      for (const timestamp of generateManualArrivalTimestamps(batch)) {
        this.pushEvent(
          {
            type: "arrival",
            timestampMs: timestamp,
            priority: EventPriority.ArrivalForwardOrRetry,
            requestId: MANUAL_ARRIVAL,
            batchId: batch.id
          },
          timestamp
        );
      }
    }
    let nextMetricTick = 0;
    while (nextMetricTick <= this.input.durationMs) {
      this.pushEvent(
        { type: "metric-tick", timestampMs: nextMetricTick, priority: EventPriority.MetricSnapshot },
        nextMetricTick
      );
      nextMetricTick += this.input.settings.metricIntervalMs;
    }

    while (!this.queue.isEmpty()) {
      const event = this.queue.pop();
      if (!event) break;
      if (event.timestampMs > this.input.durationMs + 60_000) continue; // safety bound
      this.eventsProcessed += 1;
      if (this.eventsProcessed > this.input.settings.maxEventsProcessed) break;
      this.handleEvent(event);
    }

    this.aggregator.maybeSnapshot(this.input.durationMs, [...this.runtimeByNodeId.values()], true);

    const observedAvailability =
      this.completedRootRequests > 0 ? this.successfulRootRequests / this.completedRootRequests : undefined;

    const componentMetrics = this.aggregator.componentSnapshots;
    const systemMetrics = this.aggregator.systemSnapshots;
    const summary = this.aggregator.buildSummary(this.input.durationMs);
    const validationIssues = validateGraph(this.input.projectSnapshot.nodes, this.input.projectSnapshot.edges);

    return {
      runId: crypto.randomUUID(),
      seed: this.input.seed,
      status: "completed",
      engineVersion: ENGINE_VERSION,
      componentModelVersion: COMPONENT_MODEL_VERSION,
      summary,
      systemMetrics,
      componentMetrics,
      events: this.diagnosticEvents,
      findings: deriveFindings(validationIssues, componentMetrics, observedAvailability),
      assumptions: [
        "Capacity is modeled as concurrent in-flight request slots, not literal RPS ceilings.",
        "CDN and Load Balancer nodes are treated as near-zero-overhead forwarders in this MVP.",
        "Retries are bounded by node-level configuration and the shared request deadline.",
        "Queue consumption uses configured throughput per worker instance; no partitioning is modeled.",
        "Manual request batches are logical arrivals only; no network activity of any kind occurs.",
        "Request-flow playback replays recorded telemetry and cannot change a calculated result."
      ],
      observedAvailability,
      flowTimeline: this.flowRecorder.build(this.input.durationMs),
      methodDistribution: Object.fromEntries(this.methodCounts),
      manualBatchIds: (this.input.manualRequests ?? []).map((batch) => batch.id),
      retryCount: this.totalRetries,
      timeoutCount: this.totalTimeouts
    };
  }

  private pushEvent(partial: Omit<EngineEvent, "sequence">, timestampMs: number): void {
    this.sequence += 1;
    this.queue.push({ ...partial, timestampMs, sequence: this.sequence });
  }

  private recordDiagnostic(timestampMs: number, type: string, message: string, extra?: Partial<SimulationEvent>): void {
    if (this.diagnosticEvents.length >= this.input.settings.maxRecordedEvents) return;
    this.diagnosticEvents.push({
      sequence: this.diagnosticEvents.length,
      timestampMs,
      type,
      message,
      ...extra
    });
  }

  private handleEvent(event: EngineEvent): void {
    switch (event.type) {
      case "arrival":
        if (event.requestId === PROFILE_ARRIVAL) {
          this.processRootArrival(event.timestampMs);
        } else if (event.requestId === MANUAL_ARRIVAL && event.batchId) {
          this.processManualArrival(event.batchId, event.timestampMs);
        } else if (event.requestId === "__retry_root_arrival__" && event.nodeId) {
          this.processRetryArrival(event.nodeId, event.timestampMs);
        } else if (event.nodeId && event.requestId) {
          this.processArrival(event.nodeId, event.requestId, event.timestampMs);
        }
        break;
      case "complete":
        if (event.nodeId && event.requestId) {
          this.processCompletion(event.nodeId, event.requestId, event.timestampMs);
        }
        break;
      case "timeout-check":
        if (event.requestId) this.processTimeoutCheck(event.requestId, event.timestampMs);
        break;
      case "queue-pull":
        if (event.nodeId) this.processQueuePull(event.nodeId, event.timestampMs);
        break;
      case "metric-tick":
        this.aggregator.maybeSnapshot(event.timestampMs, [...this.runtimeByNodeId.values()], true);
        break;
      default:
        break;
    }
  }

  private clientNode(): ArchitectureNode | undefined {
    return this.input.projectSnapshot.nodes.find((node) => node.type === "client");
  }

  private processRootArrival(nowMs: number): void {
    const client = this.clientNode();
    if (!client) return;
    const edges = this.requestEdgesBySource.get(client.id) ?? [];
    if (edges.length === 0) return;

    // Traffic-spike faults scale arrival volume at this instant (AC-FA-02): a
    // multiplier above 1 creates extra requests, below 1 probabilistically drops one.
    const multiplier = findActiveTrafficMultiplier(this.faults, nowMs);
    const wholeCopies = Math.floor(multiplier);
    const fractional = multiplier - wholeCopies;
    let copies = wholeCopies;
    if (fractional > 0 && this.random.chance(fractional)) copies += 1;
    if (multiplier < 1) copies = this.random.chance(multiplier) ? 1 : 0;

    for (let i = 0; i < copies; i += 1) {
      this.createAndRouteRootRequest(client, edges, nowMs);
    }
  }

  private createAndRouteRootRequest(
    client: ArchitectureNode,
    edges: ArchitectureEdge[],
    nowMs: number
  ): void {
    const isRead = this.random.chance(this.profile.readRatio);
    this.spawnRootRequest(client, edges, nowMs, {
      isRead,
      method: isRead ? "GET" : "POST",
      requestClass: isRead ? "read" : "write",
      payloadSizeBytes: this.profile.requestSizeBytes,
      responseSizeBytes: this.profile.responseSizeBytes,
      timeoutMs: client.config.timeoutMs || DEFAULT_REQUEST_TIMEOUT_MS
    });
  }

  /**
   * Dispatches one request from a manual batch. Manual batches consume no
   * random draws for their read/write split — the class is user-declared — so
   * adding a batch cannot shift the profile traffic's random sequence.
   */
  private processManualArrival(batchId: string, nowMs: number): void {
    const batch = (this.input.manualRequests ?? []).find((item) => item.id === batchId);
    if (!batch) return;
    const origin = this.nodeById.get(batch.sourceNodeId) ?? this.clientNode();
    if (!origin) return;
    const edges = this.requestEdgesBySource.get(origin.id) ?? [];
    if (edges.length === 0) return;

    const requestClass = effectiveRequestClass(batch);
    this.spawnRootRequest(origin, edges, nowMs, {
      isRead: isReadRequestClass(batch.method, batch.requestClass),
      method: batch.method,
      requestClass,
      manualBatchId: batch.id,
      path: batch.path,
      payloadSizeBytes: batch.payloadSizeBytes,
      responseSizeBytes: batch.responseSizeBytes,
      timeoutMs: batch.timeoutMs ?? origin.config.timeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS
    });
  }

  private spawnRootRequest(
    origin: ArchitectureNode,
    edges: ArchitectureEdge[],
    nowMs: number,
    meta: {
      isRead: boolean;
      method: SimRequest["method"];
      requestClass: SimRequest["requestClass"];
      manualBatchId?: string;
      path?: string;
      payloadSizeBytes?: number;
      responseSizeBytes?: number;
      timeoutMs: number;
    }
  ): void {
    const rootId = nextRequestId(origin.id, 0);
    const request: SimRequest = {
      id: rootId,
      rootId,
      attempt: 0,
      createdAtMs: nowMs,
      deadlineMs: nowMs + meta.timeoutMs,
      isRead: meta.isRead,
      hopCount: 0,
      status: "active",
      accumulatedLatencyMs: 0,
      timeoutScheduled: false,
      method: meta.method,
      requestClass: meta.requestClass,
      originNodeId: origin.id,
      manualBatchId: meta.manualBatchId,
      path: meta.path,
      payloadSizeBytes: meta.payloadSizeBytes,
      responseSizeBytes: meta.responseSizeBytes
    };
    this.methodCounts.set(meta.method, (this.methodCounts.get(meta.method) ?? 0) + 1);
    this.requests.set(request.id, request);
    this.scheduleTimeoutCheck(request);
    this.routeAlong(edges, request, nowMs);
  }

  private processRetryArrival(retryRequestId: string, nowMs: number): void {
    const client = this.clientNode();
    const request = this.requests.get(retryRequestId);
    if (!client || !request || request.status === "terminal") return;
    const edges = this.requestEdgesBySource.get(request.originNodeId) ?? this.requestEdgesBySource.get(client.id) ?? [];
    this.routeAlong(edges, request, nowMs);
  }

  private scheduleTimeoutCheck(request: SimRequest): void {
    if (request.timeoutScheduled) return;
    request.timeoutScheduled = true;
    this.pushEvent(
      {
        type: "timeout-check",
        timestampMs: request.deadlineMs,
        priority: EventPriority.TimeoutOrCircuitBreaker,
        requestId: request.id
      },
      request.deadlineMs
    );
  }

  private routeAlong(edges: ArchitectureEdge[], request: SimRequest, nowMs: number): void {
    if (request.hopCount >= this.input.settings.maxHopCount) {
      this.finishRootRequest(request, false, nowMs, "routing-loop");
      return;
    }
    const edge = this.selectEdge(edges, request);
    if (!edge) {
      this.finishRootRequest(request, false, nowMs, "no-healthy-target");
      return;
    }
    request.hopCount += 1;
    request.currentNodeId = edge.targetNodeId;
    this.recordFlow(edge, request, nowMs);
    const arriveAt = nowMs + edge.latencyMs;
    this.pushEvent(
      {
        type: "arrival",
        timestampMs: arriveAt,
        priority: EventPriority.ArrivalForwardOrRetry,
        nodeId: edge.targetNodeId,
        requestId: request.id
      },
      arriveAt
    );
  }

  private selectEdge(edges: ArchitectureEdge[], _request: SimRequest): ArchitectureEdge | undefined {
    const healthy = edges.filter((edge) => this.isNodeRoutable(edge.targetNodeId));
    if (healthy.length === 0) return undefined;
    if (healthy.length === 1) return healthy[0];
    const sourceRuntime = this.runtimeByNodeId.get(healthy[0]!.sourceNodeId);
    const strategy = healthy[0]?.routingStrategy ?? "round-robin";
    if (strategy === "weighted") {
      const totalWeight = healthy.reduce((sum, edge) => sum + (edge.weight ?? 1), 0);
      let roll = this.random.next() * totalWeight;
      for (const edge of healthy) {
        roll -= edge.weight ?? 1;
        if (roll <= 0) return edge;
      }
      return healthy[healthy.length - 1];
    }
    if (strategy === "random") {
      return this.random.pick(healthy);
    }
    if (strategy === "least-active") {
      return healthy.reduce((best, edge) => {
        const bestActive = this.runtimeByNodeId.get(best.targetNodeId)?.activeWork ?? 0;
        const edgeActive = this.runtimeByNodeId.get(edge.targetNodeId)?.activeWork ?? 0;
        return edgeActive < bestActive ? edge : best;
      }, healthy[0]!);
    }
    // round-robin default, stable cursor stored on the source node runtime
    if (sourceRuntime) {
      const index = sourceRuntime.roundRobinCursor % healthy.length;
      sourceRuntime.roundRobinCursor += 1;
      return healthy[index];
    }
    return healthy[0];
  }

  private isNodeRoutable(nodeId: string): boolean {
    const runtime = this.runtimeByNodeId.get(nodeId);
    if (!runtime) return false;
    return runtime.health !== "unavailable";
  }

  /**
   * Records a single edge traversal for visual playback. Write-only telemetry:
   * the sample is retained against the root request purely so that, if the
   * request later fails, the failure can be attributed to the edges it really
   * used rather than guessed at.
   */
  private recordFlow(edge: ArchitectureEdge, request: SimRequest, nowMs: number): void {
    const sample = this.flowRecorder.record(edge.id, flowClassFor(edge, request), nowMs, {
      isRetry: request.attempt > 0
    });
    const samples = this.flowSamplesByRoot.get(request.rootId);
    if (samples) samples.push(sample);
    else this.flowSamplesByRoot.set(request.rootId, [sample]);
  }

  private processArrival(nodeId: string, requestId: string, nowMs: number): void {
    const runtime = this.runtimeByNodeId.get(nodeId);
    const request = this.requests.get(requestId);
    if (!runtime || !request || request.status === "terminal") return;

    this.refreshFaults(runtime, nowMs);

    if (runtime.activeFaultUnavailable || runtime.health === "unavailable") {
      this.finishRootRequest(request, false, nowMs, "node-unavailable");
      return;
    }

    switch (runtime.node.type) {
      case "load-balancer":
      case "cdn": {
        const targets = this.requestEdgesBySource.get(nodeId) ?? [];
        request.accumulatedLatencyMs += runtime.node.config.baseLatencyMs;
        this.routeAlong(targets, request, nowMs);
        return;
      }
      case "api-gateway": {
        this.processApiGatewayArrival(runtime, request, nowMs);
        return;
      }
      case "dns-traffic-manager": {
        this.processDnsArrival(runtime, request, nowMs);
        return;
      }
      case "nosql-database": {
        this.processNoSqlArrival(runtime, request, nowMs);
        return;
      }
      case "event-topic": {
        request.accumulatedLatencyMs += runtime.node.config.baseLatencyMs;
        this.publishToTopic(runtime, request, nowMs);
        this.finishRootRequest(request, true, nowMs, "published");
        return;
      }
      case "external-service": {
        this.processExternalServiceArrival(runtime, request, nowMs);
        return;
      }
      case "cache": {
        this.processCacheArrival(runtime, request, nowMs);
        return;
      }
      case "message-queue": {
        this.enqueueMessage(runtime, request, nowMs);
        this.finishRootRequest(request, true, nowMs, "enqueued");
        return;
      }
      default: {
        this.admitOrQueue(runtime, request, nowMs);
      }
    }
  }

  /**
   * API gateway per SIMULATION_SPEC.md "API gateway": policy latency, quota
   * enforcement, optional authentication, then weighted route selection.
   * Quota and auth rejections are counted as failed root requests with
   * distinct reason codes, never silently dropped.
   */
  private processApiGatewayArrival(runtime: NodeRuntime, request: SimRequest, nowMs: number): void {
    const config = runtime.node.config as Record<string, unknown>;
    request.accumulatedLatencyMs +=
      runtime.node.config.baseLatencyMs + readNumberConfig(config, "policyLatencyMs", 3);

    const limitRps = readNumberConfig(config, "rateLimitRps", 0);
    const quotaExhausted = runtime.activeFaultFlags.has("quota-exhaustion");
    if (quotaExhausted || !consumeToken(
      runtime.rateLimitBucket,
      limitRps,
      readNumberConfig(config, "rateLimitBurst", 0),
      nowMs
    )) {
      runtime.quotaRejectionCount += 1;
      this.finishRootRequest(request, false, nowMs, "quota-exceeded");
      return;
    }

    const authMode = typeof config["authMode"] === "string" ? config["authMode"] : "none";
    if (authMode !== "none" && !this.applyAuthentication(runtime, request, nowMs, authMode)) {
      return;
    }

    const routes = (this.requestEdgesBySource.get(runtime.node.id) ?? []).filter(
      (edge) => this.nodeById.get(edge.targetNodeId)?.type !== "identity-auth-service"
    );
    if (routes.length === 0) {
      this.finishRootRequest(request, false, nowMs, "gateway-no-routes");
      return;
    }
    this.routeAlong(routes, request, nowMs);
  }

  /**
   * Inline authentication dependency. `validate-local` costs only verification
   * latency at the caller; `delegate` additionally consumes the identity
   * component's latency and throughput without creating a separate routable
   * hop. This is a documented simplification: the engine has no synchronous
   * sub-call primitive, so delegation is modeled as an inline dependency.
   *
   * Returns false when the request has already been terminated.
   */
  private applyAuthentication(
    gateway: NodeRuntime,
    request: SimRequest,
    nowMs: number,
    authMode: string
  ): boolean {
    const identityEdge = (this.requestEdgesBySource.get(gateway.node.id) ?? []).find(
      (edge) => this.nodeById.get(edge.targetNodeId)?.type === "identity-auth-service"
    );
    const identity = identityEdge ? this.runtimeByNodeId.get(identityEdge.targetNodeId) : undefined;

    if (!identity) {
      if (authMode === "delegate") {
        gateway.authBlockedCount += 1;
        this.finishRootRequest(request, false, nowMs, "auth-delegation-missing");
        return false;
      }
      return true;
    }

    this.refreshFaults(identity, nowMs);
    const identityConfig = identity.node.config as Record<string, unknown>;
    const failMode =
      typeof identityConfig["failMode"] === "string" ? identityConfig["failMode"] : "fail-closed";

    if (identity.activeFaultUnavailable || identity.health === "unavailable") {
      if (failMode === "fail-open") {
        this.recordDiagnostic(
          nowMs,
          "auth-fail-open",
          `Identity "${identity.node.config.displayName}" is unavailable; request admitted without verification.`,
          { nodeId: identity.node.id, requestId: request.rootId }
        );
        return true;
      }
      identity.totalFailed += 1;
      gateway.authBlockedCount += 1;
      this.finishRootRequest(request, false, nowMs, "auth-unavailable");
      return false;
    }

    identity.authCallCount += 1;
    const cacheHit = this.random.chance(readNumberConfig(identityConfig, "cacheHitRatio", 0.9));
    const verificationMs = readNumberConfig(identityConfig, "verificationLatencyMs", 8);
    let authLatency = verificationMs;
    if (cacheHit) {
      identity.authCacheHitCount += 1;
    } else {
      authLatency += identity.node.config.baseLatencyMs + identity.activeFaultAdditionalLatencyMs;
      identity.totalCompleted += 1;
    }
    identity.latencySamples.push(authLatency);
    request.accumulatedLatencyMs += authLatency;
    request.authenticated = true;
    return true;
  }

  /**
   * DNS per SIMULATION_SPEC.md "DNS and traffic manager": a cached answer is
   * reused for its TTL without re-evaluating target health, so traffic keeps
   * reaching a dead target until the entry expires.
   */
  private processDnsArrival(runtime: NodeRuntime, request: SimRequest, nowMs: number): void {
    const config = runtime.node.config as Record<string, unknown>;
    request.accumulatedLatencyMs += runtime.node.config.baseLatencyMs;
    const targets = this.requestEdgesBySource.get(runtime.node.id) ?? [];
    if (targets.length === 0) {
      this.finishRootRequest(request, false, nowMs, "dns-no-targets");
      return;
    }

    const frozen = runtime.activeFaultFlags.has("stale-dns-record");
    const cachedEdge = runtime.dnsCachedEdgeId
      ? targets.find((edge) => edge.id === runtime.dnsCachedEdgeId)
      : undefined;
    const cacheValid = cachedEdge !== undefined && (frozen || nowMs < runtime.dnsCacheExpiresAtMs);

    let edge = cachedEdge;
    if (cacheValid) {
      runtime.dnsCacheHitCount += 1;
      if (!this.isNodeRoutable(edge!.targetNodeId)) {
        runtime.staleResolutionCount += 1;
      }
    } else {
      runtime.dnsResolutionCount += 1;
      request.accumulatedLatencyMs += readNumberConfig(config, "resolutionLatencyMs", 20);
      edge = this.resolveDnsTarget(targets, String(config["policy"] ?? "failover"));
      if (!edge) {
        this.finishRootRequest(request, false, nowMs, "no-healthy-target");
        return;
      }
      runtime.dnsCachedEdgeId = edge.id;
      runtime.dnsCacheExpiresAtMs = nowMs + readNumberConfig(config, "ttlSeconds", 60) * 1000;
    }

    // Routed explicitly rather than through selectEdge so an unhealthy cached
    // answer still produces a failure instead of silently rerouting.
    if (request.hopCount >= this.input.settings.maxHopCount) {
      this.finishRootRequest(request, false, nowMs, "routing-loop");
      return;
    }
    request.hopCount += 1;
    request.currentNodeId = edge!.targetNodeId;
    const arriveAt = nowMs + edge!.latencyMs;
    this.pushEvent(
      {
        type: "arrival",
        timestampMs: arriveAt,
        priority: EventPriority.ArrivalForwardOrRetry,
        nodeId: edge!.targetNodeId,
        requestId: request.id
      },
      arriveAt
    );
  }

  private resolveDnsTarget(
    targets: ArchitectureEdge[],
    policy: string
  ): ArchitectureEdge | undefined {
    const healthy = targets.filter((edge) => this.isNodeRoutable(edge.targetNodeId));
    if (healthy.length === 0) return undefined;
    if (policy === "weighted") {
      const totalWeight = healthy.reduce((sum, edge) => sum + (edge.weight ?? 1), 0);
      let roll = this.random.next() * totalWeight;
      for (const edge of healthy) {
        roll -= edge.weight ?? 1;
        if (roll <= 0) return edge;
      }
      return healthy[healthy.length - 1];
    }
    if (policy === "latency") {
      return healthy.reduce((best, edge) => {
        const bestLatency = this.nodeById.get(best.targetNodeId)?.config.baseLatencyMs ?? 0;
        const edgeLatency = this.nodeById.get(edge.targetNodeId)?.config.baseLatencyMs ?? 0;
        return edgeLatency < bestLatency ? edge : best;
      }, healthy[0]!);
    }
    // `failover` and `geo` both resolve to the first healthy target in declared order.
    return healthy[0];
  }

  /**
   * NoSQL per SIMULATION_SPEC.md "NoSQL database": per-partition capacity with
   * seeded hot-key skew, plus lag-window staleness for eventual reads.
   */
  private processNoSqlArrival(runtime: NodeRuntime, request: SimRequest, nowMs: number): void {
    const config = runtime.node.config as Record<string, unknown>;
    const partitionCount = Math.max(1, Math.floor(readNumberConfig(config, "partitionCount", 1)));
    const skew = runtime.activeFaultFlags.has("partition-hotspot")
      ? 1
      : readNumberConfig(config, "hotPartitionSkew", 0);
    const partition = this.random.chance(skew)
      ? 0
      : Math.min(partitionCount - 1, Math.floor(this.random.next() * partitionCount));
    request.partitionIndex = partition;

    if (runtime.partitionActive.length !== partitionCount) {
      runtime.partitionActive = new Array<number>(partitionCount).fill(0);
    }
    const perPartitionCapacity = effectiveCapacity(runtime) / partitionCount;
    if ((runtime.partitionActive[partition] ?? 0) >= perPartitionCapacity) {
      runtime.hotPartitionThrottleCount += 1;
      this.finishRootRequest(request, false, nowMs, "hot-partition-throttled");
      return;
    }

    const consistency = String(config["consistency"] ?? "eventual");
    const replicationLagMs = readNumberConfig(config, "replicationLagMs", 0);
    if (request.isRead) {
      if (consistency === "eventual" && nowMs - runtime.lastWriteAtMs < replicationLagMs) {
        runtime.staleReadCount += 1;
      } else if (consistency === "quorum") {
        request.accumulatedLatencyMs += replicationLagMs * 0.5;
      }
    } else {
      runtime.lastWriteAtMs = nowMs;
    }

    runtime.partitionActive[partition] = (runtime.partitionActive[partition] ?? 0) + 1;
    this.admitOrQueue(runtime, request, nowMs);
  }

  /**
   * External third-party dependency. Rejects above the provider's rate limit
   * and never gains capacity from an autoscaler — that is the lesson.
   */
  private processExternalServiceArrival(
    runtime: NodeRuntime,
    request: SimRequest,
    nowMs: number
  ): void {
    const config = runtime.node.config as Record<string, unknown>;
    const limit = readNumberConfig(config, "providerRateLimitRps", 0);
    const throttled = runtime.activeFaultFlags.has("provider-throttling");
    if (throttled || !consumeToken(runtime.providerBucket, limit, limit, nowMs)) {
      runtime.providerThrottleCount += 1;
      this.finishRootRequest(request, false, nowMs, "provider-throttled");
      return;
    }
    if (request.attempt > 1 && config["idempotencySupported"] === false) {
      runtime.duplicateSideEffectCount += 1;
    }
    request.accumulatedLatencyMs += readNumberConfig(config, "slaLatencyMs", 0);
    this.admitOrQueue(runtime, request, nowMs);
  }

  /**
   * Event topic fan-out. Each outgoing consumer edge is one subscriber group
   * with an independent queue and lag, so a slow group cannot stall the others.
   */
  private publishToTopic(runtime: NodeRuntime, request: SimRequest, nowMs: number): void {
    const groups = this.subscriberGroupsOf(runtime.node.id);
    runtime.publishCount += 1;
    if (runtime.activeFaultFlags.has("subscriber-group-stall")) return;

    const retentionMs = readNumberConfig(runtime.node.config as Record<string, unknown>, "retentionMs", 0);
    for (const consumerNodeId of groups) {
      const queue = runtime.subscriberQueues.get(consumerNodeId) ?? [];
      if (retentionMs > 0) {
        while (queue.length > 0 && nowMs - queue[0]!.enqueuedAtMs > retentionMs) {
          queue.shift();
          runtime.retentionDropCount += 1;
        }
      }
      queue.push({ enqueuedAtMs: nowMs, deadlineMs: request.deadlineMs });
      if (queue.length > runtime.node.config.maxQueueDepth) {
        queue.shift();
        runtime.retentionDropCount += 1;
      }
      runtime.subscriberQueues.set(consumerNodeId, queue);
      this.pushEvent(
        {
          type: "queue-pull",
          timestampMs: nowMs,
          priority: EventPriority.CompletionOrConsume,
          nodeId: consumerNodeId
        },
        nowMs
      );
    }
  }

  /** Distinct consumer node ids in declared edge order, for deterministic fan-out. */
  private subscriberGroupsOf(topicNodeId: string): string[] {
    const edges = (this.eventEdgesBySource.get(topicNodeId) ?? []).concat(
      this.requestEdgesBySource.get(topicNodeId) ?? []
    );
    const groups: string[] = [];
    for (const edge of edges) {
      const target = this.runtimeByNodeId.get(edge.targetNodeId);
      if (!target || target.node.type !== "worker") continue;
      if (!groups.includes(edge.targetNodeId)) groups.push(edge.targetNodeId);
    }
    return groups;
  }

  private processCacheArrival(runtime: NodeRuntime, request: SimRequest, nowMs: number): void {
    const hitRatio = readNumberConfig(runtime.node.config, "hitRatio", 0.8);
    const isHit = this.random.chance(hitRatio);
    if (isHit) {
      runtime.cacheHits += 1;
      request.accumulatedLatencyMs += runtime.node.config.baseLatencyMs;
      runtime.latencySamples.push(runtime.node.config.baseLatencyMs);
      const originEdges = this.requestEdgesBySource.get(runtime.node.id) ?? [];
      const hasOrigin = originEdges.length > 0;
      if (!hasOrigin) {
        this.finishRootRequest(request, true, nowMs, "cache-hit-terminal");
      } else {
        this.finishRootRequest(request, true, nowMs, "cache-hit");
      }
      return;
    }
    runtime.cacheMisses += 1;
    const originEdges = this.requestEdgesBySource.get(runtime.node.id) ?? [];
    if (originEdges.length === 0) {
      this.finishRootRequest(request, false, nowMs, "cache-miss-no-origin");
      return;
    }
    this.routeAlong(originEdges, request, nowMs);
  }

  private admitOrQueue(runtime: NodeRuntime, request: SimRequest, nowMs: number): void {
    const capacity = effectiveCapacity(runtime);
    if (runtime.activeWork < capacity) {
      this.admit(runtime, request, nowMs);
      return;
    }
    switch (runtime.node.config.overflowBehavior) {
      case "queue":
        if (runtime.queue.length < runtime.node.config.maxQueueDepth) {
          request.status = "queued";
          request.queueEnqueuedAtMs = nowMs;
          runtime.queue.push(request);
        } else {
          this.finishRootRequest(request, false, nowMs, "queue-full");
        }
        return;
      case "reject":
        this.finishRootRequest(request, false, nowMs, "overloaded-rejected");
        return;
      case "shed-load":
        this.finishRootRequest(request, false, nowMs, "load-shed");
        return;
      case "penalty":
        this.admit(runtime, request, nowMs, true);
        return;
      default:
        this.finishRootRequest(request, false, nowMs, "overloaded-rejected");
    }
  }

  private admit(runtime: NodeRuntime, request: SimRequest, nowMs: number, overloadPenalty = false): void {
    request.status = "active";
    runtime.activeWork += 1;
    if (request.queueEnqueuedAtMs !== undefined) {
      request.accumulatedLatencyMs += nowMs - request.queueEnqueuedAtMs;
      request.queueEnqueuedAtMs = undefined;
    }
    const jitter = runtime.node.config.jitterMs > 0 ? this.random.next() * runtime.node.config.jitterMs : 0;
    const overload = overloadPenalty ? runtime.node.config.baseLatencyMs * 0.5 : 0;
    const latency =
      runtime.node.config.baseLatencyMs + jitter + overload + runtime.activeFaultAdditionalLatencyMs;
    request.accumulatedLatencyMs += latency;
    runtime.latencySamples.push(latency);
    const completeAt = nowMs + latency;
    this.pushEvent(
      {
        type: "complete",
        timestampMs: completeAt,
        priority: EventPriority.CompletionOrConsume,
        nodeId: runtime.node.id,
        requestId: request.id
      },
      completeAt
    );
  }

  private processCompletion(nodeId: string, requestId: string, nowMs: number): void {
    const runtime = this.runtimeByNodeId.get(nodeId);
    const request = this.requests.get(requestId);
    if (!runtime || !request) return;

    if (request.status === "terminal") {
      // The request already timed out while this side effect was in flight.
      runtime.activeWork = Math.max(0, runtime.activeWork - 1);
      this.releasePartition(runtime, request);
      this.recordDiagnostic(nowMs, "late-completion", "Component finished work after the request had already timed out.", {
        nodeId,
        requestId
      });
      this.dequeueNext(runtime, nowMs);
      return;
    }

    runtime.activeWork = Math.max(0, runtime.activeWork - 1);
    this.releasePartition(runtime, request);
    const failed = this.random.chance(effectiveErrorRate(runtime));
    if (failed) {
      runtime.totalFailed += 1;
      this.dequeueNext(runtime, nowMs);
      this.publishAsyncEvents(runtime, request, nowMs);
      this.finishRootRequest(request, false, nowMs, "component-error");
      return;
    }
    runtime.totalCompleted += 1;
    this.publishAsyncEvents(runtime, request, nowMs);
    this.dequeueNext(runtime, nowMs);

    const nextEdges = this.requestEdgesBySource.get(nodeId) ?? [];
    if (nextEdges.length === 0) {
      this.finishRootRequest(request, true, nowMs, "completed");
    } else {
      this.routeAlong(nextEdges, request, nowMs);
    }
  }

  private releasePartition(runtime: NodeRuntime, request: SimRequest): void {
    if (runtime.node.type !== "nosql-database" || request.partitionIndex === undefined) return;
    const index = request.partitionIndex;
    runtime.partitionActive[index] = Math.max(0, (runtime.partitionActive[index] ?? 0) - 1);
    request.partitionIndex = undefined;
  }

  private publishAsyncEvents(runtime: NodeRuntime, request: SimRequest, nowMs: number): void {
    const eventEdges = this.eventEdgesBySource.get(runtime.node.id) ?? [];
    for (const edge of eventEdges) {
      const targetRuntime = this.runtimeByNodeId.get(edge.targetNodeId);
      if (!targetRuntime) continue;
      if (targetRuntime.node.type === "message-queue") {
        this.enqueueMessage(targetRuntime, request, nowMs + edge.latencyMs);
      } else if (targetRuntime.node.type === "event-topic") {
        this.publishToTopic(targetRuntime, request, nowMs + edge.latencyMs);
      }
    }
  }

  private dequeueNext(runtime: NodeRuntime, nowMs: number): void {
    const capacity = effectiveCapacity(runtime);
    while (runtime.queue.length > 0 && runtime.activeWork < capacity) {
      const next = runtime.queue.shift();
      if (!next || next.status === "terminal") continue;
      this.admit(runtime, next, nowMs);
    }
  }

  private enqueueMessage(runtime: NodeRuntime, request: SimRequest, nowMs: number): void {
    runtime.queueMessages.push({ enqueuedAtMs: nowMs, deadlineMs: request.deadlineMs });
    if (runtime.queueMessages.length > runtime.node.config.maxQueueDepth) {
      runtime.queueMessages.shift(); // oldest dropped; a bounded-depth simplification
    }
    const consumerEdges = (this.requestEdgesBySource.get(runtime.node.id) ?? []).concat(
      this.eventEdgesBySource.get(runtime.node.id) ?? []
    );
    for (const edge of consumerEdges) {
      const consumerRuntime = this.runtimeByNodeId.get(edge.targetNodeId);
      if (consumerRuntime?.node.type === "worker") {
        this.pushEvent(
          { type: "queue-pull", timestampMs: nowMs, priority: EventPriority.CompletionOrConsume, nodeId: consumerRuntime.node.id },
          nowMs
        );
      }
    }
  }

  private processQueuePull(workerNodeId: string, nowMs: number): void {
    const workerRuntime = this.runtimeByNodeId.get(workerNodeId);
    if (!workerRuntime) return;
    this.refreshFaults(workerRuntime, nowMs);
    const capacity = effectiveCapacity(workerRuntime);
    if (workerRuntime.activeWork >= capacity) return;

    const message = this.takeNextMessageFor(workerNodeId);
    if (!message) return;
    workerRuntime.activeWork += 1;
    const consumerLagMs = nowMs - message.enqueuedAtMs;
    const jitter =
      workerRuntime.node.config.jitterMs > 0 ? this.random.next() * workerRuntime.node.config.jitterMs : 0;
    const latency = workerRuntime.node.config.baseLatencyMs + jitter + workerRuntime.activeFaultAdditionalLatencyMs;
    workerRuntime.latencySamples.push(latency + consumerLagMs);
    const completeAt = nowMs + latency;
    this.pushEvent(
      {
        type: "complete",
        timestampMs: completeAt,
        priority: EventPriority.CompletionOrConsume,
        nodeId: workerRuntime.node.id,
        requestId: `${workerNodeId}-msg-${completeAt}-${this.sequence}`
      },
      completeAt
    );
    // Re-trigger a pull attempt in case more capacity remains for further messages.
    if (workerRuntime.activeWork < capacity) {
      this.pushEvent(
        { type: "queue-pull", timestampMs: nowMs, priority: EventPriority.CompletionOrConsume, nodeId: workerNodeId },
        nowMs
      );
    }
  }

  /**
   * Pulls the next message for a worker from either a shared message queue
   * (competing consumers) or its own subscriber-group queue on an event topic
   * (independent fan-out). Producers are scanned in insertion order so the
   * choice is deterministic.
   */
  private takeNextMessageFor(workerNodeId: string): QueuedMessage | undefined {
    for (const candidate of this.runtimeByNodeId.values()) {
      const feedsWorker = (this.requestEdgesBySource.get(candidate.node.id) ?? [])
        .concat(this.eventEdgesBySource.get(candidate.node.id) ?? [])
        .some((edge) => edge.targetNodeId === workerNodeId);
      if (!feedsWorker) continue;

      if (candidate.node.type === "message-queue" && candidate.queueMessages.length > 0) {
        return candidate.queueMessages.shift();
      }
      if (candidate.node.type === "event-topic") {
        const groupQueue = candidate.subscriberQueues.get(workerNodeId);
        if (groupQueue && groupQueue.length > 0) return groupQueue.shift();
      }
    }
    return undefined;
  }

  private processTimeoutCheck(requestId: string, nowMs: number): void {
    const request = this.requests.get(requestId);
    if (!request || request.status === "terminal") return;
    if (request.status === "queued" && request.currentNodeId) {
      const runtime = this.runtimeByNodeId.get(request.currentNodeId);
      if (runtime) {
        const index = runtime.queue.indexOf(request);
        if (index >= 0) runtime.queue.splice(index, 1);
      }
    }
    this.finishRootRequest(request, false, nowMs, "timeout");
  }

  private refreshFaults(runtime: NodeRuntime, nowMs: number): void {
    const active = findActiveFaults(this.faults, nowMs);
    applyFaultsToNode(runtime, active, (nodeId) => this.nodeById.get(nodeId)?.config.region);
  }

  private finishRootRequest(request: SimRequest, success: boolean, nowMs: number, reason: string): void {
    if (request.status === "terminal") return;
    request.status = "terminal";
    request.outcome = success ? "success" : reason === "timeout" ? "timeout" : "error";

    if (!success && this.canRetry(request, reason, nowMs)) {
      this.scheduleRetry(request, nowMs);
      return;
    }

    this.completedRootRequests += 1;
    if (success) this.successfulRootRequests += 1;
    this.aggregator.recordCompletion(request.accumulatedLatencyMs, success);
    if (!success) {
      if (reason === "timeout") this.totalTimeouts += 1;
      // Attribute the failure to the exact edges this request travelled, so
      // playback can fade the particles on the path that actually broke.
      this.flowRecorder.markFailed(this.flowSamplesByRoot.get(request.rootId) ?? []);
      this.recordDiagnostic(nowMs, reason, `Request ${request.rootId} failed: ${reason}`, {
        requestId: request.rootId
      });
    }
    // The root request is settled; its per-edge samples are no longer needed.
    this.flowSamplesByRoot.delete(request.rootId);
  }

  /**
   * Bounded retry eligibility per SIMULATION_SPEC.md "Retry behavior": a retry
   * requires max attempts, a retry budget, and deadline headroom. Only a
   * declared set of transient failure reasons are retryable; timeouts,
   * routing loops, and no-healthy-target failures are terminal.
   */
  private canRetry(request: SimRequest, reason: string, nowMs: number): boolean {
    if (!RETRYABLE_REASONS.has(reason)) return false;
    const client = this.clientNode();
    if (!client) return false;
    const maxRetries = readNumberConfig(client.config, "maxRetries", 0);
    if (maxRetries <= 0) return false;
    const retriesSoFar = this.retryCountByRoot.get(request.rootId) ?? 0;
    if (retriesSoFar >= maxRetries) return false;
    const backoffMs = readNumberConfig(client.config, "retryBackoffMs", 100);
    return nowMs + backoffMs <= request.deadlineMs;
  }

  private scheduleRetry(request: SimRequest, nowMs: number): void {
    const client = this.clientNode();
    if (!client) return;
    const edges = this.requestEdgesBySource.get(client.id) ?? [];
    if (edges.length === 0) return;
    const backoffMs = readNumberConfig(client.config, "retryBackoffMs", 100);
    const retriesSoFar = (this.retryCountByRoot.get(request.rootId) ?? 0) + 1;
    this.retryCountByRoot.set(request.rootId, retriesSoFar);
    this.totalRetries += 1;

    const retryRequest: SimRequest = {
      id: nextRequestId(request.rootId, request.attempt + 1),
      rootId: request.rootId,
      attempt: request.attempt + 1,
      createdAtMs: request.createdAtMs,
      deadlineMs: request.deadlineMs,
      isRead: request.isRead,
      hopCount: request.hopCount,
      status: "active",
      accumulatedLatencyMs: request.accumulatedLatencyMs,
      timeoutScheduled: false,
      method: request.method,
      requestClass: request.requestClass,
      originNodeId: request.originNodeId,
      manualBatchId: request.manualBatchId,
      path: request.path,
      payloadSizeBytes: request.payloadSizeBytes,
      responseSizeBytes: request.responseSizeBytes
    };
    this.requests.set(retryRequest.id, retryRequest);
    this.scheduleTimeoutCheck(retryRequest);
    const retryAt = nowMs + backoffMs;
    this.recordDiagnostic(retryAt, "retry-scheduled", `Retry attempt ${retryRequest.attempt} for ${request.rootId}`, {
      requestId: request.rootId,
      nodeId: client.id
    });
    this.pushEvent(
      { type: "arrival", timestampMs: retryAt, priority: EventPriority.ArrivalForwardOrRetry, requestId: "__retry_root_arrival__", nodeId: retryRequest.id },
      retryAt
    );
  }
}

const RETRYABLE_REASONS = new Set(["component-error", "overloaded-rejected", "load-shed", "queue-full"]);

/**
 * Classifies an edge traversal for playback. The edge kind wins where it is
 * unambiguous — replication and async event edges are structurally distinct
 * regardless of what request travels them — and otherwise the request's own
 * class decides, so a PUT reads as a write stream and an authenticated call
 * reads as auth traffic.
 */
function flowClassFor(edge: ArchitectureEdge, request: SimRequest): FlowClass {
  if (edge.kind === "replication") return "replication";
  if (edge.kind === "event") return "async-event";
  if (request.requestClass === "auth-required") return "auth";
  return request.isRead ? "read" : "write";
}

function readNumberConfig(config: Record<string, unknown>, key: string, fallback: number): number {
  const value = config[key];
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

