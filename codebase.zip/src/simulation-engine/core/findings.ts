import type { ValidationIssue } from "@/domain/validation/graphValidation";
import type { ComponentMetricSnapshot, Finding } from "@/domain/metrics/schema";

/**
 * Turns a kebab-case validation code into a readable headline. Findings are
 * surfaced as toasts, where the title is the first and sometimes only thing
 * read, so "single-point-of-failure" becomes "Single point of failure".
 */
function humanizeCode(code: string): string {
  const words = code.replace(/[-_]+/g, " ").trim();
  return words.charAt(0).toUpperCase() + words.slice(1);
}

/**
 * Converts static topology warnings and observed metrics into labeled
 * Findings, per PRD.md's requirement that findings distinguish observed
 * results, architecture warnings, and recommendations (SIMULATION_SPEC.md
 * "Result contract").
 *
 * Severity is assigned here rather than in the UI so every consumer — the
 * metrics modal, findings toasts, exported JSON, tests — agrees on how serious
 * a finding is.
 */
export function deriveFindings(
  validationIssues: ValidationIssue[],
  componentMetrics: ComponentMetricSnapshot[],
  observedAvailability: number | undefined
): Finding[] {
  const findings: Finding[] = [];

  for (const issue of validationIssues.filter((candidate) => candidate.severity === "warning")) {
    findings.push({
      id: `warning-${issue.code}-${issue.nodeIds?.join(",") ?? "graph"}`,
      source: "architecture-warning",
      severity: "warning",
      title: humanizeCode(issue.code),
      detail: issue.message,
      evidence: [],
      relatedNodeIds: issue.nodeIds ?? [],
      relatedEdgeIds: issue.edgeIds ?? []
    });
  }

  const utilizationByNode = new Map<string, number[]>();
  for (const snapshot of componentMetrics) {
    const list = utilizationByNode.get(snapshot.nodeId) ?? [];
    list.push(snapshot.utilization);
    utilizationByNode.set(snapshot.nodeId, list);
  }
  for (const [nodeId, utilizations] of utilizationByNode) {
    const peak = Math.max(0, ...utilizations);
    if (peak >= 0.95) {
      findings.push({
        id: `bottleneck-${nodeId}`,
        source: "observed-result",
        severity: "critical",
        title: "Component near saturation",
        detail: `Node ${nodeId} reached ${(peak * 100).toFixed(0)}% utilization during the run.`,
        evidence: [`peak-utilization=${peak.toFixed(2)}`],
        relatedNodeIds: [nodeId],
        relatedEdgeIds: [],
        suggestedAction:
          "Inspect this component and either raise its capacity or move work off the hot path."
      });
      findings.push({
        id: `recommendation-${nodeId}`,
        source: "recommendation",
        severity: "info",
        title: "Consider adding capacity",
        detail: `Increasing instance count or capacity on node ${nodeId} may reduce queueing and errors under this workload.`,
        evidence: [`peak-utilization=${peak.toFixed(2)}`],
        relatedNodeIds: [nodeId],
        relatedEdgeIds: [],
        suggestedAction: "Raise instance count or per-instance capacity, then re-run to compare."
      });
    }
  }

  if (observedAvailability !== undefined && observedAvailability < 0.99) {
    const saturatedNodeIds = [...utilizationByNode.entries()]
      .filter(([, utilizations]) => Math.max(0, ...utilizations) >= 0.95)
      .map(([nodeId]) => nodeId);
    const relatedNodeIds = saturatedNodeIds;
    findings.push({
      id: "observed-availability",
      source: "observed-result",
      severity: observedAvailability < 0.95 ? "critical" : "warning",
      title: "Observed availability below 99%",
      detail:
        saturatedNodeIds.length > 0
          ? `The run completed with ${(observedAvailability * 100).toFixed(2)}% observed availability while ${saturatedNodeIds.length} component${saturatedNodeIds.length === 1 ? "" : "s"} reached saturation.`
          : `The run completed with ${(observedAvailability * 100).toFixed(2)}% observed availability without a saturated component, so inspect timeouts, injected faults, and dependency errors.`,
      evidence: [
        `observed-availability=${observedAvailability.toFixed(4)}`,
        ...(saturatedNodeIds.length > 0 ? [`saturated-nodes=${saturatedNodeIds.join(",")}`] : [])
      ],
      relatedNodeIds,
      relatedEdgeIds: [],
      suggestedAction:
        saturatedNodeIds.length > 0
          ? "Inspect the saturated components first, then raise capacity, reduce work, or isolate the hot path before re-running."
          : "Compare the same seed with faults disabled and inspect timeout or dependency events before changing capacity."
    });
  }

  return findings;
}
