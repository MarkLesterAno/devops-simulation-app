import type { ArchitectureNode } from "@/domain/architecture/schema";
import type { FaultType } from "@/domain/simulation/faultScenario";
import type { SimRequest } from "@/simulation-engine/core/RequestTypes";

export type ComponentHealth = "healthy" | "degraded" | "unavailable" | "recovering";

/** Deterministic token bucket used for gateway quota and provider rate limits. */
export interface TokenBucket {
  tokens: number;
  lastRefillMs: number;
}

/** One queued message belonging to a single subscriber group of an event topic. */
export interface QueuedMessage {
  enqueuedAtMs: number;
  deadlineMs: number;
}

/**
 * Isolated runtime state for one node during a run. Never mutates the
 * persisted ArchitectureNode configuration, per SIMULATION_SPEC.md
 * "Component runtime state".
 */
export interface NodeRuntime {
  node: ArchitectureNode;
  health: ComponentHealth;
  activeWork: number;
  queue: SimRequest[];
  circuitState: "closed" | "open" | "half-open";
  circuitFailureWindow: boolean[];
  roundRobinCursor: number;
  cacheEntries: Map<string, number>; // key -> expiry timestamp, for TTL simulation
  cacheHits: number;
  cacheMisses: number;
  queueMessages: QueuedMessage[];
  totalCompleted: number;
  totalFailed: number;
  latencySamples: number[];
  activeFaultCapacityMultiplier: number;
  activeFaultAdditionalLatencyMs: number;
  activeFaultAdditionalErrorRate: number;
  activeFaultUnavailable: boolean;
  /** Behavioral fault flags consumed by a specific component branch. */
  activeFaultFlags: Set<FaultType>;

  // --- API gateway ---
  rateLimitBucket: TokenBucket;
  quotaRejectionCount: number;
  /** Requests rejected because authentication could not be completed. */
  authBlockedCount: number;

  // --- DNS / traffic manager ---
  dnsCachedEdgeId: string | null;
  dnsCacheExpiresAtMs: number;
  dnsResolutionCount: number;
  dnsCacheHitCount: number;
  staleResolutionCount: number;

  // --- NoSQL database ---
  /** Concurrent work per partition; index 0 is the hot partition. */
  partitionActive: number[];
  hotPartitionThrottleCount: number;
  staleReadCount: number;
  lastWriteAtMs: number;

  // --- Event topic (insertion-ordered for determinism) ---
  subscriberQueues: Map<string, QueuedMessage[]>;
  publishCount: number;
  retentionDropCount: number;

  // --- Identity & auth service ---
  authCallCount: number;
  authCacheHitCount: number;

  // --- External service ---
  providerBucket: TokenBucket;
  providerThrottleCount: number;
  duplicateSideEffectCount: number;
}

export function createNodeRuntime(node: ArchitectureNode): NodeRuntime {
  return {
    node,
    health: "healthy",
    activeWork: 0,
    queue: [],
    circuitState: "closed",
    circuitFailureWindow: [],
    roundRobinCursor: 0,
    cacheEntries: new Map(),
    cacheHits: 0,
    cacheMisses: 0,
    queueMessages: [],
    totalCompleted: 0,
    totalFailed: 0,
    latencySamples: [],
    activeFaultCapacityMultiplier: 1,
    activeFaultAdditionalLatencyMs: 0,
    activeFaultAdditionalErrorRate: 0,
    activeFaultUnavailable: false,
    activeFaultFlags: new Set(),
    rateLimitBucket: { tokens: readNumber(node, "rateLimitBurst", 0), lastRefillMs: 0 },
    quotaRejectionCount: 0,
    authBlockedCount: 0,
    dnsCachedEdgeId: null,
    dnsCacheExpiresAtMs: 0,
    dnsResolutionCount: 0,
    dnsCacheHitCount: 0,
    staleResolutionCount: 0,
    partitionActive: new Array<number>(Math.max(1, readNumber(node, "partitionCount", 1))).fill(0),
    hotPartitionThrottleCount: 0,
    staleReadCount: 0,
    lastWriteAtMs: Number.NEGATIVE_INFINITY,
    subscriberQueues: new Map(),
    publishCount: 0,
    retentionDropCount: 0,
    authCallCount: 0,
    authCacheHitCount: 0,
    providerBucket: { tokens: readNumber(node, "providerRateLimitRps", 0), lastRefillMs: 0 },
    providerThrottleCount: 0,
    duplicateSideEffectCount: 0
  };
}

function readNumber(node: ArchitectureNode, key: string, fallback: number): number {
  const value = (node.config as Record<string, unknown>)[key];
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

/**
 * Deterministically refills a token bucket to the elapsed-time allowance and
 * consumes one token. Returns false when the bucket is empty.
 */
export function consumeToken(
  bucket: TokenBucket,
  ratePerSecond: number,
  burst: number,
  nowMs: number
): boolean {
  if (ratePerSecond <= 0) return true;
  const capacity = Math.max(burst, ratePerSecond);
  const elapsedMs = Math.max(0, nowMs - bucket.lastRefillMs);
  bucket.tokens = Math.min(capacity, bucket.tokens + (elapsedMs / 1000) * ratePerSecond);
  bucket.lastRefillMs = nowMs;
  if (bucket.tokens < 1) return false;
  bucket.tokens -= 1;
  return true;
}

/**
 * effective capacity = instanceCount * perInstanceCapacity * healthFactor * faultCapacityFactor
 * per SIMULATION_SPEC.md "Overload behavior".
 */
export function effectiveCapacity(runtime: NodeRuntime): number {
  if (runtime.activeFaultUnavailable || runtime.health === "unavailable") return 0;
  const healthFactor = runtime.health === "degraded" ? 0.5 : 1;
  const capacity =
    runtime.node.config.instanceCount *
    runtime.node.config.perInstanceCapacityRps *
    healthFactor *
    runtime.activeFaultCapacityMultiplier;
  return Math.max(0, capacity);
}

export function effectiveErrorRate(runtime: NodeRuntime): number {
  const base = runtime.node.config.errorRate;
  const fault = runtime.activeFaultAdditionalErrorRate;
  return 1 - (1 - base) * (1 - fault);
}
