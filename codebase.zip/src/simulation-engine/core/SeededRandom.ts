/**
 * Deterministic seeded PRNG (mulberry32). Used for all jitter, overload
 * penalties, sampling, and routing randomness per SIMULATION_SPEC.md's
 * requirement that equal inputs and seed produce equal outputs.
 */
export class SeededRandom {
  private state: number;

  constructor(seed: number) {
    // Force to unsigned 32-bit; 0 is a valid but degenerate seed, nudge it.
    this.state = (seed >>> 0) || 0x9e3779b9;
  }

  /** Returns a float in [0, 1). */
  next(): number {
    this.state |= 0;
    this.state = (this.state + 0x6d2b79f5) | 0;
    let t = Math.imul(this.state ^ (this.state >>> 15), 1 | this.state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  /** Returns an integer in [min, max]. */
  nextInt(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }

  /** Returns true with the given probability in [0, 1]. */
  chance(probability: number): boolean {
    if (probability <= 0) return false;
    if (probability >= 1) return true;
    return this.next() < probability;
  }

  /** Picks an array element deterministically. */
  pick<T>(items: readonly T[]): T {
    const item = items[this.nextInt(0, items.length - 1)];
    if (item === undefined) {
      throw new Error("SeededRandom.pick called with an empty array");
    }
    return item;
  }
}
