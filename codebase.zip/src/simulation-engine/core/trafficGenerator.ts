import type { TrafficProfile, TrafficInterval } from "@/domain/simulation/trafficProfile";

/**
 * Generates deterministic evenly distributed arrival timestamps (ms) for a
 * traffic profile, per SIMULATION_SPEC.md "Traffic generation". Constant,
 * step, ramp, and burst schedules are all reduced to a per-millisecond
 * instantaneous rate function that is integrated to produce arrivals.
 */
export function generateArrivalTimestamps(profile: TrafficProfile): number[] {
  const arrivals: number[] = [];
  for (const interval of profile.intervals) {
    arrivals.push(...generateIntervalArrivals(interval));
  }
  arrivals.sort((a, b) => a - b);
  return arrivals;
}

function rateAtOffset(interval: TrafficInterval, offsetMs: number): number {
  const durationMs = interval.endMs - interval.startMs;
  if (durationMs <= 0) return interval.startRps;
  const progress = Math.min(1, Math.max(0, offsetMs / durationMs));
  switch (interval.kind) {
    case "constant":
      return interval.startRps;
    case "step":
      return progress >= 1 ? interval.endRps : interval.startRps;
    case "ramp":
      return interval.startRps + (interval.endRps - interval.startRps) * progress;
    case "burst":
      return interval.startRps + interval.endRps; // endRps is the additive burst amount
    default:
      return interval.startRps;
  }
}

function generateIntervalArrivals(interval: TrafficInterval): number[] {
  const arrivals: number[] = [];
  const stepMs = 1;
  const epsilon = 1e-9;
  let accumulator = 0;
  for (let t = interval.startMs; t < interval.endMs; t += stepMs) {
    const rps = rateAtOffset(interval, t - interval.startMs);
    accumulator += (rps * stepMs) / 1000;
    while (accumulator >= 1 - epsilon) {
      arrivals.push(t);
      accumulator -= 1;
    }
  }
  return arrivals;
}
