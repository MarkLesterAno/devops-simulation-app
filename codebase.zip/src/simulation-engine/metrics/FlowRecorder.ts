import type {
  EdgeFlowSample,
  FlowClass,
  FlowTimeline,
  FlowTimelineBucket
} from "@/domain/metrics/flowTimeline";

/**
 * Accumulates per-edge traversal counts into fixed-width time buckets while the
 * engine runs, per SIMULATION_SPEC.md "Presentation-derived flow state".
 *
 * This is write-only from the engine's perspective. Nothing here is read back
 * into simulation state, so recording cannot perturb a result. Bucketing also
 * bounds the output: cost scales with (edges x classes x buckets), never with
 * the number of requests, which is what lets a million-request batch animate
 * without a million DOM elements.
 */
export class FlowRecorder {
  private readonly buckets = new Map<number, Map<string, EdgeFlowSample>>();
  private peakBucketCount = 0;
  private maxTimestampMs = 0;

  constructor(private readonly bucketMs: number) {}

  /**
   * Records one traversal of `edgeId` and returns the sample it landed in, so
   * the caller can retroactively mark it failed once the root request's fate is
   * known. `isRetry` is recorded alongside the count rather than as a separate
   * sample so a single edge in a single bucket stays one record.
   */
  record(
    edgeId: string,
    flowClass: FlowClass,
    timestampMs: number,
    options: { isRetry?: boolean } = {}
  ): EdgeFlowSample {
    const bucketStart = Math.floor(timestampMs / this.bucketMs) * this.bucketMs;
    let bucket = this.buckets.get(bucketStart);
    if (!bucket) {
      bucket = new Map<string, EdgeFlowSample>();
      this.buckets.set(bucketStart, bucket);
    }
    const key = `${edgeId}|${flowClass}`;
    let sample = bucket.get(key);
    if (!sample) {
      sample = { edgeId, flowClass, count: 0, failureCount: 0, retryCount: 0 };
      bucket.set(key, sample);
    }
    sample.count += 1;
    if (options.isRetry) sample.retryCount += 1;

    if (sample.count > this.peakBucketCount) this.peakBucketCount = sample.count;
    if (bucketStart > this.maxTimestampMs) this.maxTimestampMs = bucketStart;
    return sample;
  }

  /**
   * Attributes a root request's failure to the exact samples it traversed. The
   * engine only learns the outcome after the request has moved through the
   * graph, so failure is applied retroactively to the samples handed back by
   * {@link record}.
   */
  markFailed(samples: readonly EdgeFlowSample[]): void {
    for (const sample of samples) {
      if (sample.failureCount < sample.count) sample.failureCount += 1;
    }
  }

  /**
   * Produces the timeline. Buckets are emitted in ascending time order and
   * samples in insertion order so the output is byte-identical between runs
   * with the same seed, which the determinism contract requires.
   */
  build(durationMs: number): FlowTimeline {
    const orderedStarts = [...this.buckets.keys()].sort((a, b) => a - b);
    const buckets: FlowTimelineBucket[] = orderedStarts.map((timestampMs) => ({
      timestampMs,
      samples: [...(this.buckets.get(timestampMs) ?? new Map()).values()]
    }));
    return {
      bucketMs: this.bucketMs,
      durationMs: Math.max(durationMs, this.maxTimestampMs + this.bucketMs),
      peakBucketCount: this.peakBucketCount,
      buckets
    };
  }
}
