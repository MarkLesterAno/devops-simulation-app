import type {
  ComponentMetricSnapshot,
  LatencyPercentiles,
  SystemMetricSnapshot
} from "@/domain/metrics/schema";
import type { NodeRuntime } from "@/simulation-engine/core/NodeRuntime";
import { effectiveCapacity } from "@/simulation-engine/core/NodeRuntime";

export function computePercentiles(latenciesMs: number[]): LatencyPercentiles {
  if (latenciesMs.length === 0) {
    return { p50: 0, p95: 0, p99: 0 };
  }
  const sorted = [...latenciesMs].sort((a, b) => a - b);
  const at = (p: number): number => {
    const index = Math.min(sorted.length - 1, Math.floor((p / 100) * sorted.length));
    return sorted[index] ?? 0;
  };
  return { p50: at(50), p95: at(95), p99: at(99) };
}

interface IntervalCounters {
  requestCount: number;
  successCount: number;
  failureCount: number;
  latencies: number[];
}

/**
 * Accumulates per-interval counters and produces bounded system/component
 * metric snapshots at the configured metricIntervalMs cadence, per
 * TRD.md performance requirements ("Metrics updates: at least 5/sec").
 */
export class MetricAggregator {
  private current: IntervalCounters = emptyCounters();
  private lastSnapshotAtMs = 0;
  readonly systemSnapshots: SystemMetricSnapshot[] = [];
  readonly componentSnapshots: ComponentMetricSnapshot[] = [];

  // Whole-run cumulative totals (never reset), used to build the
  // aggregate `summary` snapshot per AC-ME-01, independent of the
  // per-interval `systemSnapshots` time series.
  private totalRequestCount = 0;
  private totalSuccessCount = 0;
  private totalFailureCount = 0;
  private readonly allLatencies: number[] = [];

  constructor(private readonly metricIntervalMs: number) {}

  recordCompletion(latencyMs: number, success: boolean): void {
    this.current.requestCount += 1;
    if (success) this.current.successCount += 1;
    else this.current.failureCount += 1;
    this.current.latencies.push(latencyMs);

    this.totalRequestCount += 1;
    if (success) this.totalSuccessCount += 1;
    else this.totalFailureCount += 1;
    this.allLatencies.push(latencyMs);
  }

  /**
   * Builds a single aggregate snapshot over the entire run (total counts,
   * average RPS across `totalDurationMs`, and global latency percentiles).
   */
  buildSummary(totalDurationMs: number): SystemMetricSnapshot {
    const elapsedSeconds = Math.max(0.001, totalDurationMs / 1000);
    return {
      timestampMs: totalDurationMs,
      requestCount: this.totalRequestCount,
      successCount: this.totalSuccessCount,
      failureCount: this.totalFailureCount,
      rps: this.totalRequestCount / elapsedSeconds,
      errorRate: this.totalRequestCount > 0 ? this.totalFailureCount / this.totalRequestCount : 0,
      latency: computePercentiles(this.allLatencies)
    };
  }

  maybeSnapshot(nowMs: number, nodeRuntimes: NodeRuntime[], force = false): void {
    if (!force && nowMs - this.lastSnapshotAtMs < this.metricIntervalMs) return;
    const elapsedSeconds = Math.max(0.001, (nowMs - this.lastSnapshotAtMs) / 1000);
    const rps = this.current.requestCount / elapsedSeconds;
    const errorRate =
      this.current.requestCount > 0 ? this.current.failureCount / this.current.requestCount : 0;

    this.systemSnapshots.push({
      timestampMs: nowMs,
      requestCount: this.current.requestCount,
      successCount: this.current.successCount,
      failureCount: this.current.failureCount,
      rps,
      errorRate,
      latency: computePercentiles(this.current.latencies)
    });

    for (const runtime of nodeRuntimes) {
      const capacity = effectiveCapacity(runtime);
      const utilization = capacity > 0 ? Math.min(1, runtime.activeWork / capacity) : runtime.activeWork > 0 ? 1 : 0;
      const cacheTotal = runtime.cacheHits + runtime.cacheMisses;
      const dnsTotal = runtime.dnsResolutionCount + runtime.dnsCacheHitCount;
      this.componentSnapshots.push({
        nodeId: runtime.node.id,
        timestampMs: nowMs,
        utilization,
        activeWork: runtime.activeWork,
        queuedWork: runtime.queue.length,
        latencyMs: average(runtime.latencySamples),
        errorRate: runtime.totalCompleted + runtime.totalFailed > 0
          ? runtime.totalFailed / (runtime.totalCompleted + runtime.totalFailed)
          : 0,
        cacheHitRatio: runtime.node.type === "cache" && cacheTotal > 0 ? runtime.cacheHits / cacheTotal : undefined,
        queueDepth:
          runtime.node.type === "message-queue"
            ? runtime.queueMessages.length
            : runtime.node.type === "event-topic"
              ? totalSubscriberDepth(runtime)
              : undefined,
        quotaRejectionCount:
          runtime.node.type === "api-gateway" ? runtime.quotaRejectionCount : undefined,
        authBlockedCount: runtime.node.type === "api-gateway" ? runtime.authBlockedCount : undefined,
        dnsCacheHitRatio:
          runtime.node.type === "dns-traffic-manager" && dnsTotal > 0
            ? runtime.dnsCacheHitCount / dnsTotal
            : undefined,
        staleResolutionCount:
          runtime.node.type === "dns-traffic-manager" ? runtime.staleResolutionCount : undefined,
        hotPartitionThrottleCount:
          runtime.node.type === "nosql-database" ? runtime.hotPartitionThrottleCount : undefined,
        staleReadCount: runtime.node.type === "nosql-database" ? runtime.staleReadCount : undefined,
        partitionUtilization:
          runtime.node.type === "nosql-database" ? [...runtime.partitionActive] : undefined,
        fanOutFactor: runtime.node.type === "event-topic" ? runtime.subscriberQueues.size : undefined,
        providerThrottleCount:
          runtime.node.type === "external-service" ? runtime.providerThrottleCount : undefined
      });
      runtime.latencySamples = [];
    }

    this.current = emptyCounters();
    this.lastSnapshotAtMs = nowMs;
  }
}

function emptyCounters(): IntervalCounters {
  return { requestCount: 0, successCount: 0, failureCount: 0, latencies: [] };
}

function average(values: number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function totalSubscriberDepth(runtime: NodeRuntime): number {
  let depth = 0;
  for (const queue of runtime.subscriberQueues.values()) depth += queue.length;
  return depth;
}
