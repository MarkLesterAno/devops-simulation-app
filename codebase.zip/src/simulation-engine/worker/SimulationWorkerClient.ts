import type { SimulationInput } from "@/domain/simulation/simulationInput";
import type { SimulationResult } from "@/domain/metrics/schema";
import type { WorkerRequestMessage, WorkerResponseMessage } from "@/simulation-engine/worker/simulationWorker";
import {
  COMPONENT_MODEL_VERSION,
  ENGINE_VERSION
} from "@/simulation-engine/core/SimulationEngine";

interface ActiveRun {
  worker: Worker;
  resolve: (result: SimulationResult) => void;
  input: SimulationInput;
  settled: boolean;
}

/**
 * Renderer-side client for the simulation Web Worker. Each call spins up a
 * fresh worker so a long-running or cancelled simulation cannot leak state
 * into the next run; this also trivially satisfies AC-SI-06 (cancellation).
 */
export class SimulationWorkerClient {
  private activeRun?: ActiveRun;

  run(input: SimulationInput): Promise<SimulationResult> {
    this.cancel();
    return new Promise<SimulationResult>((resolve, reject) => {
      const worker = new Worker(new URL("./simulationWorker.ts", import.meta.url), { type: "module" });
      const activeRun: ActiveRun = { worker, resolve, input, settled: false };
      this.activeRun = activeRun;
      const requestId = crypto.randomUUID();

      worker.onmessage = (event: MessageEvent<WorkerResponseMessage>) => {
        const message = event.data;
        if (message.requestId !== requestId) return;
        if (message.kind === "result" && message.result) {
          activeRun.settled = true;
          resolve(message.result);
        } else {
          activeRun.settled = true;
          reject(new Error(message.error ?? "Simulation failed"));
        }
        worker.terminate();
        if (this.activeRun === activeRun) this.activeRun = undefined;
      };
      worker.onerror = (event) => {
        activeRun.settled = true;
        reject(new Error(event.message || "Simulation worker error"));
        worker.terminate();
        if (this.activeRun === activeRun) this.activeRun = undefined;
      };

      const request: WorkerRequestMessage = { kind: "run", requestId, input };
      worker.postMessage(request);
    });
  }

  cancel(): void {
    const activeRun = this.activeRun;
    if (!activeRun) return;
    this.activeRun = undefined;
    activeRun.worker.terminate();
    if (!activeRun.settled) {
      activeRun.settled = true;
      activeRun.resolve(cancelledResult(activeRun.input));
    }
  }
}

function cancelledResult(input: SimulationInput): SimulationResult {
  return {
    runId: crypto.randomUUID(),
    seed: input.seed,
    status: "cancelled",
    engineVersion: ENGINE_VERSION,
    componentModelVersion: COMPONENT_MODEL_VERSION,
    systemMetrics: [],
    componentMetrics: [],
    events: [],
    findings: [],
    assumptions: [
      "Simulation was cancelled before the worker could return metrics. Run again to collect complete results."
    ],
    flowTimeline: {
      bucketMs: input.settings.metricIntervalMs,
      durationMs: 0,
      peakBucketCount: 0,
      buckets: []
    },
    methodDistribution: {},
    manualBatchIds: (input.manualRequests ?? []).map((batch) => batch.id),
    retryCount: 0,
    timeoutCount: 0
  };
}
