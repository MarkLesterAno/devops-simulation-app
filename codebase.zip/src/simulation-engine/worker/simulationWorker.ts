/// <reference lib="webworker" />
import { runSimulation } from "@/simulation-engine/core/SimulationEngine";
import type { SimulationInput } from "@/domain/simulation/simulationInput";
import type { SimulationResult } from "@/domain/metrics/schema";

export interface WorkerRequestMessage {
  kind: "run";
  requestId: string;
  input: SimulationInput;
}

export interface WorkerResponseMessage {
  kind: "result" | "error";
  requestId: string;
  result?: SimulationResult;
  error?: string;
}

/**
 * Simulation Web Worker entry point per TRD.md's architecture diagram: the
 * engine executes off the main thread so canvas interaction stays responsive
 * (AC-SI-07) while metrics stream back to the renderer.
 */
self.onmessage = (event: MessageEvent<WorkerRequestMessage>) => {
  const message = event.data;
  if (message.kind !== "run") return;
  try {
    const result = runSimulation(message.input);
    const response: WorkerResponseMessage = { kind: "result", requestId: message.requestId, result };
    (self as unknown as Worker).postMessage(response);
  } catch (error) {
    const response: WorkerResponseMessage = {
      kind: "error",
      requestId: message.requestId,
      error: error instanceof Error ? error.message : "Unknown simulation error"
    };
    (self as unknown as Worker).postMessage(response);
  }
};
