/**
 * Event priority classes, in ascending sort order, per SIMULATION_SPEC.md
 * "Time and event ordering". Lower numeric value sorts first at equal timestamps.
 */
export enum EventPriority {
  FaultBoundary = 0,
  AutoscaleOrHealth = 1,
  TimeoutOrCircuitBreaker = 2,
  CompletionOrConsume = 3,
  ArrivalForwardOrRetry = 4,
  MetricSnapshot = 5
}

export interface SimulationEventBase {
  timestampMs: number;
  priority: EventPriority;
  sequence: number;
  type: string;
}

/**
 * Binary-heap priority queue ordered by (timestampMs, priority, sequence),
 * all ascending. This guarantees stable, reproducible event ordering that
 * never depends on insertion order beyond the explicit sequence number.
 */
export class EventQueue<TEvent extends SimulationEventBase> {
  private heap: TEvent[] = [];

  get size(): number {
    return this.heap.length;
  }

  isEmpty(): boolean {
    return this.heap.length === 0;
  }

  push(event: TEvent): void {
    this.heap.push(event);
    this.bubbleUp(this.heap.length - 1);
  }

  pop(): TEvent | undefined {
    if (this.heap.length === 0) return undefined;
    const top = this.heap[0];
    const last = this.heap.pop();
    if (this.heap.length > 0 && last !== undefined) {
      this.heap[0] = last;
      this.bubbleDown(0);
    }
    return top;
  }

  peek(): TEvent | undefined {
    return this.heap[0];
  }

  private isBefore(a: TEvent, b: TEvent): boolean {
    if (a.timestampMs !== b.timestampMs) return a.timestampMs < b.timestampMs;
    if (a.priority !== b.priority) return a.priority < b.priority;
    return a.sequence < b.sequence;
  }

  private bubbleUp(index: number): void {
    let currentIndex = index;
    while (currentIndex > 0) {
      const parentIndex = (currentIndex - 1) >> 1;
      const current = this.heap[currentIndex];
      const parent = this.heap[parentIndex];
      if (current === undefined || parent === undefined || !this.isBefore(current, parent)) {
        break;
      }
      this.heap[currentIndex] = parent;
      this.heap[parentIndex] = current;
      currentIndex = parentIndex;
    }
  }

  private bubbleDown(index: number): void {
    let currentIndex = index;
    const length = this.heap.length;
    for (;;) {
      const left = currentIndex * 2 + 1;
      const right = currentIndex * 2 + 2;
      let smallest = currentIndex;

      const smallestItem = this.heap[smallest];
      const leftItem = left < length ? this.heap[left] : undefined;
      const rightItem = right < length ? this.heap[right] : undefined;

      if (leftItem !== undefined && smallestItem !== undefined && this.isBefore(leftItem, smallestItem)) {
        smallest = left;
      }
      const currentSmallest = this.heap[smallest];
      if (rightItem !== undefined && currentSmallest !== undefined && this.isBefore(rightItem, currentSmallest)) {
        smallest = right;
      }
      if (smallest === currentIndex) break;

      const tmp = this.heap[currentIndex]!;
      this.heap[currentIndex] = this.heap[smallest]!;
      this.heap[smallest] = tmp;
      currentIndex = smallest;
    }
  }
}
