import type { ScheduledFault } from "@/domain/simulation/faultScenario";
import type { FaultType } from "@/domain/simulation/faultScenario";
import type { NodeRuntime } from "@/simulation-engine/core/NodeRuntime";

/**
 * Applies the combined effect of every currently-active fault to a node's
 * runtime fields, per SIMULATION_SPEC.md "Fault model and precedence".
 * Capacity multipliers multiply; latency adds; error rates combine as
 * 1 - product(1 - errorRate); any outage makes the target unavailable.
 */
export function applyFaultsToNode(
  runtime: NodeRuntime,
  activeFaults: ScheduledFault[],
  regionOf: (nodeId: string) => string | undefined
): void {
  let capacityMultiplier = 1;
  let additionalLatencyMs = 0;
  let errorSurvivalProduct = 1;
  let unavailable = false;
  const flags = new Set<FaultType>();

  for (const fault of activeFaults) {
    const targetsNode = fault.target.nodeIds.includes(runtime.node.id);
    const targetsRegion =
      fault.target.region !== undefined && fault.target.region === regionOf(runtime.node.id);
    if (!targetsNode && !targetsRegion) continue;

    switch (fault.type) {
      case "node-outage":
      case "database-primary-failure":
      case "queue-consumer-failure":
      case "regional-outage":
        unavailable = true;
        break;
      case "capacity-reduction":
        capacityMultiplier *= fault.capacityMultiplier ?? 0.5;
        break;
      case "degradation":
        capacityMultiplier *= fault.capacityMultiplier ?? 0.5;
        additionalLatencyMs += fault.additionalLatencyMs ?? 0;
        break;
      case "latency-increase":
        additionalLatencyMs += fault.additionalLatencyMs ?? 0;
        break;
      case "error-rate-increase":
        errorSurvivalProduct *= 1 - (fault.additionalErrorRate ?? 0);
        break;
      case "cache-failure":
        unavailable = runtime.node.type === "cache" ? true : unavailable;
        break;
      case "credential-store-unavailable":
        unavailable = runtime.node.type === "identity-auth-service" ? true : unavailable;
        break;
      case "quota-exhaustion":
      case "stale-dns-record":
      case "partition-hotspot":
      case "subscriber-group-stall":
      case "provider-throttling":
        // Behavioral flags consumed by the owning component's engine branch.
        flags.add(fault.type);
        break;
      default:
        break;
    }
  }

  runtime.activeFaultFlags = flags;
  runtime.activeFaultCapacityMultiplier = Math.max(0, capacityMultiplier);
  runtime.activeFaultAdditionalLatencyMs = additionalLatencyMs;
  runtime.activeFaultAdditionalErrorRate = 1 - errorSurvivalProduct;
  runtime.activeFaultUnavailable = unavailable;
  runtime.health = unavailable
    ? "unavailable"
    : capacityMultiplier < 1
      ? "degraded"
      : "healthy";
}

export function findActiveFaults(faults: ScheduledFault[], nowMs: number): ScheduledFault[] {
  return faults.filter(
    (fault) => fault.startMs <= nowMs && (fault.endMs === undefined || fault.endMs > nowMs)
  );
}

export function findActiveTrafficMultiplier(faults: ScheduledFault[], nowMs: number): number {
  let multiplier = 1;
  for (const fault of faults) {
    if (fault.type !== "traffic-spike") continue;
    if (fault.startMs <= nowMs && (fault.endMs === undefined || fault.endMs > nowMs)) {
      multiplier *= fault.trafficMultiplier ?? 1;
    }
  }
  return multiplier;
}
