import type { ProjectDocument } from "@/domain/architecture/projectDocument";
import type { SimulationResult } from "@/domain/metrics/schema";
import {
  COMPONENT_MODEL_VERSION,
  ENGINE_VERSION
} from "@/simulation-engine/core/SimulationEngine";

/**
 * Stable fingerprint of everything a simulation result depends on.
 *
 * Compared against the signature captured when a result arrived, this is what
 * lets the UI mark results stale after the architecture, traffic, or fault
 * configuration changes. Node positions are excluded on purpose: moving a box
 * on the canvas does not invalidate a run.
 */
export function architectureSignature(document: ProjectDocument): string {
  const nodes = document.nodes
    .map((node) => `${node.id}:${node.type}:${stableSerialize(node.config)}`)
    .sort()
    .join("|");
  const edges = document.edges
    .map((edge) => stableSerialize(edge))
    .sort()
    .join("|");
  const profiles = stableSerialize(document.trafficProfiles);
  const faults = stableSerialize(document.faultScenarios);
  return `${nodes}#${edges}#${profiles}#${faults}`;
}

/**
 * Produces a deterministic value representation so equivalent project data
 * always has the same signature regardless of object-property insertion order.
 */
function stableSerialize(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableSerialize).join(",")}]`;
  if (value !== null && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableSerialize(record[key])}`)
      .join(",")}}`;
  }
  return JSON.stringify(value);
}

export type ResultFreshness = "current" | "architecture-changed" | "simulation-model-changed";

export function resultFreshness(
  result: SimulationResult | undefined,
  document: ProjectDocument,
  lastResultSignature: string | undefined
): ResultFreshness {
  if (!result || architectureSignature(document) !== lastResultSignature) {
    return "architecture-changed";
  }
  if (
    result.engineVersion !== ENGINE_VERSION ||
    result.componentModelVersion !== COMPONENT_MODEL_VERSION
  ) {
    return "simulation-model-changed";
  }
  return "current";
}

export interface DeletionImpact {
  edgeCount: number;
  /** Fault scenarios that reference the node and would lose that reference. */
  faultScenarioNames: string[];
  /** True when deletion affects more than the node itself and needs confirming. */
  requiresConfirmation: boolean;
}

/**
 * Summarizes what else a node deletion would affect, so the confirmation dialog
 * can state the consequences instead of asking "are you sure?" about nothing.
 */
export function describeDeletionImpact(
  document: ProjectDocument,
  nodeId: string
): DeletionImpact {
  const edgeCount = document.edges.filter(
    (edge) => edge.sourceNodeId === nodeId || edge.targetNodeId === nodeId
  ).length;

  const faultScenarioNames = document.faultScenarios
    .filter((scenario) =>
      scenario.faults.some((fault) => fault.target.nodeIds.includes(nodeId))
    )
    .map((scenario) => scenario.name);

  return {
    edgeCount,
    faultScenarioNames,
    requiresConfirmation: edgeCount > 0 || faultScenarioNames.length > 0
  };
}
