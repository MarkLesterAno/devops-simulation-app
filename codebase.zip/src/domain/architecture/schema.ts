import { z } from "zod";

/**
 * Connection kinds constrain which edges a component may send or receive,
 * per TRD.md's ComponentDefinition contract and SIMULATION_SPEC.md routing rules.
 */
export const connectionKindSchema = z.enum([
  "request",
  "response",
  "event",
  "replication",
  "failover",
  "observability"
]);
export type ConnectionKind = z.infer<typeof connectionKindSchema>;

export const componentCategorySchema = z.enum([
  "entry",
  "compute",
  "data",
  "messaging",
  "performance",
  "reliability",
  "operations",
  "identity",
  "external"
]);
export type ComponentCategory = z.infer<typeof componentCategorySchema>;

/**
 * Append-only enumeration. Values are persisted by string in project documents,
 * so entries must never be reordered, renamed, or removed (TRD.md "Domain model").
 */
export const componentTypeSchema = z.enum([
  "client",
  "cdn",
  "load-balancer",
  "server",
  "worker",
  "cache",
  "relational-database",
  "read-replica",
  "object-storage",
  "message-queue",
  "dead-letter-queue",
  "circuit-breaker",
  "autoscaler",
  "observability",
  // Priority 1 catalog expansion.
  "api-gateway",
  "dns-traffic-manager",
  "nosql-database",
  "event-topic",
  "identity-auth-service",
  "external-service"
]);
export type ComponentType = z.infer<typeof componentTypeSchema>;

export const routingStrategySchema = z.enum([
  "round-robin",
  "weighted",
  "least-active",
  "random",
  "conditional"
]);
export type RoutingStrategy = z.infer<typeof routingStrategySchema>;

export const overflowBehaviorSchema = z.enum(["queue", "reject", "shed-load", "penalty"]);
export type OverflowBehavior = z.infer<typeof overflowBehaviorSchema>;

/**
 * Real-world technology assigned to a node, e.g. Redis for a cache.
 *
 * This is educational metadata only: it never triggers provisioning, network
 * calls, or credential prompts, and the simulation engine ignores it entirely.
 * `displayName`, `provider`, and `componentTypes` are denormalized on purpose so
 * a project referencing a removed or renamed technology still renders safely.
 */
export const technologyAssignmentSchema = z.object({
  id: z.string().min(1),
  displayName: z.string().min(1),
  provider: z.string().min(1).optional(),
  componentTypes: z.array(componentTypeSchema).optional()
});
export type TechnologyAssignment = z.infer<typeof technologyAssignmentSchema>;

/** Shared settings present on every component per PRD.md's initial component catalog. */
export const baseComponentConfigSchema = z.object({
  displayName: z.string().min(1).max(80),
  region: z.string().min(1).max(40).default("local"),
  instanceCount: z.number().int().min(1).max(1000).default(1),
  perInstanceCapacityRps: z.number().min(0).default(100),
  baseLatencyMs: z.number().min(0).default(5),
  jitterMs: z.number().min(0).default(0),
  timeoutMs: z.number().min(1).default(2000),
  errorRate: z.number().min(0).max(1).default(0),
  overflowBehavior: overflowBehaviorSchema.default("queue"),
  maxQueueDepth: z.number().int().min(0).default(1000),
  estimatedCostPerHour: z.number().min(0).default(0),
  maxRetries: z.number().int().min(0).max(10).default(0),
  retryBackoffMs: z.number().min(0).default(100),
  /** Optional real-world implementation assigned to this node. */
  technology: technologyAssignmentSchema.optional()
});
export type BaseComponentConfig = z.infer<typeof baseComponentConfigSchema>;

export const architectureNodeSchema = z.object({
  id: z.string().min(1),
  type: componentTypeSchema,
  position: z.object({ x: z.number(), y: z.number() }),
  config: baseComponentConfigSchema.passthrough()
});
export type ArchitectureNode = z.infer<typeof architectureNodeSchema>;
export const architectureEdgeSchema = z.object({
  id: z.string().min(1),
  sourceNodeId: z.string().min(1),
  targetNodeId: z.string().min(1),
  kind: connectionKindSchema,
  routingStrategy: routingStrategySchema.optional(),
  weight: z.number().min(0).optional(),
  latencyMs: z.number().min(0).default(0)
});
export type ArchitectureEdge = z.infer<typeof architectureEdgeSchema>;
