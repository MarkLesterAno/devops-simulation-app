import { z } from "zod";
import { architectureNodeSchema, architectureEdgeSchema } from "@/domain/architecture/schema";
import { trafficProfileSchema } from "@/domain/simulation/trafficProfile";
import { faultScenarioSchema } from "@/domain/simulation/faultScenario";

/**
 * Current persisted project schema version.
 *
 * v2 marks the Priority 1 catalog expansion. The document shape is unchanged —
 * every new component configuration field is optional or defaulted — so the
 * migration from v1 is a version stamp rather than a structural rewrite.
 * Bump and add a migration when the shape changes.
 */
export const PROJECT_SCHEMA_VERSION = 2;

/** Schema versions that can be migrated forward to the current version. */
export const MIGRATABLE_SCHEMA_VERSIONS = [1];

export const projectDocumentSchema = z.object({
  schemaVersion: z.literal(PROJECT_SCHEMA_VERSION),
  id: z.string().min(1),
  name: z.string().min(1).max(120),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
  nodes: z.array(architectureNodeSchema),
  edges: z.array(architectureEdgeSchema),
  trafficProfiles: z.array(trafficProfileSchema),
  faultScenarios: z.array(faultScenarioSchema)
});
export type ProjectDocument = z.infer<typeof projectDocumentSchema>;

export function createEmptyProject(name = "Untitled Project"): ProjectDocument {
  const now = new Date().toISOString();
  return {
    schemaVersion: PROJECT_SCHEMA_VERSION,
    id: crypto.randomUUID(),
    name,
    createdAt: now,
    updatedAt: now,
    nodes: [],
    edges: [],
    trafficProfiles: [],
    faultScenarios: []
  };
}

export interface ProjectParseResult {
  ok: boolean;
  document?: ProjectDocument;
  error?: string;
}

/**
 * Safely parses an unknown value (for example, loaded from disk) into a
 * ProjectDocument. Never throws; malformed documents are rejected with a
 * descriptive error per AC-PE-02 and SECURITY_AND_PRIVACY.md.
 *
 * Documents written by a supported older schema version are migrated forward
 * before validation, so saved projects keep opening after a catalog expansion
 * (AC-PE-04).
 */
export function parseProjectDocument(value: unknown): ProjectParseResult {
  let candidate = value;
  if (typeof value === "object" && value !== null && "schemaVersion" in value) {
    const version = (value as { schemaVersion?: unknown }).schemaVersion;
    if (typeof version === "number" && version !== PROJECT_SCHEMA_VERSION) {
      if (!MIGRATABLE_SCHEMA_VERSIONS.includes(version)) {
        return {
          ok: false,
          error: `Unsupported project schema version ${version}; expected ${PROJECT_SCHEMA_VERSION}`
        };
      }
      candidate = migrateProjectDocument(value as Record<string, unknown>, version);
    }
  }
  const result = projectDocumentSchema.safeParse(candidate);
  if (!result.success) {
    return { ok: false, error: result.error.issues.map((issue) => issue.message).join("; ") };
  }
  return { ok: true, document: result.data };
}

/**
 * Forward migration chain. Each step is additive and must preserve every field
 * it does not explicitly change — notably `technology` assignments, which are
 * denormalized so a project referencing a removed technology still loads.
 */
function migrateProjectDocument(
  document: Record<string, unknown>,
  fromVersion: number
): Record<string, unknown> {
  let migrated = document;
  if (fromVersion <= 1) {
    // v1 -> v2: catalog expansion only. New component configuration fields are
    // optional or defaulted, so no node rewriting is required.
    migrated = { ...migrated, schemaVersion: 2 };
  }
  return migrated;
}
