import type { ComponentType } from "@/domain/architecture/schema";

/**
 * Local, offline icon model for canvas nodes.
 *
 * Two separate concerns live here:
 *
 * 1. `ComponentGlyph` — a small set of locally authored, generic shapes that
 *    describe what a component *does*. Every component type always resolves to
 *    one, so a node is never iconless.
 * 2. `TechnologyIcon` — per-product visual identity keyed by the stable
 *    technology id. This is a registry, not conditional logic in the canvas, so
 *    adding a product never means editing a component.
 *
 * Nothing here is fetched at runtime. Vendor brand assets are trademarked and
 * are intentionally *not* bundled; see `LOGO_ASSETS` for the drop-in path.
 */

export type ComponentGlyph =
  | "client"
  | "edge"
  | "dns"
  | "gateway"
  | "balancer"
  | "server"
  | "worker"
  | "cache"
  | "database"
  | "replica"
  | "storage"
  | "queue"
  | "topic"
  | "breaker"
  | "scale"
  | "observe"
  | "identity"
  | "external";

/**
 * SVG path data for each glyph, drawn on a 24x24 grid and stroked with
 * `currentColor` so glyphs inherit theme and status colors rather than
 * hard-coding them.
 */
export const GLYPH_PATHS: Record<ComponentGlyph, string[]> = {
  client: ["M4 5h16v11H4z", "M9 20h6", "M12 16v4"],
  edge: [
    "M12 3a9 9 0 100 18 9 9 0 000-18z",
    "M3 12h18",
    "M12 3c3 3 3 15 0 18",
    "M12 3c-3 3-3 15 0 18"
  ],
  dns: ["M12 3a9 9 0 100 18 9 9 0 000-18z", "M3.5 9h17", "M3.5 15h17", "M12 3c2.5 3 2.5 15 0 18"],
  gateway: ["M5 20V8l7-4 7 4v12", "M9 20v-6h6v6", "M5 12h14"],
  balancer: ["M12 4v5", "M4 13h16", "M6 13v3a2 2 0 002 2h1", "M18 13v3a2 2 0 01-2 2h-1"],
  server: ["M4 5h16v5H4z", "M4 14h16v5H4z", "M7.5 7.5h.01", "M7.5 16.5h.01"],
  worker: ["M6 7h12v11H6z", "M9 4v3", "M15 4v3", "M9.5 12h5"],
  cache: [
    "M4 7c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3z",
    "M4 7v10c0 1.7 3.6 3 8 3s8-1.3 8-3V7",
    "M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"
  ],
  database: [
    "M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3z",
    "M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6",
    "M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"
  ],
  replica: [
    "M3 6c0-1.4 2.7-2.5 6-2.5S15 4.6 15 6v10c0 1.4-2.7 2.5-6 2.5S3 17.4 3 16z",
    "M17 8c2.5.4 4 1.3 4 2.3V19c0 1.4-2.7 2.5-6 2.5-1.4 0-2.7-.2-3.7-.5"
  ],
  storage: ["M12 3l8 4.5v9L12 21l-8-4.5v-9z", "M12 12l8-4.5", "M12 12v9", "M12 12L4 7.5"],
  queue: ["M3 8h4v8H3z", "M10 8h4v8h-4z", "M17 8h4v8h-4z"],
  topic: ["M12 8a3 3 0 100 6 3 3 0 000-6z", "M12 3v5", "M12 14l-5 7", "M12 14l5 7"],
  breaker: ["M13 3l-7 9h5l-1 9 7-9h-5z"],
  scale: ["M12 20V6", "M7 11l5-5 5 5", "M4 20h16"],
  observe: [
    "M2 12s3.8-6 10-6 10 6 10 6-3.8 6-10 6-10-6-10-6z",
    "M12 9.5a2.5 2.5 0 100 5 2.5 2.5 0 000-5z"
  ],
  identity: [
    "M12 3l7 3v5c0 4.3-2.9 8.1-7 9-4.1-.9-7-4.7-7-9V6z",
    "M12 10a2 2 0 100 4 2 2 0 000-4z",
    "M9 17c.6-1.6 1.7-2.4 3-2.4s2.4.8 3 2.4"
  ],
  external: ["M6 6h6", "M6 6v12h12v-6", "M14 4h6v6", "M20 4l-9 9"]
};

const GLYPH_BY_COMPONENT: Record<ComponentType, ComponentGlyph> = {
  client: "client",
  cdn: "edge",
  "load-balancer": "balancer",
  server: "server",
  worker: "worker",
  cache: "cache",
  "relational-database": "database",
  "read-replica": "replica",
  "object-storage": "storage",
  "message-queue": "queue",
  "dead-letter-queue": "queue",
  "circuit-breaker": "breaker",
  autoscaler: "scale",
  observability: "observe",
  "api-gateway": "gateway",
  "dns-traffic-manager": "dns",
  "nosql-database": "database",
  "event-topic": "topic",
  "identity-auth-service": "identity",
  "external-service": "external"
};

export function glyphForComponentType(type: ComponentType): ComponentGlyph {
  return GLYPH_BY_COMPONENT[type] ?? "server";
}

export interface TechnologyIcon {
  /** Short monogram shown when no logo asset has been approved. */
  monogram: string;
  /** Provider-derived accent used for the badge. */
  accent: string;
  /** Bundled logo asset path, when one has been approved and added. */
  assetPath?: string;
}

/**
 * Approved, locally bundled logo assets keyed by stable technology id.
 *
 * Deliberately empty. Vendor logos are trademarked, and licensing them is a
 * product decision rather than an implementation detail, so none are shipped.
 * To add one: place the file under `src/assets/logos/`, import it, and map it
 * here. Node rendering, the configuration modal, and accessibility labels are
 * already asset-aware and need no further change.
 */
export const LOGO_ASSETS: Record<string, string> = {};

/**
 * Accent colors grouped by provider, so each product inherits its vendor's
 * identity without anyone maintaining a per-technology entry.
 */
const PROVIDER_ACCENTS: Record<string, string> = {
  "Amazon Web Services": "#e88b00",
  "Microsoft Azure": "#0089d6",
  "Google Cloud": "#4285f4",
  Cloudflare: "#f6821f",
  Redis: "#d92b21",
  MongoDB: "#13aa52",
  "Apache Software Foundation": "#d22128",
  "Cloud Native Computing Foundation": "#326ce5",
  Elastic: "#00a99d",
  HashiCorp: "#8a5cf6",
  Docker: "#2496ed",
  "Grafana Labs": "#f46800",
  Datadog: "#7c4dbd",
  Oracle: "#c74634",
  IBM: "#4589ff",
  "IBM NS1": "#4589ff",
  Stripe: "#7a73ff",
  Twilio: "#f22f46",
  "Twilio SendGrid": "#1a82e2",
  Okta: "#1e8fd4",
  "Red Hat": "#ee3124",
  Fastly: "#ff444d",
  Akamai: "#22a1d6",
  Nginx: "#009639",
  Kong: "#1a7fc1",
  ScyllaDB: "#3ab0e0",
  Couchbase: "#ea2328",
  Aerospike: "#c8202f",
  Apple: "#9aa4b2",
  DataStax: "#6b6bd6",
  Confluent: "#3d6fd1",
  Snowflake: "#29b5e8",
  MinIO: "#c72c48",
  Supabase: "#3ecf8e",
  PostgreSQL: "#4a82b8",
  Riak: "#c0392b",
  "Riak (Legacy)": "#c0392b",
  Unspecified: "#5b6b84"
};

const DEFAULT_ACCENT = "#5b6b84";

/** Initials for multi-word names, otherwise a short prefix of the single word. */
export function monogramFor(displayName: string): string {
  const words = displayName
    .replace(/[^A-Za-z0-9 ]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
  const first = words[0];
  if (!first) return "?";
  if (words.length === 1) {
    return (first.length <= 2 ? first : first.slice(0, 2)).toUpperCase();
  }
  return words
    .slice(0, 2)
    .map((word) => word.charAt(0).toUpperCase())
    .join("");
}

/**
 * Resolves the icon for an assigned technology.
 *
 * Driven by the assignment stored on the node rather than the live catalog, so
 * a project referencing a renamed or removed product still renders a stable,
 * recognizable badge instead of collapsing into an error state.
 */
export function technologyIconFor(
  technologyId: string,
  displayName: string,
  provider: string | undefined
): TechnologyIcon {
  return {
    monogram: monogramFor(displayName),
    accent: (provider ? PROVIDER_ACCENTS[provider] : undefined) ?? DEFAULT_ACCENT,
    assetPath: LOGO_ASSETS[technologyId]
  };
}
