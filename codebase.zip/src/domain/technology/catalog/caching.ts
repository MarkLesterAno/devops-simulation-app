import type { TechnologyOptionInput } from "@/domain/technology/schema";

const MODEL_VERSION = "1.0.0";

/**
 * Caches and session stores mapped to the `cache` component. Presets bias
 * toward low latency and high hit ratios to contrast with datastore components.
 */
export const cachingTechnologies: TechnologyOptionInput[] = [
  {
    id: "redis",
    displayName: "Redis",
    provider: "Redis",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["cache", "relational-database", "message-queue"],
    description:
      "In-memory data structure store used as a cache, session store, key-value database, and stream broker.",
    capabilities: [
      "in-memory-storage",
      "key-value-model",
      "ttl-expiry",
      "pub-sub",
      "streams",
      "replication"
    ],
    roleCapabilities: {
      cache: ["in-memory-storage", "ttl-expiry", "eviction-policies", "sub-millisecond-reads"],
      "relational-database": ["key-value-model", "persistence-options", "replication"],
      "message-queue": ["pub-sub", "streams", "consumer-groups"]
    },
    advisories: [
      {
        message:
          "Non-relational key-value data model. Persistence is optional and weaker than a durable OLTP datastore.",
        componentTypes: ["relational-database"]
      },
      {
        message:
          "Redis Streams provide consumer groups, but delivery and retention guarantees are weaker than a dedicated durable broker.",
        componentTypes: ["message-queue"]
      }
    ],
    simulationPreset: { baseLatencyMs: 2, hitRatio: 0.9, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://redis.io/docs/latest/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "memcached",
    displayName: "Memcached",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["cache"],
    description: "Simple, high-throughput distributed memory object cache with LRU eviction.",
    capabilities: ["in-memory-storage", "ttl-expiry", "lru-eviction", "horizontal-sharding"],
    advisories: [
      { message: "No persistence or replication; cached data is lost when a node restarts." }
    ],
    simulationPreset: { baseLatencyMs: 1, hitRatio: 0.88, perInstanceCapacityRps: 6000 },
    documentationUrl: "https://docs.memcached.org/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "dragonfly",
    displayName: "Dragonfly",
    provider: "DragonflyDB",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["cache"],
    description:
      "Redis and Memcached compatible in-memory store using a multi-threaded shared-nothing design.",
    capabilities: ["in-memory-storage", "multi-threaded", "redis-protocol-compatible", "ttl-expiry"],
    simulationPreset: { baseLatencyMs: 1, hitRatio: 0.9, perInstanceCapacityRps: 9000 },
    documentationUrl: "https://www.dragonflydb.io/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "keydb",
    displayName: "KeyDB",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["cache"],
    description: "Multi-threaded Redis fork supporting active-active replication.",
    capabilities: ["in-memory-storage", "multi-threaded", "active-active-replication", "ttl-expiry"],
    simulationPreset: { baseLatencyMs: 1, hitRatio: 0.9, perInstanceCapacityRps: 8000 },
    documentationUrl: "https://docs.keydb.dev/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "garnet",
    displayName: "Garnet",
    provider: "Microsoft",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["cache"],
    description:
      "Remote cache store from Microsoft Research offering RESP compatibility and high throughput.",
    capabilities: ["in-memory-storage", "redis-protocol-compatible", "tiered-storage", "ttl-expiry"],
    simulationPreset: { baseLatencyMs: 1, hitRatio: 0.9, perInstanceCapacityRps: 8000 },
    documentationUrl: "https://microsoft.github.io/garnet/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "hazelcast",
    displayName: "Hazelcast",
    provider: "Hazelcast",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["cache"],
    description: "Distributed in-memory data grid with compute and near-cache capabilities.",
    capabilities: ["in-memory-data-grid", "near-cache", "distributed-compute", "replication"],
    simulationPreset: { baseLatencyMs: 3, hitRatio: 0.88, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://docs.hazelcast.com/home/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "apache-ignite",
    displayName: "Apache Ignite",
    provider: "Apache Software Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["cache"],
    description: "Distributed in-memory platform combining caching, SQL queries, and compute.",
    capabilities: ["in-memory-data-grid", "sql-queries", "distributed-compute", "persistence-options"],
    simulationPreset: { baseLatencyMs: 4, hitRatio: 0.85, perInstanceCapacityRps: 3500 },
    documentationUrl: "https://ignite.apache.org/docs/latest/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "infinispan",
    displayName: "Infinispan",
    provider: "Red Hat",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["cache"],
    description: "Java in-memory key-value data grid used for clustered caching and session storage.",
    capabilities: ["in-memory-data-grid", "session-replication", "ttl-expiry", "clustering"],
    simulationPreset: { baseLatencyMs: 4, hitRatio: 0.85, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://infinispan.org/documentation/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-elasticache",
    displayName: "Amazon ElastiCache",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cache"],
    description: "Managed Redis and Memcached caching service with clustering and failover.",
    capabilities: ["in-memory-storage", "managed-failover", "cluster-mode", "ttl-expiry"],
    simulationPreset: { baseLatencyMs: 2, hitRatio: 0.9, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://docs.aws.amazon.com/elasticache/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-memorydb-for-redis",
    displayName: "Amazon MemoryDB for Redis",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cache", "relational-database"],
    description:
      "Redis-compatible in-memory database with multi-AZ durable transaction log persistence.",
    capabilities: ["in-memory-storage", "durable-transaction-log", "multi-az-failover", "ttl-expiry"],
    roleCapabilities: {
      cache: ["in-memory-storage", "ttl-expiry", "sub-millisecond-reads"],
      "relational-database": ["durable-transaction-log", "multi-az-failover", "key-value-model"]
    },
    advisories: [
      {
        message: "Non-relational key-value data model.",
        componentTypes: ["relational-database"]
      }
    ],
    simulationPreset: { baseLatencyMs: 3, hitRatio: 0.9, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://docs.aws.amazon.com/memorydb/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-memorystore",
    displayName: "Google Memorystore",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cache"],
    description: "Managed Redis, Valkey, and Memcached instances on Google Cloud.",
    capabilities: ["in-memory-storage", "managed-failover", "ttl-expiry", "replication"],
    aliases: ["Google Memorystore for Redis"],
    simulationPreset: { baseLatencyMs: 2, hitRatio: 0.9, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://cloud.google.com/memorystore/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-cache-for-redis",
    displayName: "Azure Cache for Redis",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cache"],
    description: "Managed Redis service integrated with Azure networking and monitoring.",
    capabilities: ["in-memory-storage", "managed-failover", "clustering", "ttl-expiry"],
    simulationPreset: { baseLatencyMs: 2, hitRatio: 0.9, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://learn.microsoft.com/azure/azure-cache-for-redis/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "varnish-cache",
    displayName: "Varnish Cache",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["cache"],
    description: "HTTP reverse-proxy accelerator that caches full responses in memory.",
    capabilities: ["http-response-caching", "edge-side-includes", "vcl-rules", "cache-invalidation"],
    simulationPreset: { baseLatencyMs: 2, hitRatio: 0.85, perInstanceCapacityRps: 7000 },
    documentationUrl: "https://varnish-cache.org/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "nginx-cache",
    displayName: "NGINX Cache",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["cache"],
    description: "NGINX proxy cache storing upstream HTTP responses on disk or in memory.",
    capabilities: ["http-response-caching", "proxy-cache", "cache-invalidation", "stale-while-revalidate"],
    simulationPreset: { baseLatencyMs: 2, hitRatio: 0.8, perInstanceCapacityRps: 6000 },
    documentationUrl: "https://docs.nginx.com/nginx/admin-guide/content-cache/content-caching/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "cloudflare-workers-kv",
    displayName: "Cloudflare Workers KV",
    provider: "Cloudflare",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["cache"],
    description: "Globally replicated eventually-consistent key-value store for edge reads.",
    capabilities: ["global-replication", "key-value-model", "edge-reads", "ttl-expiry"],
    advisories: [
      {
        message:
          "Eventually consistent with propagation delay after writes; unsuitable for read-after-write critical paths."
      }
    ],
    simulationPreset: { baseLatencyMs: 5, hitRatio: 0.9, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://developers.cloudflare.com/kv/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "cloudflare-durable-objects",
    displayName: "Cloudflare Durable Objects",
    provider: "Cloudflare",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["cache", "relational-database"],
    description:
      "Single-instance stateful edge objects providing strongly consistent coordination and storage.",
    capabilities: ["strong-consistency", "stateful-coordination", "transactional-storage", "websockets"],
    advisories: [
      {
        message:
          "Each object is a single-threaded instance; throughput scales by partitioning across many objects rather than within one.",
      },
      {
        message: "Non-relational key-value storage API.",
        componentTypes: ["relational-database"]
      }
    ],
    simulationPreset: { baseLatencyMs: 8, hitRatio: 0.8, perInstanceCapacityRps: 500 },
    documentationUrl: "https://developers.cloudflare.com/durable-objects/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "dynamodb-accelerator",
    displayName: "DynamoDB Accelerator (DAX)",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cache"],
    description: "Write-through in-memory cache fronting DynamoDB for microsecond reads.",
    capabilities: ["write-through-caching", "in-memory-storage", "ttl-expiry", "dynamodb-api-compatible"],
    aliases: ["DAX"],
    advisories: [
      { message: "Purpose-built for DynamoDB; it cannot cache arbitrary backends." }
    ],
    simulationPreset: { baseLatencyMs: 1, hitRatio: 0.9, perInstanceCapacityRps: 6000 },
    documentationUrl: "https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DAX.html",
    modelVersion: MODEL_VERSION
  }
];
