import type { TechnologyOptionInput } from "@/domain/technology/schema";

const MODEL_VERSION = "1.0.0";

/**
 * Autoscaling controllers (`autoscaler`) and resilience libraries/proxies
 * (`circuit-breaker`). Infrastructure-as-code and CI/CD tools from the catalog
 * spec are intentionally excluded: they provision and deploy systems rather than
 * participate in request-time behavior, so no current component represents them.
 */
export const operationsTechnologies: TechnologyOptionInput[] = [
  {
    id: "kubernetes-horizontal-pod-autoscaler",
    displayName: "Kubernetes Horizontal Pod Autoscaler",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["autoscaler"],
    description:
      "Scales the replica count of a workload based on observed CPU, memory, or custom metrics.",
    capabilities: ["horizontal-scaling", "metric-driven-scaling", "custom-metrics", "stabilization-windows"],
    aliases: ["HPA"],
    simulationPreset: { baseLatencyMs: 0, perInstanceCapacityRps: 0 },
    documentationUrl:
      "https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "kubernetes-vertical-pod-autoscaler",
    displayName: "Kubernetes Vertical Pod Autoscaler",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["autoscaler"],
    description: "Adjusts CPU and memory requests for pods instead of changing replica count.",
    capabilities: ["vertical-scaling", "resource-recommendation", "metric-driven-scaling"],
    aliases: ["VPA"],
    advisories: [
      {
        message:
          "Resizes individual instances rather than adding replicas, so it does not increase horizontal request concurrency."
      }
    ],
    documentationUrl:
      "https://github.com/kubernetes/autoscaler/tree/master/vertical-pod-autoscaler",
    modelVersion: MODEL_VERSION
  },
  {
    id: "karpenter",
    displayName: "Karpenter",
    provider: "Amazon Web Services",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["autoscaler"],
    description:
      "Kubernetes node provisioner that launches right-sized capacity in response to pending pods.",
    capabilities: ["cluster-scaling", "just-in-time-provisioning", "instance-right-sizing", "consolidation"],
    documentationUrl: "https://karpenter.sh/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "cluster-autoscaler",
    displayName: "Cluster Autoscaler",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["autoscaler"],
    description: "Adds or removes Kubernetes cluster nodes based on unschedulable pods and utilization.",
    capabilities: ["cluster-scaling", "node-group-management", "scale-down-on-idle"],
    documentationUrl:
      "https://github.com/kubernetes/autoscaler/tree/master/cluster-autoscaler",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-auto-scaling",
    displayName: "AWS Auto Scaling",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["autoscaler"],
    description: "Scales EC2 Auto Scaling groups using target tracking, step, and scheduled policies.",
    capabilities: ["horizontal-scaling", "target-tracking", "scheduled-scaling", "health-replacement"],
    documentationUrl: "https://docs.aws.amazon.com/autoscaling/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-application-auto-scaling",
    displayName: "AWS Application Auto Scaling",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["autoscaler"],
    description:
      "Applies scaling policies to non-EC2 resources such as ECS services, DynamoDB, and Aurora replicas.",
    capabilities: ["horizontal-scaling", "target-tracking", "scheduled-scaling", "multi-service-support"],
    documentationUrl: "https://docs.aws.amazon.com/autoscaling/application/userguide/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-autoscaler",
    displayName: "Google Cloud Autoscaler",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["autoscaler"],
    description: "Scales managed instance groups based on utilization, load balancing, or custom metrics.",
    capabilities: ["horizontal-scaling", "metric-driven-scaling", "load-balancing-signals", "scale-in-controls"],
    documentationUrl: "https://cloud.google.com/compute/docs/autoscaler",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-autoscale",
    displayName: "Azure Autoscale",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["autoscaler"],
    description: "Rule- and schedule-based scaling for Azure virtual machine scale sets and app services.",
    capabilities: ["horizontal-scaling", "metric-driven-scaling", "scheduled-scaling", "scale-rules"],
    documentationUrl: "https://learn.microsoft.com/azure/azure-monitor/autoscale/autoscale-overview",
    modelVersion: MODEL_VERSION
  },
  {
    id: "keda",
    displayName: "KEDA",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["autoscaler"],
    description:
      "Event-driven Kubernetes autoscaler that scales workloads from queue depth and external event sources.",
    capabilities: ["event-driven-scaling", "queue-depth-scaling", "scale-to-zero", "horizontal-scaling"],
    aliases: ["Kubernetes Event-Driven Autoscaling"],
    documentationUrl: "https://keda.sh/docs/latest/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "resilience4j",
    displayName: "Resilience4j",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["circuit-breaker"],
    description:
      "Java fault-tolerance library providing circuit breakers, retries, rate limiters, and bulkheads.",
    capabilities: ["circuit-breaking", "retries", "bulkhead-isolation", "rate-limiting", "fallbacks"],
    simulationPreset: { baseLatencyMs: 1, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://resilience4j.readme.io/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "polly",
    displayName: "Polly",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["circuit-breaker"],
    description:
      ".NET resilience library offering retry, circuit breaker, timeout, and fallback policies.",
    capabilities: ["circuit-breaking", "retries", "timeouts", "fallbacks", "bulkhead-isolation"],
    simulationPreset: { baseLatencyMs: 1, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://www.pollydocs.org/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "istio",
    displayName: "Istio",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["circuit-breaker", "load-balancer"],
    description:
      "Service mesh providing traffic management, outlier detection, mTLS, and telemetry via Envoy sidecars.",
    capabilities: [
      "circuit-breaking",
      "outlier-detection",
      "retries",
      "traffic-shifting",
      "mutual-tls",
      "layer-7-routing"
    ],
    roleCapabilities: {
      "circuit-breaker": ["circuit-breaking", "outlier-detection", "retries", "timeouts"],
      "load-balancer": ["layer-7-routing", "traffic-shifting", "locality-aware-routing"]
    },
    simulationPreset: { baseLatencyMs: 2, perInstanceCapacityRps: 6000 },
    documentationUrl: "https://istio.io/latest/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "linkerd",
    displayName: "Linkerd",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["circuit-breaker", "load-balancer"],
    description:
      "Lightweight service mesh offering automatic mTLS, retries, and latency-aware load balancing.",
    capabilities: ["retries", "timeouts", "mutual-tls", "latency-aware-load-balancing", "circuit-breaking"],
    roleCapabilities: {
      "circuit-breaker": ["retries", "timeouts", "failure-accrual"],
      "load-balancer": ["latency-aware-load-balancing", "layer-7-routing"]
    },
    simulationPreset: { baseLatencyMs: 1, perInstanceCapacityRps: 7000 },
    documentationUrl: "https://linkerd.io/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "hystrix",
    displayName: "Hystrix",
    provider: "Netflix",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["circuit-breaker"],
    description: "Java latency and fault-tolerance library that popularised the circuit breaker pattern.",
    capabilities: ["circuit-breaking", "bulkhead-isolation", "fallbacks", "request-collapsing"],
    status: "deprecated",
    advisories: [
      {
        message:
          "No longer in active development. Netflix recommends Resilience4j or a service mesh for new work."
      }
    ],
    simulationPreset: { baseLatencyMs: 1, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://github.com/Netflix/Hystrix/wiki",
    modelVersion: MODEL_VERSION
  }
];
