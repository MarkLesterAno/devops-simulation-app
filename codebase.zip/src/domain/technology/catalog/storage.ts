import type { TechnologyOptionInput } from "@/domain/technology/schema";

const MODEL_VERSION = "1.0.0";

/**
 * Object, file, and block storage mapped to the `object-storage` component.
 * Block and file storage products carry an advisory because their access
 * semantics differ substantially from HTTP object stores.
 */
const BLOCK_STORAGE = {
  message:
    "Block storage volume attached to a single instance rather than an independently addressable HTTP object store."
};

const FILE_STORAGE = {
  message:
    "Shared file system using POSIX/SMB semantics rather than an HTTP object API."
};

export const storageTechnologies: TechnologyOptionInput[] = [
  {
    id: "amazon-s3",
    displayName: "Amazon S3",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["object-storage"],
    description:
      "Durable object storage with HTTP access, lifecycle policies, and multiple storage classes.",
    capabilities: [
      "object-storage",
      "high-durability",
      "lifecycle-policies",
      "versioning",
      "event-notifications",
      "presigned-urls"
    ],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 3500 },
    documentationUrl: "https://docs.aws.amazon.com/s3/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-ebs",
    displayName: "Amazon EBS",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["object-storage"],
    description: "Network-attached block storage volumes for EC2 instances.",
    capabilities: ["block-storage", "snapshots", "provisioned-iops", "encryption"],
    advisories: [BLOCK_STORAGE],
    simulationPreset: { baseLatencyMs: 3, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://docs.aws.amazon.com/ebs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-efs",
    displayName: "Amazon EFS",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["object-storage"],
    description: "Elastic NFS file system shared across many compute instances.",
    capabilities: ["file-storage", "nfs", "elastic-capacity", "multi-az"],
    advisories: [FILE_STORAGE],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 1500 },
    documentationUrl: "https://docs.aws.amazon.com/efs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-storage",
    displayName: "Google Cloud Storage",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["object-storage"],
    description: "Unified object storage with multi-region, regional, and archival storage classes.",
    capabilities: ["object-storage", "high-durability", "lifecycle-policies", "versioning", "signed-urls"],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 3500 },
    documentationUrl: "https://cloud.google.com/storage/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-persistent-disk",
    displayName: "Google Persistent Disk",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["object-storage"],
    description: "Durable network block storage for Compute Engine and GKE workloads.",
    capabilities: ["block-storage", "snapshots", "encryption", "resizable-volumes"],
    advisories: [BLOCK_STORAGE],
    simulationPreset: { baseLatencyMs: 3, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://cloud.google.com/compute/docs/disks",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-filestore",
    displayName: "Google Filestore",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["object-storage"],
    description: "Managed NFS file storage for applications requiring a shared file system.",
    capabilities: ["file-storage", "nfs", "shared-access", "snapshots"],
    advisories: [FILE_STORAGE],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 1500 },
    documentationUrl: "https://cloud.google.com/filestore/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-blob-storage",
    displayName: "Azure Blob Storage",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["object-storage"],
    description: "Massively scalable object storage for unstructured data with tiered access.",
    capabilities: ["object-storage", "high-durability", "lifecycle-policies", "versioning", "event-notifications"],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 3500 },
    documentationUrl: "https://learn.microsoft.com/azure/storage/blobs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-managed-disks",
    displayName: "Azure Managed Disks",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["object-storage"],
    description: "Managed block storage volumes for Azure virtual machines.",
    capabilities: ["block-storage", "snapshots", "encryption", "provisioned-iops"],
    advisories: [BLOCK_STORAGE],
    simulationPreset: { baseLatencyMs: 3, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://learn.microsoft.com/azure/virtual-machines/managed-disks-overview",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-files",
    displayName: "Azure Files",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["object-storage"],
    description: "Managed SMB and NFS file shares accessible from cloud and on-premises clients.",
    capabilities: ["file-storage", "smb", "nfs", "snapshots"],
    advisories: [FILE_STORAGE],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 1500 },
    documentationUrl: "https://learn.microsoft.com/azure/storage/files/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "cloudflare-r2",
    displayName: "Cloudflare R2",
    provider: "Cloudflare",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["object-storage"],
    description: "S3-compatible object storage with no egress fees, integrated with the Cloudflare edge.",
    capabilities: ["object-storage", "s3-api-compatible", "zero-egress-fees", "edge-integration"],
    simulationPreset: { baseLatencyMs: 30, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://developers.cloudflare.com/r2/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "minio",
    displayName: "MinIO",
    provider: "MinIO",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["object-storage"],
    description: "High-performance S3-compatible object storage for self-hosted deployments.",
    capabilities: ["object-storage", "s3-api-compatible", "erasure-coding", "versioning"],
    simulationPreset: { baseLatencyMs: 20, perInstanceCapacityRps: 2500 },
    documentationUrl: "https://min.io/docs/minio/linux/index.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "ceph",
    displayName: "Ceph",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["object-storage"],
    description:
      "Unified distributed storage platform providing object, block, and file interfaces.",
    capabilities: ["object-storage", "block-storage", "file-storage", "self-healing", "erasure-coding"],
    simulationPreset: { baseLatencyMs: 25, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://docs.ceph.com/en/latest/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "wasabi",
    displayName: "Wasabi",
    provider: "Wasabi Technologies",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["object-storage"],
    description: "S3-compatible cloud object storage with flat pricing and no egress charges.",
    capabilities: ["object-storage", "s3-api-compatible", "immutability", "versioning"],
    simulationPreset: { baseLatencyMs: 40, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://docs.wasabi.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "backblaze-b2",
    displayName: "Backblaze B2",
    provider: "Backblaze",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["object-storage"],
    description: "Low-cost S3-compatible cloud object storage often used for backup and archives.",
    capabilities: ["object-storage", "s3-api-compatible", "lifecycle-rules", "versioning"],
    simulationPreset: { baseLatencyMs: 45, perInstanceCapacityRps: 1500 },
    documentationUrl: "https://www.backblaze.com/docs/cloud-storage",
    modelVersion: MODEL_VERSION
  },
  {
    id: "digitalocean-spaces",
    displayName: "DigitalOcean Spaces",
    provider: "DigitalOcean",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["object-storage"],
    description: "S3-compatible object storage with an integrated CDN.",
    capabilities: ["object-storage", "s3-api-compatible", "integrated-cdn", "signed-urls"],
    simulationPreset: { baseLatencyMs: 40, perInstanceCapacityRps: 1800 },
    documentationUrl: "https://docs.digitalocean.com/products/spaces/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "netapp",
    displayName: "NetApp",
    provider: "NetApp",
    deploymentModel: ["on-premises", "self-managed", "managed-cloud"],
    componentTypes: ["object-storage"],
    description: "Enterprise storage systems providing file, block, and object services.",
    capabilities: ["file-storage", "block-storage", "object-storage", "snapshots", "replication"],
    advisories: [FILE_STORAGE],
    simulationPreset: { baseLatencyMs: 8, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://docs.netapp.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "dell-emc-powerscale",
    displayName: "Dell EMC PowerScale",
    provider: "Dell Technologies",
    deploymentModel: ["on-premises", "self-managed"],
    componentTypes: ["object-storage"],
    description: "Scale-out NAS platform for large unstructured data sets.",
    capabilities: ["file-storage", "scale-out-nas", "snapshots", "replication"],
    advisories: [FILE_STORAGE],
    simulationPreset: { baseLatencyMs: 8, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://www.dell.com/support/product-details/en-us/product/powerscale-onefs/docs",
    modelVersion: MODEL_VERSION
  }
];
