﻿import type { TechnologyOptionInput } from "@/domain/technology/schema";

const MODEL_VERSION = "1.0.0";

/**
 * Load balancers, reverse proxies, and API gateways mapped to the generic
 * `load-balancer` component. API gateways are included because they perform
 * request routing, but they carry an advisory noting the extra policy
 * responsibilities they own beyond plain load distribution.
 */
export const loadBalancingTechnologies: TechnologyOptionInput[] = [
  {
    id: "aws-application-load-balancer",
    displayName: "AWS Application Load Balancer",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["load-balancer"],
    description:
      "Layer-7 load balancer routing HTTP/HTTPS traffic by host, path, and header rules.",
    capabilities: ["layer-7-routing", "health-checks", "tls-termination", "sticky-sessions"],
    aliases: ["ALB"],
    simulationPreset: { baseLatencyMs: 5, perInstanceCapacityRps: 5000 },
    documentationUrl:
      "https://docs.aws.amazon.com/elasticloadbalancing/latest/application/introduction.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-network-load-balancer",
    displayName: "AWS Network Load Balancer",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["load-balancer"],
    description:
      "Layer-4 load balancer for TCP/UDP traffic with very high throughput and static IP support.",
    capabilities: ["layer-4-routing", "health-checks", "static-ip", "high-throughput"],
    aliases: ["NLB"],
    simulationPreset: { baseLatencyMs: 2, perInstanceCapacityRps: 10000 },
    documentationUrl:
      "https://docs.aws.amazon.com/elasticloadbalancing/latest/network/introduction.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-gateway-load-balancer",
    displayName: "AWS Gateway Load Balancer",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["load-balancer"],
    description:
      "Transparently distributes traffic across fleets of third-party virtual network appliances.",
    capabilities: ["layer-3-routing", "appliance-insertion", "health-checks"],
    advisories: [
      {
        message:
          "Designed for inserting inline network appliances (firewalls, IDS/IPS) rather than balancing application traffic.",
        componentTypes: ["load-balancer"]
      }
    ],
    simulationPreset: { baseLatencyMs: 3, perInstanceCapacityRps: 8000 },
    documentationUrl:
      "https://docs.aws.amazon.com/elasticloadbalancing/latest/gateway/introduction.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-classic-load-balancer",
    displayName: "Elastic Load Balancing Classic Load Balancer",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["load-balancer"],
    description:
      "First-generation AWS load balancer offering basic layer-4 and layer-7 distribution.",
    capabilities: ["layer-4-routing", "layer-7-routing", "health-checks"],
    aliases: ["CLB", "ELB Classic"],
    status: "legacy",
    advisories: [
      {
        message:
          "Legacy generation. Prefer Application Load Balancer or Network Load Balancer for new designs."
      }
    ],
    simulationPreset: { baseLatencyMs: 6, perInstanceCapacityRps: 3000 },
    documentationUrl:
      "https://docs.aws.amazon.com/elasticloadbalancing/latest/classic/introduction.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-load-balancing",
    displayName: "Google Cloud Load Balancing",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["load-balancer"],
    description:
      "Global and regional load balancing family covering HTTP(S), TCP/SSL proxy, and internal traffic.",
    capabilities: ["global-http-routing", "layer-4-routing", "health-checks", "tls-termination"],
    simulationPreset: { baseLatencyMs: 5, perInstanceCapacityRps: 6000 },
    documentationUrl: "https://cloud.google.com/load-balancing/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-load-balancer",
    displayName: "Azure Load Balancer",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["load-balancer"],
    description: "Layer-4 load balancer distributing TCP/UDP flows across Azure backend pools.",
    capabilities: ["layer-4-routing", "health-probes", "outbound-nat"],
    simulationPreset: { baseLatencyMs: 3, perInstanceCapacityRps: 8000 },
    documentationUrl: "https://learn.microsoft.com/azure/load-balancer/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-application-gateway",
    displayName: "Azure Application Gateway",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["load-balancer"],
    description:
      "Regional layer-7 load balancer with URL-based routing, TLS offload, and optional WAF.",
    capabilities: ["layer-7-routing", "tls-termination", "waf", "session-affinity"],
    simulationPreset: { baseLatencyMs: 6, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://learn.microsoft.com/azure/application-gateway/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "cloudflare-load-balancing",
    displayName: "Cloudflare Load Balancing",
    provider: "Cloudflare",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["load-balancer"],
    description:
      "DNS and proxy-based global load balancing with health monitoring and geo steering.",
    capabilities: ["global-traffic-steering", "health-checks", "failover", "geo-routing"],
    simulationPreset: { baseLatencyMs: 5, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://developers.cloudflare.com/load-balancing/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "haproxy",
    displayName: "HAProxy",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["load-balancer"],
    description:
      "High-performance TCP and HTTP load balancer widely used as a software reverse proxy.",
    capabilities: ["layer-4-routing", "layer-7-routing", "health-checks", "connection-pooling"],
    simulationPreset: { baseLatencyMs: 2, perInstanceCapacityRps: 8000 },
    documentationUrl: "https://docs.haproxy.org/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "nginx",
    displayName: "NGINX",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["load-balancer", "server", "cache"],
    description:
      "Web server, reverse proxy, load balancer, and content cache used across many architectures.",
    capabilities: [
      "reverse-proxy",
      "layer-7-routing",
      "static-content-serving",
      "response-caching",
      "tls-termination"
    ],
    roleCapabilities: {
      "load-balancer": ["layer-7-routing", "health-checks", "tls-termination", "reverse-proxy"],
      server: ["static-content-serving", "fastcgi", "reverse-proxy"],
      cache: ["response-caching", "proxy-cache", "cache-invalidation"]
    },
    simulationPreset: { baseLatencyMs: 2, perInstanceCapacityRps: 6000 },
    documentationUrl: "https://nginx.org/en/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "nginx-plus",
    displayName: "NGINX Plus",
    provider: "F5",
    deploymentModel: ["self-managed", "on-premises", "managed-cloud"],
    componentTypes: ["load-balancer"],
    description:
      "Commercial NGINX distribution adding active health checks, session persistence, and clustering.",
    capabilities: ["layer-7-routing", "active-health-checks", "session-persistence", "api-management"],
    simulationPreset: { baseLatencyMs: 2, perInstanceCapacityRps: 7000 },
    documentationUrl: "https://docs.nginx.com/nginx/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "envoy-proxy",
    displayName: "Envoy Proxy",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["load-balancer"],
    description:
      "Cloud-native L4/L7 proxy used standalone and as the data plane for service meshes.",
    capabilities: ["layer-7-routing", "circuit-breaking", "observability", "grpc-support", "retries"],
    simulationPreset: { baseLatencyMs: 2, perInstanceCapacityRps: 7000 },
    documentationUrl: "https://www.envoyproxy.io/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "traefik-proxy",
    displayName: "Traefik Proxy",
    provider: "Traefik Labs",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["load-balancer"],
    description:
      "Dynamic reverse proxy and load balancer with native service-discovery integration.",
    capabilities: ["layer-7-routing", "service-discovery", "automatic-tls", "health-checks"],
    simulationPreset: { baseLatencyMs: 3, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://doc.traefik.io/traefik/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "caddy",
    displayName: "Caddy",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["load-balancer", "server"],
    description:
      "HTTP server and reverse proxy with automatic HTTPS certificate management.",
    capabilities: ["reverse-proxy", "automatic-tls", "static-content-serving", "layer-7-routing"],
    roleCapabilities: {
      "load-balancer": ["reverse-proxy", "layer-7-routing", "automatic-tls"],
      server: ["static-content-serving", "automatic-tls"]
    },
    simulationPreset: { baseLatencyMs: 3, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://caddyserver.com/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "f5-big-ip",
    displayName: "F5 BIG-IP",
    provider: "F5",
    deploymentModel: ["on-premises", "self-managed"],
    componentTypes: ["load-balancer"],
    description:
      "Enterprise application delivery controller providing load balancing, TLS offload, and traffic policy.",
    capabilities: ["layer-4-routing", "layer-7-routing", "tls-offload", "traffic-policy", "waf"],
    simulationPreset: { baseLatencyMs: 3, perInstanceCapacityRps: 9000 },
    documentationUrl: "https://my.f5.com/manage/s/tech-documents",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-api-gateway",
    displayName: "Amazon API Gateway",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["api-gateway", "load-balancer"],
    description:
      "Managed API front door handling request routing, authorization, throttling, and transformation.",
    capabilities: ["api-routing", "rate-limiting", "request-authorization", "request-transformation"],
    advisories: [
      {
        message:
          "API gateway: assign this to the API Gateway component to model authorization, throttling, and routing policy. As a plain load balancer those policy behaviours are not simulated.",
        componentTypes: ["load-balancer"]
      }
    ],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://docs.aws.amazon.com/apigateway/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "kong-gateway",
    displayName: "Kong Gateway",
    provider: "Kong",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["api-gateway", "load-balancer"],
    description:
      "Plugin-driven API gateway built on NGINX providing routing, auth, and rate limiting.",
    capabilities: ["api-routing", "rate-limiting", "request-authorization", "plugin-extensibility"],
    advisories: [
      {
        message:
          "API gateway: assign this to the API Gateway component to model authorization, throttling, and routing policy. As a plain load balancer those policy behaviours are not simulated.",
        componentTypes: ["load-balancer"]
      }
    ],
    simulationPreset: { baseLatencyMs: 6, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://docs.konghq.com/gateway/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "apache-apisix",
    displayName: "Apache APISIX",
    provider: "Apache Software Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["api-gateway", "load-balancer"],
    description:
      "Dynamic, high-performance API gateway with hot-reloadable routing and plugin configuration.",
    capabilities: ["api-routing", "rate-limiting", "dynamic-configuration", "plugin-extensibility"],
    advisories: [
      {
        message:
          "API gateway: assign this to the API Gateway component to model authorization, throttling, and routing policy. As a plain load balancer those policy behaviours are not simulated.",
        componentTypes: ["load-balancer"]
      }
    ],
    simulationPreset: { baseLatencyMs: 5, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://apisix.apache.org/docs/apisix/getting-started/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "tyk",
    displayName: "Tyk",
    provider: "Tyk Technologies",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["api-gateway", "load-balancer"],
    description: "API gateway and management platform with quota, policy, and analytics features.",
    capabilities: ["api-routing", "rate-limiting", "quota-management", "api-analytics"],
    advisories: [
      {
        message:
          "API gateway: assign this to the API Gateway component to model authorization, throttling, and routing policy. As a plain load balancer those policy behaviours are not simulated.",
        componentTypes: ["load-balancer"]
      }
    ],
    simulationPreset: { baseLatencyMs: 7, perInstanceCapacityRps: 3500 },
    documentationUrl: "https://tyk.io/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-api-management",
    displayName: "Azure API Management",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["api-gateway", "load-balancer"],
    description:
      "Managed API gateway and developer portal providing policy enforcement and versioning.",
    capabilities: ["api-routing", "rate-limiting", "policy-enforcement", "developer-portal"],
    advisories: [
      {
        message:
          "API gateway: assign this to the API Gateway component to model authorization, throttling, and routing policy. As a plain load balancer those policy behaviours are not simulated.",
        componentTypes: ["load-balancer"]
      }
    ],
    simulationPreset: { baseLatencyMs: 14, perInstanceCapacityRps: 2500 },
    documentationUrl: "https://learn.microsoft.com/azure/api-management/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-api-gateway",
    displayName: "Google Cloud API Gateway",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["api-gateway", "load-balancer"],
    description:
      "Managed gateway fronting serverless and backend services with OpenAPI-based configuration.",
    capabilities: ["api-routing", "request-authorization", "openapi-configuration"],
    advisories: [
      {
        message:
          "API gateway: assign this to the API Gateway component to model authorization, throttling, and routing policy. As a plain load balancer those policy behaviours are not simulated.",
        componentTypes: ["load-balancer"]
      }
    ],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 2500 },
    documentationUrl: "https://cloud.google.com/api-gateway/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "apigee",
    displayName: "Apigee",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["api-gateway", "load-balancer"],
    description:
      "Enterprise API management platform covering gateway policy, monetization, and analytics.",
    capabilities: ["api-routing", "policy-enforcement", "api-analytics", "monetization"],
    advisories: [
      {
        message:
          "API gateway: assign this to the API Gateway component to model authorization, throttling, and routing policy. As a plain load balancer those policy behaviours are not simulated.",
        componentTypes: ["load-balancer"]
      }
    ],
    simulationPreset: { baseLatencyMs: 15, perInstanceCapacityRps: 2500 },
    documentationUrl: "https://cloud.google.com/apigee/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "cloudflare-api-gateway",
    displayName: "Cloudflare API Gateway",
    provider: "Cloudflare",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["api-gateway", "load-balancer"],
    description:
      "Edge-delivered API protection and routing with schema validation and abuse detection.",
    capabilities: ["api-routing", "schema-validation", "rate-limiting", "api-discovery"],
    advisories: [
      {
        message:
          "API gateway: assign this to the API Gateway component to model authorization, throttling, and routing policy. As a plain load balancer those policy behaviours are not simulated.",
        componentTypes: ["load-balancer"]
      }
    ],
    simulationPreset: { baseLatencyMs: 6, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://developers.cloudflare.com/api-shield/",
    modelVersion: MODEL_VERSION
  }
];
