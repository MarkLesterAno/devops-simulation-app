import type { TechnologyOptionInput } from "@/domain/technology/schema";

const MODEL_VERSION = "1.0.0";

/**
 * Metrics, logging, tracing, and alerting products mapped to the `observability`
 * component. Alerting/on-call tools are included but flagged, since they consume
 * signals rather than collect telemetry themselves.
 */
const ALERTING_ONLY = {
  message:
    "Incident response and on-call routing tool. It consumes alerts from a monitoring system rather than collecting telemetry itself."
};

export const observabilityTechnologies: TechnologyOptionInput[] = [
  {
    id: "prometheus",
    displayName: "Prometheus",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["observability"],
    description:
      "Pull-based metrics collection and time-series database with the PromQL query language.",
    capabilities: ["metrics-collection", "time-series-storage", "promql", "alerting-rules", "service-discovery"],
    simulationPreset: { baseLatencyMs: 5, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://prometheus.io/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "grafana",
    displayName: "Grafana",
    provider: "Grafana Labs",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["observability"],
    description: "Visualization and dashboarding layer querying many metrics and log backends.",
    capabilities: ["dashboards", "visualization", "multi-datasource-queries", "alerting"],
    advisories: [
      {
        message:
          "Visualization layer. It queries other backends and does not store telemetry itself."
      }
    ],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 500 },
    documentationUrl: "https://grafana.com/docs/grafana/latest/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "grafana-loki",
    displayName: "Grafana Loki",
    provider: "Grafana Labs",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["observability"],
    description: "Log aggregation system indexing labels rather than full log content.",
    capabilities: ["log-aggregation", "label-indexing", "logql", "object-storage-backend"],
    simulationPreset: { baseLatencyMs: 8, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://grafana.com/docs/loki/latest/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "grafana-tempo",
    displayName: "Grafana Tempo",
    provider: "Grafana Labs",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["observability"],
    description: "High-scale distributed tracing backend storing traces in object storage.",
    capabilities: ["distributed-tracing", "trace-storage", "otlp-ingestion", "trace-search"],
    simulationPreset: { baseLatencyMs: 8, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://grafana.com/docs/tempo/latest/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "opentelemetry",
    displayName: "OpenTelemetry",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["observability"],
    description:
      "Vendor-neutral instrumentation standard and collector for metrics, logs, and traces.",
    capabilities: ["instrumentation-sdks", "otlp-protocol", "collector-pipelines", "vendor-neutral-export"],
    aliases: ["OTel"],
    advisories: [
      {
        message:
          "Instrumentation and collection standard rather than a storage or query backend; it exports to one."
      }
    ],
    simulationPreset: { baseLatencyMs: 3, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://opentelemetry.io/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "jaeger",
    displayName: "Jaeger",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["observability"],
    description: "Distributed tracing system for latency analysis and dependency mapping.",
    capabilities: ["distributed-tracing", "trace-search", "dependency-graphs", "otlp-ingestion"],
    simulationPreset: { baseLatencyMs: 6, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://www.jaegertracing.io/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "zipkin",
    displayName: "Zipkin",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["observability"],
    description: "Lightweight distributed tracing system for collecting and querying span data.",
    capabilities: ["distributed-tracing", "trace-search", "span-collection"],
    simulationPreset: { baseLatencyMs: 6, perInstanceCapacityRps: 2500 },
    documentationUrl: "https://zipkin.io/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "elastic-stack",
    displayName: "Elastic Stack",
    provider: "Elastic",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["observability"],
    description:
      "Elasticsearch, Kibana, and Beats/Logstash used together for log search and analytics.",
    capabilities: ["log-aggregation", "full-text-search", "dashboards", "alerting"],
    aliases: ["ELK Stack"],
    simulationPreset: { baseLatencyMs: 15, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://www.elastic.co/guide/index.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "elastic-observability",
    displayName: "Elastic Observability",
    provider: "Elastic",
    deploymentModel: ["managed-cloud", "self-managed", "saas"],
    componentTypes: ["observability"],
    description: "Elastic's unified APM, logs, metrics, and uptime monitoring solution.",
    capabilities: ["apm", "log-aggregation", "metrics-collection", "distributed-tracing", "alerting"],
    simulationPreset: { baseLatencyMs: 15, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://www.elastic.co/guide/en/observability/current/index.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "splunk",
    displayName: "Splunk",
    provider: "Cisco",
    deploymentModel: ["self-managed", "on-premises", "saas"],
    componentTypes: ["observability"],
    description: "Enterprise machine-data platform for log search, security, and operational analytics.",
    capabilities: ["log-aggregation", "search-processing-language", "dashboards", "alerting", "siem"],
    simulationPreset: { baseLatencyMs: 20, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://docs.splunk.com/Documentation",
    modelVersion: MODEL_VERSION
  },
  {
    id: "datadog",
    displayName: "Datadog",
    provider: "Datadog",
    deploymentModel: ["saas", "managed-cloud"],
    componentTypes: ["observability"],
    description: "SaaS observability platform unifying metrics, traces, logs, and synthetics.",
    capabilities: ["metrics-collection", "apm", "log-aggregation", "distributed-tracing", "alerting", "dashboards"],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://docs.datadoghq.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "new-relic",
    displayName: "New Relic",
    provider: "New Relic",
    deploymentModel: ["saas", "managed-cloud"],
    componentTypes: ["observability"],
    description: "Full-stack observability platform with APM, infrastructure, and log monitoring.",
    capabilities: ["apm", "metrics-collection", "log-aggregation", "distributed-tracing", "alerting"],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://docs.newrelic.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "dynatrace",
    displayName: "Dynatrace",
    provider: "Dynatrace",
    deploymentModel: ["saas", "managed-cloud", "on-premises"],
    componentTypes: ["observability"],
    description: "Observability platform with automatic dependency discovery and AI root-cause analysis.",
    capabilities: ["apm", "automatic-instrumentation", "root-cause-analysis", "distributed-tracing", "alerting"],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://docs.dynatrace.com/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "sentry",
    displayName: "Sentry",
    provider: "Sentry",
    deploymentModel: ["open-source", "self-managed", "saas"],
    componentTypes: ["observability"],
    description: "Application error monitoring with stack traces, release tracking, and performance data.",
    capabilities: ["error-tracking", "release-tracking", "performance-monitoring", "alerting"],
    advisories: [
      {
        message:
          "Focused on application errors and performance; it is not a general-purpose infrastructure metrics store."
      }
    ],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://docs.sentry.io/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "honeycomb",
    displayName: "Honeycomb",
    provider: "Honeycomb",
    deploymentModel: ["saas"],
    componentTypes: ["observability"],
    description: "Event-based observability tool for high-cardinality querying and trace exploration.",
    capabilities: ["distributed-tracing", "high-cardinality-analysis", "event-storage", "alerting"],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 3500 },
    documentationUrl: "https://docs.honeycomb.io/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-cloudwatch",
    displayName: "AWS CloudWatch",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["observability"],
    description: "Native AWS metrics, logs, dashboards, and alarms for cloud resources.",
    capabilities: ["metrics-collection", "log-aggregation", "alarms", "dashboards"],
    simulationPreset: { baseLatencyMs: 15, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://docs.aws.amazon.com/cloudwatch/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-x-ray",
    displayName: "AWS X-Ray",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["observability"],
    description: "Distributed tracing service for analysing request paths across AWS services.",
    capabilities: ["distributed-tracing", "service-maps", "latency-analysis", "sampling"],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 2500 },
    documentationUrl: "https://docs.aws.amazon.com/xray/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-operations-suite",
    displayName: "Google Cloud Operations Suite",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["observability"],
    description: "Google Cloud monitoring, logging, trace, and profiler services.",
    capabilities: ["metrics-collection", "log-aggregation", "distributed-tracing", "profiling", "alerting"],
    aliases: ["Stackdriver"],
    simulationPreset: { baseLatencyMs: 15, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://cloud.google.com/products/operations",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-monitor",
    displayName: "Azure Monitor",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["observability"],
    description: "Azure-native metrics, logs, and Application Insights APM telemetry.",
    capabilities: ["metrics-collection", "log-aggregation", "apm", "alerting", "dashboards"],
    aliases: ["Application Insights"],
    simulationPreset: { baseLatencyMs: 15, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://learn.microsoft.com/azure/azure-monitor/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "better-stack",
    displayName: "Better Stack",
    provider: "Better Stack",
    deploymentModel: ["saas"],
    componentTypes: ["observability"],
    description: "Combined log management, uptime monitoring, and incident management platform.",
    capabilities: ["log-aggregation", "uptime-monitoring", "incident-management", "alerting"],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://betterstack.com/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "pagerduty",
    displayName: "PagerDuty",
    provider: "PagerDuty",
    deploymentModel: ["saas"],
    componentTypes: ["observability"],
    description: "Incident response platform handling on-call scheduling, escalation, and paging.",
    capabilities: ["incident-management", "on-call-scheduling", "escalation-policies", "alert-routing"],
    advisories: [ALERTING_ONLY],
    simulationPreset: { baseLatencyMs: 20, perInstanceCapacityRps: 500 },
    documentationUrl: "https://support.pagerduty.com/main/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "opsgenie",
    displayName: "Opsgenie",
    provider: "Atlassian",
    deploymentModel: ["saas"],
    componentTypes: ["observability"],
    description: "Alert and on-call management with routing rules and escalation chains.",
    capabilities: ["incident-management", "on-call-scheduling", "alert-routing", "escalation-policies"],
    advisories: [ALERTING_ONLY],
    simulationPreset: { baseLatencyMs: 20, perInstanceCapacityRps: 500 },
    documentationUrl: "https://support.atlassian.com/opsgenie/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "splunk-on-call",
    displayName: "Splunk On-Call",
    provider: "Cisco",
    deploymentModel: ["saas"],
    componentTypes: ["observability"],
    description: "On-call scheduling and incident routing platform, formerly VictorOps.",
    capabilities: ["incident-management", "on-call-scheduling", "alert-routing"],
    aliases: ["VictorOps"],
    advisories: [ALERTING_ONLY],
    simulationPreset: { baseLatencyMs: 20, perInstanceCapacityRps: 500 },
    documentationUrl: "https://docs.splunk.com/Observability/en/incident-intelligence/incident-intelligence.html",
    modelVersion: MODEL_VERSION
  }
];
