﻿import type { TechnologyOptionInput } from "@/domain/technology/schema";

const MODEL_VERSION = "1.0.0";

/**
 * Brokers, queues, and event streaming platforms mapped to `message-queue` and
 * `dead-letter-queue`. Workflow orchestrators are included but explicitly
 * marked, because they schedule tasks rather than act as message transports.
 */
const WORKFLOW_ORCHESTRATION = {
  message:
    "Workflow orchestration engine rather than a message broker. It schedules and tracks task execution instead of providing durable message transport."
};

export const messagingTechnologies: TechnologyOptionInput[] = [
  {
    id: "apache-kafka",
    displayName: "Apache Kafka",
    provider: "Apache Software Foundation",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["message-queue", "event-topic"],
    description:
      "Distributed append-only event streaming log with partitioned topics and consumer groups.",
    capabilities: [
      "event-streaming",
      "partitioned-topics",
      "consumer-groups",
      "log-retention",
      "replay",
      "exactly-once-semantics"
    ],
    simulationPreset: { baseLatencyMs: 8, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://kafka.apache.org/documentation/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "confluent-cloud",
    displayName: "Confluent Cloud",
    provider: "Confluent",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["message-queue", "event-topic"],
    description: "Fully managed Kafka with schema registry, connectors, and stream processing.",
    capabilities: ["event-streaming", "schema-registry", "managed-connectors", "consumer-groups", "replay"],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://docs.confluent.io/cloud/current/overview.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "redpanda",
    displayName: "Redpanda",
    provider: "Redpanda Data",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["message-queue", "event-topic"],
    description: "Kafka-API-compatible streaming platform written in C++ with no ZooKeeper dependency.",
    capabilities: ["event-streaming", "kafka-api-compatible", "partitioned-topics", "low-latency", "replay"],
    simulationPreset: { baseLatencyMs: 5, perInstanceCapacityRps: 6000 },
    documentationUrl: "https://docs.redpanda.com/current/home/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "apache-pulsar",
    displayName: "Apache Pulsar",
    provider: "Apache Software Foundation",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["message-queue", "event-topic", "dead-letter-queue"],
    description:
      "Multi-tenant messaging and streaming platform with tiered storage and native geo-replication.",
    capabilities: [
      "event-streaming",
      "pub-sub",
      "queueing",
      "geo-replication",
      "tiered-storage",
      "dead-letter-topics"
    ],
    roleCapabilities: {
      "dead-letter-queue": ["dead-letter-topics", "retry-topics", "message-redelivery"]
    },
    simulationPreset: { baseLatencyMs: 8, perInstanceCapacityRps: 4500 },
    documentationUrl: "https://pulsar.apache.org/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "rabbitmq",
    displayName: "RabbitMQ",
    provider: "Broadcom",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["message-queue", "event-topic", "dead-letter-queue"],
    description:
      "Mature AMQP message broker with flexible exchange routing and per-queue delivery semantics.",
    capabilities: [
      "amqp",
      "flexible-routing",
      "message-acknowledgement",
      "dead-letter-exchanges",
      "priority-queues"
    ],
    roleCapabilities: {
      "dead-letter-queue": ["dead-letter-exchanges", "message-ttl", "rejected-message-capture"]
    },
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 2500 },
    documentationUrl: "https://www.rabbitmq.com/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "activemq-artemis",
    displayName: "ActiveMQ Artemis",
    provider: "Apache Software Foundation",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["message-queue", "dead-letter-queue"],
    description: "High-performance JMS-compatible broker supporting AMQP, MQTT, and STOMP.",
    capabilities: ["jms", "amqp", "queueing", "pub-sub", "dead-letter-addresses"],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 2500 },
    documentationUrl: "https://activemq.apache.org/components/artemis/documentation/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "nats",
    displayName: "NATS",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["message-queue", "event-topic"],
    description: "Lightweight high-throughput messaging system for pub/sub and request-reply.",
    capabilities: ["pub-sub", "request-reply", "low-latency", "clustering"],
    advisories: [
      {
        message:
          "Core NATS is fire-and-forget with no persistence; use NATS JetStream when durability is required."
      }
    ],
    simulationPreset: { baseLatencyMs: 2, perInstanceCapacityRps: 9000 },
    documentationUrl: "https://docs.nats.io/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "nats-jetstream",
    displayName: "NATS JetStream",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["message-queue", "event-topic", "dead-letter-queue"],
    description: "Persistence and streaming layer for NATS adding durable consumers and replay.",
    capabilities: ["event-streaming", "durable-consumers", "replay", "message-acknowledgement", "retention-policies"],
    simulationPreset: { baseLatencyMs: 4, perInstanceCapacityRps: 6000 },
    documentationUrl: "https://docs.nats.io/nats-concepts/jetstream",
    modelVersion: MODEL_VERSION
  },
  {
    id: "redis-streams",
    displayName: "Redis Streams",
    provider: "Redis",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["message-queue", "event-topic"],
    description: "Append-only log data type in Redis supporting consumer groups and acknowledgements.",
    capabilities: ["event-streaming", "consumer-groups", "message-acknowledgement", "low-latency"],
    advisories: [
      {
        message:
          "Retention and durability guarantees are weaker than a dedicated broker and bounded by available memory."
      }
    ],
    simulationPreset: { baseLatencyMs: 2, perInstanceCapacityRps: 7000 },
    documentationUrl: "https://redis.io/docs/latest/develop/data-types/streams/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-sqs",
    displayName: "Amazon SQS",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["message-queue", "dead-letter-queue"],
    description:
      "Fully managed queue service offering standard and FIFO queues with visibility timeouts.",
    capabilities: [
      "queueing",
      "at-least-once-delivery",
      "fifo-queues",
      "dead-letter-queues",
      "visibility-timeout"
    ],
    roleCapabilities: {
      "dead-letter-queue": ["dead-letter-queues", "redrive-policy", "max-receive-count"]
    },
    simulationPreset: { baseLatencyMs: 20, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://docs.aws.amazon.com/sqs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-sns",
    displayName: "Amazon SNS",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["message-queue", "event-topic"],
    description: "Managed pub/sub notification service fanning messages out to multiple subscribers.",
    capabilities: ["pub-sub", "fan-out", "message-filtering", "multi-protocol-delivery"],
    advisories: [
      {
        message:
          "Push-based fan-out topic without consumer-managed queues; commonly paired with SQS for durable buffering."
      }
    ],
    simulationPreset: { baseLatencyMs: 18, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://docs.aws.amazon.com/sns/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-eventbridge",
    displayName: "Amazon EventBridge",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["message-queue", "event-topic"],
    description: "Serverless event bus routing events between AWS services, SaaS apps, and custom apps.",
    capabilities: ["event-routing", "content-based-filtering", "schema-registry", "event-replay"],
    simulationPreset: { baseLatencyMs: 25, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://docs.aws.amazon.com/eventbridge/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-msk",
    displayName: "Amazon MSK",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["message-queue", "event-topic"],
    description: "Managed Apache Kafka service handling broker provisioning, patching, and scaling.",
    capabilities: ["event-streaming", "kafka-api-compatible", "partitioned-topics", "consumer-groups", "replay"],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://docs.aws.amazon.com/msk/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-pubsub",
    displayName: "Google Pub/Sub",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["message-queue", "event-topic", "dead-letter-queue"],
    description: "Globally distributed managed messaging with push and pull subscriptions.",
    capabilities: ["pub-sub", "at-least-once-delivery", "dead-letter-topics", "message-ordering", "global-routing"],
    simulationPreset: { baseLatencyMs: 20, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://cloud.google.com/pubsub/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-service-bus",
    displayName: "Azure Service Bus",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["message-queue", "event-topic", "dead-letter-queue"],
    description:
      "Enterprise message broker with queues, topics, sessions, and transactional messaging.",
    capabilities: ["queueing", "pub-sub", "sessions", "dead-letter-queues", "transactions"],
    roleCapabilities: {
      "dead-letter-queue": ["dead-letter-queues", "max-delivery-count", "message-deferral"]
    },
    simulationPreset: { baseLatencyMs: 22, perInstanceCapacityRps: 2500 },
    documentationUrl: "https://learn.microsoft.com/azure/service-bus-messaging/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-event-hubs",
    displayName: "Azure Event Hubs",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["message-queue", "event-topic"],
    description: "Big-data event ingestion service with a partitioned Kafka-compatible endpoint.",
    capabilities: ["event-streaming", "partitioned-topics", "kafka-api-compatible", "capture-to-storage", "replay"],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://learn.microsoft.com/azure/event-hubs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-event-grid",
    displayName: "Azure Event Grid",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["message-queue", "event-topic", "dead-letter-queue"],
    description: "Event routing service delivering discrete events to subscribers with retry policies.",
    capabilities: ["event-routing", "content-based-filtering", "retry-policies", "dead-lettering"],
    simulationPreset: { baseLatencyMs: 25, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://learn.microsoft.com/azure/event-grid/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "ibm-mq",
    displayName: "IBM MQ",
    provider: "IBM",
    deploymentModel: ["self-managed", "on-premises", "managed-cloud"],
    componentTypes: ["message-queue", "dead-letter-queue"],
    description: "Enterprise transactional message queueing widely used in financial systems.",
    capabilities: ["queueing", "transactions", "assured-delivery", "dead-letter-queues"],
    simulationPreset: { baseLatencyMs: 15, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://www.ibm.com/docs/en/ibm-mq",
    modelVersion: MODEL_VERSION
  },
  {
    id: "solace-pubsub-plus",
    displayName: "Solace PubSub+",
    provider: "Solace",
    deploymentModel: ["self-managed", "on-premises", "managed-cloud"],
    componentTypes: ["message-queue", "event-topic"],
    description: "Event broker supporting multiple protocols and dynamic event mesh topologies.",
    capabilities: ["pub-sub", "queueing", "event-mesh", "multi-protocol-delivery", "guaranteed-delivery"],
    simulationPreset: { baseLatencyMs: 8, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://docs.solace.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "celery",
    displayName: "Celery",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["worker", "message-queue"],
    description:
      "Python distributed task queue that executes background jobs using a broker such as Redis or RabbitMQ.",
    capabilities: ["background-jobs", "task-scheduling", "retries", "worker-pools"],
    roleCapabilities: {
      worker: ["background-jobs", "worker-pools", "retries", "task-routing"],
      "message-queue": ["task-queueing", "broker-backed-transport"]
    },
    advisories: [
      {
        message:
          "Task execution framework that requires a separate broker; it is not itself a durable message transport.",
        componentTypes: ["message-queue"]
      }
    ],
    simulationPreset: { baseLatencyMs: 60, perInstanceCapacityRps: 120 },
    documentationUrl: "https://docs.celeryq.dev/en/stable/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "sidekiq",
    displayName: "Sidekiq",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["worker"],
    description: "Redis-backed Ruby background job processor using threaded workers.",
    capabilities: ["background-jobs", "retries", "scheduled-jobs", "worker-pools"],
    simulationPreset: { baseLatencyMs: 50, perInstanceCapacityRps: 150 },
    documentationUrl: "https://github.com/sidekiq/sidekiq/wiki",
    modelVersion: MODEL_VERSION
  },
  {
    id: "bullmq",
    displayName: "BullMQ",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["worker"],
    description: "Redis-backed Node.js queue library for background jobs and flows.",
    capabilities: ["background-jobs", "retries", "rate-limiting", "job-flows"],
    simulationPreset: { baseLatencyMs: 45, perInstanceCapacityRps: 160 },
    documentationUrl: "https://docs.bullmq.io/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "temporal",
    displayName: "Temporal",
    provider: "Temporal Technologies",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["worker"],
    description:
      "Durable execution platform running long-lived workflows with automatic state persistence and retries.",
    capabilities: ["durable-execution", "workflow-state-persistence", "retries", "long-running-processes"],
    advisories: [WORKFLOW_ORCHESTRATION],
    simulationPreset: { baseLatencyMs: 70, perInstanceCapacityRps: 120 },
    documentationUrl: "https://docs.temporal.io/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "apache-airflow",
    displayName: "Apache Airflow",
    provider: "Apache Software Foundation",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["worker"],
    description: "DAG-based workflow scheduler for batch data and operational pipelines.",
    capabilities: ["dag-scheduling", "batch-pipelines", "retries", "backfills"],
    advisories: [WORKFLOW_ORCHESTRATION],
    simulationPreset: { baseLatencyMs: 200, perInstanceCapacityRps: 30 },
    documentationUrl: "https://airflow.apache.org/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "prefect",
    displayName: "Prefect",
    provider: "Prefect",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["worker"],
    description: "Python-native workflow orchestration with dynamic, code-defined flows.",
    capabilities: ["workflow-orchestration", "dynamic-flows", "retries", "observability"],
    advisories: [WORKFLOW_ORCHESTRATION],
    simulationPreset: { baseLatencyMs: 180, perInstanceCapacityRps: 40 },
    documentationUrl: "https://docs.prefect.io/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "dagster",
    displayName: "Dagster",
    provider: "Dagster Labs",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["worker"],
    description: "Asset-oriented data orchestrator emphasising typed data dependencies and lineage.",
    capabilities: ["data-orchestration", "asset-lineage", "scheduling", "retries"],
    advisories: [
      {
        message:
          "Data orchestration platform rather than a message broker. It models data assets and pipelines, not durable message transport."
      }
    ],
    simulationPreset: { baseLatencyMs: 180, perInstanceCapacityRps: 40 },
    documentationUrl: "https://docs.dagster.io/",
    modelVersion: MODEL_VERSION
  }
];
