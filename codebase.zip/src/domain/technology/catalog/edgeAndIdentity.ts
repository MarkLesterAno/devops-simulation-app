import type { TechnologyOptionInput } from "@/domain/technology/schema";

const MODEL_VERSION = "1.0.0";

/**
 * DNS / global traffic management, identity, and third-party dependency products.
 *
 * These map to the `dns-traffic-manager`, `identity-auth-service`, and
 * `external-service` components added in the Priority 1 catalog expansion. The
 * entries are metadata plus teaching presets only: the simulator never contacts
 * any of these providers.
 */
export const edgeAndIdentityTechnologies: TechnologyOptionInput[] = [
  {
    id: "amazon-route-53",
    displayName: "Amazon Route 53",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["dns-traffic-manager"],
    description:
      "Authoritative DNS with health checks plus weighted, latency, geolocation, and failover routing policies.",
    capabilities: ["authoritative-dns", "health-checks", "weighted-routing", "latency-routing", "failover-routing"],
    simulationPreset: { baseLatencyMs: 20, perInstanceCapacityRps: 100_000 },
    documentationUrl: "https://docs.aws.amazon.com/route53/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "cloudflare-dns",
    displayName: "Cloudflare DNS",
    provider: "Cloudflare",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["dns-traffic-manager"],
    description: "Anycast authoritative DNS with fast propagation and integrated load balancing.",
    capabilities: ["authoritative-dns", "anycast", "health-checks", "geo-steering"],
    simulationPreset: { baseLatencyMs: 14, perInstanceCapacityRps: 100_000 },
    documentationUrl: "https://developers.cloudflare.com/dns/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-traffic-manager",
    displayName: "Azure Traffic Manager",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["dns-traffic-manager"],
    description: "DNS-based global traffic distribution with priority, weighted, and performance routing.",
    capabilities: ["dns-traffic-routing", "endpoint-monitoring", "priority-routing", "performance-routing"],
    simulationPreset: { baseLatencyMs: 22, perInstanceCapacityRps: 80_000 },
    documentationUrl: "https://learn.microsoft.com/azure/traffic-manager/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-dns",
    displayName: "Google Cloud DNS",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["dns-traffic-manager"],
    description: "Managed authoritative DNS with geolocation and weighted round-robin routing policies.",
    capabilities: ["authoritative-dns", "geolocation-routing", "weighted-round-robin", "dnssec"],
    simulationPreset: { baseLatencyMs: 18, perInstanceCapacityRps: 80_000 },
    documentationUrl: "https://cloud.google.com/dns/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "ns1-managed-dns",
    displayName: "NS1 Managed DNS",
    provider: "IBM NS1",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["dns-traffic-manager"],
    description: "Data-driven DNS steering using real-time telemetry to shape global traffic distribution.",
    capabilities: ["authoritative-dns", "traffic-steering", "real-time-telemetry", "failover-routing"],
    simulationPreset: { baseLatencyMs: 20, perInstanceCapacityRps: 60_000 },
    documentationUrl: "https://ns1.com/resources",
    modelVersion: MODEL_VERSION
  },
  {
    id: "coredns",
    displayName: "CoreDNS",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["dns-traffic-manager"],
    description: "Plugin-driven DNS server commonly used for in-cluster service discovery in Kubernetes.",
    capabilities: ["service-discovery", "plugin-extensibility", "dns-caching"],
    advisories: [
      {
        message:
          "Primarily an internal service-discovery resolver. Modelling it as an internet-facing traffic manager overstates its role."
      }
    ],
    simulationPreset: { baseLatencyMs: 3, perInstanceCapacityRps: 20_000 },
    documentationUrl: "https://coredns.io/manual/toc/",
    modelVersion: MODEL_VERSION
  },

  {
    id: "keycloak",
    displayName: "Keycloak",
    provider: "Red Hat",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["identity-auth-service"],
    description:
      "Open-source identity and access management server supporting OIDC, OAuth 2.0, and SAML.",
    capabilities: ["oidc", "oauth2", "saml", "user-federation", "role-based-access-control"],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 500 },
    documentationUrl: "https://www.keycloak.org/documentation",
    modelVersion: MODEL_VERSION
  },
  {
    id: "auth0",
    displayName: "Auth0",
    provider: "Okta",
    deploymentModel: ["saas", "managed-cloud"],
    componentTypes: ["identity-auth-service"],
    description: "Hosted identity platform providing authentication, social login, and token issuance.",
    capabilities: ["oidc", "oauth2", "social-login", "mfa", "token-issuance"],
    simulationPreset: { baseLatencyMs: 45, perInstanceCapacityRps: 1000 },
    documentationUrl: "https://auth0.com/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "okta-workforce-identity",
    displayName: "Okta Workforce Identity",
    provider: "Okta",
    deploymentModel: ["saas"],
    componentTypes: ["identity-auth-service"],
    description: "Enterprise identity provider with single sign-on, MFA, and lifecycle management.",
    capabilities: ["single-sign-on", "mfa", "saml", "oidc", "directory-integration"],
    simulationPreset: { baseLatencyMs: 50, perInstanceCapacityRps: 800 },
    documentationUrl: "https://developer.okta.com/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-cognito",
    displayName: "Amazon Cognito",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["identity-auth-service"],
    description: "Managed user directory and token service for web and mobile applications.",
    capabilities: ["user-pools", "oidc", "oauth2", "mfa", "token-issuance"],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 1200 },
    documentationUrl: "https://docs.aws.amazon.com/cognito/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "microsoft-entra-id",
    displayName: "Microsoft Entra ID",
    provider: "Microsoft Azure",
    deploymentModel: ["saas", "managed-cloud"],
    componentTypes: ["identity-auth-service"],
    description: "Cloud identity provider issuing OAuth 2.0 and OIDC tokens with conditional access policies.",
    capabilities: ["oidc", "oauth2", "conditional-access", "mfa", "directory-services"],
    aliases: ["Azure Active Directory", "Azure AD"],
    simulationPreset: { baseLatencyMs: 40, perInstanceCapacityRps: 1500 },
    documentationUrl: "https://learn.microsoft.com/entra/identity/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "open-policy-agent",
    displayName: "Open Policy Agent",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["identity-auth-service"],
    description: "General-purpose policy engine evaluating authorization decisions from declarative Rego policies.",
    capabilities: ["policy-decision-point", "attribute-based-access-control", "sidecar-deployment"],
    advisories: [
      {
        message:
          "Authorization only. It evaluates policy decisions and does not authenticate users or issue tokens, so set the node mode to authorization."
      }
    ],
    simulationPreset: { baseLatencyMs: 2, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://www.openpolicyagent.org/docs/",
    modelVersion: MODEL_VERSION
  },

  {
    id: "stripe-payments",
    displayName: "Stripe Payments",
    provider: "Stripe",
    deploymentModel: ["saas"],
    componentTypes: ["external-service"],
    description: "Third-party payment processing API with idempotency keys and webhook callbacks.",
    capabilities: ["payment-processing", "idempotency-keys", "webhook-callbacks", "provider-rate-limits"],
    simulationPreset: { baseLatencyMs: 250, perInstanceCapacityRps: 100 },
    documentationUrl: "https://docs.stripe.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "twilio-messaging",
    displayName: "Twilio Messaging",
    provider: "Twilio",
    deploymentModel: ["saas"],
    componentTypes: ["external-service"],
    description: "Third-party SMS and voice delivery API with per-account throughput limits.",
    capabilities: ["sms-delivery", "voice-delivery", "delivery-webhooks", "provider-rate-limits"],
    simulationPreset: { baseLatencyMs: 300, perInstanceCapacityRps: 50 },
    documentationUrl: "https://www.twilio.com/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "sendgrid-email",
    displayName: "Twilio SendGrid",
    provider: "Twilio SendGrid",
    deploymentModel: ["saas"],
    componentTypes: ["external-service"],
    description: "Third-party transactional email delivery API with asynchronous delivery events.",
    capabilities: ["email-delivery", "delivery-webhooks", "provider-rate-limits"],
    simulationPreset: { baseLatencyMs: 220, perInstanceCapacityRps: 80 },
    documentationUrl: "https://www.twilio.com/docs/sendgrid",
    modelVersion: MODEL_VERSION
  },
  {
    id: "firebase-cloud-messaging",
    displayName: "Firebase Cloud Messaging",
    provider: "Google Cloud",
    deploymentModel: ["saas", "managed-cloud"],
    componentTypes: ["external-service"],
    description: "Third-party push-notification delivery service for mobile and web clients.",
    capabilities: ["push-notifications", "topic-fan-out", "delivery-receipts"],
    simulationPreset: { baseLatencyMs: 180, perInstanceCapacityRps: 200 },
    documentationUrl: "https://firebase.google.com/docs/cloud-messaging",
    modelVersion: MODEL_VERSION
  },
  {
    id: "generic-third-party-api",
    displayName: "Generic Third-Party API",
    provider: "Unspecified",
    deploymentModel: ["saas"],
    componentTypes: ["external-service"],
    description:
      "Provider-neutral placeholder for any dependency you do not operate: fixed capacity, published latency, and no autoscaling.",
    capabilities: ["provider-rate-limits", "no-autoscaling", "third-party-sla"],
    simulationPreset: { baseLatencyMs: 250, perInstanceCapacityRps: 100 },
    modelVersion: MODEL_VERSION
  }
];
