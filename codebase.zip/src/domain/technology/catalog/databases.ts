﻿import type { TechnologyOptionInput } from "@/domain/technology/schema";

const MODEL_VERSION = "1.0.0";

/**
 * Persistent datastores mapped to the `relational-database` and `read-replica`
 * components.
 *
 * The simulator currently models a single generic persistent-datastore
 * component whose display name is "Relational Database". Non-relational stores
 * are included because they fill the same architectural role (primary OLTP
 * datastore), but each carries an explicit advisory stating its actual data
 * model so the catalog never implies SQL/relational semantics it lacks.
 */
const NON_RELATIONAL = (model: string): { message: string } => ({
  message: `Non-relational data model (${model}). Assign it to the NoSQL datastore component and set the matching data model and consistency mode; it does not provide SQL relational semantics.`
});

const ANALYTICAL = {
  message:
    "Analytical / data warehouse engine rather than an OLTP datastore. Optimized for large scans and batch queries, not high-rate transactional reads and writes."
};

export const databaseTechnologies: TechnologyOptionInput[] = [
  {
    id: "postgresql",
    displayName: "PostgreSQL",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["relational-database", "read-replica"],
    description:
      "Standards-compliant relational database with strong transactional guarantees and rich extensions.",
    capabilities: ["sql-transactions", "acid", "streaming-replication", "json-support", "indexing"],
    roleCapabilities: {
      "read-replica": ["streaming-replication", "read-scaling", "eventual-consistency"]
    },
    aliases: ["Postgres"],
    simulationPreset: { baseLatencyMs: 25, perInstanceCapacityRps: 300 },
    documentationUrl: "https://www.postgresql.org/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "mysql",
    displayName: "MySQL",
    provider: "Oracle",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["relational-database", "read-replica"],
    description: "Widely deployed open-source relational database with pluggable storage engines.",
    capabilities: ["sql-transactions", "acid", "binlog-replication", "indexing"],
    roleCapabilities: {
      "read-replica": ["binlog-replication", "read-scaling", "eventual-consistency"]
    },
    simulationPreset: { baseLatencyMs: 22, perInstanceCapacityRps: 320 },
    documentationUrl: "https://dev.mysql.com/doc/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "mariadb",
    displayName: "MariaDB",
    provider: "MariaDB Foundation",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["relational-database", "read-replica"],
    description: "Community-developed MySQL fork with additional storage engines and features.",
    capabilities: ["sql-transactions", "acid", "replication", "indexing"],
    simulationPreset: { baseLatencyMs: 22, perInstanceCapacityRps: 320 },
    documentationUrl: "https://mariadb.com/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "sqlite",
    displayName: "SQLite",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["relational-database"],
    description: "Embedded, serverless relational database stored in a single file.",
    capabilities: ["sql-transactions", "acid", "embedded", "zero-configuration"],
    advisories: [
      {
        message:
          "Embedded single-writer database. It does not run as a networked, horizontally scaled service."
      }
    ],
    simulationPreset: { baseLatencyMs: 2, perInstanceCapacityRps: 80 },
    documentationUrl: "https://www.sqlite.org/docs.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "microsoft-sql-server",
    displayName: "Microsoft SQL Server",
    provider: "Microsoft",
    deploymentModel: ["self-managed", "on-premises", "managed-cloud"],
    componentTypes: ["relational-database", "read-replica"],
    description: "Enterprise relational database with T-SQL, always-on availability groups, and BI tooling.",
    capabilities: ["sql-transactions", "acid", "availability-groups", "columnstore-indexes"],
    simulationPreset: { baseLatencyMs: 25, perInstanceCapacityRps: 300 },
    documentationUrl: "https://learn.microsoft.com/sql/sql-server/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "oracle-database",
    displayName: "Oracle Database",
    provider: "Oracle",
    deploymentModel: ["self-managed", "on-premises", "managed-cloud"],
    componentTypes: ["relational-database", "read-replica"],
    description: "Enterprise relational database with advanced partitioning, RAC clustering, and PL/SQL.",
    capabilities: ["sql-transactions", "acid", "rac-clustering", "partitioning", "data-guard"],
    simulationPreset: { baseLatencyMs: 25, perInstanceCapacityRps: 320 },
    documentationUrl: "https://docs.oracle.com/en/database/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "ibm-db2",
    displayName: "IBM Db2",
    provider: "IBM",
    deploymentModel: ["self-managed", "on-premises", "managed-cloud"],
    componentTypes: ["relational-database"],
    description: "Enterprise relational database used heavily in mainframe and transactional systems.",
    capabilities: ["sql-transactions", "acid", "high-availability", "partitioning"],
    simulationPreset: { baseLatencyMs: 25, perInstanceCapacityRps: 300 },
    documentationUrl: "https://www.ibm.com/docs/en/db2",
    modelVersion: MODEL_VERSION
  },
  {
    id: "cockroachdb",
    displayName: "CockroachDB",
    provider: "Cockroach Labs",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["relational-database", "read-replica"],
    description:
      "Distributed SQL database providing horizontal scale with serializable transactions.",
    capabilities: [
      "sql-transactions",
      "distributed-sql",
      "horizontal-scaling",
      "multi-region",
      "automatic-rebalancing"
    ],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 400 },
    documentationUrl: "https://www.cockroachlabs.com/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "yugabytedb",
    displayName: "YugabyteDB",
    provider: "Yugabyte",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["relational-database", "read-replica"],
    description: "Distributed SQL database with PostgreSQL-compatible query layer.",
    capabilities: ["sql-transactions", "distributed-sql", "horizontal-scaling", "multi-region"],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 400 },
    documentationUrl: "https://docs.yugabyte.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "tidb",
    displayName: "TiDB",
    provider: "PingCAP",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["relational-database", "read-replica"],
    description:
      "MySQL-compatible distributed SQL database supporting hybrid transactional/analytical workloads.",
    capabilities: ["sql-transactions", "distributed-sql", "horizontal-scaling", "htap"],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 400 },
    documentationUrl: "https://docs.pingcap.com/tidb/stable",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-rds",
    displayName: "Amazon RDS",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["relational-database", "read-replica"],
    description:
      "Managed relational database service supporting PostgreSQL, MySQL, MariaDB, SQL Server, and Oracle engines.",
    capabilities: ["managed-backups", "read-replicas", "multi-az-failover", "sql-transactions"],
    roleCapabilities: {
      "read-replica": ["read-replicas", "read-scaling", "eventual-consistency"]
    },
    simulationPreset: { baseLatencyMs: 25, perInstanceCapacityRps: 350 },
    documentationUrl: "https://docs.aws.amazon.com/rds/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-aurora",
    displayName: "Amazon Aurora",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["relational-database", "read-replica"],
    description:
      "Cloud-native MySQL/PostgreSQL-compatible database with a distributed storage layer.",
    capabilities: [
      "sql-transactions",
      "distributed-storage",
      "fast-read-replicas",
      "automatic-failover",
      "point-in-time-recovery"
    ],
    simulationPreset: { baseLatencyMs: 18, perInstanceCapacityRps: 500 },
    documentationUrl: "https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-sql",
    displayName: "Google Cloud SQL",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["relational-database", "read-replica"],
    description: "Managed PostgreSQL, MySQL, and SQL Server instances on Google Cloud.",
    capabilities: ["managed-backups", "read-replicas", "high-availability", "sql-transactions"],
    simulationPreset: { baseLatencyMs: 25, perInstanceCapacityRps: 350 },
    documentationUrl: "https://cloud.google.com/sql/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "alloydb-for-postgresql",
    displayName: "AlloyDB for PostgreSQL",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["relational-database", "read-replica"],
    description:
      "PostgreSQL-compatible managed database with a disaggregated storage layer and columnar acceleration.",
    capabilities: ["sql-transactions", "distributed-storage", "read-pools", "columnar-engine"],
    simulationPreset: { baseLatencyMs: 18, perInstanceCapacityRps: 500 },
    documentationUrl: "https://cloud.google.com/alloydb/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-sql-database",
    displayName: "Azure SQL Database",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["relational-database", "read-replica"],
    description: "Fully managed SQL Server-compatible relational database service.",
    capabilities: ["sql-transactions", "geo-replication", "automatic-tuning", "managed-backups"],
    simulationPreset: { baseLatencyMs: 25, perInstanceCapacityRps: 350 },
    documentationUrl: "https://learn.microsoft.com/azure/azure-sql/database/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-database-for-postgresql",
    displayName: "Azure Database for PostgreSQL",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["relational-database", "read-replica"],
    description: "Managed PostgreSQL service with flexible-server deployment options.",
    capabilities: ["sql-transactions", "read-replicas", "high-availability", "managed-backups"],
    simulationPreset: { baseLatencyMs: 25, perInstanceCapacityRps: 350 },
    documentationUrl: "https://learn.microsoft.com/azure/postgresql/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "planetscale",
    displayName: "PlanetScale",
    provider: "PlanetScale",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["relational-database", "read-replica"],
    description: "MySQL-compatible serverless database built on Vitess with branching workflows.",
    capabilities: ["sql-transactions", "horizontal-sharding", "schema-branching", "read-replicas"],
    simulationPreset: { baseLatencyMs: 22, perInstanceCapacityRps: 400 },
    documentationUrl: "https://planetscale.com/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "neon",
    displayName: "Neon",
    provider: "Neon",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["relational-database", "read-replica"],
    description:
      "Serverless PostgreSQL with separated storage and compute, branching, and scale-to-zero.",
    capabilities: ["sql-transactions", "serverless-compute", "database-branching", "scale-to-zero"],
    simulationPreset: { baseLatencyMs: 28, jitterMs: 15, perInstanceCapacityRps: 300 },
    documentationUrl: "https://neon.com/docs/introduction",
    modelVersion: MODEL_VERSION
  },
  {
    id: "supabase-postgres",
    displayName: "Supabase Postgres",
    provider: "Supabase",
    deploymentModel: ["managed-cloud", "open-source", "saas"],
    componentTypes: ["relational-database"],
    description:
      "Managed PostgreSQL bundled with auto-generated REST APIs, auth, and realtime subscriptions.",
    capabilities: ["sql-transactions", "auto-generated-apis", "realtime-subscriptions", "row-level-security"],
    simulationPreset: { baseLatencyMs: 28, perInstanceCapacityRps: 300 },
    documentationUrl: "https://supabase.com/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-redshift",
    displayName: "Amazon Redshift",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["relational-database"],
    description: "Columnar cloud data warehouse for large-scale analytical SQL workloads.",
    capabilities: ["columnar-storage", "massively-parallel-processing", "analytical-sql"],
    advisories: [ANALYTICAL],
    simulationPreset: { baseLatencyMs: 250, perInstanceCapacityRps: 40 },
    documentationUrl: "https://docs.aws.amazon.com/redshift/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-bigquery",
    displayName: "Google BigQuery",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["relational-database"],
    description: "Serverless analytical data warehouse with separated storage and compute.",
    capabilities: ["columnar-storage", "serverless-analytics", "analytical-sql", "streaming-ingestion"],
    advisories: [ANALYTICAL],
    simulationPreset: { baseLatencyMs: 300, perInstanceCapacityRps: 40 },
    documentationUrl: "https://cloud.google.com/bigquery/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "snowflake",
    displayName: "Snowflake",
    provider: "Snowflake",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["relational-database"],
    description:
      "Cloud data platform with independently scalable virtual warehouses over shared storage.",
    capabilities: ["columnar-storage", "elastic-compute", "analytical-sql", "data-sharing"],
    advisories: [ANALYTICAL],
    simulationPreset: { baseLatencyMs: 280, perInstanceCapacityRps: 40 },
    documentationUrl: "https://docs.snowflake.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "mongodb",
    displayName: "MongoDB",
    provider: "MongoDB",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["nosql-database", "read-replica"],
    description: "Document database storing flexible BSON documents with secondary indexes.",
    capabilities: ["document-model", "replica-sets", "sharding", "secondary-indexes", "aggregation-pipeline"],
    roleCapabilities: {
      "read-replica": ["replica-sets", "secondary-reads", "eventual-consistency"]
    },
    advisories: [NON_RELATIONAL("document")],
    simulationPreset: { baseLatencyMs: 20, perInstanceCapacityRps: 400 },
    documentationUrl: "https://www.mongodb.com/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "mongodb-atlas",
    displayName: "MongoDB Atlas",
    provider: "MongoDB",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["nosql-database", "read-replica"],
    description: "Fully managed MongoDB service with automated scaling, backup, and multi-cloud deployment.",
    capabilities: ["document-model", "managed-backups", "auto-scaling", "global-clusters", "sharding"],
    advisories: [NON_RELATIONAL("document")],
    simulationPreset: { baseLatencyMs: 22, perInstanceCapacityRps: 450 },
    documentationUrl: "https://www.mongodb.com/docs/atlas/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-dynamodb",
    displayName: "Amazon DynamoDB",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["nosql-database"],
    description:
      "Serverless key-value and document database with single-digit millisecond access at scale.",
    capabilities: [
      "key-value-model",
      "document-model",
      "auto-scaling",
      "global-tables",
      "change-streams"
    ],
    advisories: [
      NON_RELATIONAL("key-value / document"),
      {
        message:
          "Access patterns must be designed around partition and sort keys; ad-hoc joins and arbitrary queries are not supported."
      }
    ],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 1000 },
    documentationUrl: "https://docs.aws.amazon.com/dynamodb/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "apache-cassandra",
    displayName: "Apache Cassandra",
    provider: "Apache Software Foundation",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["nosql-database", "read-replica"],
    description:
      "Wide-column distributed database with masterless replication and tunable consistency.",
    capabilities: [
      "wide-column-model",
      "masterless-replication",
      "tunable-consistency",
      "linear-scalability",
      "multi-region"
    ],
    advisories: [NON_RELATIONAL("wide-column")],
    simulationPreset: { baseLatencyMs: 15, perInstanceCapacityRps: 600 },
    documentationUrl: "https://cassandra.apache.org/doc/latest/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "datastax-astra-db",
    displayName: "DataStax Astra DB",
    provider: "DataStax",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["nosql-database"],
    description: "Managed Cassandra-compatible database with serverless scaling.",
    capabilities: ["wide-column-model", "serverless-scaling", "multi-region", "tunable-consistency"],
    advisories: [NON_RELATIONAL("wide-column")],
    simulationPreset: { baseLatencyMs: 18, perInstanceCapacityRps: 600 },
    documentationUrl: "https://docs.datastax.com/en/astra-db-serverless/index.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "scylladb",
    displayName: "ScyllaDB",
    provider: "ScyllaDB",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["nosql-database"],
    description:
      "C++ Cassandra-compatible wide-column database tuned for low latency and high throughput.",
    capabilities: ["wide-column-model", "shard-per-core", "tunable-consistency", "linear-scalability"],
    advisories: [NON_RELATIONAL("wide-column")],
    simulationPreset: { baseLatencyMs: 8, perInstanceCapacityRps: 900 },
    documentationUrl: "https://docs.scylladb.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "apache-hbase",
    displayName: "Apache HBase",
    provider: "Apache Software Foundation",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["nosql-database"],
    description: "Wide-column store built on HDFS for random real-time access to large tables.",
    capabilities: ["wide-column-model", "hdfs-storage", "strong-row-consistency", "linear-scalability"],
    advisories: [NON_RELATIONAL("wide-column")],
    simulationPreset: { baseLatencyMs: 30, perInstanceCapacityRps: 400 },
    documentationUrl: "https://hbase.apache.org/book.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-bigtable",
    displayName: "Google Cloud Bigtable",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["nosql-database"],
    description:
      "Managed wide-column database for very large analytical and operational key-ordered workloads.",
    capabilities: ["wide-column-model", "linear-scalability", "low-latency-reads", "time-series-friendly"],
    advisories: [NON_RELATIONAL("wide-column")],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 900 },
    documentationUrl: "https://cloud.google.com/bigtable/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-cosmos-db",
    displayName: "Azure Cosmos DB",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["nosql-database", "read-replica"],
    description:
      "Globally distributed multi-model database with configurable consistency levels.",
    capabilities: [
      "document-model",
      "key-value-model",
      "global-distribution",
      "tunable-consistency",
      "change-feed"
    ],
    advisories: [NON_RELATIONAL("multi-model: document, key-value, graph, wide-column")],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 800 },
    documentationUrl: "https://learn.microsoft.com/azure/cosmos-db/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "couchbase",
    displayName: "Couchbase",
    provider: "Couchbase",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["nosql-database", "cache"],
    description:
      "Distributed document database with an integrated memory-first caching layer and SQL++ queries.",
    capabilities: ["document-model", "memory-first-architecture", "sql-plus-plus-queries", "cross-datacenter-replication"],
    roleCapabilities: {
      cache: ["memory-first-architecture", "key-value-access", "ttl-expiry"],
      "relational-database": ["document-model", "sql-plus-plus-queries", "cross-datacenter-replication"]
    },
    advisories: [NON_RELATIONAL("document")],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 700 },
    documentationUrl: "https://docs.couchbase.com/home/index.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "couchdb",
    displayName: "CouchDB",
    provider: "Apache Software Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["nosql-database"],
    description: "Document database with HTTP API and multi-master replication designed for offline sync.",
    capabilities: ["document-model", "multi-master-replication", "http-api", "offline-sync"],
    advisories: [NON_RELATIONAL("document")],
    simulationPreset: { baseLatencyMs: 30, perInstanceCapacityRps: 250 },
    documentationUrl: "https://docs.couchdb.org/en/stable/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aerospike",
    displayName: "Aerospike",
    provider: "Aerospike",
    deploymentModel: ["open-source", "self-managed", "managed-cloud"],
    componentTypes: ["nosql-database", "cache"],
    description:
      "Hybrid memory/SSD key-value store built for predictable sub-millisecond access at scale.",
    capabilities: ["key-value-model", "hybrid-memory-storage", "strong-consistency-mode", "linear-scalability"],
    advisories: [NON_RELATIONAL("key-value")],
    simulationPreset: { baseLatencyMs: 4, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://aerospike.com/docs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "foundationdb",
    displayName: "FoundationDB",
    provider: "Apple",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["nosql-database"],
    description:
      "Distributed ordered key-value store providing strictly serializable ACID transactions.",
    capabilities: ["key-value-model", "acid", "strict-serializability", "horizontal-scaling"],
    advisories: [NON_RELATIONAL("ordered key-value")],
    simulationPreset: { baseLatencyMs: 12, perInstanceCapacityRps: 700 },
    documentationUrl: "https://apple.github.io/foundationdb/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "riak-kv",
    displayName: "Riak KV",
    provider: "Riak",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["nosql-database"],
    description: "Masterless distributed key-value store emphasising availability and partition tolerance.",
    capabilities: ["key-value-model", "masterless-replication", "eventual-consistency", "high-availability"],
    status: "legacy",
    advisories: [
      NON_RELATIONAL("key-value"),
      { message: "Limited active development and adoption compared with contemporary alternatives." }
    ],
    simulationPreset: { baseLatencyMs: 20, perInstanceCapacityRps: 400 },
    documentationUrl: "https://docs.riak.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "etcd",
    displayName: "etcd",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["nosql-database"],
    description:
      "Strongly consistent distributed key-value store used for configuration and coordination.",
    capabilities: ["key-value-model", "raft-consensus", "strong-consistency", "watch-notifications"],
    advisories: [
      NON_RELATIONAL("key-value"),
      {
        message:
          "Coordination and configuration store. It is not intended as a general-purpose application datastore and holds modest data volumes."
      }
    ],
    simulationPreset: { baseLatencyMs: 10, perInstanceCapacityRps: 200 },
    documentationUrl: "https://etcd.io/docs/",
    modelVersion: MODEL_VERSION
  }
];
