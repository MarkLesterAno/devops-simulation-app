import type { TechnologyOptionInput } from "@/domain/technology/schema";

const MODEL_VERSION = "1.0.0";

/**
 * Compute platforms and application frameworks for the `server` and `worker`
 * components. Per the catalog spec these are kept distinct: an infrastructure
 * runtime (Kubernetes, EC2) is not interchangeable with an application
 * framework (Spring Boot, Django) that runs on top of one.
 */
export const computeTechnologies: TechnologyOptionInput[] = [
  {
    id: "amazon-ec2",
    displayName: "Amazon EC2",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "Resizable virtual machine instances providing general-purpose compute capacity.",
    capabilities: ["virtual-machines", "auto-scaling-groups", "custom-runtime", "persistent-instances"],
    simulationPreset: { baseLatencyMs: 40, perInstanceCapacityRps: 200 },
    documentationUrl: "https://docs.aws.amazon.com/ec2/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-ecs",
    displayName: "Amazon ECS",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "AWS-native container orchestration service for running Docker workloads.",
    capabilities: ["container-orchestration", "service-discovery", "auto-scaling", "rolling-deploys"],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 250 },
    documentationUrl: "https://docs.aws.amazon.com/ecs/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-eks",
    displayName: "Amazon EKS",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "Managed Kubernetes control plane for running containerized workloads on AWS.",
    capabilities: ["container-orchestration", "kubernetes-api", "auto-scaling", "self-healing"],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 250 },
    documentationUrl: "https://docs.aws.amazon.com/eks/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-fargate",
    displayName: "AWS Fargate",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "Serverless container compute engine that removes node management from ECS and EKS.",
    capabilities: ["serverless-containers", "auto-scaling", "per-task-isolation"],
    simulationPreset: { baseLatencyMs: 45, perInstanceCapacityRps: 200 },
    documentationUrl: "https://docs.aws.amazon.com/AmazonECS/latest/developerguide/AWS_Fargate.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-lambda",
    displayName: "AWS Lambda",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "Event-driven serverless functions billed per invocation with automatic scaling.",
    capabilities: ["serverless-functions", "event-driven", "auto-scaling", "per-request-isolation"],
    advisories: [
      {
        message:
          "Cold starts and per-invocation concurrency limits make latency behavior differ markedly from always-on servers."
      }
    ],
    simulationPreset: { baseLatencyMs: 60, jitterMs: 40, perInstanceCapacityRps: 150 },
    documentationUrl: "https://docs.aws.amazon.com/lambda/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-compute-engine",
    displayName: "Google Compute Engine",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "Virtual machine instances on Google Cloud infrastructure.",
    capabilities: ["virtual-machines", "managed-instance-groups", "auto-scaling", "custom-runtime"],
    simulationPreset: { baseLatencyMs: 40, perInstanceCapacityRps: 200 },
    documentationUrl: "https://cloud.google.com/compute/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-kubernetes-engine",
    displayName: "Google Kubernetes Engine",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "Managed Kubernetes service with autopilot and standard operating modes.",
    capabilities: ["container-orchestration", "kubernetes-api", "auto-scaling", "self-healing"],
    aliases: ["GKE"],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 250 },
    documentationUrl: "https://cloud.google.com/kubernetes-engine/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-run",
    displayName: "Google Cloud Run",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "Serverless container platform that scales request-driven services to zero.",
    capabilities: ["serverless-containers", "auto-scaling", "scale-to-zero", "request-concurrency"],
    simulationPreset: { baseLatencyMs: 45, jitterMs: 20, perInstanceCapacityRps: 200 },
    documentationUrl: "https://cloud.google.com/run/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-functions",
    displayName: "Google Cloud Functions",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "Event-driven serverless functions integrated with Google Cloud event sources.",
    capabilities: ["serverless-functions", "event-driven", "auto-scaling"],
    advisories: [
      {
        message:
          "Cold starts and per-invocation concurrency limits make latency behavior differ markedly from always-on servers."
      }
    ],
    simulationPreset: { baseLatencyMs: 60, jitterMs: 40, perInstanceCapacityRps: 150 },
    documentationUrl: "https://cloud.google.com/functions/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-virtual-machines",
    displayName: "Azure Virtual Machines",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "On-demand virtual machines with scale-set based horizontal scaling.",
    capabilities: ["virtual-machines", "scale-sets", "auto-scaling", "custom-runtime"],
    simulationPreset: { baseLatencyMs: 40, perInstanceCapacityRps: 200 },
    documentationUrl: "https://learn.microsoft.com/azure/virtual-machines/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-kubernetes-service",
    displayName: "Azure Kubernetes Service",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "Managed Kubernetes service integrated with Azure identity and networking.",
    capabilities: ["container-orchestration", "kubernetes-api", "auto-scaling", "self-healing"],
    aliases: ["AKS"],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 250 },
    documentationUrl: "https://learn.microsoft.com/azure/aks/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-container-apps",
    displayName: "Azure Container Apps",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "Serverless container platform built on Kubernetes and KEDA-based event scaling.",
    capabilities: ["serverless-containers", "auto-scaling", "scale-to-zero", "event-driven-scaling"],
    simulationPreset: { baseLatencyMs: 45, jitterMs: 20, perInstanceCapacityRps: 200 },
    documentationUrl: "https://learn.microsoft.com/azure/container-apps/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-functions",
    displayName: "Azure Functions",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["server", "worker"],
    description: "Event-driven serverless compute with consumption and premium hosting plans.",
    capabilities: ["serverless-functions", "event-driven", "auto-scaling", "durable-functions"],
    advisories: [
      {
        message:
          "Cold starts and per-invocation concurrency limits make latency behavior differ markedly from always-on servers."
      }
    ],
    simulationPreset: { baseLatencyMs: 60, jitterMs: 40, perInstanceCapacityRps: 150 },
    documentationUrl: "https://learn.microsoft.com/azure/azure-functions/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "kubernetes",
    displayName: "Kubernetes",
    provider: "Cloud Native Computing Foundation",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["server", "worker", "autoscaler"],
    description:
      "Container orchestration platform managing scheduling, scaling, and self-healing of workloads.",
    capabilities: [
      "container-orchestration",
      "declarative-scheduling",
      "self-healing",
      "horizontal-scaling",
      "service-discovery"
    ],
    roleCapabilities: {
      server: ["container-orchestration", "declarative-scheduling", "self-healing"],
      worker: ["job-scheduling", "cronjobs", "self-healing"],
      autoscaler: ["horizontal-scaling", "cluster-scaling", "metric-driven-scaling"]
    },
    aliases: ["K8s"],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 250 },
    documentationUrl: "https://kubernetes.io/docs/home/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "docker",
    displayName: "Docker",
    provider: "Docker",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server", "worker"],
    description: "Container runtime and image tooling for packaging and running applications.",
    capabilities: ["containerization", "image-packaging", "process-isolation"],
    advisories: [
      {
        message:
          "Container runtime and packaging format rather than a clustered orchestration or scaling platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 40, perInstanceCapacityRps: 200 },
    documentationUrl: "https://docs.docker.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "openshift",
    displayName: "OpenShift",
    provider: "Red Hat",
    deploymentModel: ["self-managed", "on-premises", "managed-cloud"],
    componentTypes: ["server", "worker"],
    description:
      "Enterprise Kubernetes distribution adding developer workflow, build, and policy tooling.",
    capabilities: ["container-orchestration", "kubernetes-api", "build-pipelines", "self-healing"],
    simulationPreset: { baseLatencyMs: 38, perInstanceCapacityRps: 230 },
    documentationUrl: "https://docs.openshift.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "hashicorp-nomad",
    displayName: "HashiCorp Nomad",
    provider: "HashiCorp",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["server", "worker"],
    description:
      "Lightweight scheduler orchestrating containers, binaries, and batch jobs in one workflow.",
    capabilities: ["workload-scheduling", "batch-jobs", "multi-runtime", "horizontal-scaling"],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 240 },
    documentationUrl: "https://developer.hashicorp.com/nomad/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "apache-tomcat",
    displayName: "Apache Tomcat",
    provider: "Apache Software Foundation",
    deploymentModel: ["open-source", "self-managed", "on-premises"],
    componentTypes: ["server"],
    description: "Java servlet container and web server implementing Jakarta Servlet and JSP.",
    capabilities: ["servlet-container", "http-serving", "connection-pooling"],
    simulationPreset: { baseLatencyMs: 45, perInstanceCapacityRps: 180 },
    documentationUrl: "https://tomcat.apache.org/tomcat-10.1-doc/index.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "nodejs",
    displayName: "Node.js",
    provider: "OpenJS Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server", "worker"],
    description: "Event-driven JavaScript runtime well suited to I/O-bound network services.",
    capabilities: ["event-loop-concurrency", "non-blocking-io", "javascript-runtime"],
    advisories: [
      {
        message:
          "Application runtime rather than an infrastructure platform; pair it with a compute or orchestration platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 220 },
    documentationUrl: "https://nodejs.org/docs/latest/api/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "spring-boot",
    displayName: "Spring Boot",
    provider: "VMware Tanzu",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server", "worker"],
    description: "Opinionated Java application framework for building production-ready services.",
    capabilities: ["dependency-injection", "embedded-server", "rest-apis", "batch-processing"],
    advisories: [
      {
        message:
          "Application framework rather than an infrastructure platform; pair it with a compute or orchestration platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 45, perInstanceCapacityRps: 200 },
    documentationUrl: "https://docs.spring.io/spring-boot/index.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aspnet-core",
    displayName: ".NET ASP.NET Core",
    provider: "Microsoft",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server", "worker"],
    description: "Cross-platform .NET framework for building high-performance web APIs and apps.",
    capabilities: ["rest-apis", "dependency-injection", "middleware-pipeline", "background-services"],
    aliases: ["ASP.NET Core"],
    advisories: [
      {
        message:
          "Application framework rather than an infrastructure platform; pair it with a compute or orchestration platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 260 },
    documentationUrl: "https://learn.microsoft.com/aspnet/core/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "django",
    displayName: "Django",
    provider: "Django Software Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server"],
    description: "Batteries-included Python web framework with ORM, admin, and auth built in.",
    capabilities: ["rest-apis", "orm", "admin-interface", "server-side-rendering"],
    advisories: [
      {
        message:
          "Application framework rather than an infrastructure platform; pair it with a compute or orchestration platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 55, perInstanceCapacityRps: 140 },
    documentationUrl: "https://docs.djangoproject.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "flask",
    displayName: "Flask",
    provider: "Pallets",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server"],
    description: "Minimal Python web framework favouring explicit composition over convention.",
    capabilities: ["rest-apis", "lightweight-routing", "wsgi"],
    advisories: [
      {
        message:
          "Application framework rather than an infrastructure platform; pair it with a compute or orchestration platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 50, perInstanceCapacityRps: 150 },
    documentationUrl: "https://flask.palletsprojects.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "fastapi",
    displayName: "FastAPI",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server"],
    description: "Async Python framework with type-driven validation and automatic OpenAPI docs.",
    capabilities: ["rest-apis", "async-io", "schema-validation", "openapi-generation"],
    advisories: [
      {
        message:
          "Application framework rather than an infrastructure platform; pair it with a compute or orchestration platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 40, perInstanceCapacityRps: 200 },
    documentationUrl: "https://fastapi.tiangolo.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "ruby-on-rails",
    displayName: "Ruby on Rails",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server"],
    description: "Convention-over-configuration Ruby framework with integrated ORM and MVC stack.",
    capabilities: ["rest-apis", "orm", "server-side-rendering", "background-jobs"],
    advisories: [
      {
        message:
          "Application framework rather than an infrastructure platform; pair it with a compute or orchestration platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 60, perInstanceCapacityRps: 120 },
    documentationUrl: "https://guides.rubyonrails.org/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "laravel",
    displayName: "Laravel",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server"],
    description: "PHP application framework with expressive routing, ORM, and queue integration.",
    capabilities: ["rest-apis", "orm", "queue-integration", "server-side-rendering"],
    advisories: [
      {
        message:
          "Application framework rather than an infrastructure platform; pair it with a compute or orchestration platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 55, perInstanceCapacityRps: 130 },
    documentationUrl: "https://laravel.com/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "phoenix",
    displayName: "Phoenix",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server"],
    description:
      "Elixir framework on the BEAM VM offering high concurrency and real-time channels.",
    capabilities: ["rest-apis", "websockets", "high-concurrency", "fault-tolerant-processes"],
    advisories: [
      {
        message:
          "Application framework rather than an infrastructure platform; pair it with a compute or orchestration platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 30, perInstanceCapacityRps: 300 },
    documentationUrl: "https://hexdocs.pm/phoenix/overview.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "expressjs",
    displayName: "Express.js",
    provider: "OpenJS Foundation",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server"],
    description: "Minimal Node.js web framework built around composable middleware.",
    capabilities: ["rest-apis", "middleware-pipeline", "lightweight-routing"],
    advisories: [
      {
        message:
          "Application framework rather than an infrastructure platform; pair it with a compute or orchestration platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 35, perInstanceCapacityRps: 220 },
    documentationUrl: "https://expressjs.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "nestjs",
    displayName: "NestJS",
    provider: "Open Source",
    deploymentModel: ["open-source", "self-managed"],
    componentTypes: ["server", "worker"],
    description:
      "Structured TypeScript Node.js framework with modules, DI, and microservice transports.",
    capabilities: ["rest-apis", "dependency-injection", "microservice-transports", "background-jobs"],
    advisories: [
      {
        message:
          "Application framework rather than an infrastructure platform; pair it with a compute or orchestration platform."
      }
    ],
    simulationPreset: { baseLatencyMs: 38, perInstanceCapacityRps: 210 },
    documentationUrl: "https://docs.nestjs.com/",
    modelVersion: MODEL_VERSION
  }
];
