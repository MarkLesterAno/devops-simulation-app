import type { TechnologyOptionInput } from "@/domain/technology/schema";

const MODEL_VERSION = "1.0.0";

/**
 * CDN, edge delivery, and edge-security products mapped to the generic `cdn`
 * component. Presets express *relative* edge-cache behavior for teaching, not
 * measured provider performance.
 */
export const cdnTechnologies: TechnologyOptionInput[] = [
  {
    id: "cloudflare-cdn",
    displayName: "Cloudflare CDN",
    provider: "Cloudflare",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["cdn"],
    description:
      "Global anycast content delivery network with integrated caching, TLS termination, and edge security.",
    capabilities: ["global-edge-delivery", "tls-termination", "cache-purge", "ddos-protection"],
    simulationPreset: { baseLatencyMs: 12, hitRatio: 0.9, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://developers.cloudflare.com/cache/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "amazon-cloudfront",
    displayName: "Amazon CloudFront",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cdn"],
    description:
      "AWS content delivery network that caches origin responses at global edge locations.",
    capabilities: ["global-edge-delivery", "tls-termination", "origin-shield", "signed-urls"],
    simulationPreset: { baseLatencyMs: 15, hitRatio: 0.88, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "akamai-cdn",
    displayName: "Akamai Content Delivery Network",
    provider: "Akamai",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cdn"],
    description:
      "Large-scale distributed edge delivery platform focused on media and enterprise workloads.",
    capabilities: ["global-edge-delivery", "media-streaming", "tls-termination", "edge-rules"],
    simulationPreset: { baseLatencyMs: 14, hitRatio: 0.9, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://techdocs.akamai.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "fastly",
    displayName: "Fastly",
    provider: "Fastly",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cdn"],
    description:
      "Edge cloud platform known for instant cache purge and programmable VCL edge logic.",
    capabilities: ["global-edge-delivery", "instant-purge", "edge-compute", "tls-termination"],
    simulationPreset: { baseLatencyMs: 12, hitRatio: 0.88, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://docs.fastly.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-front-door",
    displayName: "Azure Front Door",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cdn", "load-balancer"],
    description:
      "Global entry point combining edge caching, HTTP routing, and layer-7 global load balancing.",
    capabilities: ["global-edge-delivery", "global-http-routing", "tls-termination", "waf"],
    roleCapabilities: {
      cdn: ["global-edge-delivery", "cache-rules", "tls-termination"],
      "load-balancer": ["global-http-routing", "health-probes", "session-affinity", "waf"]
    },
    simulationPreset: { baseLatencyMs: 15, hitRatio: 0.85, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://learn.microsoft.com/azure/frontdoor/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-cdn",
    displayName: "Google Cloud CDN",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cdn"],
    description:
      "Edge caching layer integrated with Google Cloud external HTTP(S) load balancing.",
    capabilities: ["global-edge-delivery", "cache-invalidation", "tls-termination"],
    simulationPreset: { baseLatencyMs: 15, hitRatio: 0.87, perInstanceCapacityRps: 4000 },
    documentationUrl: "https://cloud.google.com/cdn/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "vercel-edge-network",
    displayName: "Vercel Edge Network",
    provider: "Vercel",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["cdn"],
    description:
      "Application-oriented edge network providing static asset caching and edge rendering for web frameworks.",
    capabilities: ["global-edge-delivery", "edge-compute", "static-asset-caching"],
    simulationPreset: { baseLatencyMs: 14, hitRatio: 0.85, perInstanceCapacityRps: 2500 },
    documentationUrl: "https://vercel.com/docs/edge-network/overview",
    modelVersion: MODEL_VERSION
  },
  {
    id: "netlify-edge",
    displayName: "Netlify Edge",
    provider: "Netlify",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["cdn"],
    description: "Edge delivery and edge function platform for static sites and JAMstack apps.",
    capabilities: ["global-edge-delivery", "edge-compute", "atomic-deploys"],
    simulationPreset: { baseLatencyMs: 16, hitRatio: 0.85, perInstanceCapacityRps: 2000 },
    documentationUrl: "https://docs.netlify.com/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "cloudflare-workers",
    displayName: "Cloudflare Workers",
    provider: "Cloudflare",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["cdn", "server"],
    description:
      "Serverless JavaScript/WASM runtime executing at edge locations close to the user.",
    capabilities: ["edge-compute", "global-distribution", "sub-request-routing"],
    roleCapabilities: {
      cdn: ["edge-compute", "request-rewriting", "global-distribution"],
      server: ["serverless-execution", "auto-scaling", "global-distribution"]
    },
    advisories: [
      {
        message:
          "Edge runtime with short CPU time limits and no persistent local state; not a general-purpose long-running application server.",
        componentTypes: ["server"]
      }
    ],
    simulationPreset: { baseLatencyMs: 8, perInstanceCapacityRps: 3000 },
    documentationUrl: "https://developers.cloudflare.com/workers/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-global-accelerator",
    displayName: "AWS Global Accelerator",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cdn", "load-balancer"],
    description:
      "Anycast network layer that routes user traffic over the AWS backbone to regional endpoints.",
    capabilities: ["anycast-routing", "global-traffic-steering", "health-based-failover"],
    advisories: [
      {
        message:
          "Traffic accelerator rather than a content cache; it does not store or serve cached objects.",
        componentTypes: ["cdn"]
      }
    ],
    simulationPreset: { baseLatencyMs: 10, hitRatio: 0, perInstanceCapacityRps: 5000 },
    documentationUrl: "https://docs.aws.amazon.com/global-accelerator/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-shield",
    displayName: "AWS Shield",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cdn"],
    description: "Managed DDoS detection and mitigation service for AWS edge and regional resources.",
    capabilities: ["ddos-protection", "traffic-scrubbing", "attack-visibility"],
    advisories: [
      {
        message:
          "Edge protection control rather than a delivery cache; model it as an attribute of the edge tier.",
        componentTypes: ["cdn"]
      }
    ],
    documentationUrl: "https://docs.aws.amazon.com/waf/latest/developerguide/shield-chapter.html",
    modelVersion: MODEL_VERSION
  },
  {
    id: "cloudflare-waf",
    displayName: "Cloudflare WAF",
    provider: "Cloudflare",
    deploymentModel: ["managed-cloud", "saas"],
    componentTypes: ["cdn"],
    description:
      "Edge web application firewall inspecting HTTP traffic against managed and custom rule sets.",
    capabilities: ["waf", "rate-limiting", "bot-management", "owasp-rules"],
    advisories: [
      {
        message: "Security filtering layer rather than a content cache.",
        componentTypes: ["cdn"]
      }
    ],
    simulationPreset: { baseLatencyMs: 4, hitRatio: 0 },
    documentationUrl: "https://developers.cloudflare.com/waf/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "aws-waf",
    displayName: "AWS WAF",
    provider: "Amazon Web Services",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cdn"],
    description:
      "Web application firewall that filters HTTP requests at CloudFront, ALB, or API Gateway.",
    capabilities: ["waf", "rate-limiting", "managed-rule-groups"],
    advisories: [
      {
        message: "Security filtering layer rather than a content cache.",
        componentTypes: ["cdn"]
      }
    ],
    simulationPreset: { baseLatencyMs: 4, hitRatio: 0 },
    documentationUrl: "https://docs.aws.amazon.com/waf/",
    modelVersion: MODEL_VERSION
  },
  {
    id: "google-cloud-armor",
    displayName: "Google Cloud Armor",
    provider: "Google Cloud",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cdn"],
    description:
      "Edge DDoS defense and WAF policy enforcement for Google Cloud load balancing front ends.",
    capabilities: ["waf", "ddos-protection", "adaptive-protection"],
    advisories: [
      {
        message: "Security filtering layer rather than a content cache.",
        componentTypes: ["cdn"]
      }
    ],
    simulationPreset: { baseLatencyMs: 4, hitRatio: 0 },
    documentationUrl: "https://cloud.google.com/armor/docs",
    modelVersion: MODEL_VERSION
  },
  {
    id: "azure-web-application-firewall",
    displayName: "Azure Web Application Firewall",
    provider: "Microsoft Azure",
    deploymentModel: ["managed-cloud"],
    componentTypes: ["cdn"],
    description:
      "WAF policies applied at Azure Front Door or Application Gateway to filter layer-7 traffic.",
    capabilities: ["waf", "owasp-rules", "bot-protection"],
    aliases: ["Azure WAF"],
    advisories: [
      {
        message: "Security filtering layer rather than a content cache.",
        componentTypes: ["cdn"]
      }
    ],
    simulationPreset: { baseLatencyMs: 4, hitRatio: 0 },
    documentationUrl: "https://learn.microsoft.com/azure/web-application-firewall/",
    modelVersion: MODEL_VERSION
  }
];
