import type { SimulationPreset, TechnologyOption } from "@/domain/technology/schema";

const PRESET_FIELD_LABELS: Record<keyof SimulationPreset, string> = {
  perInstanceCapacityRps: "Per-instance capacity",
  baseLatencyMs: "Base latency (ms)",
  jitterMs: "Jitter (ms)",
  timeoutMs: "Timeout (ms)",
  errorRate: "Error rate",
  hitRatio: "Hit ratio",
  estimatedCostPerHour: "Estimated cost / hour"
};

export interface PresetFieldChange {
  key: keyof SimulationPreset;
  label: string;
  currentValue: number;
  nextValue: number;
}

/**
 * Computes which configuration fields a preset would actually change, so the UI
 * can show an explicit before/after list and let the user accept or cancel
 * rather than silently overwriting manually tuned values.
 */
export function diffPreset(
  config: Readonly<Record<string, unknown>>,
  preset: SimulationPreset
): PresetFieldChange[] {
  const changes: PresetFieldChange[] = [];
  for (const [key, nextValue] of Object.entries(preset)) {
    if (typeof nextValue !== "number") continue;
    const presetKey = key as keyof SimulationPreset;
    const rawCurrent = config[presetKey];
    const currentValue = typeof rawCurrent === "number" ? rawCurrent : Number.NaN;
    if (currentValue === nextValue) continue;
    changes.push({
      key: presetKey,
      label: PRESET_FIELD_LABELS[presetKey],
      currentValue,
      nextValue
    });
  }
  return changes;
}

/** Builds the config patch for the subset of preset fields the user accepted. */
export function buildPresetPatch(
  preset: SimulationPreset,
  acceptedKeys: Array<keyof SimulationPreset>
): Record<string, number> {
  const patch: Record<string, number> = {};
  for (const key of acceptedKeys) {
    const value = preset[key];
    if (typeof value === "number") {
      patch[key] = value;
    }
  }
  return patch;
}

export function hasApplicablePreset(option: TechnologyOption): boolean {
  return option.simulationPreset !== undefined;
}
