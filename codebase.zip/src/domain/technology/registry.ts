import type { ComponentType } from "@/domain/architecture/schema";
import {
  GENERIC_TECHNOLOGY_ID,
  TECHNOLOGY_ID_MIGRATIONS,
  technologyOptionSchema,
  type DeploymentModel,
  type TechnologyAdvisory,
  type TechnologyAssignment,
  type TechnologyOption,
  type TechnologyOptionInput
} from "@/domain/technology/schema";
import { cdnTechnologies } from "@/domain/technology/catalog/cdn";
import { loadBalancingTechnologies } from "@/domain/technology/catalog/loadBalancing";
import { computeTechnologies } from "@/domain/technology/catalog/compute";
import { databaseTechnologies } from "@/domain/technology/catalog/databases";
import { cachingTechnologies } from "@/domain/technology/catalog/caching";
import { messagingTechnologies } from "@/domain/technology/catalog/messaging";
import { storageTechnologies } from "@/domain/technology/catalog/storage";
import { observabilityTechnologies } from "@/domain/technology/catalog/observability";
import { operationsTechnologies } from "@/domain/technology/catalog/operations";
import { edgeAndIdentityTechnologies } from "@/domain/technology/catalog/edgeAndIdentity";

const rawCatalog: TechnologyOptionInput[] = [
  ...cdnTechnologies,
  ...loadBalancingTechnologies,
  ...computeTechnologies,
  ...databaseTechnologies,
  ...cachingTechnologies,
  ...messagingTechnologies,
  ...storageTechnologies,
  ...observabilityTechnologies,
  ...operationsTechnologies,
  ...edgeAndIdentityTechnologies
];

/**
 * Parses and integrity-checks the catalog at module load. Failing fast here means
 * a malformed or duplicated entry can never reach the UI or a saved project.
 */
export function buildCatalog(entries: TechnologyOptionInput[]): TechnologyOption[] {
  const parsed = entries.map((entry, index) => {
    const result = technologyOptionSchema.safeParse(entry);
    if (!result.success) {
      const label = entry.id ?? `index ${index}`;
      throw new Error(`Invalid technology catalog entry "${label}": ${result.error.message}`);
    }
    return result.data;
  });

  const seenIds = new Set<string>();
  const seenCanonical = new Set<string>();
  for (const option of parsed) {
    if (seenIds.has(option.id)) {
      throw new Error(`Duplicate technology id "${option.id}" in the catalog.`);
    }
    seenIds.add(option.id);

    // Guards against the same product being listed twice under different ids.
    const canonical = `${option.provider.toLowerCase()}::${option.displayName.toLowerCase()}`;
    if (seenCanonical.has(canonical)) {
      throw new Error(
        `Duplicate provider/product combination "${option.provider} — ${option.displayName}" in the catalog.`
      );
    }
    seenCanonical.add(canonical);
  }

  return parsed;
}

export const technologyCatalog: TechnologyOption[] = buildCatalog(rawCatalog);

const catalogById = new Map(technologyCatalog.map((option) => [option.id, option]));

const catalogByComponentType = technologyCatalog.reduce<Map<ComponentType, TechnologyOption[]>>(
  (index, option) => {
    for (const componentType of option.componentTypes) {
      const list = index.get(componentType) ?? [];
      list.push(option);
      index.set(componentType, list);
    }
    return index;
  },
  new Map()
);

/** Resolves an id through the rename-migration map before lookup. */
export function resolveTechnologyId(technologyId: string): string {
  return TECHNOLOGY_ID_MIGRATIONS[technologyId] ?? technologyId;
}

export function getTechnologyById(technologyId: string): TechnologyOption | undefined {
  return catalogById.get(resolveTechnologyId(technologyId));
}

/** Catalog entries valid for a component type, sorted by display name. */
export function getTechnologiesForComponentType(componentType: ComponentType): TechnologyOption[] {
  const options = catalogByComponentType.get(componentType) ?? [];
  return [...options].sort((left, right) => left.displayName.localeCompare(right.displayName));
}

/** Capabilities scoped to the role the technology is filling on this node. */
export function getCapabilitiesForRole(
  option: TechnologyOption,
  componentType: ComponentType
): string[] {
  return option.roleCapabilities?.[componentType] ?? option.capabilities;
}

/** Advisories that apply globally plus those scoped to this component type. */
export function getAdvisoriesForRole(
  option: TechnologyOption,
  componentType: ComponentType
): TechnologyAdvisory[] {
  return option.advisories.filter(
    (advisory) => !advisory.componentTypes || advisory.componentTypes.includes(componentType)
  );
}

export function getProviders(options: TechnologyOption[]): string[] {
  return [...new Set(options.map((option) => option.provider))].sort((left, right) =>
    left.localeCompare(right)
  );
}

export interface TechnologyFilters {
  search?: string;
  provider?: string;
  deploymentModel?: DeploymentModel;
}

export function filterTechnologies(
  options: TechnologyOption[],
  filters: TechnologyFilters
): TechnologyOption[] {
  const search = filters.search?.trim().toLowerCase();
  return options.filter((option) => {
    if (filters.provider && option.provider !== filters.provider) return false;
    if (filters.deploymentModel && !option.deploymentModel.includes(filters.deploymentModel)) {
      return false;
    }
    if (!search) return true;
    const haystack = [
      option.displayName,
      option.provider,
      option.description,
      ...option.aliases,
      ...option.capabilities
    ]
      .join(" ")
      .toLowerCase();
    return haystack.includes(search);
  });
}

export type TechnologyResolution =
  | { state: "generic" }
  | { state: "known"; option: TechnologyOption; compatible: boolean }
  | { state: "unknown"; assignment: TechnologyAssignment };

/**
 * Resolves a saved assignment against the active catalog.
 *
 * An assignment that is no longer in the catalog resolves to `unknown` rather
 * than being discarded, so imported projects still render and still simulate
 * using their generic component configuration.
 */
export function resolveTechnologyAssignment(
  assignment: TechnologyAssignment | undefined,
  componentType: ComponentType
): TechnologyResolution {
  if (!assignment || assignment.id === GENERIC_TECHNOLOGY_ID) {
    return { state: "generic" };
  }
  const option = getTechnologyById(assignment.id);
  if (!option) {
    return { state: "unknown", assignment };
  }
  return { state: "known", option, compatible: option.componentTypes.includes(componentType) };
}

export function toTechnologyAssignment(option: TechnologyOption): TechnologyAssignment {
  return {
    id: option.id,
    displayName: option.displayName,
    provider: option.provider,
    componentTypes: option.componentTypes
  };
}
