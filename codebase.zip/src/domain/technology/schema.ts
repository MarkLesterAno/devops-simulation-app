import { z } from "zod";
import { componentTypeSchema } from "@/domain/architecture/schema";

/**
 * Technology catalog model per docs/TECHNOLOGY_CATALOG_IMPLEMENTATION_PROMPT.md.
 *
 * Technology assignments are *educational metadata*. Selecting a technology never
 * provisions, connects to, or validates a live service, and the simulation engine
 * stays provider-agnostic: provider-specific products map onto generic component
 * behavior through the optional, versioned `simulationPreset` only.
 */

export const deploymentModelSchema = z.enum([
  "managed-cloud",
  "self-managed",
  "open-source",
  "saas",
  "on-premises"
]);
export type DeploymentModel = z.infer<typeof deploymentModelSchema>;

/**
 * Lifecycle marker. `legacy` and `deprecated` entries remain selectable so saved
 * projects keep working, but the inspector surfaces a warning for them.
 */
export const technologyStatusSchema = z.enum(["current", "legacy", "deprecated"]);
export type TechnologyStatus = z.infer<typeof technologyStatusSchema>;

/**
 * A role-scoped caveat, e.g. "analytical warehouse rather than OLTP" or
 * "workflow orchestration rather than a queue". When `componentTypes` is set the
 * advisory only applies while the technology is used in those roles.
 */
export const technologyAdvisorySchema = z.object({
  message: z.string().min(1),
  componentTypes: z.array(componentTypeSchema).nonempty().optional()
});
export type TechnologyAdvisory = z.infer<typeof technologyAdvisorySchema>;

/**
 * Educational defaults only. These are coarse, order-of-magnitude teaching values
 * chosen to contrast architectural trade-offs; they are explicitly NOT vendor
 * benchmarks, SLAs, or performance guarantees.
 */
export const simulationPresetSchema = z
  .object({
    perInstanceCapacityRps: z.number().min(0).optional(),
    baseLatencyMs: z.number().min(0).optional(),
    jitterMs: z.number().min(0).optional(),
    timeoutMs: z.number().min(1).optional(),
    errorRate: z.number().min(0).max(1).optional(),
    hitRatio: z.number().min(0).max(1).optional(),
    estimatedCostPerHour: z.number().min(0).optional()
  })
  .refine((preset) => Object.values(preset).some((value) => value !== undefined), {
    message: "A simulation preset must define at least one field."
  });
export type SimulationPreset = z.infer<typeof simulationPresetSchema>;

export const technologyOptionSchema = z.object({
  id: z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, "Technology ids must be kebab-case."),
  displayName: z.string().min(1),
  provider: z.string().min(1),
  deploymentModel: z.array(deploymentModelSchema).nonempty(),
  componentTypes: z.array(componentTypeSchema).nonempty(),
  description: z.string().min(1),
  capabilities: z.array(z.string().min(1)),
  /** Role-specific capabilities shown instead of `capabilities` for a given component type. */
  roleCapabilities: z.record(componentTypeSchema, z.array(z.string().min(1))).optional(),
  status: technologyStatusSchema.default("current"),
  advisories: z.array(technologyAdvisorySchema).default([]),
  /** Non-canonical names recorded separately so they never become duplicate entries. */
  aliases: z.array(z.string().min(1)).default([]),
  simulationPreset: simulationPresetSchema.optional(),
  documentationUrl: z.string().url().optional(),
  modelVersion: z.string().min(1)
});
export type TechnologyOption = z.infer<typeof technologyOptionSchema>;

/** Input type before Zod applies defaults, used by the per-domain data modules. */
export type TechnologyOptionInput = z.input<typeof technologyOptionSchema>;

/**
 * Assignment stored on a node. Defined in the architecture schema to keep the
 * project document self-contained; re-exported here for catalog consumers.
 */
export { technologyAssignmentSchema } from "@/domain/architecture/schema";
export type { TechnologyAssignment } from "@/domain/architecture/schema";

/** Sentinel used by the UI for the explicit "no specific product" choice. */
export const GENERIC_TECHNOLOGY_ID = "generic-custom";

/** Current catalog version; bump alongside `TECHNOLOGY_ID_MIGRATIONS`. */
export const TECHNOLOGY_CATALOG_VERSION = "1.0.0";

/**
 * Migration map for renamed identifiers. Saved projects referencing an old id are
 * transparently resolved to the current entry instead of being reported unknown.
 */
export const TECHNOLOGY_ID_MIGRATIONS: Record<string, string> = {};
