import { z } from "zod";
import { faultTypeSchema, type FaultType } from "@/domain/simulation/faultScenario";
import type { ScenarioTemplate } from "@/domain/scenarios/builder";
import { buildScenarioRequestPresets } from "@/domain/scenarios/requestPresets";

export const scenarioFaultPresetSchema = z.object({
  id: z.string().min(1),
  scenarioId: z.string().min(1),
  name: z.string().min(1),
  description: z.string().min(1),
  targetNodeIds: z.array(z.string()).min(1),
  faultType: faultTypeSchema,
  startsAtMs: z.number().min(0),
  durationMs: z.number().positive().optional(),
  pairedRequestPresetId: z.string().min(1),
  teachingNote: z.string().min(1),
  remediationHint: z.string().min(1)
});
export type ScenarioFaultPreset = z.infer<typeof scenarioFaultPresetSchema>;

/** Describes existing persisted faults without giving them privileged runtime behavior. */
export function buildScenarioFaultPresets(template: ScenarioTemplate): ScenarioFaultPreset[] {
  const requests = buildScenarioRequestPresets(template);
  const pairedRequestPresetId = requests.find((preset) => preset.intent === "sustained")!.id;
  return template.blueprint.faultScenarios.flatMap((entry) => {
    const scenario = entry as {
      id: string;
      name: string;
      faults: Array<{ id: string; type: FaultType; target: { nodeIds: string[] }; startMs: number; endMs?: number }>;
    };
    return scenario.faults.map((fault) =>
      scenarioFaultPresetSchema.parse({
        id: `${template.metadata.id}-${fault.id}`,
        scenarioId: template.metadata.id,
        name: scenario.name,
        description: `Inject ${fault.type} into ${fault.target.nodeIds.join(", ")} while sustained traffic is running.`,
        targetNodeIds: fault.target.nodeIds,
        faultType: faultTypeSchema.parse(fault.type),
        startsAtMs: fault.startMs,
        ...(fault.endMs ? { durationMs: fault.endMs - fault.startMs } : {}),
        pairedRequestPresetId,
        teachingNote: "Compare the run with and without this fault using the same seed and request preset.",
        remediationHint:
          "Consider redundancy, capacity headroom, or isolation, while accounting for the added cost and operational complexity."
      })
    );
  });
}
