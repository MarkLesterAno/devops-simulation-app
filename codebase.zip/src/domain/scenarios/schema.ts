import { z } from "zod";
import { componentTypeSchema } from "@/domain/architecture/schema";

/**
 * Scenario template contract, per
 * SCENARIO_LIBRARY_AND_USER_DOCUMENTATION_PROMPT.md section 4.
 *
 * A scenario is an example architecture plus the teaching material that makes
 * it useful: what it models, what it deliberately does not model, and what the
 * learner should try next. Metadata is kept separate from the project document
 * so the gallery can filter and search without materialising every template.
 */

export const scenarioDifficultySchema = z.enum([
  "beginner",
  "intermediate",
  "advanced",
  "specialized"
]);
export type ScenarioDifficulty = z.infer<typeof scenarioDifficultySchema>;

export const tutorialModeSchema = z.enum(["guided-tour", "build", "challenge"]);
export type TutorialMode = z.infer<typeof tutorialModeSchema>;

/**
 * The dimension a workload is most sensitive to. Stated explicitly because it
 * determines which metric a learner should be reading first.
 */
export const workloadShapeSchema = z.enum([
  "read-heavy",
  "write-heavy",
  "latency-sensitive",
  "throughput-sensitive",
  "consistency-sensitive",
  "availability-sensitive"
]);
export type WorkloadShape = z.infer<typeof workloadShapeSchema>;

/**
 * A real-world concept the simulator has no first-class component for, modelled
 * by a generic stand-in. Declared per template so the documentation and the
 * gallery can be honest about the approximation rather than implying the
 * simulator understands, say, a web application firewall.
 */
export const scenarioStandInSchema = z.object({
  concept: z.string().min(1),
  modelledAs: componentTypeSchema,
  rationale: z.string().min(1)
});
export type ScenarioStandIn = z.infer<typeof scenarioStandInSchema>;

export const requirementBriefSchema = z.object({
  id: z.string().min(1),
  problemStatement: z.string().min(1),
  functionalRequirements: z.array(z.string().min(1)).min(1),
  constraints: z.array(z.string().min(1)).min(1),
  outOfScope: z.array(z.string().min(1)).min(1)
});
export type RequirementBrief = z.infer<typeof requirementBriefSchema>;

export const scenarioTemplateMetadataSchema = z.object({
  id: z.string().min(1).regex(/^[a-z0-9-]+$/, "Template ids are lowercase kebab-case"),
  version: z.string().regex(/^\d+\.\d+\.\d+$/, "Template versions are semantic"),
  name: z.string().min(1).max(120),
  summary: z.string().min(1),
  difficulty: scenarioDifficultySchema,
  tags: z.array(z.string().min(1)).min(1),
  learningObjectives: z.array(z.string().min(1)).min(1),
  estimatedCompletionMinutes: z.number().int().min(1).max(480),
  recommendedPrerequisites: z.array(z.string().min(1)),
  supportedComponentTypes: z.array(componentTypeSchema).min(1),
  defaultTrafficProfileId: z.string().min(1),
  defaultFaultScenarioIds: z.array(z.string().min(1)),
  /** Repository-relative path to the scenario's Markdown documentation. */
  documentationPath: z.string().min(1),
  workloadShapes: z.array(workloadShapeSchema).min(1),
  /** Behaviours this template genuinely exercises in the engine. */
  modelledProperties: z.array(z.string().min(1)).min(1),
  /** Real-world concerns the template simplifies or omits outright. */
  simplifications: z.array(z.string().min(1)).min(1),
  standIns: z.array(scenarioStandInSchema),
  /** Finding codes a default run is expected to raise. */
  expectedFindings: z.array(z.string().min(1)),
  challenges: z.array(z.string().min(1)).min(1)
});
export type ScenarioTemplateMetadata = z.infer<typeof scenarioTemplateMetadataSchema>;
