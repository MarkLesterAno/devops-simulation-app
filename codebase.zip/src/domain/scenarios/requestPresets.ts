import { z } from "zod";
import type { ManualRequestDefinition } from "@/domain/simulation/manualRequest";
import type { ScenarioTemplate } from "@/domain/scenarios/builder";

export const scenarioRequestIntentSchema = z.enum([
  "baseline",
  "read-path",
  "write-path",
  "burst",
  "sustained",
  "boundary",
  "overload"
]);
export type ScenarioRequestIntent = z.infer<typeof scenarioRequestIntentSchema>;

export const scenarioRequestPresetSchema = z.object({
  id: z.string().min(1),
  scenarioId: z.string().min(1),
  name: z.string().min(1),
  description: z.string().min(1),
  intent: scenarioRequestIntentSchema,
  expectedOutcome: z.object({
    expectSuccess: z.boolean(),
    notes: z.string().min(1)
  }),
  request: z.object({
    sourceNodeId: z.string().min(1),
    method: z.enum(["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]),
    requestCount: z.number().int().min(1),
    dispatchRateRps: z.number().positive(),
    startAtMs: z.number().min(0),
    requestClass: z.enum(["read", "write", "auth-required"]).optional(),
    payloadSizeBytes: z.number().min(0).optional(),
    responseSizeBytes: z.number().min(0).optional(),
    timeoutMs: z.number().positive().optional(),
    seed: z.number().int(),
    label: z.string().min(1)
  })
});
export type ScenarioRequestPreset = z.infer<typeof scenarioRequestPresetSchema>;

function peakRps(template: ScenarioTemplate): number {
  return Math.max(
    1,
    ...template.blueprint.trafficProfiles.flatMap((profile) => {
      const candidate = profile as { intervals?: Array<{ startRps?: number; endRps?: number }> };
      return (candidate.intervals ?? []).flatMap((interval) => [
        interval.startRps ?? 0,
        interval.endRps ?? 0
      ]);
    })
  );
}

function modeledCapacityRps(template: ScenarioTemplate): number {
  const capacities = template.blueprint.nodes.flatMap((node) => {
    const configuration = node.config as
      | { perInstanceCapacityRps?: number; instanceCount?: number }
      | undefined;
    if (!configuration?.perInstanceCapacityRps || configuration.perInstanceCapacityRps <= 0) {
      return [];
    }
    return [configuration.perInstanceCapacityRps * Math.max(1, configuration.instanceCount ?? 1)];
  });
  return capacities.length > 0 ? Math.min(...capacities) : peakRps(template);
}

/**
 * Creates deterministic request exercises from the reference topology. A
 * request class is a logical signal to the simulator, not real HTTP traffic;
 * the UI describes only outcomes it can observe reliably.
 */
export function buildScenarioRequestPresets(template: ScenarioTemplate): ScenarioRequestPreset[] {
  const source = template.blueprint.nodes.find((node) => node.type === "client");
  if (!source) {
    throw new Error(`Scenario "${template.metadata.id}" needs a client node for request presets.`);
  }

  const profile = template.blueprint.trafficProfiles.find(
    (entry) => (entry as { id?: string }).id === template.metadata.defaultTrafficProfileId
  ) as { readRatio?: number; requestSizeBytes?: number; responseSizeBytes?: number } | undefined;
  if (!profile) {
    throw new Error(
      `Scenario "${template.metadata.id}" has no default profile for request preset generation.`
    );
  }

  const rate = Math.ceil(peakRps(template));
  const capacity = Math.ceil(modeledCapacityRps(template));
  const writeFocused = (profile.readRatio ?? 0.8) < 0.5;
  const pathMethod = writeFocused ? "POST" : "GET";
  const boundaryRate = Math.max(1, Math.floor(capacity * 0.9));
  const overloadRate = capacity + Math.max(1, Math.ceil(capacity * 0.25));
  const base = {
    scenarioId: template.metadata.id,
    request: {
      sourceNodeId: source.id,
      startAtMs: 0,
      payloadSizeBytes: profile.requestSizeBytes,
      responseSizeBytes: profile.responseSizeBytes,
      timeoutMs: 5_000
    }
  };

  return [
    scenarioRequestPresetSchema.parse({
      ...base,
      id: `${template.metadata.id}-baseline`,
      name: "Baseline request flow",
      description: `Nominal ${rate} RPS traffic matching the default profile.`,
      intent: "baseline",
      expectedOutcome: { expectSuccess: true, notes: "Compare nominal latency and throughput." },
      request: {
        ...base.request,
        method: "GET",
        requestClass: "read",
        requestCount: rate * 10,
        dispatchRateRps: rate,
        seed: 101,
        label: "Scenario baseline"
      }
    }),
    scenarioRequestPresetSchema.parse({
      ...base,
      id: `${template.metadata.id}-read-path`,
      name: "Read path",
      description: "A deterministic read-oriented batch for cache, replica, or read traffic analysis.",
      intent: "read-path",
      expectedOutcome: { expectSuccess: true, notes: "Compare read-path latency and component utilization." },
      request: {
        ...base.request,
        method: "GET",
        requestClass: "read",
        requestCount: rate * 10,
        dispatchRateRps: rate,
        seed: 202,
        label: "Scenario read path"
      }
    }),
    scenarioRequestPresetSchema.parse({
      ...base,
      id: `${template.metadata.id}-write-path`,
      name: "Write path",
      description: "A deterministic write-oriented batch for primary-store, queue producer, or transactional analysis.",
      intent: "write-path",
      expectedOutcome: { expectSuccess: true, notes: "Compare write-path latency and persistence pressure." },
      request: {
        ...base.request,
        method: "POST",
        requestClass: "write",
        requestCount: rate * 10,
        dispatchRateRps: rate,
        seed: 303,
        label: "Scenario write path"
      }
    }),
    scenarioRequestPresetSchema.parse({
      ...base,
      id: `${template.metadata.id}-burst`,
      name: "Burst load",
      description: "A short high-volume burst that reveals queueing and saturation behavior.",
      intent: "burst",
      expectedOutcome: { expectSuccess: false, notes: "Inspect tail latency, queue depth, and rejected work." },
      request: {
        ...base.request,
        method: pathMethod,
        requestClass: writeFocused ? "write" : "read",
        requestCount: overloadRate * 2,
        dispatchRateRps: overloadRate * 2,
        seed: 404,
        label: "Scenario burst"
      }
    }),
    scenarioRequestPresetSchema.parse({
      ...base,
      id: `${template.metadata.id}-sustained`,
      name: "Sustained load",
      description: "A longer deterministic batch for observing persistent utilization and queue growth.",
      intent: "sustained",
      expectedOutcome: { expectSuccess: true, notes: "Observe utilization trends over a full minute." },
      request: {
        ...base.request,
        method: pathMethod,
        requestClass: writeFocused ? "write" : "read",
        requestCount: rate * 60,
        dispatchRateRps: rate,
        seed: 505,
        label: "Scenario sustained load"
      }
    }),
    scenarioRequestPresetSchema.parse({
      ...base,
      id: `${template.metadata.id}-boundary`,
      name: "Capacity boundary",
      description: `Runs at ${boundaryRate} RPS, below the narrowest configured capacity of ${capacity} RPS.`,
      intent: "boundary",
      expectedOutcome: { expectSuccess: true, notes: "Compare latency immediately below the modeled capacity boundary." },
      request: {
        ...base.request,
        method: pathMethod,
        requestClass: writeFocused ? "write" : "read",
        requestCount: boundaryRate * 10,
        dispatchRateRps: boundaryRate,
        seed: 606,
        label: "Scenario capacity boundary"
      }
    }),
    scenarioRequestPresetSchema.parse({
      ...base,
      id: `${template.metadata.id}-overload`,
      name: "Capacity overload",
      description: `Runs at ${overloadRate} RPS, above the narrowest configured capacity of ${capacity} RPS.`,
      intent: "overload",
      expectedOutcome: { expectSuccess: false, notes: "Inspect the first saturated component and the resulting failure behavior." },
      request: {
        ...base.request,
        method: pathMethod,
        requestClass: writeFocused ? "write" : "read",
        requestCount: overloadRate * 10,
        dispatchRateRps: overloadRate,
        seed: 707,
        label: "Scenario capacity overload"
      }
    })
  ];
}

export function toManualRequestDefinition(preset: ScenarioRequestPreset): ManualRequestDefinition {
  return { id: `preset-${preset.id}`, ...preset.request };
}
