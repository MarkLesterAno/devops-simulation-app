/**
 * Traffic-profile and fault-scenario shorthands for scenario templates.
 *
 * These produce plain objects; `buildScenarioDocument` parses them through the
 * real schemas, so a malformed shorthand fails loudly at template build time.
 */

export interface ProfileOptions {
  readRatio?: number;
  concurrentUsers?: number;
  requestSizeBytes?: number;
  responseSizeBytes?: number;
}

export function constantProfile(
  id: string,
  name: string,
  durationMs: number,
  rps: number,
  options: ProfileOptions = {}
): Record<string, unknown> {
  return {
    id,
    name,
    durationMs,
    intervals: [{ kind: "constant", startMs: 0, endMs: durationMs, startRps: rps, endRps: rps }],
    ...options
  };
}

/** Steady baseline, a linear ramp to peak, then a steady plateau at peak. */
export function rampProfile(
  id: string,
  name: string,
  durationMs: number,
  baseRps: number,
  peakRps: number,
  options: ProfileOptions = {}
): Record<string, unknown> {
  const third = Math.round(durationMs / 3);
  return {
    id,
    name,
    durationMs,
    intervals: [
      { kind: "constant", startMs: 0, endMs: third, startRps: baseRps, endRps: baseRps },
      { kind: "ramp", startMs: third, endMs: third * 2, startRps: baseRps, endRps: peakRps },
      { kind: "constant", startMs: third * 2, endMs: durationMs, startRps: peakRps, endRps: peakRps }
    ],
    ...options
  };
}

/** Baseline traffic interrupted by a short high-rate burst, then recovery. */
export function burstProfile(
  id: string,
  name: string,
  durationMs: number,
  baseRps: number,
  burstRps: number,
  burstStartMs: number,
  burstEndMs: number,
  options: ProfileOptions = {}
): Record<string, unknown> {
  return {
    id,
    name,
    durationMs,
    intervals: [
      { kind: "constant", startMs: 0, endMs: burstStartMs, startRps: baseRps, endRps: baseRps },
      { kind: "burst", startMs: burstStartMs, endMs: burstEndMs, startRps: burstRps, endRps: burstRps },
      { kind: "constant", startMs: burstEndMs, endMs: durationMs, startRps: baseRps, endRps: baseRps }
    ],
    ...options
  };
}

export interface FaultOptions {
  endMs?: number;
  capacityMultiplier?: number;
  additionalLatencyMs?: number;
  additionalErrorRate?: number;
  trafficMultiplier?: number;
  edgeIds?: string[];
  region?: string;
}

export function faultScenario(
  id: string,
  name: string,
  faults: Record<string, unknown>[]
): Record<string, unknown> {
  return { id, name, faults };
}

export function fault(
  id: string,
  type: string,
  nodeIds: string[],
  startMs: number,
  options: FaultOptions = {}
): Record<string, unknown> {
  const { edgeIds = [], region, ...rest } = options;
  return {
    id,
    type,
    target: { nodeIds, edgeIds, ...(region ? { region } : {}) },
    startMs,
    ...rest
  };
}
