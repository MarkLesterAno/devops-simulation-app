import type { ScenarioTemplate } from "@/domain/scenarios/builder";
import { burstProfile, constantProfile, fault, faultScenario } from "@/domain/scenarios/profiles";

/**
 * Beginner scenarios: a single synchronous path from client to store, with one
 * clear bottleneck and one clear failure mode each.
 */

const basicWebApplication: ScenarioTemplate = {
  metadata: {
    id: "basic-web-application",
    version: "1.0.0",
    name: "Basic Web Application",
    summary:
      "A single synchronous path from client through DNS and a load balancer to one application server and one relational database.",
    difficulty: "beginner",
    tags: ["web", "three-tier", "latency", "single-point-of-failure"],
    learningObjectives: [
      "Trace a synchronous request from client to database and back",
      "Read utilisation to find which component saturates first",
      "Recognise a single point of failure from the architecture alone",
      "Observe what a node outage does to success rate and latency"
    ],
    estimatedCompletionMinutes: 20,
    recommendedPrerequisites: [],
    supportedComponentTypes: [
      "client",
      "dns-traffic-manager",
      "load-balancer",
      "server",
      "relational-database"
    ],
    defaultTrafficProfileId: "steady-100",
    defaultFaultScenarioIds: ["app-server-outage"],
    documentationPath: "docs/scenarios/basic-web-application.md",
    workloadShapes: ["read-heavy", "latency-sensitive"],
    modelledProperties: [
      "Per-hop base latency and jitter accumulating into end-to-end latency",
      "Server capacity expressed as instances × per-instance RPS",
      "Queueing and overflow once arrival rate exceeds capacity",
      "Total loss of a component during a node outage"
    ],
    simplifications: [
      "TLS handshakes, connection pooling, and keep-alive are not modelled",
      "The database is a single logical node with no connection limit or lock contention",
      "DNS resolution is one hop with a TTL; recursive resolver hierarchies are not modelled"
    ],
    standIns: [],
    expectedFindings: ["single-point-of-failure"],
    challenges: [
      "Raise the server to three instances and compare p95 latency before and after",
      "Add a read replica and route read traffic to it",
      "Lower the database capacity until it, not the server, becomes the bottleneck"
    ]
  },
  blueprint: {
    projectName: "Basic Web Application",
    nodes: [
      { id: "client", type: "client", x: 0, y: 220, config: { displayName: "Browser Client" } },
      {
        id: "dns",
        type: "dns-traffic-manager",
        x: 200,
        y: 220,
        technology: "cloudflare-dns",
        config: { displayName: "DNS", ttlSeconds: 60, policy: "failover" }
      },
      {
        id: "lb",
        type: "load-balancer",
        x: 420,
        y: 220,
        technology: "aws-application-load-balancer",
        config: { displayName: "Load Balancer", perInstanceCapacityRps: 5000 }
      },
      {
        id: "app",
        type: "server",
        x: 640,
        y: 220,
        technology: "nodejs",
        config: {
          displayName: "Application Server",
          instanceCount: 1,
          perInstanceCapacityRps: 120,
          baseLatencyMs: 35,
          jitterMs: 12,
          estimatedCostPerHour: 0.12
        }
      },
      {
        id: "db",
        type: "relational-database",
        x: 880,
        y: 220,
        technology: "postgresql",
        config: {
          displayName: "Primary Database",
          perInstanceCapacityRps: 300,
          baseLatencyMs: 22,
          jitterMs: 6,
          estimatedCostPerHour: 0.25
        }
      }
    ],
    edges: [
      { from: "client", to: "dns", kind: "request" },
      { from: "dns", to: "lb", kind: "request", latencyMs: 4 },
      { from: "lb", to: "app", kind: "request", latencyMs: 2 },
      { from: "app", to: "db", kind: "request", latencyMs: 3 }
    ],
    trafficProfiles: [
      constantProfile("steady-100", "Steady 100 RPS", 30_000, 100, { readRatio: 0.8 }),
      burstProfile("lunch-peak", "Lunchtime peak", 40_000, 80, 260, 15_000, 25_000, {
        readRatio: 0.8
      })
    ],
    faultScenarios: [
      faultScenario("app-server-outage", "Application server outage", [
        fault("outage-1", "node-outage", ["app"], 12_000, { endMs: 20_000 })
      ]),
      faultScenario("database-slowdown", "Database slowdown", [
        fault("latency-1", "latency-increase", ["db"], 10_000, {
          endMs: 25_000,
          additionalLatencyMs: 180
        })
      ])
    ]
  }
};

const urlShortener: ScenarioTemplate = {
  metadata: {
    id: "url-shortener",
    version: "1.0.0",
    name: "URL Shortener",
    summary:
      "A read-dominated redirect service fronted by a CDN, served from a cache, and backed by a partitioned key-value store.",
    difficulty: "beginner",
    tags: ["read-heavy", "cache", "hot-key", "key-value"],
    learningObjectives: [
      "Quantify how cache hit ratio changes origin load",
      "See why a read-heavy workload tolerates a small, fast data path",
      "Understand hot-partition skew and why it defeats average-case capacity",
      "Observe the load transfer when a cache fails"
    ],
    estimatedCompletionMinutes: 25,
    recommendedPrerequisites: ["basic-web-application"],
    supportedComponentTypes: [
      "client",
      "cdn",
      "load-balancer",
      "server",
      "cache",
      "nosql-database"
    ],
    defaultTrafficProfileId: "redirect-traffic",
    defaultFaultScenarioIds: ["cache-outage"],
    documentationPath: "docs/scenarios/url-shortener.md",
    workloadShapes: ["read-heavy", "latency-sensitive"],
    modelledProperties: [
      "Cache hit ratio and the miss path to the origin store",
      "CDN edge hit ratio ahead of the application tier",
      "Hot-partition skew concentrating load on one partition of the key-value store",
      "Cache failure shifting the full read rate onto the origin"
    ],
    simplifications: [
      "Short-code generation, collision handling, and ID encoding are not modelled",
      "Cache eviction is a configured hit ratio, not a simulated working set",
      "HTTP redirect semantics are not modelled; a redirect is just a response"
    ],
    standIns: [
      {
        concept: "Key-value store (DynamoDB, Cassandra)",
        modelledAs: "nosql-database",
        rationale:
          "The NoSQL component's key-value model, partition count, and hot-partition skew cover the behaviour that matters here."
      }
    ],
    expectedFindings: [],
    challenges: [
      "Drop the cache hit ratio from 0.92 to 0.5 and measure the origin RPS increase",
      "Raise hot-partition skew to 0.8 and watch tail latency separate from the median",
      "Run the cache-outage scenario and decide what capacity the store would need to survive it"
    ]
  },
  blueprint: {
    projectName: "URL Shortener",
    nodes: [
      { id: "client", type: "client", x: 0, y: 220, config: { displayName: "Client" } },
      {
        id: "cdn",
        type: "cdn",
        x: 200,
        y: 220,
        technology: "cloudflare-cdn",
        config: { displayName: "CDN", hitRatio: 0.35, baseLatencyMs: 12 }
      },
      {
        id: "lb",
        type: "load-balancer",
        x: 400,
        y: 220,
        technology: "nginx",
        config: { displayName: "Load Balancer", perInstanceCapacityRps: 8000 }
      },
      {
        id: "redirect",
        type: "server",
        x: 610,
        y: 220,
        technology: "nodejs",
        config: {
          displayName: "Redirect Service",
          instanceCount: 3,
          perInstanceCapacityRps: 400,
          baseLatencyMs: 8,
          jitterMs: 3,
          estimatedCostPerHour: 0.09
        }
      },
      {
        id: "cache",
        type: "cache",
        x: 830,
        y: 140,
        technology: "redis",
        config: {
          displayName: "Link Cache",
          hitRatio: 0.92,
          ttlMs: 300_000,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 5000,
          estimatedCostPerHour: 0.08
        }
      },
      {
        id: "store",
        type: "nosql-database",
        x: 1060,
        y: 140,
        technology: "amazon-dynamodb",
        config: {
          displayName: "Link Store",
          model: "key-value",
          consistency: "eventual",
          partitionCount: 8,
          hotPartitionSkew: 0.35,
          replicationLagMs: 40,
          perInstanceCapacityRps: 500,
          baseLatencyMs: 9,
          estimatedCostPerHour: 0.2
        }
      }
    ],
    edges: [
      { from: "client", to: "cdn", kind: "request" },
      { from: "cdn", to: "lb", kind: "request", latencyMs: 6 },
      { from: "lb", to: "redirect", kind: "request", latencyMs: 1 },
      { from: "redirect", to: "cache", kind: "request", latencyMs: 1 },
      { from: "cache", to: "store", kind: "request", latencyMs: 2 }
    ],
    trafficProfiles: [
      constantProfile("redirect-traffic", "Redirect traffic 600 RPS", 30_000, 600, {
        readRatio: 0.97,
        requestSizeBytes: 256,
        responseSizeBytes: 512
      }),
      burstProfile("viral-link", "Viral link burst", 40_000, 400, 2200, 12_000, 22_000, {
        readRatio: 0.99,
        requestSizeBytes: 256,
        responseSizeBytes: 512
      })
    ],
    faultScenarios: [
      faultScenario("cache-outage", "Link cache outage", [
        fault("cache-1", "cache-failure", ["cache"], 12_000, { endMs: 24_000 })
      ]),
      faultScenario("hot-partition", "Hot partition pressure", [
        fault("hot-1", "partition-hotspot", ["store"], 10_000, {
          endMs: 26_000,
          additionalLatencyMs: 120
        })
      ])
    ]
  }
};

const fileUploadService: ScenarioTemplate = {
  metadata: {
    id: "file-upload-service",
    version: "1.0.0",
    name: "Simple File Upload Service",
    summary:
      "A write-heavy upload path that stores bytes in object storage and records metadata in a relational database behind an API gateway.",
    difficulty: "beginner",
    tags: ["upload", "object-storage", "write-heavy", "api-gateway"],
    learningObjectives: [
      "Separate a bulk data path from a metadata path",
      "See how large request payloads change throughput and cost",
      "Understand why an upload service fans out to two different stores",
      "Observe retries against a slow storage dependency"
    ],
    estimatedCompletionMinutes: 25,
    recommendedPrerequisites: ["basic-web-application"],
    supportedComponentTypes: [
      "client",
      "api-gateway",
      "server",
      "object-storage",
      "relational-database"
    ],
    defaultTrafficProfileId: "upload-traffic",
    defaultFaultScenarioIds: ["storage-slowdown"],
    documentationPath: "docs/scenarios/file-upload-service.md",
    workloadShapes: ["write-heavy", "throughput-sensitive"],
    modelledProperties: [
      "Gateway policy latency ahead of the application tier",
      "One request fanning out to two downstream dependencies",
      "Object storage latency dominating a write-heavy path",
      "Retry attempts and their amplification of a slow dependency"
    ],
    simplifications: [
      "Payload size is a number used for cost and throughput accounting; no bytes are transferred",
      "Multipart uploads, resumable uploads, and presigned URLs are not modelled",
      "Virus scanning, content inspection, and thumbnailing are out of scope"
    ],
    standIns: [],
    expectedFindings: [],
    challenges: [
      "Move metadata writes behind a queue and compare upload latency",
      "Raise maxRetries on the upload service during the storage slowdown and explain the result",
      "Add a CDN in front of downloads and model a read-heavy profile"
    ]
  },
  blueprint: {
    projectName: "Simple File Upload Service",
    nodes: [
      { id: "client", type: "client", x: 0, y: 240, config: { displayName: "Uploader Client" } },
      {
        id: "gateway",
        type: "api-gateway",
        x: 220,
        y: 240,
        technology: "amazon-api-gateway",
        config: {
          displayName: "API Gateway",
          authMode: "none",
          policyLatencyMs: 4,
          perInstanceCapacityRps: 2000
        }
      },
      {
        id: "upload",
        type: "server",
        x: 470,
        y: 240,
        technology: "spring-boot",
        config: {
          displayName: "Upload Service",
          instanceCount: 3,
          perInstanceCapacityRps: 60,
          baseLatencyMs: 45,
          jitterMs: 15,
          maxRetries: 2,
          retryBackoffMs: 200,
          timeoutMs: 8000,
          estimatedCostPerHour: 0.18
        }
      },
      {
        id: "objects",
        type: "object-storage",
        x: 740,
        y: 160,
        technology: "amazon-s3",
        config: {
          displayName: "Object Storage",
          perInstanceCapacityRps: 250,
          baseLatencyMs: 90,
          jitterMs: 30,
          estimatedCostPerHour: 0.06
        }
      },
      {
        id: "metadata",
        type: "relational-database",
        x: 740,
        y: 340,
        technology: "postgresql",
        config: {
          displayName: "Metadata Database",
          perInstanceCapacityRps: 400,
          baseLatencyMs: 18,
          estimatedCostPerHour: 0.22
        }
      }
    ],
    edges: [
      { from: "client", to: "gateway", kind: "request" },
      { from: "gateway", to: "upload", kind: "request", latencyMs: 2 },
      { from: "upload", to: "objects", kind: "request", latencyMs: 5 },
      { from: "upload", to: "metadata", kind: "request", latencyMs: 2 }
    ],
    trafficProfiles: [
      constantProfile("upload-traffic", "Uploads 120 RPS", 30_000, 120, {
        readRatio: 0.2,
        requestSizeBytes: 1_500_000,
        responseSizeBytes: 512
      }),
      burstProfile("bulk-import", "Bulk import burst", 40_000, 80, 400, 14_000, 24_000, {
        readRatio: 0.1,
        requestSizeBytes: 2_000_000,
        responseSizeBytes: 512
      })
    ],
    faultScenarios: [
      faultScenario("storage-slowdown", "Object storage slowdown", [
        fault("storage-1", "latency-increase", ["objects"], 10_000, {
          endMs: 24_000,
          additionalLatencyMs: 450
        })
      ]),
      faultScenario("metadata-outage", "Metadata database outage", [
        fault("meta-1", "database-primary-failure", ["metadata"], 12_000, { endMs: 22_000 })
      ])
    ]
  }
};

export const beginnerScenarios: ScenarioTemplate[] = [
  basicWebApplication,
  urlShortener,
  fileUploadService
];
