import type { ScenarioTemplate } from "@/domain/scenarios/builder";
import {
  burstProfile,
  constantProfile,
  fault,
  faultScenario,
  rampProfile
} from "@/domain/scenarios/profiles";

/**
 * Advanced scenarios: multi-region topologies, third-party dependencies,
 * fan-out pipelines, and failure modes whose blast radius depends on where the
 * architecture chose to put its boundaries.
 */

const multiRegionEcommerce: ScenarioTemplate = {
  metadata: {
    id: "multi-region-ecommerce",
    version: "1.0.0",
    name: "Multi-Region E-Commerce",
    summary:
      "An active-active read topology across two regions with a single write primary, geo-routed at DNS and backed by asynchronous replication to regional read replicas.",
    difficulty: "advanced",
    tags: ["multi-region", "replication", "failover", "dns", "consistency"],
    learningObjectives: [
      "Separate a globally distributed read path from a single-region write path",
      "Quantify what cross-region write latency costs the user-facing p95",
      "Reason about replication lag as a correctness problem, not just a delay",
      "Observe how DNS TTL bounds the speed of any regional failover"
    ],
    estimatedCompletionMinutes: 60,
    recommendedPrerequisites: ["ecommerce-storefront", "basic-web-application"],
    supportedComponentTypes: [
      "client",
      "dns-traffic-manager",
      "load-balancer",
      "server",
      "cache",
      "relational-database",
      "read-replica",
      "observability"
    ],
    defaultTrafficProfileId: "global-daily-cycle",
    defaultFaultScenarioIds: ["eu-regional-outage"],
    workloadShapes: ["read-heavy", "availability-sensitive", "consistency-sensitive"],
    documentationPath: "docs/scenarios/multi-region-ecommerce.md",
    modelledProperties: [
      "Weighted DNS distribution of traffic across two regional entry points",
      "Cross-region request latency on the write path to the single primary",
      "Replication edges carrying lag from the primary to each regional replica",
      "Loss of an entire region's nodes during a regional outage"
    ],
    simplifications: [
      "Failover is modelled as traffic redistribution, not as an automated controller: the simulator has no failover-controller component, so DNS weights and TTL stand in for the decision",
      "Replication is one-way and never conflicts; multi-primary conflict resolution is not modelled",
      "Data residency, regional pricing, and inter-region egress cost are not modelled"
    ],
    standIns: [
      {
        concept: "Regional failover controller",
        modelledAs: "dns-traffic-manager",
        rationale:
          "The DNS component already owns routing policy and TTL, which are the two properties that actually determine how quickly traffic leaves a failed region."
      }
    ],
    expectedFindings: ["multi-region-no-failover"],
    challenges: [
      "Drop the DNS TTL from 60s to 10s and measure how much sooner traffic leaves the failed region",
      "Promote the EU replica to a second primary and describe what the simulator can no longer tell you about correctness",
      "Raise EU replication lag to 2000ms and decide which reads may no longer be served there"
    ]
  },
  blueprint: {
    projectName: "Multi-Region E-Commerce",
    nodes: [
      { id: "client", type: "client", x: 0, y: 400, config: { displayName: "Global Client" } },
      {
        id: "dns",
        type: "dns-traffic-manager",
        x: 200,
        y: 400,
        technology: "amazon-route-53",
        config: {
          displayName: "Global DNS",
          ttlSeconds: 60,
          resolutionLatencyMs: 18,
          policy: "geo"
        }
      },
      {
        id: "lb-us",
        type: "load-balancer",
        x: 440,
        y: 220,
        technology: "aws-application-load-balancer",
        config: { displayName: "US Load Balancer", region: "us-east", perInstanceCapacityRps: 8000 }
      },
      {
        id: "lb-eu",
        type: "load-balancer",
        x: 440,
        y: 620,
        technology: "aws-application-load-balancer",
        config: { displayName: "EU Load Balancer", region: "eu-west", perInstanceCapacityRps: 8000 }
      },
      {
        id: "app-us",
        type: "server",
        x: 680,
        y: 220,
        technology: "spring-boot",
        config: {
          displayName: "US Application",
          region: "us-east",
          instanceCount: 6,
          perInstanceCapacityRps: 140,
          baseLatencyMs: 24,
          jitterMs: 9,
          estimatedCostPerHour: 0.42
        }
      },
      {
        id: "app-eu",
        type: "server",
        x: 680,
        y: 620,
        technology: "spring-boot",
        config: {
          displayName: "EU Application",
          region: "eu-west",
          instanceCount: 4,
          perInstanceCapacityRps: 140,
          baseLatencyMs: 24,
          jitterMs: 9,
          estimatedCostPerHour: 0.28
        }
      },
      {
        id: "cache-us",
        type: "cache",
        x: 920,
        y: 100,
        technology: "amazon-elasticache",
        config: {
          displayName: "US Cache",
          region: "us-east",
          hitRatio: 0.86,
          ttlMs: 60_000,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 9000
        }
      },
      {
        id: "cache-eu",
        type: "cache",
        x: 920,
        y: 740,
        technology: "amazon-elasticache",
        config: {
          displayName: "EU Cache",
          region: "eu-west",
          hitRatio: 0.86,
          ttlMs: 60_000,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 9000
        }
      },
      {
        id: "db-primary",
        type: "relational-database",
        x: 1180,
        y: 400,
        technology: "amazon-aurora",
        config: {
          displayName: "Write Primary (US)",
          region: "us-east",
          perInstanceCapacityRps: 600,
          baseLatencyMs: 18,
          jitterMs: 6,
          estimatedCostPerHour: 0.95
        }
      },
      {
        id: "replica-us",
        type: "read-replica",
        x: 1180,
        y: 220,
        technology: "amazon-aurora",
        config: {
          displayName: "US Read Replica",
          region: "us-east",
          perInstanceCapacityRps: 800,
          baseLatencyMs: 14,
          estimatedCostPerHour: 0.55
        }
      },
      {
        id: "replica-eu",
        type: "read-replica",
        x: 1180,
        y: 620,
        technology: "amazon-aurora",
        config: {
          displayName: "EU Read Replica",
          region: "eu-west",
          perInstanceCapacityRps: 800,
          baseLatencyMs: 14,
          estimatedCostPerHour: 0.55
        }
      },
      {
        id: "telemetry",
        type: "observability",
        x: 920,
        y: 400,
        technology: "datadog",
        config: { displayName: "Global Telemetry", perInstanceCapacityRps: 20_000 }
      }
    ],
    edges: [
      { from: "client", to: "dns", kind: "request" },
      { from: "dns", to: "lb-us", kind: "request", latencyMs: 12, weight: 0.6 },
      { from: "dns", to: "lb-eu", kind: "request", latencyMs: 14, weight: 0.4 },
      { from: "lb-us", to: "app-us", kind: "request", latencyMs: 2 },
      { from: "lb-eu", to: "app-eu", kind: "request", latencyMs: 2 },
      { from: "app-us", to: "cache-us", kind: "request", latencyMs: 1 },
      { from: "app-eu", to: "cache-eu", kind: "request", latencyMs: 1 },
      { from: "app-us", to: "replica-us", kind: "request", latencyMs: 3 },
      { from: "app-eu", to: "replica-eu", kind: "request", latencyMs: 3 },
      { from: "app-us", to: "db-primary", kind: "request", latencyMs: 4 },
      { from: "app-eu", to: "db-primary", kind: "request", latencyMs: 85 },
      { from: "db-primary", to: "replica-us", kind: "replication", latencyMs: 20 },
      { from: "db-primary", to: "replica-eu", kind: "replication", latencyMs: 95 },
      { from: "app-us", to: "telemetry", kind: "observability" },
      { from: "app-eu", to: "telemetry", kind: "observability" },
      { from: "db-primary", to: "telemetry", kind: "observability" }
    ],
    trafficProfiles: [
      rampProfile("global-daily-cycle", "Global daily cycle", 60_000, 220, 700, {
        readRatio: 0.85,
        concurrentUsers: 4000
      }),
      constantProfile("steady-global", "Steady global load", 45_000, 400, { readRatio: 0.85 })
    ],
    faultScenarios: [
      faultScenario("eu-regional-outage", "EU region lost", [
        fault("eu-out", "regional-outage", ["lb-eu", "app-eu", "cache-eu", "replica-eu"], 20_000, {
          endMs: 45_000,
          region: "eu-west"
        })
      ]),
      faultScenario("stale-dns", "Stale DNS records delay failover", [
        fault("dns-stale", "stale-dns-record", ["dns"], 15_000, {
          endMs: 40_000,
          additionalLatencyMs: 60
        })
      ]),
      faultScenario("primary-failure", "Write primary fails", [
        fault("primary-down", "database-primary-failure", ["db-primary"], 18_000, { endMs: 38_000 })
      ])
    ]
  }
};

const paymentProcessingWorkflow: ScenarioTemplate = {
  metadata: {
    id: "payment-processing-workflow",
    version: "1.0.0",
    name: "Payment Processing Workflow",
    summary:
      "A checkout path that records an order synchronously and settles payment asynchronously through a rate-limited third-party processor behind a circuit breaker, with a dead-letter queue for poison messages.",
    difficulty: "advanced",
    tags: ["payments", "external-service", "circuit-breaker", "dead-letter-queue", "idempotency"],
    learningObjectives: [
      "Decouple an unreliable third-party dependency from the user-facing request",
      "Watch a circuit breaker trip and stop amplifying a failing provider",
      "Use a dead-letter queue to separate retryable failures from poison messages",
      "Explain why payment settlement needs idempotency keys"
    ],
    estimatedCompletionMinutes: 55,
    recommendedPrerequisites: ["ecommerce-storefront", "notification-delivery-platform"],
    supportedComponentTypes: [
      "client",
      "api-gateway",
      "identity-auth-service",
      "server",
      "relational-database",
      "message-queue",
      "worker",
      "circuit-breaker",
      "external-service",
      "dead-letter-queue",
      "observability"
    ],
    defaultTrafficProfileId: "checkout-load",
    defaultFaultScenarioIds: ["processor-throttling"],
    workloadShapes: ["write-heavy", "availability-sensitive", "consistency-sensitive"],
    documentationPath: "docs/scenarios/payment-processing-workflow.md",
    modelledProperties: [
      "Provider-side rate limiting and SLA latency on the external processor",
      "Circuit-breaker state transitions driven by observed downstream failure rate",
      "Settlement queue depth growing while the provider is throttled",
      "Dead-letter overflow once the settlement queue exceeds its depth limit"
    ],
    simplifications: [
      "No money moves and nothing is contacted: the external service is a latency and error model only",
      "Idempotency is a configuration flag, not an enforced deduplication mechanism",
      "Ledger correctness, double-entry accounting, and reconciliation are not modelled",
      "Card-network multi-leg authorisation and capture are collapsed into one call"
    ],
    standIns: [
      {
        concept: "Payment gateway / processor",
        modelledAs: "external-service",
        rationale:
          "What matters for simulation is a bounded third-party call with its own rate limit, SLA latency, and error behaviour, which the external-service component models directly."
      },
      {
        concept: "Workflow orchestrator",
        modelledAs: "worker",
        rationale:
          "The settlement worker plays the orchestrator's role. Durable multi-step state and compensation are not modelled; only the step that calls the provider is."
      }
    ],
    expectedFindings: [],
    challenges: [
      "Run the throttling scenario and find the point where the breaker opens",
      "Raise the worker's maxRetries and show that retries make the throttling worse",
      "Lower the settlement queue's maxQueueDepth until messages spill into the dead-letter queue"
    ]
  },
  blueprint: {
    projectName: "Payment Processing Workflow",
    nodes: [
      { id: "client", type: "client", x: 0, y: 340, config: { displayName: "Checkout Client" } },
      {
        id: "gateway",
        type: "api-gateway",
        x: 220,
        y: 340,
        technology: "amazon-api-gateway",
        config: {
          displayName: "API Gateway",
          authMode: "delegate",
          policyLatencyMs: 3,
          rateLimitRps: 400,
          rateLimitBurst: 200,
          perInstanceCapacityRps: 4000
        }
      },
      {
        id: "identity",
        type: "identity-auth-service",
        x: 220,
        y: 140,
        technology: "auth0",
        config: {
          displayName: "Identity Service",
          instanceCount: 2,
          mode: "authn",
          validationMode: "local-jwt",
          cacheHitRatio: 0.92,
          failMode: "fail-closed",
          perInstanceCapacityRps: 1500
        }
      },
      {
        id: "checkout",
        type: "server",
        x: 460,
        y: 340,
        technology: "spring-boot",
        config: {
          displayName: "Checkout Service",
          instanceCount: 4,
          perInstanceCapacityRps: 90,
          baseLatencyMs: 38,
          jitterMs: 14,
          estimatedCostPerHour: 0.32
        }
      },
      {
        id: "orders-db",
        type: "relational-database",
        x: 700,
        y: 180,
        technology: "postgresql",
        config: {
          displayName: "Orders Database",
          perInstanceCapacityRps: 450,
          baseLatencyMs: 20,
          jitterMs: 7,
          estimatedCostPerHour: 0.38
        }
      },
      {
        id: "settlement-queue",
        type: "message-queue",
        x: 700,
        y: 420,
        technology: "amazon-sqs",
        config: {
          displayName: "Settlement Queue",
          maxQueueDepth: 4000,
          baseLatencyMs: 4,
          perInstanceCapacityRps: 5000
        }
      },
      {
        id: "settlement-worker",
        type: "worker",
        x: 940,
        y: 420,
        technology: "temporal",
        config: {
          displayName: "Settlement Worker",
          instanceCount: 3,
          perInstanceCapacityRps: 45,
          baseLatencyMs: 25,
          maxRetries: 2,
          retryBackoffMs: 400,
          estimatedCostPerHour: 0.24
        }
      },
      {
        id: "psp-breaker",
        type: "circuit-breaker",
        x: 1180,
        y: 420,
        technology: "resilience4j",
        config: {
          displayName: "Processor Breaker",
          failureThreshold: 0.35,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 5000
        }
      },
      {
        id: "processor",
        type: "external-service",
        x: 1420,
        y: 420,
        technology: "stripe-payments",
        config: {
          displayName: "Payment Processor",
          providerLabel: "Card processor",
          slaLatencyMs: 320,
          providerRateLimitRps: 90,
          idempotencySupported: true,
          callMode: "sync",
          errorRate: 0.01,
          perInstanceCapacityRps: 120
        }
      },
      {
        id: "settlement-dlq",
        type: "dead-letter-queue",
        x: 940,
        y: 620,
        technology: "amazon-sqs",
        config: { displayName: "Settlement DLQ", maxQueueDepth: 2000 }
      },
      {
        id: "telemetry",
        type: "observability",
        x: 460,
        y: 620,
        technology: "opentelemetry",
        config: { displayName: "Telemetry", perInstanceCapacityRps: 20_000 }
      }
    ],
    edges: [
      { from: "client", to: "gateway", kind: "request" },
      { from: "gateway", to: "identity", kind: "request", latencyMs: 2 },
      { from: "gateway", to: "checkout", kind: "request", latencyMs: 2 },
      { from: "checkout", to: "orders-db", kind: "request", latencyMs: 3 },
      { from: "checkout", to: "settlement-queue", kind: "event", latencyMs: 2 },
      { from: "settlement-queue", to: "settlement-worker", kind: "event", latencyMs: 2 },
      { from: "settlement-queue", to: "settlement-dlq", kind: "failover", latencyMs: 1 },
      { from: "settlement-worker", to: "psp-breaker", kind: "request", latencyMs: 1 },
      { from: "psp-breaker", to: "processor", kind: "request", latencyMs: 25 },
      { from: "checkout", to: "telemetry", kind: "observability" },
      { from: "settlement-worker", to: "telemetry", kind: "observability" }
    ],
    trafficProfiles: [
      constantProfile("checkout-load", "Sustained checkout load", 45_000, 180, {
        readRatio: 0.25,
        concurrentUsers: 900
      }),
      burstProfile("flash-sale", "Flash sale burst", 60_000, 150, 620, 20_000, 34_000, {
        readRatio: 0.2
      })
    ],
    faultScenarios: [
      faultScenario("processor-throttling", "Processor throttles us", [
        fault("psp-throttle", "provider-throttling", ["processor"], 15_000, {
          endMs: 38_000,
          capacityMultiplier: 0.25,
          additionalErrorRate: 0.3
        })
      ]),
      faultScenario("processor-latency", "Processor slows down", [
        fault("psp-slow", "latency-increase", ["processor"], 12_000, {
          endMs: 36_000,
          additionalLatencyMs: 1400
        })
      ]),
      faultScenario("settlement-stall", "Settlement workers stall", [
        fault("worker-stall", "queue-consumer-failure", ["settlement-worker"], 14_000, {
          endMs: 34_000
        })
      ])
    ]
  }
};

const videoStreamingPlatform: ScenarioTemplate = {
  metadata: {
    id: "video-streaming-platform",
    version: "1.0.0",
    name: "Video Streaming Platform",
    summary:
      "Edge-cached playback served from object storage, with uploads fanned out to a pool of transcoding workers through a partitioned job topic.",
    difficulty: "advanced",
    tags: ["cdn", "object-storage", "fan-out", "batch", "media"],
    learningObjectives: [
      "Separate a bandwidth-heavy read path from a compute-heavy write path",
      "Understand why a CDN in front of object storage changes the cost model, not just latency",
      "Size a worker pool against a job arrival rate rather than a request rate",
      "See how a long-running job queue absorbs an upload spike"
    ],
    estimatedCompletionMinutes: 55,
    recommendedPrerequisites: ["file-upload-service", "ecommerce-storefront"],
    supportedComponentTypes: [
      "client",
      "cdn",
      "api-gateway",
      "server",
      "nosql-database",
      "object-storage",
      "event-topic",
      "worker",
      "dead-letter-queue",
      "observability"
    ],
    defaultTrafficProfileId: "evening-playback-peak",
    defaultFaultScenarioIds: ["transcoder-stall"],
    workloadShapes: ["read-heavy", "throughput-sensitive"],
    documentationPath: "docs/scenarios/video-streaming-platform.md",
    modelledProperties: [
      "CDN hit ratio deciding how much playback traffic ever reaches origin",
      "Object storage serving origin reads with its own capacity ceiling",
      "Topic partitioning and worker concurrency governing transcode throughput",
      "Job backlog growth when transcoding capacity falls below upload rate"
    ],
    simplifications: [
      "Bitrate ladders, segment sizes, and adaptive-bitrate switching are not modelled; a playback request is one request",
      "Byte-level bandwidth and egress cost are not modelled, only request rate and latency",
      "DRM, licence issuance, and content moderation are out of scope",
      "Transcoding duration is expressed as worker capacity, not as a per-asset job length"
    ],
    standIns: [
      {
        concept: "Media transcoding pipeline",
        modelledAs: "worker",
        rationale:
          "Transcoding is a throughput-bound consumer of a job queue, which the worker component models through instance count and per-instance capacity."
      },
      {
        concept: "Video metadata catalogue",
        modelledAs: "nosql-database",
        rationale:
          "Catalogue lookups are document reads by key; the NoSQL component provides the document model and eventual-consistency behaviour this needs."
      }
    ],
    expectedFindings: [],
    challenges: [
      "Lower the CDN hit ratio to 0.6 and identify which component saturates first",
      "Run the upload spike and size the transcoder pool so the backlog drains before the run ends",
      "Raise topic partitionCount and explain why it does not help unless workers are added too"
    ]
  },
  blueprint: {
    projectName: "Video Streaming Platform",
    nodes: [
      { id: "client", type: "client", x: 0, y: 360, config: { displayName: "Viewer Client" } },
      {
        id: "edge",
        type: "cdn",
        x: 200,
        y: 360,
        technology: "akamai-cdn",
        config: { displayName: "Streaming Edge", hitRatio: 0.93, baseLatencyMs: 10 }
      },
      {
        id: "gateway",
        type: "api-gateway",
        x: 420,
        y: 440,
        technology: "kong-gateway",
        config: {
          displayName: "API Gateway",
          authMode: "none",
          policyLatencyMs: 2,
          perInstanceCapacityRps: 6000
        }
      },
      {
        id: "playback",
        type: "server",
        x: 660,
        y: 340,
        technology: "nodejs",
        config: {
          displayName: "Playback Service",
          instanceCount: 6,
          perInstanceCapacityRps: 200,
          baseLatencyMs: 14,
          jitterMs: 5,
          estimatedCostPerHour: 0.36
        }
      },
      {
        id: "upload",
        type: "server",
        x: 660,
        y: 620,
        technology: "nodejs",
        config: {
          displayName: "Upload Service",
          instanceCount: 3,
          perInstanceCapacityRps: 40,
          baseLatencyMs: 60,
          jitterMs: 25,
          estimatedCostPerHour: 0.18
        }
      },
      {
        id: "catalog",
        type: "nosql-database",
        x: 920,
        y: 240,
        technology: "amazon-dynamodb",
        config: {
          displayName: "Video Catalogue",
          model: "document",
          consistency: "eventual",
          partitionCount: 16,
          replicationLagMs: 40,
          perInstanceCapacityRps: 1200,
          baseLatencyMs: 9
        }
      },
      {
        id: "raw-storage",
        type: "object-storage",
        x: 920,
        y: 700,
        technology: "amazon-s3",
        config: {
          displayName: "Raw Upload Bucket",
          perInstanceCapacityRps: 300,
          baseLatencyMs: 40,
          estimatedCostPerHour: 0.08
        }
      },
      {
        id: "renditions",
        type: "object-storage",
        x: 420,
        y: 180,
        technology: "amazon-s3",
        config: {
          displayName: "Rendition Bucket",
          perInstanceCapacityRps: 900,
          baseLatencyMs: 32,
          estimatedCostPerHour: 0.22
        }
      },
      {
        id: "transcode-topic",
        type: "event-topic",
        x: 920,
        y: 480,
        technology: "apache-kafka",
        config: {
          displayName: "Transcode Jobs",
          partitionCount: 12,
          orderingScope: "partition",
          retentionMs: 7_200_000,
          maxQueueDepth: 20_000,
          perInstanceCapacityRps: 8000
        }
      },
      {
        id: "transcoder",
        type: "worker",
        x: 1180,
        y: 480,
        technology: "aws-fargate",
        config: {
          displayName: "Transcoding Workers",
          instanceCount: 8,
          perInstanceCapacityRps: 6,
          baseLatencyMs: 900,
          jitterMs: 300,
          estimatedCostPerHour: 1.6
        }
      },
      {
        id: "transcode-dlq",
        type: "dead-letter-queue",
        x: 1180,
        y: 700,
        technology: "apache-pulsar",
        config: { displayName: "Failed Transcodes", maxQueueDepth: 3000 }
      },
      {
        id: "telemetry",
        type: "observability",
        x: 1420,
        y: 340,
        technology: "grafana",
        config: { displayName: "Telemetry", perInstanceCapacityRps: 25_000 }
      }
    ],
    edges: [
      { from: "client", to: "edge", kind: "request" },
      { from: "edge", to: "renditions", kind: "request", latencyMs: 12 },
      { from: "edge", to: "gateway", kind: "request", latencyMs: 8 },
      { from: "gateway", to: "playback", kind: "request", latencyMs: 2 },
      { from: "gateway", to: "upload", kind: "request", latencyMs: 2 },
      { from: "playback", to: "catalog", kind: "request", latencyMs: 2 },
      { from: "upload", to: "raw-storage", kind: "request", latencyMs: 6 },
      { from: "upload", to: "transcode-topic", kind: "event", latencyMs: 2 },
      { from: "transcode-topic", to: "transcoder", kind: "event", latencyMs: 2 },
      { from: "transcode-topic", to: "transcode-dlq", kind: "failover", latencyMs: 1 },
      { from: "transcoder", to: "renditions", kind: "request", latencyMs: 8 },
      { from: "transcoder", to: "catalog", kind: "request", latencyMs: 3 },
      { from: "playback", to: "telemetry", kind: "observability" },
      { from: "transcoder", to: "telemetry", kind: "observability" }
    ],
    trafficProfiles: [
      rampProfile("evening-playback-peak", "Evening playback peak", 60_000, 300, 1400, {
        readRatio: 0.95,
        concurrentUsers: 9000
      }),
      burstProfile("upload-spike", "Creator upload spike", 60_000, 250, 900, 18_000, 32_000, {
        readRatio: 0.55
      })
    ],
    faultScenarios: [
      faultScenario("transcoder-stall", "Transcoding pool stalls", [
        fault("tc-stall", "queue-consumer-failure", ["transcoder"], 16_000, { endMs: 42_000 })
      ]),
      faultScenario("edge-miss-storm", "Edge cache purged", [
        fault("edge-cold", "cache-failure", ["edge"], 14_000, { endMs: 36_000 })
      ]),
      faultScenario("origin-degraded", "Rendition bucket degraded", [
        fault("origin-slow", "degradation", ["renditions"], 18_000, {
          endMs: 40_000,
          capacityMultiplier: 0.4,
          additionalLatencyMs: 120
        })
      ])
    ]
  }
};

const rideSharingDispatch: ScenarioTemplate = {
  metadata: {
    id: "ride-sharing-dispatch",
    version: "1.0.0",
    name: "Ride-Sharing Dispatch",
    summary:
      "High-frequency driver location ingestion into a partitioned key-value store, with trip matching driven off an ordered event topic and push notification through a third-party provider.",
    difficulty: "advanced",
    tags: ["geospatial", "hot-partition", "event-ordering", "real-time", "matching"],
    learningObjectives: [
      "Size a write-heavy ingestion path that never touches a relational database",
      "See how a hot partition defeats an otherwise well-provisioned data store",
      "Understand why matching needs per-partition ordering but not global ordering",
      "Keep a third-party push provider from becoming a dispatch dependency"
    ],
    estimatedCompletionMinutes: 60,
    recommendedPrerequisites: ["chat-application", "social-media-feed"],
    supportedComponentTypes: [
      "client",
      "api-gateway",
      "server",
      "cache",
      "nosql-database",
      "event-topic",
      "worker",
      "relational-database",
      "circuit-breaker",
      "external-service",
      "observability"
    ],
    defaultTrafficProfileId: "rush-hour",
    defaultFaultScenarioIds: ["downtown-hot-partition"],
    workloadShapes: ["write-heavy", "latency-sensitive", "throughput-sensitive"],
    documentationPath: "docs/scenarios/ride-sharing-dispatch.md",
    modelledProperties: [
      "Sustained high-rate writes from location pings dominating total traffic",
      "Hot-partition skew concentrating load on a fraction of the key space",
      "Per-partition ordering on the dispatch topic constraining consumer parallelism",
      "Circuit breaker isolating the push provider from the matching path"
    ],
    simplifications: [
      "Geospatial indexing is not modelled: the geo cache is a keyed lookup, not an S2/geohash structure",
      "Matching fairness, surge pricing, and driver acceptance behaviour are not modelled",
      "Location pings are ordinary requests; the simulator has no persistent-connection or streaming transport model",
      "Trip state machines and cancellation flows are collapsed into a single write"
    ],
    standIns: [
      {
        concept: "Geospatial index",
        modelledAs: "cache",
        rationale:
          "Proximity lookup behaves like a short-TTL hot read with a high hit ratio; the cache component captures the latency and failure behaviour that matter here."
      },
      {
        concept: "Push notification provider",
        modelledAs: "external-service",
        rationale:
          "Push delivery is a rate-limited third-party call with its own SLA latency, which is exactly the external-service model."
      }
    ],
    expectedFindings: [],
    challenges: [
      "Run the hot-partition fault and find which metric moves before latency does",
      "Reduce hotPartitionSkew to 0 and quantify the throughput you recover",
      "Set the dispatch topic to orderingScope 'none' and explain what correctness you traded away"
    ]
  },
  blueprint: {
    projectName: "Ride-Sharing Dispatch",
    nodes: [
      { id: "client", type: "client", x: 0, y: 380, config: { displayName: "Rider & Driver Apps" } },
      {
        id: "gateway",
        type: "api-gateway",
        x: 220,
        y: 380,
        technology: "apache-apisix",
        config: {
          displayName: "API Gateway",
          authMode: "none",
          policyLatencyMs: 2,
          rateLimitRps: 0,
          perInstanceCapacityRps: 12_000
        }
      },
      {
        id: "location-svc",
        type: "server",
        x: 460,
        y: 380,
        technology: "google-cloud-run",
        config: {
          displayName: "Location Ingest",
          instanceCount: 10,
          perInstanceCapacityRps: 320,
          baseLatencyMs: 8,
          jitterMs: 3,
          estimatedCostPerHour: 0.75
        }
      },
      {
        id: "geo-cache",
        type: "cache",
        x: 720,
        y: 200,
        technology: "redis",
        config: {
          displayName: "Geo Proximity Cache",
          hitRatio: 0.9,
          ttlMs: 15_000,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 20_000
        }
      },
      {
        id: "driver-state",
        type: "nosql-database",
        x: 720,
        y: 560,
        technology: "scylladb",
        config: {
          displayName: "Driver State Store",
          model: "key-value",
          consistency: "eventual",
          partitionCount: 64,
          hotPartitionSkew: 0.35,
          replicationLagMs: 25,
          perInstanceCapacityRps: 6000,
          baseLatencyMs: 4
        }
      },
      {
        id: "dispatch-topic",
        type: "event-topic",
        x: 720,
        y: 380,
        technology: "apache-kafka",
        config: {
          displayName: "Dispatch Events",
          partitionCount: 24,
          orderingScope: "partition",
          retentionMs: 1_800_000,
          maxQueueDepth: 30_000,
          perInstanceCapacityRps: 15_000
        }
      },
      {
        id: "matcher",
        type: "worker",
        x: 980,
        y: 380,
        technology: "nestjs",
        config: {
          displayName: "Matching Workers",
          instanceCount: 6,
          perInstanceCapacityRps: 120,
          baseLatencyMs: 35,
          jitterMs: 12,
          estimatedCostPerHour: 0.48
        }
      },
      {
        id: "trips-db",
        type: "relational-database",
        x: 1240,
        y: 560,
        technology: "amazon-aurora",
        config: {
          displayName: "Trips Database",
          perInstanceCapacityRps: 800,
          baseLatencyMs: 16,
          estimatedCostPerHour: 0.6
        }
      },
      {
        id: "push-breaker",
        type: "circuit-breaker",
        x: 1240,
        y: 260,
        technology: "resilience4j",
        config: {
          displayName: "Push Breaker",
          failureThreshold: 0.4,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 8000
        }
      },
      {
        id: "push-provider",
        type: "external-service",
        x: 1480,
        y: 260,
        technology: "firebase-cloud-messaging",
        config: {
          displayName: "Push Provider",
          providerLabel: "Mobile push gateway",
          slaLatencyMs: 180,
          providerRateLimitRps: 600,
          idempotencySupported: false,
          callMode: "async-callback",
          perInstanceCapacityRps: 700
        }
      },
      {
        id: "telemetry",
        type: "observability",
        x: 980,
        y: 140,
        technology: "prometheus",
        config: { displayName: "Telemetry", perInstanceCapacityRps: 40_000 }
      }
    ],
    edges: [
      { from: "client", to: "gateway", kind: "request" },
      { from: "gateway", to: "location-svc", kind: "request", latencyMs: 2 },
      { from: "location-svc", to: "geo-cache", kind: "request", latencyMs: 1 },
      { from: "location-svc", to: "driver-state", kind: "request", latencyMs: 2 },
      { from: "location-svc", to: "dispatch-topic", kind: "event", latencyMs: 2 },
      { from: "dispatch-topic", to: "matcher", kind: "event", latencyMs: 2 },
      { from: "matcher", to: "driver-state", kind: "request", latencyMs: 2 },
      { from: "matcher", to: "trips-db", kind: "request", latencyMs: 4 },
      { from: "matcher", to: "push-breaker", kind: "request", latencyMs: 1 },
      { from: "push-breaker", to: "push-provider", kind: "request", latencyMs: 20 },
      { from: "location-svc", to: "telemetry", kind: "observability" },
      { from: "matcher", to: "telemetry", kind: "observability" }
    ],
    trafficProfiles: [
      rampProfile("rush-hour", "Evening rush hour", 60_000, 800, 2600, {
        readRatio: 0.2,
        concurrentUsers: 25_000
      }),
      burstProfile("event-letout", "Stadium let-out", 60_000, 900, 3200, 22_000, 36_000, {
        readRatio: 0.2
      })
    ],
    faultScenarios: [
      faultScenario("downtown-hot-partition", "Downtown hot partition", [
        fault("hot-shard", "partition-hotspot", ["driver-state"], 16_000, {
          endMs: 42_000,
          capacityMultiplier: 0.45,
          additionalLatencyMs: 90
        })
      ]),
      faultScenario("geo-cache-loss", "Geo cache lost", [
        fault("geo-down", "cache-failure", ["geo-cache"], 14_000, { endMs: 38_000 })
      ]),
      faultScenario("matcher-lag", "Matching consumers fall behind", [
        fault("match-stall", "subscriber-group-stall", ["matcher"], 15_000, {
          endMs: 40_000,
          capacityMultiplier: 0.3
        })
      ])
    ]
  }
};

const searchAndRecommendation: ScenarioTemplate = {
  metadata: {
    id: "search-and-recommendation-platform",
    version: "1.0.0",
    name: "Search & Recommendation Platform",
    summary:
      "A query path served from a search index and a vector index, kept current by an indexing pipeline that consumes catalogue change events rather than reading the source database.",
    difficulty: "advanced",
    tags: ["search", "vector", "indexing", "cdc", "eventual-consistency"],
    learningObjectives: [
      "Separate a query-optimised read store from the system of record",
      "Reason about index freshness as a deliberate consistency trade-off",
      "Understand why change events, not database polling, drive an index pipeline",
      "Compare a keyword index and a vector index on the same query path"
    ],
    estimatedCompletionMinutes: 60,
    recommendedPrerequisites: ["ecommerce-storefront", "social-media-feed"],
    supportedComponentTypes: [
      "client",
      "api-gateway",
      "server",
      "cache",
      "nosql-database",
      "relational-database",
      "event-topic",
      "worker",
      "observability"
    ],
    defaultTrafficProfileId: "query-load",
    defaultFaultScenarioIds: ["indexer-stall"],
    workloadShapes: ["read-heavy", "latency-sensitive", "consistency-sensitive"],
    documentationPath: "docs/scenarios/search-and-recommendation-platform.md",
    modelledProperties: [
      "Query traffic served entirely from derived stores, never from the catalogue database",
      "Index staleness expressed as topic backlog plus indexer throughput",
      "Query cache absorbing repeated head queries",
      "Recommendation reads fanning out to a feature lookup and a vector lookup"
    ],
    simplifications: [
      "Relevance, ranking quality, embeddings, and recall are not modelled; a query is a request with a latency and a cost",
      "Change data capture is modelled as the catalogue service publishing events, not as log-based replication",
      "Index rebuilds, segment merges, and shard rebalancing are not modelled",
      "Vector similarity search is a NoSQL lookup with a vector model flag, not an ANN algorithm"
    ],
    standIns: [
      {
        concept: "Search engine / inverted index",
        modelledAs: "nosql-database",
        rationale:
          "For simulation the search index is a high-throughput document store with its own latency and capacity; the NoSQL component's document model covers it."
      },
      {
        concept: "Vector search index",
        modelledAs: "nosql-database",
        rationale:
          "The NoSQL component exposes a 'vector' data model, so the index's capacity, latency, and partitioning are modelled while the ANN algorithm is not."
      },
      {
        concept: "Feature store",
        modelledAs: "nosql-database",
        rationale:
          "Online feature serving is a low-latency key-value read; the extra machinery of training/serving skew is outside the simulator's scope."
      },
      {
        concept: "Change data capture pipeline",
        modelledAs: "worker",
        rationale:
          "The indexer consumes a change topic and writes derived stores, which reproduces CDC's observable effect: index lag bounded by consumer throughput."
      }
    ],
    expectedFindings: [],
    challenges: [
      "Stall the indexer and describe, in seconds, how stale the search index becomes",
      "Halve the query cache hit ratio and identify the new bottleneck",
      "Route recommendation traffic through the query cache and argue whether that is safe"
    ]
  },
  blueprint: {
    projectName: "Search & Recommendation Platform",
    nodes: [
      { id: "client", type: "client", x: 0, y: 400, config: { displayName: "Search Client" } },
      {
        id: "gateway",
        type: "api-gateway",
        x: 220,
        y: 400,
        technology: "cloudflare-api-gateway",
        config: {
          displayName: "API Gateway",
          authMode: "none",
          policyLatencyMs: 2,
          perInstanceCapacityRps: 9000
        }
      },
      {
        id: "search-api",
        type: "server",
        x: 470,
        y: 240,
        technology: "fastapi",
        config: {
          displayName: "Search API",
          instanceCount: 5,
          perInstanceCapacityRps: 160,
          baseLatencyMs: 18,
          jitterMs: 7,
          estimatedCostPerHour: 0.35
        }
      },
      {
        id: "recs-api",
        type: "server",
        x: 470,
        y: 560,
        technology: "fastapi",
        config: {
          displayName: "Recommendation API",
          instanceCount: 4,
          perInstanceCapacityRps: 110,
          baseLatencyMs: 28,
          jitterMs: 11,
          estimatedCostPerHour: 0.3
        }
      },
      {
        id: "catalog-api",
        type: "server",
        x: 470,
        y: 800,
        technology: "spring-boot",
        config: {
          displayName: "Catalogue Service",
          instanceCount: 2,
          perInstanceCapacityRps: 80,
          baseLatencyMs: 26,
          estimatedCostPerHour: 0.16
        }
      },
      {
        id: "query-cache",
        type: "cache",
        x: 730,
        y: 120,
        technology: "redis",
        config: {
          displayName: "Query Cache",
          hitRatio: 0.62,
          ttlMs: 45_000,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 12_000
        }
      },
      {
        id: "search-index",
        type: "nosql-database",
        x: 730,
        y: 300,
        config: {
          displayName: "Search Index",
          model: "document",
          consistency: "eventual",
          partitionCount: 24,
          replicationLagMs: 60,
          perInstanceCapacityRps: 2500,
          baseLatencyMs: 12,
          estimatedCostPerHour: 0.7
        }
      },
      {
        id: "feature-store",
        type: "nosql-database",
        x: 730,
        y: 500,
        technology: "aerospike",
        config: {
          displayName: "Feature Store",
          model: "key-value",
          consistency: "eventual",
          partitionCount: 32,
          replicationLagMs: 20,
          perInstanceCapacityRps: 5000,
          baseLatencyMs: 3
        }
      },
      {
        id: "vector-index",
        type: "nosql-database",
        x: 730,
        y: 660,
        config: {
          displayName: "Vector Index",
          model: "vector",
          consistency: "eventual",
          partitionCount: 12,
          replicationLagMs: 120,
          perInstanceCapacityRps: 900,
          baseLatencyMs: 35,
          estimatedCostPerHour: 0.85
        }
      },
      {
        id: "catalog-db",
        type: "relational-database",
        x: 730,
        y: 860,
        technology: "postgresql",
        config: {
          displayName: "Catalogue Database",
          perInstanceCapacityRps: 400,
          baseLatencyMs: 20,
          estimatedCostPerHour: 0.3
        }
      },
      {
        id: "change-topic",
        type: "event-topic",
        x: 990,
        y: 800,
        technology: "redpanda",
        config: {
          displayName: "Catalogue Change Events",
          partitionCount: 8,
          orderingScope: "partition",
          retentionMs: 21_600_000,
          maxQueueDepth: 25_000,
          perInstanceCapacityRps: 7000
        }
      },
      {
        id: "indexer",
        type: "worker",
        x: 1240,
        y: 620,
        technology: "bullmq",
        config: {
          displayName: "Index Writers",
          instanceCount: 4,
          perInstanceCapacityRps: 90,
          baseLatencyMs: 45,
          jitterMs: 15,
          estimatedCostPerHour: 0.32
        }
      },
      {
        id: "telemetry",
        type: "observability",
        x: 1240,
        y: 300,
        technology: "grafana",
        config: { displayName: "Telemetry", perInstanceCapacityRps: 30_000 }
      }
    ],
    edges: [
      { from: "client", to: "gateway", kind: "request" },
      { from: "gateway", to: "search-api", kind: "request", latencyMs: 2 },
      { from: "gateway", to: "recs-api", kind: "request", latencyMs: 2 },
      { from: "gateway", to: "catalog-api", kind: "request", latencyMs: 2 },
      { from: "search-api", to: "query-cache", kind: "request", latencyMs: 1 },
      { from: "search-api", to: "search-index", kind: "request", latencyMs: 3 },
      { from: "recs-api", to: "feature-store", kind: "request", latencyMs: 2 },
      { from: "recs-api", to: "vector-index", kind: "request", latencyMs: 4 },
      { from: "catalog-api", to: "catalog-db", kind: "request", latencyMs: 3 },
      { from: "catalog-api", to: "change-topic", kind: "event", latencyMs: 2 },
      { from: "change-topic", to: "indexer", kind: "event", latencyMs: 2 },
      { from: "indexer", to: "search-index", kind: "request", latencyMs: 4 },
      { from: "indexer", to: "vector-index", kind: "request", latencyMs: 6 },
      { from: "indexer", to: "feature-store", kind: "request", latencyMs: 3 },
      { from: "search-api", to: "telemetry", kind: "observability" },
      { from: "indexer", to: "telemetry", kind: "observability" }
    ],
    trafficProfiles: [
      constantProfile("query-load", "Sustained query load", 45_000, 520, {
        readRatio: 0.93,
        concurrentUsers: 7000
      }),
      burstProfile("trending-spike", "Trending query spike", 60_000, 450, 1600, 20_000, 33_000, {
        readRatio: 0.95
      })
    ],
    faultScenarios: [
      faultScenario("indexer-stall", "Index writers stall", [
        fault("idx-stall", "subscriber-group-stall", ["indexer"], 16_000, {
          endMs: 40_000,
          capacityMultiplier: 0.15
        })
      ]),
      faultScenario("index-latency", "Search index slows down", [
        fault("idx-slow", "latency-increase", ["search-index"], 14_000, {
          endMs: 36_000,
          additionalLatencyMs: 260
        })
      ]),
      faultScenario("cache-cold", "Query cache flushed", [
        fault("qc-cold", "cache-failure", ["query-cache"], 12_000, { endMs: 34_000 })
      ])
    ]
  }
};

export const advancedScenarios: ScenarioTemplate[] = [
  multiRegionEcommerce,
  paymentProcessingWorkflow,
  videoStreamingPlatform,
  rideSharingDispatch,
  searchAndRecommendation
];
