import type { ScenarioTemplate } from "@/domain/scenarios/builder";
import {
  burstProfile,
  constantProfile,
  fault,
  faultScenario,
  rampProfile
} from "@/domain/scenarios/profiles";

/**
 * Intermediate scenarios: service decomposition, caching, asynchronous work,
 * and the first failure modes that are not simply "a node went away".
 */

const ecommerceStorefront: ScenarioTemplate = {
  metadata: {
    id: "ecommerce-storefront",
    version: "1.0.0",
    name: "E-Commerce Storefront",
    summary:
      "A decomposed storefront with cached product reads, a session-backed cart, a synchronous checkout, and queue-driven inventory and notification work.",
    difficulty: "intermediate",
    tags: ["microservices", "cache", "queue", "checkout", "session"],
    learningObjectives: [
      "Separate a synchronous checkout path from asynchronous follow-up work",
      "Compare a cached read path against an uncached write path",
      "Watch queue depth build when a consumer stalls",
      "Reason about partial failure: browsing surviving while checkout degrades"
    ],
    estimatedCompletionMinutes: 40,
    recommendedPrerequisites: ["basic-web-application", "url-shortener"],
    supportedComponentTypes: [
      "client",
      "cdn",
      "api-gateway",
      "identity-auth-service",
      "server",
      "cache",
      "relational-database",
      "message-queue",
      "worker"
    ],
    defaultTrafficProfileId: "storefront-traffic",
    defaultFaultScenarioIds: ["checkout-database-failure"],
    documentationPath: "docs/scenarios/ecommerce-storefront.md",
    workloadShapes: ["read-heavy", "availability-sensitive"],
    modelledProperties: [
      "Gateway fan-out to independently scaled services",
      "Token validation through an identity component with its own cache hit ratio",
      "Queue depth and consumer lag when inventory processing falls behind",
      "Blast radius of one database failing while the rest of the system serves traffic"
    ],
    simplifications: [
      "Cart state is a cache lookup; no session affinity or sticky routing is modelled",
      "Inventory reservation, overselling, and distributed transactions are not modelled",
      "Payment authorisation is out of scope; see the payment-processing scenario"
    ],
    standIns: [
      {
        concept: "Session store",
        modelledAs: "cache",
        rationale:
          "A session store is a keyed lookup with a TTL, which the cache component already models including hit ratio and expiry."
      }
    ],
    expectedFindings: ["consumer-semantics-simplified"],
    challenges: [
      "Run the queue-consumer stall and find the point where depth exceeds maxQueueDepth",
      "Halve the product cache hit ratio and identify which component saturates first",
      "Add a read replica for the product database and route reads to it"
    ]
  },
  blueprint: {
    projectName: "E-Commerce Storefront",
    nodes: [
      { id: "client", type: "client", x: 0, y: 320, config: { displayName: "Shopper Client" } },
      {
        id: "cdn",
        type: "cdn",
        x: 180,
        y: 320,
        technology: "amazon-cloudfront",
        config: { displayName: "CDN", hitRatio: 0.45, baseLatencyMs: 12 }
      },
      {
        id: "gateway",
        type: "api-gateway",
        x: 380,
        y: 320,
        technology: "kong-gateway",
        config: {
          displayName: "API Gateway",
          authMode: "delegate",
          policyLatencyMs: 3,
          perInstanceCapacityRps: 3000
        }
      },
      {
        id: "identity",
        type: "identity-auth-service",
        x: 380,
        y: 120,
        technology: "auth0",
        config: {
          displayName: "Identity Service",
          instanceCount: 2,
          mode: "authn",
          validationMode: "local-jwt",
          cacheHitRatio: 0.9,
          failMode: "fail-closed",
          perInstanceCapacityRps: 1200
        }
      },
      {
        id: "product-svc",
        type: "server",
        x: 620,
        y: 180,
        technology: "spring-boot",
        config: {
          displayName: "Product Service",
          instanceCount: 4,
          perInstanceCapacityRps: 150,
          baseLatencyMs: 20,
          jitterMs: 8,
          estimatedCostPerHour: 0.24
        }
      },
      {
        id: "product-cache",
        type: "cache",
        x: 860,
        y: 120,
        technology: "redis",
        config: {
          displayName: "Product Cache",
          hitRatio: 0.88,
          ttlMs: 120_000,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 6000
        }
      },
      {
        id: "product-db",
        type: "relational-database",
        x: 1100,
        y: 120,
        technology: "postgresql",
        config: {
          displayName: "Product Database",
          perInstanceCapacityRps: 400,
          baseLatencyMs: 20,
          estimatedCostPerHour: 0.28
        }
      },
      {
        id: "cart-svc",
        type: "server",
        x: 620,
        y: 320,
        technology: "nodejs",
        config: {
          displayName: "Cart Service",
          instanceCount: 3,
          perInstanceCapacityRps: 120,
          baseLatencyMs: 15,
          estimatedCostPerHour: 0.15
        }
      },
      {
        id: "session-store",
        type: "cache",
        x: 860,
        y: 320,
        technology: "amazon-elasticache",
        config: {
          displayName: "Session Store",
          hitRatio: 0.95,
          ttlMs: 1_800_000,
          baseLatencyMs: 2,
          perInstanceCapacityRps: 5000
        }
      },
      {
        id: "order-svc",
        type: "server",
        x: 620,
        y: 480,
        technology: "spring-boot",
        config: {
          displayName: "Order Service",
          instanceCount: 3,
          perInstanceCapacityRps: 80,
          baseLatencyMs: 45,
          jitterMs: 15,
          maxRetries: 1,
          estimatedCostPerHour: 0.2
        }
      },
      {
        id: "order-db",
        type: "relational-database",
        x: 860,
        y: 480,
        technology: "amazon-aurora",
        config: {
          displayName: "Order Database",
          perInstanceCapacityRps: 250,
          baseLatencyMs: 28,
          estimatedCostPerHour: 0.45
        }
      },
      {
        id: "order-queue",
        type: "message-queue",
        x: 1100,
        y: 480,
        technology: "amazon-sqs",
        config: {
          displayName: "Order Events",
          maxQueueDepth: 20_000,
          retentionMs: 3_600_000,
          perInstanceCapacityRps: 3000
        }
      },
      {
        id: "inventory-worker",
        type: "worker",
        x: 1340,
        y: 400,
        technology: "celery",
        config: {
          displayName: "Inventory Worker",
          instanceCount: 3,
          perInstanceCapacityRps: 40,
          baseLatencyMs: 70,
          maxProcessingAttempts: 3,
          estimatedCostPerHour: 0.12
        }
      },
      {
        id: "notification-worker",
        type: "worker",
        x: 1340,
        y: 560,
        technology: "sidekiq",
        config: {
          displayName: "Notification Worker",
          instanceCount: 2,
          perInstanceCapacityRps: 60,
          baseLatencyMs: 40,
          estimatedCostPerHour: 0.08
        }
      }
    ],
    edges: [
      { from: "client", to: "cdn", kind: "request" },
      { from: "cdn", to: "gateway", kind: "request", latencyMs: 8 },
      { from: "gateway", to: "identity", kind: "request", latencyMs: 2 },
      { from: "gateway", to: "product-svc", kind: "request", latencyMs: 2, weight: 6 },
      { from: "gateway", to: "cart-svc", kind: "request", latencyMs: 2, weight: 3 },
      { from: "gateway", to: "order-svc", kind: "request", latencyMs: 2, weight: 1 },
      { from: "product-svc", to: "product-cache", kind: "request", latencyMs: 1 },
      { from: "product-cache", to: "product-db", kind: "request", latencyMs: 2 },
      { from: "cart-svc", to: "session-store", kind: "request", latencyMs: 1 },
      { from: "order-svc", to: "order-db", kind: "request", latencyMs: 3 },
      { from: "order-svc", to: "order-queue", kind: "event", latencyMs: 2 },
      { from: "order-queue", to: "inventory-worker", kind: "event", latencyMs: 2 },
      { from: "order-queue", to: "notification-worker", kind: "event", latencyMs: 2 }
    ],
    trafficProfiles: [
      constantProfile("storefront-traffic", "Storefront 400 RPS", 45_000, 400, {
        readRatio: 0.85,
        concurrentUsers: 900
      }),
      burstProfile("flash-sale", "Flash sale", 60_000, 300, 1600, 20_000, 35_000, {
        readRatio: 0.7,
        concurrentUsers: 2500
      })
    ],
    faultScenarios: [
      faultScenario("checkout-database-failure", "Checkout database failure", [
        fault("order-db-1", "database-primary-failure", ["order-db"], 15_000, { endMs: 32_000 })
      ]),
      faultScenario("inventory-consumer-stall", "Inventory consumer stall", [
        fault("stall-1", "queue-consumer-failure", ["inventory-worker"], 12_000, { endMs: 36_000 })
      ]),
      faultScenario("cache-eviction-storm", "Product cache eviction storm", [
        fault("cache-1", "cache-failure", ["product-cache"], 15_000, { endMs: 30_000 })
      ])
    ]
  }
};

const chatApplication: ScenarioTemplate = {
  metadata: {
    id: "chat-application",
    version: "1.0.0",
    name: "Chat Application",
    summary:
      "A messaging backend that persists messages to a wide-column store, tracks presence in a cache, and fans messages out to delivery workers through an event topic.",
    difficulty: "intermediate",
    tags: ["realtime", "fan-out", "event-topic", "presence", "backpressure"],
    learningObjectives: [
      "Model fan-out through an event topic with independent subscriber groups",
      "Distinguish message persistence from message delivery",
      "See consumer lag accumulate when delivery cannot keep up with ingest",
      "Understand what ordering guarantees a partitioned topic does and does not give"
    ],
    estimatedCompletionMinutes: 40,
    recommendedPrerequisites: ["ecommerce-storefront"],
    supportedComponentTypes: [
      "client",
      "api-gateway",
      "server",
      "nosql-database",
      "cache",
      "event-topic",
      "worker"
    ],
    defaultTrafficProfileId: "chat-traffic",
    defaultFaultScenarioIds: ["delivery-backlog"],
    documentationPath: "docs/scenarios/chat-application.md",
    workloadShapes: ["write-heavy", "latency-sensitive", "throughput-sensitive"],
    modelledProperties: [
      "Topic fan-out to two independent subscriber groups, each with its own lag",
      "Partition count and ordering scope on the event topic",
      "Write-heavy load against a wide-column message store",
      "Backpressure when a subscriber group stalls"
    ],
    simplifications: [
      "Persistent connections are conceptual: the simulator models arrivals, not sockets",
      "No per-conversation ordering is enforced beyond the topic's partition ordering scope",
      "Read receipts, typing indicators, and message history pagination are not modelled"
    ],
    standIns: [
      {
        concept: "WebSocket gateway",
        modelledAs: "api-gateway",
        rationale:
          "Connection lifecycle is not simulated, so a realtime gateway reduces to the routing and policy latency an API gateway already models."
      },
      {
        concept: "Presence store",
        modelledAs: "cache",
        rationale: "Presence is short-lived keyed state with a TTL, exactly what the cache models."
      }
    ],
    expectedFindings: ["consumer-semantics-simplified"],
    challenges: [
      "Raise topic partitions from 12 to 48 and describe the effect on ordering",
      "Run the subscriber-group stall and measure how long the backlog takes to drain",
      "Add a dead-letter queue for messages that exceed delivery attempts"
    ]
  },
  blueprint: {
    projectName: "Chat Application",
    nodes: [
      { id: "client", type: "client", x: 0, y: 300, config: { displayName: "Chat Client" } },
      {
        id: "gateway",
        type: "api-gateway",
        x: 210,
        y: 300,
        technology: "apache-apisix",
        config: {
          displayName: "Realtime Gateway",
          authMode: "validate-local",
          policyLatencyMs: 2,
          perInstanceCapacityRps: 6000
        }
      },
      {
        id: "chat-svc",
        type: "server",
        x: 440,
        y: 300,
        technology: "nestjs",
        config: {
          displayName: "Chat Service",
          instanceCount: 6,
          perInstanceCapacityRps: 200,
          baseLatencyMs: 12,
          jitterMs: 6,
          estimatedCostPerHour: 0.36
        }
      },
      {
        id: "presence",
        type: "cache",
        x: 700,
        y: 160,
        technology: "redis",
        config: {
          displayName: "Presence Store",
          hitRatio: 0.97,
          ttlMs: 60_000,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 12_000
        }
      },
      {
        id: "messages",
        type: "nosql-database",
        x: 700,
        y: 440,
        technology: "apache-cassandra",
        config: {
          displayName: "Message Store",
          model: "wide-column",
          consistency: "quorum",
          partitionCount: 32,
          hotPartitionSkew: 0.1,
          replicationLagMs: 30,
          perInstanceCapacityRps: 900,
          baseLatencyMs: 14,
          estimatedCostPerHour: 0.5
        }
      },
      {
        id: "topic",
        type: "event-topic",
        x: 700,
        y: 300,
        technology: "apache-kafka",
        config: {
          displayName: "Message Topic",
          partitionCount: 12,
          orderingScope: "partition",
          retentionMs: 86_400_000,
          maxQueueDepth: 200_000,
          perInstanceCapacityRps: 20_000
        }
      },
      {
        id: "delivery-worker",
        type: "worker",
        x: 960,
        y: 240,
        technology: "nodejs",
        config: {
          displayName: "Delivery Worker",
          instanceCount: 8,
          perInstanceCapacityRps: 150,
          baseLatencyMs: 18,
          maxProcessingAttempts: 3,
          estimatedCostPerHour: 0.32
        }
      },
      {
        id: "archive-worker",
        type: "worker",
        x: 960,
        y: 400,
        technology: "celery",
        config: {
          displayName: "Archive Worker",
          instanceCount: 2,
          perInstanceCapacityRps: 300,
          baseLatencyMs: 25,
          estimatedCostPerHour: 0.08
        }
      }
    ],
    edges: [
      { from: "client", to: "gateway", kind: "request" },
      { from: "gateway", to: "chat-svc", kind: "request", latencyMs: 2 },
      { from: "chat-svc", to: "presence", kind: "request", latencyMs: 1 },
      { from: "chat-svc", to: "messages", kind: "request", latencyMs: 2 },
      { from: "chat-svc", to: "topic", kind: "event", latencyMs: 1 },
      { from: "topic", to: "delivery-worker", kind: "event", latencyMs: 2 },
      { from: "topic", to: "archive-worker", kind: "event", latencyMs: 2 },
      { from: "delivery-worker", to: "presence", kind: "request", latencyMs: 1 }
    ],
    trafficProfiles: [
      constantProfile("chat-traffic", "Messaging 900 RPS", 45_000, 900, {
        readRatio: 0.35,
        concurrentUsers: 5000,
        requestSizeBytes: 512,
        responseSizeBytes: 256
      }),
      rampProfile("evening-peak", "Evening peak", 60_000, 600, 3000, {
        readRatio: 0.35,
        concurrentUsers: 12_000
      })
    ],
    faultScenarios: [
      faultScenario("delivery-backlog", "Delivery subscriber stall", [
        fault("stall-1", "subscriber-group-stall", ["delivery-worker"], 15_000, { endMs: 33_000 })
      ]),
      faultScenario("message-store-pressure", "Message store hot partition", [
        fault("hot-1", "partition-hotspot", ["messages"], 12_000, {
          endMs: 34_000,
          additionalLatencyMs: 160
        })
      ])
    ]
  }
};

const notificationPlatform: ScenarioTemplate = {
  metadata: {
    id: "notification-delivery-platform",
    version: "1.0.0",
    name: "Notification Delivery Platform",
    summary:
      "A queue-decoupled notification pipeline delivering through email, SMS, and push providers, each guarded by a circuit breaker and backed by a dead-letter queue.",
    difficulty: "intermediate",
    tags: ["queue", "workers", "third-party", "circuit-breaker", "dead-letter"],
    learningObjectives: [
      "Decouple an API from slow third-party delivery using a queue",
      "Protect callers from a failing provider with a circuit breaker",
      "Understand when a message belongs in a dead-letter queue",
      "Size consumers against provider throughput rather than against ingest rate"
    ],
    estimatedCompletionMinutes: 45,
    recommendedPrerequisites: ["ecommerce-storefront"],
    supportedComponentTypes: [
      "client",
      "api-gateway",
      "server",
      "message-queue",
      "dead-letter-queue",
      "worker",
      "circuit-breaker",
      "external-service"
    ],
    defaultTrafficProfileId: "notification-traffic",
    defaultFaultScenarioIds: ["provider-outage"],
    documentationPath: "docs/scenarios/notification-delivery-platform.md",
    workloadShapes: ["throughput-sensitive", "availability-sensitive"],
    modelledProperties: [
      "Queue buffering between a fast API and slow providers",
      "Circuit breaker opening after a failure threshold and shedding calls",
      "Provider-side rate limiting on an external service you cannot scale",
      "Dead-letter routing for messages that exhaust processing attempts"
    ],
    simplifications: [
      "Providers perform no real network calls and hold no credentials",
      "Delivery receipts, bounce handling, and unsubscribe flows are not modelled",
      "Per-recipient templating and localisation are out of scope"
    ],
    standIns: [
      {
        concept: "Email, SMS, and push providers",
        modelledAs: "external-service",
        rationale:
          "The external-service component models exactly what matters: a dependency with a latency SLA and a rate limit that you cannot scale or repair."
      }
    ],
    expectedFindings: ["consumer-semantics-simplified"],
    challenges: [
      "Lower the SMS provider rate limit until the dead-letter queue starts receiving messages",
      "Compare total failures with the circuit breaker's failureThreshold at 0.3 versus 0.8",
      "Add a retry backoff and explain its effect on provider load during an outage"
    ]
  },
  blueprint: {
    projectName: "Notification Delivery Platform",
    nodes: [
      { id: "client", type: "client", x: 0, y: 360, config: { displayName: "Producer Client" } },
      {
        id: "gateway",
        type: "api-gateway",
        x: 190,
        y: 360,
        technology: "amazon-api-gateway",
        config: { displayName: "API Gateway", authMode: "validate-local", policyLatencyMs: 3 }
      },
      {
        id: "notify-api",
        type: "server",
        x: 400,
        y: 360,
        technology: "fastapi",
        config: {
          displayName: "Notification API",
          instanceCount: 3,
          perInstanceCapacityRps: 250,
          baseLatencyMs: 10,
          estimatedCostPerHour: 0.15
        }
      },
      {
        id: "queue",
        type: "message-queue",
        x: 620,
        y: 360,
        technology: "amazon-sqs",
        config: {
          displayName: "Delivery Queue",
          maxQueueDepth: 50_000,
          retentionMs: 14_400_000,
          perInstanceCapacityRps: 5000
        }
      },
      {
        id: "dlq",
        type: "dead-letter-queue",
        x: 620,
        y: 600,
        config: { displayName: "Dead-Letter Queue" }
      },
      {
        id: "email-worker",
        type: "worker",
        x: 850,
        y: 180,
        technology: "celery",
        config: {
          displayName: "Email Worker",
          instanceCount: 4,
          perInstanceCapacityRps: 30,
          baseLatencyMs: 60,
          maxProcessingAttempts: 3,
          estimatedCostPerHour: 0.1
        }
      },
      {
        id: "sms-worker",
        type: "worker",
        x: 850,
        y: 360,
        technology: "bullmq",
        config: {
          displayName: "SMS Worker",
          instanceCount: 3,
          perInstanceCapacityRps: 25,
          baseLatencyMs: 70,
          maxProcessingAttempts: 3,
          estimatedCostPerHour: 0.08
        }
      },
      {
        id: "push-worker",
        type: "worker",
        x: 850,
        y: 540,
        technology: "sidekiq",
        config: {
          displayName: "Push Worker",
          instanceCount: 3,
          perInstanceCapacityRps: 80,
          baseLatencyMs: 35,
          maxProcessingAttempts: 2,
          estimatedCostPerHour: 0.08
        }
      },
      {
        id: "email-breaker",
        type: "circuit-breaker",
        x: 1070,
        y: 180,
        technology: "resilience4j",
        config: {
          displayName: "Email Breaker",
          failureThreshold: 0.5,
          rollingWindowSize: 20,
          recoveryIntervalMs: 10_000
        }
      },
      {
        id: "sms-breaker",
        type: "circuit-breaker",
        x: 1070,
        y: 360,
        technology: "polly",
        config: {
          displayName: "SMS Breaker",
          failureThreshold: 0.4,
          rollingWindowSize: 20,
          recoveryIntervalMs: 15_000
        }
      },
      {
        id: "push-breaker",
        type: "circuit-breaker",
        x: 1070,
        y: 540,
        technology: "hystrix",
        config: {
          displayName: "Push Breaker",
          failureThreshold: 0.5,
          rollingWindowSize: 20,
          recoveryIntervalMs: 10_000
        }
      },
      {
        id: "email-provider",
        type: "external-service",
        x: 1300,
        y: 180,
        technology: "sendgrid-email",
        config: {
          displayName: "Email Provider",
          providerLabel: "Transactional email provider",
          slaLatencyMs: 220,
          providerRateLimitRps: 120,
          baseLatencyMs: 220,
          timeoutMs: 5000,
          idempotencySupported: true
        }
      },
      {
        id: "sms-provider",
        type: "external-service",
        x: 1300,
        y: 360,
        technology: "twilio-messaging",
        config: {
          displayName: "SMS Provider",
          providerLabel: "SMS provider",
          slaLatencyMs: 400,
          providerRateLimitRps: 60,
          baseLatencyMs: 400,
          timeoutMs: 6000,
          idempotencySupported: true
        }
      },
      {
        id: "push-provider",
        type: "external-service",
        x: 1300,
        y: 540,
        technology: "firebase-cloud-messaging",
        config: {
          displayName: "Push Provider",
          providerLabel: "Push notification provider",
          slaLatencyMs: 150,
          providerRateLimitRps: 400,
          baseLatencyMs: 150,
          timeoutMs: 4000
        }
      }
    ],
    edges: [
      { from: "client", to: "gateway", kind: "request" },
      { from: "gateway", to: "notify-api", kind: "request", latencyMs: 2 },
      { from: "notify-api", to: "queue", kind: "event", latencyMs: 2 },
      { from: "queue", to: "email-worker", kind: "event", latencyMs: 2 },
      { from: "queue", to: "sms-worker", kind: "event", latencyMs: 2 },
      { from: "queue", to: "push-worker", kind: "event", latencyMs: 2 },
      { from: "queue", to: "dlq", kind: "failover", latencyMs: 1 },
      { from: "email-worker", to: "email-breaker", kind: "request", latencyMs: 1 },
      { from: "sms-worker", to: "sms-breaker", kind: "request", latencyMs: 1 },
      { from: "push-worker", to: "push-breaker", kind: "request", latencyMs: 1 },
      { from: "email-breaker", to: "email-provider", kind: "request", latencyMs: 4 },
      { from: "sms-breaker", to: "sms-provider", kind: "request", latencyMs: 4 },
      { from: "push-breaker", to: "push-provider", kind: "request", latencyMs: 4 }
    ],
    trafficProfiles: [
      constantProfile("notification-traffic", "Notifications 300 RPS", 45_000, 300, {
        readRatio: 0.05,
        requestSizeBytes: 2048,
        responseSizeBytes: 256
      }),
      burstProfile("campaign-send", "Marketing campaign send", 60_000, 200, 2000, 15_000, 30_000, {
        readRatio: 0.02
      })
    ],
    faultScenarios: [
      faultScenario("provider-outage", "SMS provider outage", [
        fault("sms-1", "error-rate-increase", ["sms-provider"], 15_000, {
          endMs: 35_000,
          additionalErrorRate: 0.9
        })
      ]),
      faultScenario("provider-throttle", "Email provider throttling", [
        fault("email-1", "provider-throttling", ["email-provider"], 12_000, {
          endMs: 36_000,
          capacityMultiplier: 0.25
        })
      ]),
      faultScenario("worker-loss", "Push worker loss", [
        fault("push-1", "node-outage", ["push-worker"], 18_000, { endMs: 33_000 })
      ])
    ]
  }
};

const socialMediaFeed: ScenarioTemplate = {
  metadata: {
    id: "social-media-feed",
    version: "1.0.0",
    name: "Social Media Feed",
    summary:
      "A feed platform that reads from cache and a precomputed feed store while writes fan out through an event topic to feed-building workers.",
    difficulty: "intermediate",
    tags: ["fan-out", "cache", "event-topic", "read-heavy", "hot-key"],
    learningObjectives: [
      "Compare fan-out on write against fan-out on read",
      "See why a hot user breaks a fan-out-on-write design",
      "Separate the read path's latency budget from the write path's throughput budget",
      "Reason about the staleness a precomputed feed introduces"
    ],
    estimatedCompletionMinutes: 45,
    recommendedPrerequisites: ["url-shortener", "chat-application"],
    supportedComponentTypes: [
      "client",
      "cdn",
      "api-gateway",
      "server",
      "cache",
      "nosql-database",
      "event-topic",
      "worker"
    ],
    defaultTrafficProfileId: "feed-traffic",
    defaultFaultScenarioIds: ["hot-user-fanout"],
    documentationPath: "docs/scenarios/social-media-feed.md",
    workloadShapes: ["read-heavy", "throughput-sensitive"],
    modelledProperties: [
      "A read path served mostly from cache with a precomputed feed store behind it",
      "A write path that fans out asynchronously through an event topic",
      "Hot-partition skew standing in for a celebrity account's follower fan-out",
      "Feed-builder worker lag translating directly into feed staleness"
    ],
    simplifications: [
      "Follower graph traversal is a single request hop, not a real graph query",
      "Ranking, relevance scoring, and ad insertion are not modelled",
      "Feed deduplication and pagination cursors are out of scope"
    ],
    standIns: [
      {
        concept: "Social graph store",
        modelledAs: "nosql-database",
        rationale:
          "The NoSQL component exposes a graph model plus partitioning, which covers the load characteristics; it does not execute traversals."
      }
    ],
    expectedFindings: [],
    challenges: [
      "Raise the fan-out worker count until feed lag stays under one second during the hot-user fault",
      "Switch the design to fan-out on read by removing the topic and querying the graph directly",
      "Measure the cost difference between the two fan-out strategies"
    ]
  },
  blueprint: {
    projectName: "Social Media Feed",
    nodes: [
      { id: "client", type: "client", x: 0, y: 320, config: { displayName: "Mobile Client" } },
      {
        id: "cdn",
        type: "cdn",
        x: 180,
        y: 320,
        technology: "fastly",
        config: { displayName: "CDN", hitRatio: 0.3, baseLatencyMs: 10 }
      },
      {
        id: "gateway",
        type: "api-gateway",
        x: 380,
        y: 320,
        technology: "kong-gateway",
        config: {
          displayName: "API Gateway",
          authMode: "validate-local",
          policyLatencyMs: 2,
          perInstanceCapacityRps: 8000
        }
      },
      {
        id: "feed-api",
        type: "server",
        x: 620,
        y: 200,
        technology: "nodejs",
        config: {
          displayName: "Feed API",
          instanceCount: 6,
          perInstanceCapacityRps: 250,
          baseLatencyMs: 14,
          jitterMs: 5,
          estimatedCostPerHour: 0.36
        }
      },
      {
        id: "feed-cache",
        type: "cache",
        x: 880,
        y: 120,
        technology: "redis",
        config: {
          displayName: "Feed Cache",
          hitRatio: 0.9,
          ttlMs: 60_000,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 15_000
        }
      },
      {
        id: "feed-store",
        type: "nosql-database",
        x: 1140,
        y: 120,
        technology: "scylladb",
        config: {
          displayName: "Feed Store",
          model: "wide-column",
          consistency: "eventual",
          partitionCount: 64,
          hotPartitionSkew: 0.25,
          replicationLagMs: 60,
          perInstanceCapacityRps: 1200,
          baseLatencyMs: 8,
          estimatedCostPerHour: 0.6
        }
      },
      {
        id: "graph-store",
        type: "nosql-database",
        x: 880,
        y: 280,
        technology: "amazon-dynamodb",
        config: {
          displayName: "Social Graph Store",
          model: "graph",
          consistency: "eventual",
          partitionCount: 32,
          hotPartitionSkew: 0.4,
          replicationLagMs: 50,
          perInstanceCapacityRps: 800,
          baseLatencyMs: 12,
          estimatedCostPerHour: 0.4
        }
      },
      {
        id: "post-svc",
        type: "server",
        x: 620,
        y: 460,
        technology: "django",
        config: {
          displayName: "Post Service",
          instanceCount: 3,
          perInstanceCapacityRps: 120,
          baseLatencyMs: 25,
          estimatedCostPerHour: 0.18
        }
      },
      {
        id: "post-topic",
        type: "event-topic",
        x: 880,
        y: 460,
        technology: "apache-kafka",
        config: {
          displayName: "Post Events",
          partitionCount: 24,
          orderingScope: "partition",
          retentionMs: 43_200_000,
          maxQueueDepth: 300_000,
          perInstanceCapacityRps: 25_000
        }
      },
      {
        id: "fanout-worker",
        type: "worker",
        x: 1140,
        y: 460,
        technology: "nodejs",
        config: {
          displayName: "Fan-out Worker",
          instanceCount: 6,
          perInstanceCapacityRps: 100,
          baseLatencyMs: 30,
          maxProcessingAttempts: 3,
          estimatedCostPerHour: 0.3
        }
      }
    ],
    edges: [
      { from: "client", to: "cdn", kind: "request" },
      { from: "cdn", to: "gateway", kind: "request", latencyMs: 6 },
      { from: "gateway", to: "feed-api", kind: "request", latencyMs: 2, weight: 8 },
      { from: "gateway", to: "post-svc", kind: "request", latencyMs: 2, weight: 1 },
      { from: "feed-api", to: "feed-cache", kind: "request", latencyMs: 1 },
      { from: "feed-cache", to: "feed-store", kind: "request", latencyMs: 2 },
      { from: "feed-api", to: "graph-store", kind: "request", latencyMs: 2 },
      { from: "post-svc", to: "post-topic", kind: "event", latencyMs: 1 },
      { from: "post-topic", to: "fanout-worker", kind: "event", latencyMs: 2 },
      { from: "fanout-worker", to: "feed-store", kind: "request", latencyMs: 3 }
    ],
    trafficProfiles: [
      constantProfile("feed-traffic", "Feed reads 1200 RPS", 45_000, 1200, {
        readRatio: 0.93,
        concurrentUsers: 8000,
        requestSizeBytes: 512,
        responseSizeBytes: 8192
      }),
      burstProfile("breaking-news", "Breaking news surge", 60_000, 900, 4000, 18_000, 34_000, {
        readRatio: 0.9,
        concurrentUsers: 20_000
      })
    ],
    faultScenarios: [
      faultScenario("hot-user-fanout", "Celebrity post fan-out", [
        fault("hot-1", "partition-hotspot", ["feed-store"], 15_000, {
          endMs: 36_000,
          additionalLatencyMs: 200
        })
      ]),
      faultScenario("fanout-worker-loss", "Fan-out worker loss", [
        fault("fanout-1", "capacity-reduction", ["fanout-worker"], 12_000, {
          endMs: 34_000,
          capacityMultiplier: 0.3
        })
      ]),
      faultScenario("feed-cache-loss", "Feed cache loss", [
        fault("cache-1", "cache-failure", ["feed-cache"], 15_000, { endMs: 30_000 })
      ])
    ]
  }
};

const rateLimitedApi: ScenarioTemplate = {
  metadata: {
    id: "rate-limited-public-api",
    version: "1.0.0",
    name: "Rate-Limited Public API",
    summary:
      "A public API protected by an edge filtering layer, token-bucket quotas, and delegated key validation, so abusive traffic is rejected before it reaches the service.",
    difficulty: "intermediate",
    tags: ["rate-limiting", "quota", "abuse", "api-gateway", "retry-amplification"],
    learningObjectives: [
      "Enforce a token-bucket quota and read the resulting rejection rate",
      "See why rejecting cheaply at the edge protects expensive downstream capacity",
      "Recognise retry amplification turning a small overload into a large one",
      "Decide where authentication belongs relative to rate limiting"
    ],
    estimatedCompletionMinutes: 35,
    recommendedPrerequisites: ["basic-web-application"],
    supportedComponentTypes: [
      "client",
      "cdn",
      "api-gateway",
      "identity-auth-service",
      "server",
      "relational-database"
    ],
    defaultTrafficProfileId: "api-traffic",
    defaultFaultScenarioIds: ["abuse-spike"],
    documentationPath: "docs/scenarios/rate-limited-public-api.md",
    workloadShapes: ["throughput-sensitive", "availability-sensitive"],
    modelledProperties: [
      "Token-bucket rate limiting with a configurable burst allowance",
      "Quota rejections counted separately from downstream failures",
      "Delegated API-key validation through an identity component",
      "Traffic spikes and the retry amplification they trigger"
    ],
    simplifications: [
      "Per-key and per-tenant quotas are not modelled; the limit is per gateway",
      "The edge filtering layer inspects nothing: it applies latency and capacity only",
      "Bot detection, CAPTCHA, and IP reputation are out of scope"
    ],
    standIns: [
      {
        concept: "Web application firewall / DDoS protection",
        modelledAs: "cdn",
        rationale:
          "Packet and payload inspection is not simulated, so an edge filtering layer reduces to an edge-terminating component with its own latency, capacity, and failure behaviour. Hit ratio is set to zero because a WAF forwards rather than serves."
      },
      {
        concept: "Rate limiter",
        modelledAs: "api-gateway",
        rationale:
          "The API gateway already implements token-bucket and fixed-window limiting, so a separate node would duplicate it."
      }
    ],
    expectedFindings: [],
    challenges: [
      "Set rateLimitRps below the steady arrival rate and explain the success-rate change",
      "Move the quota behind authentication and describe the new failure mode",
      "Compare token-bucket against fixed-window during the abuse spike"
    ]
  },
  blueprint: {
    projectName: "Rate-Limited Public API",
    nodes: [
      { id: "client", type: "client", x: 0, y: 280, config: { displayName: "API Consumer" } },
      {
        id: "waf",
        type: "cdn",
        x: 210,
        y: 280,
        technology: "cloudflare-waf",
        config: {
          displayName: "Edge Filtering Layer",
          hitRatio: 0,
          perInstanceCapacityRps: 50_000,
          baseLatencyMs: 4
        }
      },
      {
        id: "gateway",
        type: "api-gateway",
        x: 440,
        y: 280,
        technology: "kong-gateway",
        config: {
          displayName: "API Gateway",
          authMode: "delegate",
          policyLatencyMs: 3,
          rateLimitRps: 400,
          rateLimitBurst: 800,
          rateLimitAlgorithm: "token-bucket",
          perInstanceCapacityRps: 5000
        }
      },
      {
        id: "identity",
        type: "identity-auth-service",
        x: 440,
        y: 100,
        technology: "keycloak",
        config: {
          displayName: "API Key Service",
          instanceCount: 2,
          mode: "both",
          validationMode: "introspection",
          cacheHitRatio: 0.85,
          failMode: "fail-closed",
          perInstanceCapacityRps: 1500,
          verificationLatencyMs: 10
        }
      },
      {
        id: "api-svc",
        type: "server",
        x: 700,
        y: 280,
        technology: "aspnet-core",
        config: {
          displayName: "API Service",
          instanceCount: 4,
          perInstanceCapacityRps: 120,
          baseLatencyMs: 28,
          jitterMs: 10,
          maxRetries: 1,
          retryBackoffMs: 150,
          estimatedCostPerHour: 0.24
        }
      },
      {
        id: "db",
        type: "relational-database",
        x: 950,
        y: 280,
        technology: "postgresql",
        config: {
          displayName: "API Database",
          perInstanceCapacityRps: 600,
          baseLatencyMs: 18,
          estimatedCostPerHour: 0.3
        }
      }
    ],
    edges: [
      { from: "client", to: "waf", kind: "request" },
      { from: "waf", to: "gateway", kind: "request", latencyMs: 2 },
      { from: "gateway", to: "identity", kind: "request", latencyMs: 2 },
      { from: "gateway", to: "api-svc", kind: "request", latencyMs: 2 },
      { from: "api-svc", to: "db", kind: "request", latencyMs: 2 }
    ],
    trafficProfiles: [
      constantProfile("api-traffic", "Steady API traffic 350 RPS", 45_000, 350, {
        readRatio: 0.75
      }),
      burstProfile("abuse-burst", "Abusive client burst", 60_000, 300, 3000, 15_000, 32_000, {
        readRatio: 0.9
      })
    ],
    faultScenarios: [
      faultScenario("abuse-spike", "Abuse traffic spike", [
        fault("spike-1", "traffic-spike", ["client"], 15_000, {
          endMs: 33_000,
          trafficMultiplier: 6
        })
      ]),
      faultScenario("quota-exhaustion", "Consumer quota exhaustion", [
        fault("quota-1", "quota-exhaustion", ["gateway"], 12_000, { endMs: 34_000 })
      ]),
      faultScenario("identity-outage", "API key service outage", [
        fault("identity-1", "credential-store-unavailable", ["identity"], 15_000, { endMs: 30_000 })
      ])
    ]
  }
};

export const intermediateScenarios: ScenarioTemplate[] = [
  ecommerceStorefront,
  chatApplication,
  notificationPlatform,
  socialMediaFeed,
  rateLimitedApi
];
