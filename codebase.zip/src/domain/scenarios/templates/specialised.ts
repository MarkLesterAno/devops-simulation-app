import type { ScenarioTemplate } from "@/domain/scenarios/builder";
import {
  burstProfile,
  constantProfile,
  fault,
  faultScenario,
  rampProfile
} from "@/domain/scenarios/profiles";

/**
 * Specialized scenarios: data platforms, machine-learning serving, and
 * multi-tenant isolation. These lean hardest on stand-ins, so each one states
 * plainly which real behaviour is being approximated.
 */

const analyticsEventIngestion: ScenarioTemplate = {
  metadata: {
    id: "analytics-event-ingestion",
    version: "1.0.0",
    name: "Analytics Event Ingestion",
    summary:
      "A high-volume telemetry pipeline that buffers events in a partitioned topic, enriches them in a stream processor, lands raw data in object storage, and serves aggregates from an analytical store.",
    difficulty: "specialized",
    tags: ["analytics", "streaming", "data-lake", "etl", "batch"],
    learningObjectives: [
      "Size an ingestion buffer against a bursty producer rather than a steady one",
      "Separate a hot serving path from a cold archival path",
      "Reason about backpressure when a stream processor cannot keep up",
      "Understand why analytical queries do not belong on the ingestion path"
    ],
    estimatedCompletionMinutes: 55,
    recommendedPrerequisites: ["notification-delivery-platform", "social-media-feed"],
    supportedComponentTypes: [
      "client",
      "load-balancer",
      "server",
      "event-topic",
      "worker",
      "object-storage",
      "nosql-database",
      "relational-database",
      "dead-letter-queue",
      "observability"
    ],
    defaultTrafficProfileId: "telemetry-firehose",
    defaultFaultScenarioIds: ["stream-processor-stall"],
    workloadShapes: ["write-heavy", "throughput-sensitive"],
    documentationPath: "docs/scenarios/analytics-event-ingestion.md",
    modelledProperties: [
      "Topic retention and depth absorbing bursts that exceed processing capacity",
      "Stream-processor throughput as the pipeline's real ceiling",
      "Divergence between the raw archive and the queryable aggregate store",
      "Malformed-event routing to a dead-letter queue"
    ],
    simplifications: [
      "Windowing, watermarks, and late-arriving events are not modelled; each event is processed once on arrival",
      "Columnar storage, partition pruning, and query planning are not modelled; the warehouse is a request-serving store with a capacity and a latency",
      "Batch ETL is represented as a continuous worker rather than a scheduled job, because the simulator has no scheduler component",
      "Event payload size and compression are not modelled, only event rate"
    ],
    standIns: [
      {
        concept: "Stream processor",
        modelledAs: "worker",
        rationale:
          "A stream processor's observable behaviour in this model is consumer throughput and lag against a topic, which the worker component provides."
      },
      {
        concept: "Data lake",
        modelledAs: "object-storage",
        rationale:
          "A lake is durable append-oriented object storage; the file-format and catalogue layers have no simulated behaviour."
      },
      {
        concept: "Data warehouse",
        modelledAs: "relational-database",
        rationale:
          "Analytical serving is modelled as a relational store with low capacity and high latency, which reproduces the cost of putting reporting queries on the critical path."
      },
      {
        concept: "Schema registry / validation service",
        modelledAs: "server",
        rationale:
          "Validation is a synchronous pre-ingest call with its own capacity ceiling; the registry's versioning semantics are not simulated."
      }
    ],
    expectedFindings: [],
    challenges: [
      "Run the firehose burst and find the topic depth high-water mark",
      "Halve the stream processor's instance count and measure how long the backlog takes to drain",
      "Point dashboard traffic at the warehouse directly and explain the latency you see"
    ]
  },
  blueprint: {
    projectName: "Analytics Event Ingestion",
    nodes: [
      { id: "client", type: "client", x: 0, y: 380, config: { displayName: "Instrumented Apps" } },
      {
        id: "ingest-lb",
        type: "load-balancer",
        x: 210,
        y: 380,
        technology: "aws-network-load-balancer",
        config: { displayName: "Ingest Load Balancer", perInstanceCapacityRps: 40_000 }
      },
      {
        id: "collector",
        type: "server",
        x: 440,
        y: 380,
        technology: "google-cloud-run",
        config: {
          displayName: "Event Collector",
          instanceCount: 12,
          perInstanceCapacityRps: 400,
          baseLatencyMs: 6,
          jitterMs: 2,
          estimatedCostPerHour: 0.9
        }
      },
      {
        id: "schema-svc",
        type: "server",
        x: 440,
        y: 140,
        technology: "fastapi",
        config: {
          displayName: "Schema Validation",
          instanceCount: 3,
          perInstanceCapacityRps: 900,
          baseLatencyMs: 3,
          estimatedCostPerHour: 0.18
        }
      },
      {
        id: "event-topic",
        type: "event-topic",
        x: 700,
        y: 380,
        technology: "amazon-msk",
        config: {
          displayName: "Raw Event Topic",
          partitionCount: 48,
          orderingScope: "partition",
          retentionMs: 86_400_000,
          maxQueueDepth: 200_000,
          perInstanceCapacityRps: 60_000
        }
      },
      {
        id: "stream-processor",
        type: "worker",
        x: 960,
        y: 380,
        technology: "apache-airflow",
        config: {
          displayName: "Stream Processor",
          instanceCount: 10,
          perInstanceCapacityRps: 450,
          baseLatencyMs: 20,
          jitterMs: 8,
          estimatedCostPerHour: 1.2
        }
      },
      {
        id: "malformed-dlq",
        type: "dead-letter-queue",
        x: 960,
        y: 620,
        technology: "google-pubsub",
        config: { displayName: "Malformed Events", maxQueueDepth: 20_000 }
      },
      {
        id: "data-lake",
        type: "object-storage",
        x: 1220,
        y: 560,
        technology: "google-cloud-storage",
        config: {
          displayName: "Raw Data Lake",
          perInstanceCapacityRps: 2000,
          baseLatencyMs: 45,
          estimatedCostPerHour: 0.3
        }
      },
      {
        id: "aggregate-store",
        type: "nosql-database",
        x: 1220,
        y: 240,
        technology: "google-cloud-bigtable",
        config: {
          displayName: "Realtime Aggregates",
          model: "time-series",
          consistency: "eventual",
          partitionCount: 32,
          replicationLagMs: 30,
          perInstanceCapacityRps: 8000,
          baseLatencyMs: 6
        }
      },
      {
        id: "warehouse",
        type: "relational-database",
        x: 1220,
        y: 800,
        technology: "google-bigquery",
        config: {
          displayName: "Analytics Warehouse",
          perInstanceCapacityRps: 60,
          baseLatencyMs: 850,
          jitterMs: 300,
          estimatedCostPerHour: 1.4
        }
      },
      {
        id: "dashboard-svc",
        type: "server",
        x: 700,
        y: 800,
        technology: "nodejs",
        config: {
          displayName: "Dashboard Service",
          instanceCount: 2,
          perInstanceCapacityRps: 60,
          baseLatencyMs: 30,
          estimatedCostPerHour: 0.12
        }
      },
      {
        id: "telemetry",
        type: "observability",
        x: 960,
        y: 140,
        technology: "prometheus",
        config: { displayName: "Pipeline Telemetry", perInstanceCapacityRps: 50_000 }
      }
    ],
    edges: [
      { from: "client", to: "ingest-lb", kind: "request" },
      { from: "ingest-lb", to: "collector", kind: "request", latencyMs: 1 },
      { from: "ingest-lb", to: "dashboard-svc", kind: "request", latencyMs: 2 },
      { from: "collector", to: "schema-svc", kind: "request", latencyMs: 1 },
      { from: "collector", to: "event-topic", kind: "event", latencyMs: 2 },
      { from: "event-topic", to: "stream-processor", kind: "event", latencyMs: 2 },
      { from: "event-topic", to: "malformed-dlq", kind: "failover", latencyMs: 1 },
      { from: "stream-processor", to: "aggregate-store", kind: "request", latencyMs: 3 },
      { from: "stream-processor", to: "data-lake", kind: "request", latencyMs: 8 },
      { from: "stream-processor", to: "warehouse", kind: "request", latencyMs: 12 },
      { from: "dashboard-svc", to: "aggregate-store", kind: "request", latencyMs: 4 },
      { from: "collector", to: "telemetry", kind: "observability" },
      { from: "stream-processor", to: "telemetry", kind: "observability" }
    ],
    trafficProfiles: [
      constantProfile("telemetry-firehose", "Steady telemetry firehose", 45_000, 3200, {
        readRatio: 0.05,
        concurrentUsers: 50_000
      }),
      burstProfile("release-burst", "Release-day burst", 60_000, 2800, 9000, 20_000, 34_000, {
        readRatio: 0.05
      })
    ],
    faultScenarios: [
      faultScenario("stream-processor-stall", "Stream processor stalls", [
        fault("sp-stall", "subscriber-group-stall", ["stream-processor"], 16_000, {
          endMs: 40_000,
          capacityMultiplier: 0.2
        })
      ]),
      faultScenario("warehouse-degraded", "Warehouse degraded", [
        fault("wh-slow", "degradation", ["warehouse"], 14_000, {
          endMs: 38_000,
          capacityMultiplier: 0.3,
          additionalLatencyMs: 900
        })
      ]),
      faultScenario("ingest-spike", "Unplanned ingest spike", [
        fault("spike", "traffic-spike", ["collector"], 18_000, {
          endMs: 36_000,
          trafficMultiplier: 3
        })
      ])
    ]
  }
};

const mlInferencePlatform: ScenarioTemplate = {
  metadata: {
    id: "ml-inference-platform",
    version: "1.0.0",
    name: "ML Inference Platform",
    summary:
      "A model-serving tier with a synchronous low-latency path for small requests and an asynchronous queue-backed path for expensive inference, sharing a feature store and a result cache.",
    difficulty: "specialized",
    tags: ["ml", "inference", "gpu", "async", "feature-store"],
    learningObjectives: [
      "Decide which inference requests deserve a synchronous response",
      "Size an expensive, low-throughput compute tier against demand",
      "Use a result cache to avoid recomputing deterministic inference",
      "Protect a scarce resource with a queue instead of with retries"
    ],
    estimatedCompletionMinutes: 55,
    recommendedPrerequisites: ["search-and-recommendation-platform", "payment-processing-workflow"],
    supportedComponentTypes: [
      "client",
      "api-gateway",
      "identity-auth-service",
      "server",
      "cache",
      "nosql-database",
      "message-queue",
      "worker",
      "object-storage",
      "dead-letter-queue",
      "observability"
    ],
    defaultTrafficProfileId: "inference-demand",
    defaultFaultScenarioIds: ["accelerator-capacity-loss"],
    workloadShapes: ["latency-sensitive", "throughput-sensitive", "availability-sensitive"],
    documentationPath: "docs/scenarios/ml-inference-platform.md",
    modelledProperties: [
      "A low-capacity, high-latency serving tier behaving as the system bottleneck",
      "Queue depth on the asynchronous path absorbing demand the serving tier cannot take",
      "Result-cache hit ratio directly reducing expensive compute",
      "Capacity reduction on the serving tier propagating as queue growth, not as errors"
    ],
    simplifications: [
      "Model accuracy, versioning, A/B routing, and drift are not modelled",
      "Batching, token streaming, and per-request compute cost are collapsed into per-instance capacity and latency",
      "Accelerator hardware is represented only by low per-instance capacity and high latency; there is no device model",
      "Training, fine-tuning, and feature backfill pipelines are out of scope"
    ],
    standIns: [
      {
        concept: "Model serving endpoint",
        modelledAs: "server",
        rationale:
          "Serving behaves as a capacity-limited synchronous service; the distinguishing property is a very low per-instance RPS with high base latency."
      },
      {
        concept: "Feature store",
        modelledAs: "nosql-database",
        rationale:
          "Online feature lookup is a low-latency key-value read, which the NoSQL component models including partitioning and replication lag."
      },
      {
        concept: "Inference queue",
        modelledAs: "message-queue",
        rationale:
          "The asynchronous path is an ordinary work queue; depth and consumer lag are exactly the behaviours worth observing."
      },
      {
        concept: "Model artifact registry",
        modelledAs: "object-storage",
        rationale:
          "Artifacts are large immutable objects fetched at startup; the registry's metadata and promotion workflow have no simulated behaviour."
      }
    ],
    expectedFindings: [],
    challenges: [
      "Raise the result cache hit ratio to 0.8 and quantify the serving capacity you free",
      "Run the capacity-loss fault and decide whether more replicas or a deeper queue is the better answer",
      "Move the synchronous path behind the queue and explain what the user now experiences"
    ]
  },
  blueprint: {
    projectName: "ML Inference Platform",
    nodes: [
      { id: "client", type: "client", x: 0, y: 400, config: { displayName: "Application Client" } },
      {
        id: "gateway",
        type: "api-gateway",
        x: 220,
        y: 400,
        technology: "amazon-api-gateway",
        config: {
          displayName: "Inference Gateway",
          authMode: "delegate",
          policyLatencyMs: 3,
          rateLimitRps: 300,
          rateLimitBurst: 150,
          perInstanceCapacityRps: 5000
        }
      },
      {
        id: "identity",
        type: "identity-auth-service",
        x: 220,
        y: 180,
        technology: "amazon-cognito",
        config: {
          displayName: "API Key Service",
          instanceCount: 2,
          mode: "both",
          validationMode: "local-jwt",
          cacheHitRatio: 0.95,
          failMode: "fail-closed",
          perInstanceCapacityRps: 2000
        }
      },
      {
        id: "router",
        type: "server",
        x: 470,
        y: 400,
        technology: "fastapi",
        config: {
          displayName: "Inference Router",
          instanceCount: 4,
          perInstanceCapacityRps: 250,
          baseLatencyMs: 6,
          jitterMs: 2,
          estimatedCostPerHour: 0.28
        }
      },
      {
        id: "result-cache",
        type: "cache",
        x: 720,
        y: 180,
        technology: "redis",
        config: {
          displayName: "Inference Result Cache",
          hitRatio: 0.55,
          ttlMs: 300_000,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 15_000
        }
      },
      {
        id: "feature-store",
        type: "nosql-database",
        x: 720,
        y: 600,
        technology: "aerospike",
        config: {
          displayName: "Online Feature Store",
          model: "key-value",
          consistency: "eventual",
          partitionCount: 32,
          replicationLagMs: 15,
          perInstanceCapacityRps: 6000,
          baseLatencyMs: 3
        }
      },
      {
        id: "realtime-serving",
        type: "server",
        x: 980,
        y: 300,
        technology: "google-kubernetes-engine",
        config: {
          displayName: "Realtime Model Serving",
          instanceCount: 6,
          perInstanceCapacityRps: 12,
          baseLatencyMs: 180,
          jitterMs: 60,
          timeoutMs: 3000,
          estimatedCostPerHour: 4.8
        }
      },
      {
        id: "inference-queue",
        type: "message-queue",
        x: 720,
        y: 400,
        technology: "amazon-sqs",
        config: {
          displayName: "Batch Inference Queue",
          maxQueueDepth: 15_000,
          baseLatencyMs: 3,
          perInstanceCapacityRps: 8000
        }
      },
      {
        id: "batch-serving",
        type: "worker",
        x: 980,
        y: 520,
        technology: "kubernetes",
        config: {
          displayName: "Batch Model Workers",
          instanceCount: 4,
          perInstanceCapacityRps: 8,
          baseLatencyMs: 900,
          jitterMs: 250,
          estimatedCostPerHour: 3.2
        }
      },
      {
        id: "inference-dlq",
        type: "dead-letter-queue",
        x: 980,
        y: 740,
        technology: "amazon-sqs",
        config: { displayName: "Failed Inference", maxQueueDepth: 5000 }
      },
      {
        id: "model-registry",
        type: "object-storage",
        x: 1240,
        y: 620,
        technology: "amazon-s3",
        config: {
          displayName: "Model Artifact Store",
          perInstanceCapacityRps: 120,
          baseLatencyMs: 60,
          estimatedCostPerHour: 0.1
        }
      },
      {
        id: "telemetry",
        type: "observability",
        x: 1240,
        y: 300,
        technology: "opentelemetry",
        config: { displayName: "Model Telemetry", perInstanceCapacityRps: 20_000 }
      }
    ],
    edges: [
      { from: "client", to: "gateway", kind: "request" },
      { from: "gateway", to: "identity", kind: "request", latencyMs: 2 },
      { from: "gateway", to: "router", kind: "request", latencyMs: 2 },
      { from: "router", to: "result-cache", kind: "request", latencyMs: 1 },
      { from: "router", to: "feature-store", kind: "request", latencyMs: 2 },
      { from: "router", to: "realtime-serving", kind: "request", latencyMs: 3 },
      { from: "router", to: "inference-queue", kind: "event", latencyMs: 2 },
      { from: "inference-queue", to: "batch-serving", kind: "event", latencyMs: 2 },
      { from: "inference-queue", to: "inference-dlq", kind: "failover", latencyMs: 1 },
      { from: "batch-serving", to: "feature-store", kind: "request", latencyMs: 2 },
      { from: "batch-serving", to: "model-registry", kind: "request", latencyMs: 10 },
      { from: "realtime-serving", to: "model-registry", kind: "request", latencyMs: 10 },
      { from: "realtime-serving", to: "telemetry", kind: "observability" },
      { from: "batch-serving", to: "telemetry", kind: "observability" }
    ],
    trafficProfiles: [
      rampProfile("inference-demand", "Growing inference demand", 60_000, 40, 180, {
        readRatio: 0.6,
        concurrentUsers: 800
      }),
      burstProfile("campaign-burst", "Campaign burst", 60_000, 50, 320, 22_000, 36_000, {
        readRatio: 0.6
      })
    ],
    faultScenarios: [
      faultScenario("accelerator-capacity-loss", "Accelerator capacity lost", [
        fault("gpu-loss", "capacity-reduction", ["realtime-serving"], 16_000, {
          endMs: 42_000,
          capacityMultiplier: 0.35
        })
      ]),
      faultScenario("feature-store-latency", "Feature store slows down", [
        fault("fs-slow", "latency-increase", ["feature-store"], 14_000, {
          endMs: 36_000,
          additionalLatencyMs: 150
        })
      ]),
      faultScenario("batch-worker-stall", "Batch workers stall", [
        fault("batch-stall", "queue-consumer-failure", ["batch-serving"], 15_000, { endMs: 40_000 })
      ])
    ]
  }
};

const multiTenantSaas: ScenarioTemplate = {
  metadata: {
    id: "multi-tenant-saas",
    version: "1.0.0",
    name: "Multi-Tenant SaaS Platform",
    summary:
      "A shared control and data plane with per-tenant quota enforcement at the gateway, a pooled tenant database, and a dedicated shard for large tenants to contain the noisy-neighbour problem.",
    difficulty: "specialized",
    tags: ["multi-tenancy", "quota", "isolation", "noisy-neighbour", "saas"],
    learningObjectives: [
      "Recognise the noisy-neighbour failure mode and where it must be contained",
      "Compare pooled and siloed tenant data models on the same architecture",
      "Use gateway quotas as an isolation mechanism, not just a billing mechanism",
      "Reason about the blast radius of a single tenant's traffic spike"
    ],
    estimatedCompletionMinutes: 60,
    recommendedPrerequisites: ["rate-limited-public-api", "ecommerce-storefront"],
    supportedComponentTypes: [
      "client",
      "cdn",
      "api-gateway",
      "identity-auth-service",
      "server",
      "cache",
      "relational-database",
      "read-replica",
      "message-queue",
      "worker",
      "observability"
    ],
    defaultTrafficProfileId: "mixed-tenant-load",
    defaultFaultScenarioIds: ["noisy-neighbour-spike"],
    workloadShapes: ["read-heavy", "availability-sensitive", "throughput-sensitive"],
    documentationPath: "docs/scenarios/multi-tenant-saas.md",
    modelledProperties: [
      "Gateway quota enforcement shedding excess traffic before it reaches shared capacity",
      "A pooled database shared by many tenants reaching saturation from one tenant's load",
      "A siloed shard whose latency is unaffected by pooled-tier saturation",
      "Background tenant work isolated onto its own queue and worker pool"
    ],
    simplifications: [
      "Tenancy is structural, not data-level: the simulator has no notion of a tenant id, so isolation is modelled by routing to separate nodes",
      "Per-tenant quotas are modelled as one aggregate gateway rate limit, not as independent per-key buckets",
      "Row-level security, encryption keys per tenant, and tenant onboarding workflows are not modelled",
      "Billing, metering, and usage aggregation are out of scope"
    ],
    standIns: [
      {
        concept: "Per-tenant quota manager",
        modelledAs: "api-gateway",
        rationale:
          "The gateway already enforces a token-bucket rate limit, which reproduces the observable effect of quota exhaustion: shed load at the edge instead of saturation downstream."
      },
      {
        concept: "Tenant configuration service",
        modelledAs: "cache",
        rationale:
          "Tenant settings are read on nearly every request and change rarely, so a high-hit-ratio cache captures their cost accurately."
      },
      {
        concept: "Web application firewall",
        modelledAs: "cdn",
        rationale:
          "Edge filtering is modelled as a pass-through edge node with no caching, adding latency and an inspection capacity ceiling without changing routing."
      }
    ],
    expectedFindings: [],
    challenges: [
      "Run the noisy-neighbour spike and confirm the siloed tenant's latency is unaffected",
      "Set the gateway rateLimitRps to 0 and describe what the pooled tier does instead",
      "Move the large tenant back onto the pooled database and measure the cost to everyone else"
    ]
  },
  blueprint: {
    projectName: "Multi-Tenant SaaS Platform",
    nodes: [
      { id: "client", type: "client", x: 0, y: 400, config: { displayName: "Tenant Users" } },
      {
        id: "edge-filter",
        type: "cdn",
        x: 200,
        y: 400,
        technology: "cloudflare-waf",
        config: {
          displayName: "Edge Filter (WAF)",
          hitRatio: 0,
          baseLatencyMs: 6,
          perInstanceCapacityRps: 30_000
        }
      },
      {
        id: "gateway",
        type: "api-gateway",
        x: 420,
        y: 400,
        technology: "kong-gateway",
        config: {
          displayName: "Tenant API Gateway",
          authMode: "delegate",
          policyLatencyMs: 4,
          rateLimitRps: 900,
          rateLimitBurst: 300,
          rateLimitAlgorithm: "token-bucket",
          perInstanceCapacityRps: 8000
        }
      },
      {
        id: "identity",
        type: "identity-auth-service",
        x: 420,
        y: 160,
        technology: "keycloak",
        config: {
          displayName: "Tenant Identity",
          instanceCount: 3,
          mode: "both",
          validationMode: "introspection",
          cacheHitRatio: 0.88,
          verificationLatencyMs: 12,
          failMode: "fail-closed",
          perInstanceCapacityRps: 1400
        }
      },
      {
        id: "tenant-config",
        type: "cache",
        x: 660,
        y: 160,
        technology: "redis",
        config: {
          displayName: "Tenant Config Cache",
          hitRatio: 0.97,
          ttlMs: 600_000,
          baseLatencyMs: 1,
          perInstanceCapacityRps: 20_000
        }
      },
      {
        id: "app-pooled",
        type: "server",
        x: 660,
        y: 400,
        technology: "aspnet-core",
        config: {
          displayName: "Shared App Tier",
          instanceCount: 8,
          perInstanceCapacityRps: 130,
          baseLatencyMs: 22,
          jitterMs: 9,
          estimatedCostPerHour: 0.64
        }
      },
      {
        id: "app-silo",
        type: "server",
        x: 660,
        y: 680,
        technology: "aspnet-core",
        config: {
          displayName: "Enterprise App Tier",
          instanceCount: 3,
          perInstanceCapacityRps: 130,
          baseLatencyMs: 22,
          jitterMs: 9,
          estimatedCostPerHour: 0.24
        }
      },
      {
        id: "db-pooled",
        type: "relational-database",
        x: 940,
        y: 400,
        technology: "amazon-aurora",
        config: {
          displayName: "Pooled Tenant Database",
          perInstanceCapacityRps: 700,
          baseLatencyMs: 19,
          jitterMs: 8,
          estimatedCostPerHour: 0.85
        }
      },
      {
        id: "db-silo",
        type: "relational-database",
        x: 940,
        y: 680,
        technology: "amazon-aurora",
        config: {
          displayName: "Enterprise Tenant Shard",
          perInstanceCapacityRps: 400,
          baseLatencyMs: 17,
          estimatedCostPerHour: 0.55
        }
      },
      {
        id: "db-pooled-replica",
        type: "read-replica",
        x: 1200,
        y: 260,
        technology: "amazon-aurora",
        config: {
          displayName: "Pooled Read Replica",
          perInstanceCapacityRps: 900,
          baseLatencyMs: 15,
          estimatedCostPerHour: 0.5
        }
      },
      {
        id: "tenant-jobs",
        type: "message-queue",
        x: 940,
        y: 900,
        technology: "rabbitmq",
        config: {
          displayName: "Tenant Background Jobs",
          maxQueueDepth: 12_000,
          baseLatencyMs: 3,
          perInstanceCapacityRps: 6000
        }
      },
      {
        id: "job-worker",
        type: "worker",
        x: 1200,
        y: 900,
        technology: "celery",
        config: {
          displayName: "Job Workers",
          instanceCount: 4,
          perInstanceCapacityRps: 70,
          baseLatencyMs: 70,
          jitterMs: 25,
          estimatedCostPerHour: 0.26
        }
      },
      {
        id: "telemetry",
        type: "observability",
        x: 1200,
        y: 520,
        technology: "datadog",
        config: { displayName: "Per-Tenant Telemetry", perInstanceCapacityRps: 30_000 }
      }
    ],
    edges: [
      { from: "client", to: "edge-filter", kind: "request" },
      { from: "edge-filter", to: "gateway", kind: "request", latencyMs: 3 },
      { from: "gateway", to: "identity", kind: "request", latencyMs: 2 },
      { from: "gateway", to: "app-pooled", kind: "request", latencyMs: 2, weight: 0.8 },
      { from: "gateway", to: "app-silo", kind: "request", latencyMs: 2, weight: 0.2 },
      { from: "app-pooled", to: "tenant-config", kind: "request", latencyMs: 1 },
      { from: "app-silo", to: "tenant-config", kind: "request", latencyMs: 1 },
      { from: "app-pooled", to: "db-pooled", kind: "request", latencyMs: 3 },
      { from: "app-pooled", to: "db-pooled-replica", kind: "request", latencyMs: 3 },
      { from: "app-silo", to: "db-silo", kind: "request", latencyMs: 3 },
      { from: "db-pooled", to: "db-pooled-replica", kind: "replication", latencyMs: 25 },
      { from: "app-pooled", to: "tenant-jobs", kind: "event", latencyMs: 2 },
      { from: "app-silo", to: "tenant-jobs", kind: "event", latencyMs: 2 },
      { from: "tenant-jobs", to: "job-worker", kind: "event", latencyMs: 2 },
      { from: "app-pooled", to: "telemetry", kind: "observability" },
      { from: "job-worker", to: "telemetry", kind: "observability" }
    ],
    trafficProfiles: [
      constantProfile("mixed-tenant-load", "Mixed tenant load", 45_000, 640, {
        readRatio: 0.82,
        concurrentUsers: 6000
      }),
      rampProfile("onboarding-growth", "Tenant onboarding growth", 60_000, 400, 1500, {
        readRatio: 0.82
      })
    ],
    faultScenarios: [
      faultScenario("noisy-neighbour-spike", "Noisy neighbour floods the pooled tier", [
        fault("noisy", "traffic-spike", ["app-pooled"], 16_000, {
          endMs: 40_000,
          trafficMultiplier: 2.6
        })
      ]),
      faultScenario("quota-exhaustion", "Tenant quota exhausted", [
        fault("quota", "quota-exhaustion", ["gateway"], 14_000, {
          endMs: 36_000,
          additionalErrorRate: 0.25
        })
      ]),
      faultScenario("pooled-db-failure", "Pooled database primary fails", [
        fault("pooled-down", "database-primary-failure", ["db-pooled"], 18_000, { endMs: 40_000 })
      ])
    ]
  }
};

export const specialisedScenarios: ScenarioTemplate[] = [
  analyticsEventIngestion,
  mlInferencePlatform,
  multiTenantSaas
];
