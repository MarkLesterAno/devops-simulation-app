import type {
  ArchitectureEdge,
  ArchitectureNode,
  ComponentType,
  ConnectionKind,
  TechnologyAssignment
} from "@/domain/architecture/schema";
import { baseComponentConfigSchema } from "@/domain/architecture/schema";
import { componentConfigSchemas } from "@/domain/components/configSchemas";
import { componentDefinitions } from "@/domain/components/registry";
import {
  PROJECT_SCHEMA_VERSION,
  type ProjectDocument
} from "@/domain/architecture/projectDocument";
import { trafficProfileSchema, type TrafficProfile } from "@/domain/simulation/trafficProfile";
import { faultScenarioSchema, type FaultScenario } from "@/domain/simulation/faultScenario";
import { getTechnologyById, toTechnologyAssignment } from "@/domain/technology/registry";
import type { ScenarioTemplateMetadata } from "@/domain/scenarios/schema";
import type { TutorialMode } from "@/domain/scenarios/schema";

/**
 * Authoring helpers for scenario templates.
 *
 * Templates are written as data, not as hand-assembled project documents, so a
 * catalog change that breaks a default configuration surfaces as a build-time
 * throw in one place instead of as a silently invalid saved project.
 */

export interface ScenarioNodeSpec {
  id: string;
  type: ComponentType;
  x: number;
  y: number;
  /** Overrides merged over the component's registered defaults. */
  config?: Record<string, unknown>;
  /** Technology catalog id assigned as educational metadata. */
  technology?: string;
}

export interface ScenarioEdgeSpec {
  from: string;
  to: string;
  kind: ConnectionKind;
  latencyMs?: number;
  weight?: number;
  routingStrategy?: ArchitectureEdge["routingStrategy"];
}

export interface ScenarioBlueprint {
  /** Project name applied when the template is opened. */
  projectName: string;
  nodes: ScenarioNodeSpec[];
  edges: ScenarioEdgeSpec[];
  trafficProfiles: unknown[];
  faultScenarios: unknown[];
}

export interface ScenarioTemplate {
  metadata: ScenarioTemplateMetadata;
  blueprint: ScenarioBlueprint;
}

export interface ScenarioStartingState {
  kind: "empty" | "origin-only" | "partial" | "complete";
  nodes: ScenarioNodeSpec[];
  edges: ScenarioEdgeSpec[];
  omittedComponentTypes: ComponentType[];
  omittedCapabilities: string[];
  rationale: string;
}

/**
 * The reference blueprint is the Guided Tour answer. Build and Challenge use
 * intentionally smaller states, but never treat the reference topology as the
 * only correct learner solution.
 */
export function getScenarioStartingState(
  template: ScenarioTemplate,
  mode: TutorialMode
): ScenarioStartingState {
  const complete = (): ScenarioStartingState => ({
    kind: "complete",
    nodes: template.blueprint.nodes,
    edges: template.blueprint.edges,
    omittedComponentTypes: [],
    omittedCapabilities: [],
    rationale: "Guided Tour starts from the reference solution so it can explain modeled behavior."
  });
  if (mode === "guided-tour") return complete();
  if (mode === "challenge") {
    return {
      kind: "empty",
      nodes: [],
      edges: [],
      omittedComponentTypes: template.metadata.supportedComponentTypes,
      omittedCapabilities: template.metadata.modelledProperties,
      rationale:
        "Challenge mode begins with a blank canvas. Design alternatives are assessed by graph validity and measured outcomes, not similarity to the reference."
    };
  }

  const client = template.blueprint.nodes.find((node) => node.type === "client");
  if (template.metadata.difficulty === "beginner") {
    return {
      kind: "origin-only",
      nodes: client ? [client] : [],
      edges: [],
      omittedComponentTypes: template.metadata.supportedComponentTypes.filter((type) => type !== "client"),
      omittedCapabilities: template.metadata.modelledProperties,
      rationale:
        "Build mode provides only the request origin so the learner chooses an ingress, service, and persistence path."
    };
  }

  const ingressTypes: ComponentType[] = ["client", "cdn", "dns-traffic-manager", "api-gateway", "load-balancer"];
  const nodes = template.blueprint.nodes.filter((node) => ingressTypes.includes(node.type));
  const includedIds = new Set(nodes.map((node) => node.id));
  return {
    kind: "partial",
    nodes,
    edges: template.blueprint.edges.filter(
      (edge) => includedIds.has(edge.from) && includedIds.has(edge.to)
    ),
    omittedComponentTypes: [
      ...new Set(template.blueprint.nodes.filter((node) => !includedIds.has(node.id)).map((node) => node.type))
    ],
    omittedCapabilities: template.metadata.modelledProperties,
    rationale:
      "Build mode includes the request entry path but deliberately omits the service, data, and asynchronous topology that the learner must justify from the requirements."
  };
}

/**
 * Resolves a technology id against the live catalog.
 *
 * Throws rather than falling back to generic: a template shipping a typo would
 * otherwise render a silently unassigned node and quietly lose its teaching
 * point about implementation choice.
 */
function resolveTechnology(technologyId: string, type: ComponentType): TechnologyAssignment {
  const option = getTechnologyById(technologyId);
  if (!option) {
    throw new Error(`Scenario template references unknown technology id "${technologyId}".`);
  }
  if (!option.componentTypes.includes(type)) {
    throw new Error(
      `Technology "${technologyId}" is not valid for component type "${type}".`
    );
  }
  return toTechnologyAssignment(option);
}

/**
 * Builds a node from registered defaults plus template overrides.
 *
 * Parsing is done with `.passthrough()` because component types without a
 * narrowed schema still carry meaningful extra fields (a cache's `hitRatio`,
 * for example) that a strict parse would silently strip.
 */
export function buildScenarioNode(spec: ScenarioNodeSpec): ArchitectureNode {
  const definition = componentDefinitions[spec.type];
  const merged: Record<string, unknown> = {
    ...definition.defaultConfiguration,
    ...spec.config
  };
  if (spec.technology) {
    merged["technology"] = resolveTechnology(spec.technology, spec.type);
  }

  const schema = componentConfigSchemas[spec.type] ?? baseComponentConfigSchema;
  const parsed = (schema as typeof baseComponentConfigSchema).passthrough().safeParse(merged);
  if (!parsed.success) {
    throw new Error(
      `Invalid configuration for scenario node "${spec.id}": ${parsed.error.issues
        .map((issue) => `${issue.path.join(".")} ${issue.message}`)
        .join("; ")}`
    );
  }

  const issues = definition.validateConfiguration(parsed.data as never);
  if (issues.length > 0) {
    throw new Error(
      `Invalid configuration for scenario node "${spec.id}": ${issues
        .map((issue) => `${issue.field} ${issue.message}`)
        .join("; ")}`
    );
  }

  return {
    id: spec.id,
    type: spec.type,
    position: { x: spec.x, y: spec.y },
    config: parsed.data as ArchitectureNode["config"]
  };
}

/**
 * Builds an edge, checking it against the component registry's allowed
 * connection kinds so a template can never ship a connection the canvas itself
 * would have refused to draw.
 */
export function buildScenarioEdge(
  spec: ScenarioEdgeSpec,
  nodesById: Map<string, ArchitectureNode>
): ArchitectureEdge {
  const source = nodesById.get(spec.from);
  const target = nodesById.get(spec.to);
  if (!source) throw new Error(`Scenario edge references unknown source node "${spec.from}".`);
  if (!target) throw new Error(`Scenario edge references unknown target node "${spec.to}".`);

  if (!componentDefinitions[source.type].allowedOutgoingConnections.includes(spec.kind)) {
    throw new Error(
      `"${source.type}" cannot send a "${spec.kind}" connection (edge ${spec.from} -> ${spec.to}).`
    );
  }
  if (!componentDefinitions[target.type].allowedIncomingConnections.includes(spec.kind)) {
    throw new Error(
      `"${target.type}" cannot receive a "${spec.kind}" connection (edge ${spec.from} -> ${spec.to}).`
    );
  }

  return {
    id: `${spec.from}--${spec.kind}--${spec.to}`,
    sourceNodeId: spec.from,
    targetNodeId: spec.to,
    kind: spec.kind,
    latencyMs: spec.latencyMs ?? 0,
    ...(spec.weight === undefined ? {} : { weight: spec.weight }),
    ...(spec.routingStrategy === undefined ? {} : { routingStrategy: spec.routingStrategy })
  };
}

export interface BuildScenarioOptions {
  /** Injected in tests so a template build is reproducible. */
  id?: string;
  now?: string;
  mode?: TutorialMode;
}

/**
 * Materialises a template into a project document ready for the project store.
 *
 * The document carries a fresh project id: opening a template creates the
 * learner's own copy, it does not hand them a shared document that a later
 * template update would overwrite.
 */
export function buildScenarioDocument(
  template: ScenarioTemplate,
  options: BuildScenarioOptions = {}
): ProjectDocument {
  const now = options.now ?? new Date().toISOString();
  const startingState = getScenarioStartingState(template, options.mode ?? "guided-tour");
  const nodes = startingState.nodes.map(buildScenarioNode);
  const nodesById = new Map(nodes.map((node) => [node.id, node]));
  const edges = startingState.edges.map((spec) => buildScenarioEdge(spec, nodesById));

  const trafficProfiles: TrafficProfile[] = template.blueprint.trafficProfiles.map((profile) =>
    trafficProfileSchema.parse(profile)
  );
  const faultScenarios: FaultScenario[] = template.blueprint.faultScenarios.map((scenario) =>
    faultScenarioSchema.parse(scenario)
  );

  return {
    schemaVersion: PROJECT_SCHEMA_VERSION,
    id: options.id ?? crypto.randomUUID(),
    name: template.blueprint.projectName,
    createdAt: now,
    updatedAt: now,
    nodes,
    edges,
    trafficProfiles,
    faultScenarios
  };
}
