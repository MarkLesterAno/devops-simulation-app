import type { ScenarioTemplate } from "@/domain/scenarios/builder";
import {
  scenarioTemplateMetadataSchema,
  type ScenarioDifficulty,
  type ScenarioTemplateMetadata
} from "@/domain/scenarios/schema";
import { beginnerScenarios } from "@/domain/scenarios/templates/beginner";
import { intermediateScenarios } from "@/domain/scenarios/templates/intermediate";
import { advancedScenarios } from "@/domain/scenarios/templates/advanced";
import { specialisedScenarios } from "@/domain/scenarios/templates/specialised";
import { buildScenarioRequestPresets, type ScenarioRequestPreset } from "@/domain/scenarios/requestPresets";
import { buildScenarioFaultPresets, type ScenarioFaultPreset } from "@/domain/scenarios/faultPresets";

const rawScenarios: ScenarioTemplate[] = [
  ...beginnerScenarios,
  ...intermediateScenarios,
  ...advancedScenarios,
  ...specialisedScenarios
];

/**
 * Parses and integrity-checks the scenario library at module load, mirroring
 * the technology catalog's fail-fast policy: a malformed template must never
 * reach the gallery, and a template whose declared default profile or fault
 * scenario does not exist would be a broken lesson rather than a broken build.
 */
export function buildScenarioLibrary(templates: ScenarioTemplate[]): ScenarioTemplate[] {
  const seenIds = new Set<string>();

  for (const template of templates) {
    const parsed = scenarioTemplateMetadataSchema.safeParse(template.metadata);
    if (!parsed.success) {
      const label = template.metadata?.id ?? "unknown";
      throw new Error(`Invalid scenario template "${label}": ${parsed.error.message}`);
    }
    const metadata = parsed.data;

    if (seenIds.has(metadata.id)) {
      throw new Error(`Duplicate scenario template id "${metadata.id}".`);
    }
    seenIds.add(metadata.id);

    const profileIds = new Set(
      template.blueprint.trafficProfiles.map(
        (profile) => (profile as { id?: string }).id ?? ""
      )
    );
    if (!profileIds.has(metadata.defaultTrafficProfileId)) {
      throw new Error(
        `Scenario "${metadata.id}" declares default traffic profile "${metadata.defaultTrafficProfileId}", which it does not define.`
      );
    }

    const scenarioIds = new Set(
      template.blueprint.faultScenarios.map((scenario) => (scenario as { id?: string }).id ?? "")
    );
    for (const faultScenarioId of metadata.defaultFaultScenarioIds) {
      if (!scenarioIds.has(faultScenarioId)) {
        throw new Error(
          `Scenario "${metadata.id}" declares default fault scenario "${faultScenarioId}", which it does not define.`
        );
      }
    }

    const nodeTypes = new Set(template.blueprint.nodes.map((node) => node.type));
    for (const declared of metadata.supportedComponentTypes) {
      if (!nodeTypes.has(declared)) {
        throw new Error(
          `Scenario "${metadata.id}" lists component type "${declared}" that no node uses.`
        );
      }
    }
    for (const used of nodeTypes) {
      if (!metadata.supportedComponentTypes.includes(used)) {
        throw new Error(
          `Scenario "${metadata.id}" uses component type "${used}" without declaring it.`
        );
      }
    }
  }

  return templates;
}

export const scenarioTemplates: ScenarioTemplate[] = buildScenarioLibrary(rawScenarios);

const templatesById = new Map(
  scenarioTemplates.map((template) => [template.metadata.id, template])
);

export function getScenarioTemplate(id: string): ScenarioTemplate | undefined {
  return templatesById.get(id);
}

/** Immutable request exercises derived from the selected template. */
export function getScenarioRequestPresets(id: string): ScenarioRequestPreset[] {
  const template = getScenarioTemplate(id);
  return template ? buildScenarioRequestPresets(template) : [];
}

export function getScenarioFaultPresets(id: string): ScenarioFaultPreset[] {
  const template = getScenarioTemplate(id);
  return template ? buildScenarioFaultPresets(template) : [];
}

export const scenarioDifficultyOrder: ScenarioDifficulty[] = [
  "beginner",
  "intermediate",
  "advanced",
  "specialized"
];

export function getScenarioMetadata(): ScenarioTemplateMetadata[] {
  return scenarioTemplates.map((template) => template.metadata);
}

/** Every tag in the library, de-duplicated and sorted for filter controls. */
export function getScenarioTags(): string[] {
  const tags = new Set<string>();
  for (const template of scenarioTemplates) {
    for (const tag of template.metadata.tags) tags.add(tag);
  }
  return [...tags].sort((left, right) => left.localeCompare(right));
}

export interface ScenarioFilters {
  search?: string;
  difficulty?: ScenarioDifficulty;
  tag?: string;
}

export function filterScenarios(
  templates: ScenarioTemplate[],
  filters: ScenarioFilters
): ScenarioTemplate[] {
  const search = filters.search?.trim().toLowerCase();
  return templates.filter(({ metadata }) => {
    if (filters.difficulty && metadata.difficulty !== filters.difficulty) return false;
    if (filters.tag && !metadata.tags.includes(filters.tag)) return false;
    if (!search) return true;
    const haystack = [
      metadata.name,
      metadata.summary,
      ...metadata.tags,
      ...metadata.learningObjectives
    ]
      .join(" ")
      .toLowerCase();
    return haystack.includes(search);
  });
}
