import type { z } from "zod";
import type {
  ArchitectureNode,
  BaseComponentConfig,
  ComponentCategory,
  ComponentType,
  ConnectionKind
} from "@/domain/architecture/schema";
import { baseComponentConfigSchema } from "@/domain/architecture/schema";
import {
  apiGatewayConfigSchema,
  dnsConfigSchema,
  eventTopicConfigSchema,
  externalServiceConfigSchema,
  identityAuthConfigSchema,
  nosqlConfigSchema,
  validateTypedConfig
} from "@/domain/components/configSchemas";

export interface ValidationIssueLite {
  field: string;
  message: string;
}

/**
 * ComponentDefinition contract from TRD.md's domain model. Each entry in
 * COMPONENT_CATALOG.md is registered here with metadata, allowed edge kinds,
 * defaults, and a validator. The simulation engine intentionally does not
 * hard-code this catalog; it reads registered defaults through this registry.
 */
export interface ComponentDefinition<TConfig extends BaseComponentConfig = BaseComponentConfig> {
  type: ComponentType;
  displayName: string;
  category: ComponentCategory;
  description: string;
  fidelity: "conceptual" | "behavioral" | "advanced";
  allowedIncomingConnections: ConnectionKind[];
  allowedOutgoingConnections: ConnectionKind[];
  defaultConfiguration: TConfig;
  validateConfiguration(configuration: TConfig): ValidationIssueLite[];
}

function withDefaults<T extends Record<string, unknown>>(
  base: z.infer<typeof baseComponentConfigSchema>,
  extra: T
): BaseComponentConfig & T {
  return { ...base, ...extra };
}

const commonDefaults = baseComponentConfigSchema.parse({ displayName: "Component" });

export const componentDefinitions: Record<ComponentType, ComponentDefinition> = {
  client: {
    type: "client",
    displayName: "Client",
    category: "entry",
    description: "Generates synchronous requests that enter the system.",
    fidelity: "conceptual",
    allowedIncomingConnections: [],
    allowedOutgoingConnections: ["request"],
    defaultConfiguration: withDefaults(commonDefaults, { displayName: "Client", requestClass: "default" }),
    validateConfiguration: () => []
  },
  cdn: {
    type: "cdn",
    displayName: "CDN",
    category: "entry",
    description: "Serves cached content at the edge or forwards to origin.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request"],
    allowedOutgoingConnections: ["request", "observability"],
    defaultConfiguration: withDefaults(commonDefaults, {
      displayName: "CDN",
      hitRatio: 0.85,
      baseLatencyMs: 15
    }),
    validateConfiguration: (config) => {
      const hitRatio = (config as Record<string, unknown>)["hitRatio"];
      if (typeof hitRatio === "number" && (hitRatio < 0 || hitRatio > 1)) {
        return [{ field: "hitRatio", message: "hitRatio must be between 0 and 1" }];
      }
      return [];
    }
  },
  "load-balancer": {
    type: "load-balancer",
    displayName: "Load Balancer",
    category: "entry",
    description: "Routes work among healthy targets using a declared algorithm.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request"],
    allowedOutgoingConnections: ["request", "observability"],
    defaultConfiguration: withDefaults(commonDefaults, {
      displayName: "Load Balancer",
      baseLatencyMs: 1,
      healthCheckIntervalMs: 5000
    }),
    validateConfiguration: () => []
  },
  server: {
    type: "server",
    displayName: "Server",
    category: "compute",
    description: "Hosts backend APIs; processes and forwards synchronous requests.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request"],
    allowedOutgoingConnections: ["request", "event", "observability"],
    defaultConfiguration: withDefaults(commonDefaults, {
      displayName: "Server",
      baseLatencyMs: 40,
      jitterMs: 10
    }),
    validateConfiguration: () => []
  },
  worker: {
    type: "worker",
    displayName: "Worker",
    category: "compute",
    description: "Consumes asynchronous messages from a queue.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["event", "request"],
    allowedOutgoingConnections: ["request", "event", "observability"],
    defaultConfiguration: withDefaults(commonDefaults, {
      displayName: "Worker",
      baseLatencyMs: 80,
      maxProcessingAttempts: 3
    }),
    validateConfiguration: () => []
  },
  cache: {
    type: "cache",
    displayName: "Cache",
    category: "performance",
    description: "Reads and writes cached values and forwards misses to an origin.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request"],
    allowedOutgoingConnections: ["request", "observability"],
    defaultConfiguration: withDefaults(commonDefaults, {
      displayName: "Cache",
      hitRatio: 0.8,
      ttlMs: 60_000,
      evictionPolicy: "lru",
      baseLatencyMs: 2
    }),
    validateConfiguration: (config) => {
      const hitRatio = (config as Record<string, unknown>)["hitRatio"];
      if (typeof hitRatio === "number" && (hitRatio < 0 || hitRatio > 1)) {
        return [{ field: "hitRatio", message: "hitRatio must be between 0 and 1" }];
      }
      return [];
    }
  },
  "relational-database": {
    type: "relational-database",
    displayName: "Relational Database",
    category: "data",
    description: "Serves reads and primary writes.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request"],
    allowedOutgoingConnections: ["replication", "observability"],
    defaultConfiguration: withDefaults(commonDefaults, {
      displayName: "Relational Database",
      role: "primary",
      baseLatencyMs: 25
    }),
    validateConfiguration: () => []
  },
  "read-replica": {
    type: "read-replica",
    displayName: "Read Replica",
    category: "data",
    description: "Serves reads with modeled replication lag.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request", "replication"],
    allowedOutgoingConnections: ["observability"],
    defaultConfiguration: withDefaults(commonDefaults, {
      displayName: "Read Replica",
      replicaLagMs: 200,
      baseLatencyMs: 20
    }),
    validateConfiguration: () => []
  },
  "object-storage": {
    type: "object-storage",
    displayName: "Object Storage",
    category: "data",
    description: "Stores and retrieves large binary objects such as files, media, and backups.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request"],
    allowedOutgoingConnections: ["observability"],
    defaultConfiguration: withDefaults(commonDefaults, {
      displayName: "Object Storage",
      baseLatencyMs: 40,
      perInstanceCapacityRps: 200
    }),
    validateConfiguration: () => []
  },
  "message-queue": {
    type: "message-queue",
    displayName: "Message Queue",
    category: "messaging",
    description: "Buffers messages for asynchronous consumers.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["event", "request"],
    allowedOutgoingConnections: ["event", "request", "failover", "observability"],
    defaultConfiguration: withDefaults(commonDefaults, {
      displayName: "Message Queue",
      retentionMs: 3_600_000,
      maxQueueDepth: 5000
    }),
    validateConfiguration: () => []
  },
  "dead-letter-queue": {
    type: "dead-letter-queue",
    displayName: "Dead-Letter Queue",
    category: "messaging",
    description: "Retains messages that exceed processing attempts.",
    fidelity: "conceptual",
    allowedIncomingConnections: ["failover", "event"],
    allowedOutgoingConnections: [],
    defaultConfiguration: withDefaults(commonDefaults, { displayName: "Dead-Letter Queue" }),
    validateConfiguration: () => []
  },
  "circuit-breaker": {
    type: "circuit-breaker",
    displayName: "Circuit Breaker",
    category: "reliability",
    description: "Protects downstream calls after a failure threshold is crossed.",
    fidelity: "advanced",
    allowedIncomingConnections: ["request"],
    allowedOutgoingConnections: ["request", "observability"],
    defaultConfiguration: withDefaults(commonDefaults, {
      displayName: "Circuit Breaker",
      failureThreshold: 0.5,
      rollingWindowSize: 20,
      recoveryIntervalMs: 10_000
    }),
    validateConfiguration: () => []
  },
  autoscaler: {
    type: "autoscaler",
    displayName: "Autoscaler",
    category: "reliability",
    description: "Changes component instance counts after configured delays.",
    fidelity: "advanced",
    allowedIncomingConnections: ["observability"],
    allowedOutgoingConnections: [],
    defaultConfiguration: withDefaults(commonDefaults, {
      displayName: "Autoscaler",
      minInstances: 1,
      maxInstances: 10,
      evaluationIntervalMs: 15_000,
      cooldownMs: 30_000,
      provisioningDelayMs: 20_000
    }),
    validateConfiguration: () => []
  },
  observability: {
    type: "observability",
    displayName: "Observability",
    category: "operations",
    description: "Collects metrics, logs, and traces emitted by other components for monitoring, dashboards, and alerting.",
    fidelity: "conceptual",
    allowedIncomingConnections: ["observability"],
    allowedOutgoingConnections: [],
    defaultConfiguration: withDefaults(commonDefaults, { displayName: "Observability" }),
    validateConfiguration: () => []
  },
  "api-gateway": {
    type: "api-gateway",
    displayName: "API Gateway",
    category: "entry",
    description:
      "Enforces routing, authentication, and quota policy between edge traffic and backend services.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request"],
    allowedOutgoingConnections: ["request", "observability"],
    defaultConfiguration: apiGatewayConfigSchema.parse({
      ...commonDefaults,
      displayName: "API Gateway",
      baseLatencyMs: 2,
      perInstanceCapacityRps: 2000
    }),
    validateConfiguration: (config) => validateTypedConfig("api-gateway", config)
  },
  "dns-traffic-manager": {
    type: "dns-traffic-manager",
    displayName: "DNS / Traffic Manager",
    category: "entry",
    description:
      "Resolves a name to a target and caches the answer for a TTL, which sets a floor on observed failover time.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request"],
    allowedOutgoingConnections: ["request", "failover", "observability"],
    defaultConfiguration: dnsConfigSchema.parse({
      ...commonDefaults,
      displayName: "DNS / Traffic Manager",
      baseLatencyMs: 1,
      perInstanceCapacityRps: 100_000
    }),
    validateConfiguration: (config) => validateTypedConfig("dns-traffic-manager", config)
  },
  "nosql-database": {
    type: "nosql-database",
    displayName: "NoSQL Database",
    category: "data",
    description:
      "Partitioned non-relational store with tunable consistency, hot-partition skew, and replication lag.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request", "replication"],
    allowedOutgoingConnections: ["replication", "observability"],
    defaultConfiguration: nosqlConfigSchema.parse({
      ...commonDefaults,
      displayName: "NoSQL Database",
      baseLatencyMs: 10,
      perInstanceCapacityRps: 400
    }),
    validateConfiguration: (config) => validateTypedConfig("nosql-database", config)
  },
  "event-topic": {
    type: "event-topic",
    displayName: "Event Topic",
    category: "messaging",
    description:
      "Publishes each event to every subscriber group independently; each group keeps its own offset and lag.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["event", "request"],
    allowedOutgoingConnections: ["event", "request", "failover", "observability"],
    defaultConfiguration: eventTopicConfigSchema.parse({
      ...commonDefaults,
      displayName: "Event Topic",
      baseLatencyMs: 2,
      maxQueueDepth: 10_000
    }),
    validateConfiguration: (config) => validateTypedConfig("event-topic", config)
  },
  "identity-auth-service": {
    type: "identity-auth-service",
    displayName: "Identity & Auth Service",
    category: "identity",
    description:
      "Validates credentials or tokens as an in-path dependency, with token caching and a fail-open or fail-closed mode.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request"],
    allowedOutgoingConnections: ["request", "observability"],
    defaultConfiguration: identityAuthConfigSchema.parse({
      ...commonDefaults,
      displayName: "Identity & Auth Service",
      baseLatencyMs: 12,
      perInstanceCapacityRps: 1000
    }),
    validateConfiguration: (config) => validateTypedConfig("identity-auth-service", config)
  },
  "external-service": {
    type: "external-service",
    displayName: "External Service",
    category: "external",
    description:
      "A simulated third-party dependency you cannot scale or repair. Performs no real I/O and holds no credentials.",
    fidelity: "behavioral",
    allowedIncomingConnections: ["request", "event"],
    allowedOutgoingConnections: ["observability"],
    defaultConfiguration: externalServiceConfigSchema.parse({
      ...commonDefaults,
      displayName: "External Service",
      baseLatencyMs: 250,
      perInstanceCapacityRps: 100,
      timeoutMs: 5000
    }),
    validateConfiguration: (config) => validateTypedConfig("external-service", config)
  }
};

export function createNodeFromDefinition(
  type: ComponentType,
  id: string,
  position: { x: number; y: number }
): ArchitectureNode {
  const definition = componentDefinitions[type];
  return {
    id,
    type,
    position,
    config: { ...definition.defaultConfiguration, displayName: `${definition.displayName}` }
  };
}
