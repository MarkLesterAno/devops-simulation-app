import { z } from "zod";
import { baseComponentConfigSchema } from "@/domain/architecture/schema";
import type { ComponentType } from "@/domain/architecture/schema";

/**
 * Per-type configuration schemas layered over `baseComponentConfigSchema`, per
 * TRD.md "Domain model". The base schema stays permissive so documents written
 * by an older catalog version keep loading; each component type narrows and
 * validates only the fields it owns.
 *
 * Every added field is optional or defaulted, so existing projects migrate
 * without user action (AC-PE-04).
 */

export const authModeSchema = z.enum(["none", "validate-local", "delegate"]);
export type AuthMode = z.infer<typeof authModeSchema>;

export const rateLimitAlgorithmSchema = z.enum(["token-bucket", "fixed-window"]);

export const apiGatewayConfigSchema = baseComponentConfigSchema.extend({
  policyLatencyMs: z.number().min(0).default(3),
  authMode: authModeSchema.default("none"),
  /** 0 disables quota enforcement. */
  rateLimitRps: z.number().min(0).default(0),
  rateLimitBurst: z.number().min(0).default(0),
  rateLimitAlgorithm: rateLimitAlgorithmSchema.default("token-bucket")
});
export type ApiGatewayConfig = z.infer<typeof apiGatewayConfigSchema>;

export const dnsPolicySchema = z.enum(["weighted", "latency", "failover", "geo"]);
export type DnsPolicy = z.infer<typeof dnsPolicySchema>;

export const dnsConfigSchema = baseComponentConfigSchema.extend({
  ttlSeconds: z.number().min(0).max(86_400).default(60),
  resolutionLatencyMs: z.number().min(0).default(20),
  policy: dnsPolicySchema.default("failover")
});
export type DnsConfig = z.infer<typeof dnsConfigSchema>;

export const nosqlModelSchema = z.enum([
  "key-value",
  "document",
  "wide-column",
  "time-series",
  "graph",
  "vector"
]);
export const consistencyModeSchema = z.enum(["strong", "eventual", "quorum"]);
export type ConsistencyMode = z.infer<typeof consistencyModeSchema>;

export const nosqlConfigSchema = baseComponentConfigSchema.extend({
  model: nosqlModelSchema.default("key-value"),
  consistency: consistencyModeSchema.default("eventual"),
  partitionCount: z.number().int().min(1).max(1024).default(4),
  /** Probability that an operation lands on the hot partition. 0 = uniform. */
  hotPartitionSkew: z.number().min(0).max(1).default(0),
  replicationLagMs: z.number().min(0).default(50)
});
export type NoSqlConfig = z.infer<typeof nosqlConfigSchema>;

export const orderingScopeSchema = z.enum(["none", "partition"]);

export const eventTopicConfigSchema = baseComponentConfigSchema.extend({
  retentionMs: z.number().min(0).default(3_600_000),
  partitionCount: z.number().int().min(1).max(1024).default(1),
  orderingScope: orderingScopeSchema.default("none")
});
export type EventTopicConfig = z.infer<typeof eventTopicConfigSchema>;

export const identityModeSchema = z.enum(["authn", "authz", "both"]);
export const tokenValidationModeSchema = z.enum(["local-jwt", "introspection"]);
export const authFailModeSchema = z.enum(["fail-closed", "fail-open"]);
export type AuthFailMode = z.infer<typeof authFailModeSchema>;

export const identityAuthConfigSchema = baseComponentConfigSchema.extend({
  mode: identityModeSchema.default("authn"),
  validationMode: tokenValidationModeSchema.default("local-jwt"),
  tokenTtlMs: z.number().min(0).default(300_000),
  /** Share of validations served from a cached token rather than a full check. */
  cacheHitRatio: z.number().min(0).max(1).default(0.9),
  verificationLatencyMs: z.number().min(0).default(8),
  failMode: authFailModeSchema.default("fail-closed")
});
export type IdentityAuthConfig = z.infer<typeof identityAuthConfigSchema>;

export const externalCallModeSchema = z.enum(["sync", "async-callback"]);

export const externalServiceConfigSchema = baseComponentConfigSchema.extend({
  /** Display metadata only. Never used to contact anything. */
  providerLabel: z.string().min(1).max(80).default("Third-party provider"),
  slaLatencyMs: z.number().min(0).default(250),
  /** 0 disables provider-side throttling. */
  providerRateLimitRps: z.number().min(0).default(0),
  idempotencySupported: z.boolean().default(false),
  callMode: externalCallModeSchema.default("sync")
});
export type ExternalServiceConfig = z.infer<typeof externalServiceConfigSchema>;

/** Schemas for the component types that narrow the base configuration. */
export const componentConfigSchemas: Partial<Record<ComponentType, z.ZodTypeAny>> = {
  "api-gateway": apiGatewayConfigSchema,
  "dns-traffic-manager": dnsConfigSchema,
  "nosql-database": nosqlConfigSchema,
  "event-topic": eventTopicConfigSchema,
  "identity-auth-service": identityAuthConfigSchema,
  "external-service": externalServiceConfigSchema
};

export interface ConfigFieldIssue {
  field: string;
  message: string;
}

/**
 * Validates a node configuration against its per-type schema when one exists.
 * Returns field-scoped issues rather than throwing, so the inspector can render
 * them inline.
 */
export function validateTypedConfig(
  type: ComponentType,
  config: Record<string, unknown>
): ConfigFieldIssue[] {
  const schema = componentConfigSchemas[type];
  if (!schema) return [];
  const result = schema.safeParse(config);
  if (result.success) return [];
  return result.error.issues.map((issue) => ({
    field: issue.path.join(".") || "config",
    message: issue.message
  }));
}
