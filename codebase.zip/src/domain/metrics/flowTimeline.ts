import { z } from "zod";

/**
 * Normalized request-flow telemetry used exclusively by the visual playback
 * layer, per LIVE_PLAYBACK_AND_REQUEST_SIMULATION_PROMPT.md section 6.
 *
 * The engine records these samples while it runs, but nothing in the engine
 * ever reads them back: they are an output, not state. Playback speed, pausing
 * and scrubbing therefore cannot influence a simulated outcome.
 *
 * Samples are aggregated into fixed-width time buckets rather than recorded per
 * request. A run of a million requests produces the same bounded number of
 * buckets as a run of ten, which is what keeps rendering cost independent of
 * traffic volume.
 */
export const flowClassSchema = z.enum([
  "read",
  "write",
  "auth",
  "async-event",
  "replication"
]);
export type FlowClass = z.infer<typeof flowClassSchema>;

export const edgeFlowSampleSchema = z.object({
  edgeId: z.string().min(1),
  flowClass: flowClassSchema,
  /** Requests that traversed this edge during the bucket. */
  count: z.number().min(0),
  /** Traversals that ended in a failed root request. */
  failureCount: z.number().min(0),
  /** Traversals that were retry attempts rather than first attempts. */
  retryCount: z.number().min(0)
});
export type EdgeFlowSample = z.infer<typeof edgeFlowSampleSchema>;

export const flowTimelineBucketSchema = z.object({
  /** Logical start time of the bucket, in milliseconds from run start. */
  timestampMs: z.number().min(0),
  samples: z.array(edgeFlowSampleSchema)
});
export type FlowTimelineBucket = z.infer<typeof flowTimelineBucketSchema>;

export const flowTimelineSchema = z.object({
  bucketMs: z.number().min(1),
  /** Logical duration the timeline spans, so playback knows when to stop. */
  durationMs: z.number().min(0),
  /**
   * Highest per-bucket count on any single edge. Playback normalizes particle
   * density against this so a busy architecture and a quiet one both render
   * legibly.
   */
  peakBucketCount: z.number().min(0),
  buckets: z.array(flowTimelineBucketSchema)
});
export type FlowTimeline = z.infer<typeof flowTimelineSchema>;

/**
 * Per-method request totals, kept separate from the flow timeline because they
 * are a reported metric rather than an animation input.
 */
export const methodDistributionSchema = z.record(z.string(), z.number().min(0));
export type MethodDistribution = z.infer<typeof methodDistributionSchema>;
