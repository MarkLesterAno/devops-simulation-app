import { z } from "zod";
import { flowTimelineSchema, methodDistributionSchema } from "@/domain/metrics/flowTimeline";

export const latencyPercentilesSchema = z.object({
  p50: z.number().min(0),
  p95: z.number().min(0),
  p99: z.number().min(0)
});
export type LatencyPercentiles = z.infer<typeof latencyPercentilesSchema>;

export const systemMetricSnapshotSchema = z.object({
  timestampMs: z.number().min(0),
  requestCount: z.number().min(0),
  successCount: z.number().min(0),
  failureCount: z.number().min(0),
  rps: z.number().min(0),
  errorRate: z.number().min(0).max(1),
  latency: latencyPercentilesSchema
});
export type SystemMetricSnapshot = z.infer<typeof systemMetricSnapshotSchema>;

export const componentMetricSnapshotSchema = z.object({
  nodeId: z.string().min(1),
  timestampMs: z.number().min(0),
  utilization: z.number().min(0),
  activeWork: z.number().min(0),
  queuedWork: z.number().min(0),
  latencyMs: z.number().min(0),
  errorRate: z.number().min(0).max(1),
  cacheHitRatio: z.number().min(0).max(1).optional(),
  queueDepth: z.number().min(0).optional(),
  consumerLagMs: z.number().min(0).optional(),
  replicaLagMs: z.number().min(0).optional(),
  // Priority 1 catalog expansion metrics.
  quotaRejectionCount: z.number().min(0).optional(),
  authBlockedCount: z.number().min(0).optional(),
  dnsCacheHitRatio: z.number().min(0).max(1).optional(),
  staleResolutionCount: z.number().min(0).optional(),
  hotPartitionThrottleCount: z.number().min(0).optional(),
  staleReadCount: z.number().min(0).optional(),
  partitionUtilization: z.array(z.number().min(0)).optional(),
  fanOutFactor: z.number().min(0).optional(),
  subscriberLagMs: z.record(z.string(), z.number().min(0)).optional(),
  providerThrottleCount: z.number().min(0).optional()
});
export type ComponentMetricSnapshot = z.infer<typeof componentMetricSnapshotSchema>;

export const simulationEventSchema = z.object({
  sequence: z.number().int().min(0),
  timestampMs: z.number().min(0),
  type: z.string().min(1),
  nodeId: z.string().optional(),
  edgeId: z.string().optional(),
  requestId: z.string().optional(),
  message: z.string().min(1)
});
export type SimulationEvent = z.infer<typeof simulationEventSchema>;

export const findingSourceSchema = z.enum([
  "observed-result",
  "architecture-warning",
  "recommendation"
]);
export type FindingSource = z.infer<typeof findingSourceSchema>;

export const findingSeveritySchema = z.enum(["critical", "warning", "info"]);
export type FindingSeverity = z.infer<typeof findingSeveritySchema>;

export const findingSchema = z.object({
  id: z.string().min(1),
  source: findingSourceSchema,
  /** Defaults to "info" so results written before severities still parse. */
  severity: findingSeveritySchema.default("info"),
  title: z.string().min(1),
  detail: z.string().min(1),
  evidence: z.array(z.string()).default([]),
  relatedNodeIds: z.array(z.string()).default([]),
  relatedEdgeIds: z.array(z.string()).default([]),
  /** Concrete action the user can take, when one is worth suggesting. */
  suggestedAction: z.string().optional()
});
export type Finding = z.infer<typeof findingSchema>;

export const runStatusSchema = z.enum(["completed", "cancelled", "invalid", "failed"]);
export type RunStatus = z.infer<typeof runStatusSchema>;

export const simulationResultSchema = z.object({
  runId: z.string().min(1),
  seed: z.number().int(),
  status: runStatusSchema,
  engineVersion: z.string().min(1),
  /** Component behavior model version; results from different values are incomparable. */
  componentModelVersion: z.string().min(1).optional(),
  /**
   * Whole-run aggregate metrics (total request/success/failure counts,
   * average RPS over the full duration, and global latency percentiles).
   * Per AC-ME-01, this is what result views should display; `systemMetrics`
   * remains available as a time series for trend/graphing use cases.
   */
  summary: systemMetricSnapshotSchema.optional(),
  systemMetrics: z.array(systemMetricSnapshotSchema),
  componentMetrics: z.array(componentMetricSnapshotSchema),
  events: z.array(simulationEventSchema),
  findings: z.array(findingSchema),
  assumptions: z.array(z.string()),
  observedAvailability: z.number().min(0).max(1).optional(),
  estimatedCost: z.number().min(0).optional(),
  /**
   * Presentation-only request-flow telemetry for visual playback. Optional so
   * that results written before playback existed still parse unchanged.
   */
  flowTimeline: flowTimelineSchema.optional(),
  /** Root-request totals per HTTP method, when methods were recorded. */
  methodDistribution: methodDistributionSchema.optional(),
  /** Ids of manual request batches that contributed to this run. */
  manualBatchIds: z.array(z.string()).optional(),
  retryCount: z.number().min(0).optional(),
  timeoutCount: z.number().min(0).optional()
});
export type SimulationResult = z.infer<typeof simulationResultSchema>;
