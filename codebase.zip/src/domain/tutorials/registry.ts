import { scenarioTemplates } from "@/domain/scenarios/registry";
import {
  tutorialDefinitionSchema,
  type TutorialDefinition,
  type TutorialStep
} from "@/domain/tutorials/schema";

interface TutorialCapabilities {
  canObserveArchitecture: boolean;
  canRunSimulation: boolean;
  canOpenMetrics: boolean;
}

function getCapabilities(scenarioId: string): TutorialCapabilities {
  const scenario = scenarioTemplates.find((template) => template.metadata.id === scenarioId);
  return {
    canObserveArchitecture: Boolean(scenario?.blueprint.nodes.length),
    canRunSimulation: Boolean(scenario?.blueprint.trafficProfiles.length),
    canOpenMetrics: Boolean(scenario?.blueprint.trafficProfiles.length)
  };
}

function automaticStep(
  id: string,
  title: string,
  body: string,
  action: TutorialStep["action"],
  predicate: "scenario-loaded" | "simulation-complete" | "metrics-open"
): TutorialStep {
  return {
    id,
    title,
    body,
    action,
    phase: "baseline-validation",
    modes: ["guided-tour", "build", "challenge"],
    hints: ["Check the toolbar and the current canvas state for the required action."],
    allowSkip: true,
    successMessage: "The required simulator action was detected.",
    completion: { kind: "automatic", predicate }
  };
}

function manualStep(
  id: string,
  title: string,
  body: string,
  action: TutorialStep["action"],
  label: string
): TutorialStep {
  return {
    id,
    title,
    body,
    action,
    phase: "introduction",
    modes: ["guided-tour", "build", "challenge"],
    hints: ["Review the visible architecture evidence before continuing."],
    allowSkip: true,
    successMessage: "Your observation was recorded.",
    completion: { kind: "manual", label }
  };
}

const basicWebApplicationTutorial: TutorialDefinition = {
  id: "basic-web-application-tutorial",
  scenarioId: "basic-web-application",
  title: "Basic Web Application tutorial",
  summary: "Trace a simple request path, run it, and inspect the resulting metrics.",
  supportedModes: ["guided-tour", "build", "challenge"],
  steps: [
    automaticStep(
      "load-scenario",
      "Open the architecture",
      "The tutorial uses a fresh Basic Web Application template. Its tutorial progress stays on this device and is not saved in the project.",
      "observe",
      "scenario-loaded"
    ),
    manualStep(
      "trace-request-path",
      "Trace the request path",
      "On the canvas, follow Browser Client to DNS, Load Balancer, Application Server, and Primary Database. Notice that every request follows this synchronous path.",
      "observe",
      "I traced the request path"
    ),
    manualStep(
      "review-single-server",
      "Review the application tier",
      "Observe that the application tier contains one server instance. This step asks only that you identify the modeled topology; it does not prescribe a technology or design change.",
      "acknowledge",
      "I found the single application server"
    ),
    automaticStep(
      "run-default-simulation",
      "Run the default simulation",
      "Use the Run button in the toolbar and wait for the deterministic simulation to finish. The tutorial will detect the completed result.",
      "run",
      "simulation-complete"
    ),
    automaticStep(
      "open-run-metrics",
      "Open the metrics",
      "Use View Metrics in the toolbar. Review the aggregate latency, throughput, success rate, and per-node utilization produced by the run.",
      "open-metrics",
      "metrics-open"
    ),
    manualStep(
      "finish-overview",
      "Complete the walkthrough",
      "You have followed the modeled path and used the simulator's run and metrics surfaces. You can now exit or restart this tutorial at any time.",
      "acknowledge",
      "I completed the walkthrough"
    )
  ]
};

function buildOverviewTutorial(scenarioId: string, scenarioName: string): TutorialDefinition {
  const capabilities = getCapabilities(scenarioId);
  const steps: TutorialStep[] = [
    automaticStep(
      "load-scenario",
      "Open the scenario",
      `This overview uses a fresh ${scenarioName} template and only covers behavior available in the simulator.`,
      "observe",
      "scenario-loaded"
    )
  ];

  if (capabilities.canObserveArchitecture) {
    steps.push(
      manualStep(
        "observe-architecture",
        "Observe the architecture",
        "Inspect the visible components and connections. Use the scenario Objectives panel for the template's modeled properties and explicit limitations.",
        "observe",
        "I reviewed the architecture and limitations"
      )
    );
  }
  if (capabilities.canRunSimulation) {
    steps.push(
      automaticStep(
        "run-simulation",
        "Run the scenario",
        "Use the Run button and wait for the configured deterministic simulation to complete.",
        "run",
        "simulation-complete"
      )
    );
  }
  if (capabilities.canOpenMetrics) {
    steps.push(
      automaticStep(
        "open-metrics",
        "Review metrics",
        "Use View Metrics to inspect only the measurements produced by this run.",
        "open-metrics",
        "metrics-open"
      )
    );
  }
  steps.push(
    manualStep(
      "complete-overview",
      "Finish the overview",
      "This overview is complete. Continue exploring the template or restart the tutorial.",
      "acknowledge",
      "I completed the overview"
    )
  );

  return {
    id: `${scenarioId}-tutorial`,
    scenarioId,
    title: `${scenarioName} overview`,
    summary: "Observe the modeled architecture, run its configured traffic, and review measured results.",
    supportedModes: ["guided-tour", "build", "challenge"],
    steps
  };
}

function buildTutorialRegistry(): TutorialDefinition[] {
  const definitions = scenarioTemplates.map((scenario) =>
    scenario.metadata.id === "basic-web-application"
      ? basicWebApplicationTutorial
      : buildOverviewTutorial(scenario.metadata.id, scenario.metadata.name)
  );
  const seenIds = new Set<string>();
  for (const definition of definitions) {
    const parsed = tutorialDefinitionSchema.parse(definition);
    if (seenIds.has(parsed.id)) throw new Error(`Duplicate tutorial id "${parsed.id}".`);
    seenIds.add(parsed.id);
  }
  return definitions;
}

export const tutorialDefinitions = buildTutorialRegistry();

const tutorialsById = new Map(tutorialDefinitions.map((tutorial) => [tutorial.id, tutorial]));
const tutorialsByScenarioId = new Map(
  tutorialDefinitions.map((tutorial) => [tutorial.scenarioId, tutorial])
);

export function getTutorial(id: string): TutorialDefinition | undefined {
  return tutorialsById.get(id);
}

export function getTutorialForScenario(scenarioId: string): TutorialDefinition | undefined {
  return tutorialsByScenarioId.get(scenarioId);
}
