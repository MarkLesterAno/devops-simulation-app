import { z } from "zod";
import { tutorialModeSchema } from "@/domain/scenarios/schema";

export const tutorialActionSchema = z.enum([
  "acknowledge",
  "observe",
  "run",
  "open-metrics"
]);
export type TutorialAction = z.infer<typeof tutorialActionSchema>;

export const tutorialPredicateSchema = z.enum([
  "scenario-loaded",
  "simulation-complete",
  "metrics-open"
]);
export type TutorialPredicate = z.infer<typeof tutorialPredicateSchema>;

export const tutorialStepSchema = z.object({
  id: z.string().min(1).regex(/^[a-z0-9-]+$/),
  title: z.string().min(1),
  body: z.string().min(1),
  action: tutorialActionSchema,
  phase: z.enum([
    "introduction",
    "topology-construction",
    "baseline-validation",
    "load-exploration",
    "fault-injection",
    "assessment",
    "extension"
  ]).default("introduction"),
  modes: z.array(tutorialModeSchema).min(1).default(["guided-tour"]),
  hints: z.array(z.string().min(1)).default([]),
  allowSkip: z.boolean().default(true),
  successMessage: z.string().min(1).default("Step complete."),
  completion: z.discriminatedUnion("kind", [
    z.object({ kind: z.literal("manual"), label: z.string().min(1) }),
    z.object({ kind: z.literal("automatic"), predicate: tutorialPredicateSchema })
  ])
});
export type TutorialStep = z.infer<typeof tutorialStepSchema>;

export const tutorialDefinitionSchema = z.object({
  id: z.string().min(1).regex(/^[a-z0-9-]+$/),
  scenarioId: z.string().min(1),
  title: z.string().min(1),
  summary: z.string().min(1),
  supportedModes: z.array(tutorialModeSchema).min(1).default(["guided-tour"]),
  steps: z.array(tutorialStepSchema).min(1)
});
export type TutorialDefinition = z.infer<typeof tutorialDefinitionSchema>;
