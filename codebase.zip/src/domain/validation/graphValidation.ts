import type { ArchitectureEdge, ArchitectureNode } from "@/domain/architecture/schema";

export type ValidationSeverity = "error" | "warning";

export interface ValidationIssue {
  severity: ValidationSeverity;
  code: string;
  message: string;
  nodeIds?: string[];
  edgeIds?: string[];
}

const REQUEST_ORIGIN_TYPES = new Set(["client"]);
const TERMINAL_CAPABLE_TYPES = new Set([
  "server",
  "relational-database",
  "read-replica",
  "object-storage",
  "cache",
  "worker",
  "cdn",
  "nosql-database",
  "external-service",
  "identity-auth-service",
  "event-topic"
]);

/**
 * Validates a graph against the blocking and warning rules in
 * TRD.md's "Graph validation" section and SIMULATION_SPEC.md routing rules.
 * Errors must block simulation start (AC-VA-01..04); warnings do not.
 */
export function validateGraph(
  nodes: ArchitectureNode[],
  edges: ArchitectureEdge[]
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const nodeById = new Map(nodes.map((node) => [node.id, node]));

  const originNodes = nodes.filter((node) => REQUEST_ORIGIN_TYPES.has(node.type));
  if (originNodes.length === 0) {
    issues.push({
      severity: "error",
      code: "no-request-origin",
      message: "The graph has no Client (request origin) node."
    });
  }

  const requestEdges = edges.filter((edge) => edge.kind === "request");
  const outgoingByNode = new Map<string, ArchitectureEdge[]>();
  for (const edge of requestEdges) {
    const list = outgoingByNode.get(edge.sourceNodeId) ?? [];
    list.push(edge);
    outgoingByNode.set(edge.sourceNodeId, list);
  }

  // Reachability from every origin to at least one terminal-capable node.
  const reachable = new Set<string>();
  const stack = [...originNodes.map((node) => node.id)];
  while (stack.length > 0) {
    const currentId = stack.pop();
    if (currentId === undefined || reachable.has(currentId)) continue;
    reachable.add(currentId);
    for (const edge of outgoingByNode.get(currentId) ?? []) {
      stack.push(edge.targetNodeId);
    }
  }
  const hasTerminalPath = nodes.some(
    (node) => reachable.has(node.id) && TERMINAL_CAPABLE_TYPES.has(node.type)
  );
  if (originNodes.length > 0 && !hasTerminalPath) {
    issues.push({
      severity: "error",
      code: "no-terminal-path",
      message: "No reachable terminal path exists from any request origin."
    });
  }

  // Load balancer must have at least one outgoing request target.
  for (const node of nodes) {
    if (node.type !== "load-balancer") continue;
    const targets = outgoingByNode.get(node.id) ?? [];
    if (targets.length === 0) {
      issues.push({
        severity: "error",
        code: "load-balancer-no-targets",
        message: `Load balancer "${node.config.displayName}" has no outgoing request targets.`,
        nodeIds: [node.id]
      });
    }
  }

  // Queue without any consumer edge is a warning (AC-VA-04): depth will accumulate unread.
  for (const node of nodes) {
    if (node.type !== "message-queue") continue;
    const hasConsumer = edges.some(
      (edge) =>
        edge.sourceNodeId === node.id &&
        (edge.kind === "event" || edge.kind === "request") &&
        nodeById.get(edge.targetNodeId)?.type === "worker"
    );
    if (!hasConsumer) {
      issues.push({
        severity: "warning",
        code: "queue-no-consumer",
        message: `Message queue "${node.config.displayName}" has no consumer; depth will accumulate.`,
        nodeIds: [node.id]
      });
    }
  }

  // Disconnected nodes (no edges at all) are a warning.
  issues.push(...validateExpansionComponents(nodes, edges, nodeById, outgoingByNode));
  issues.push(...validateDistributedTopology(nodes, edges, nodeById, requestEdges));

  const connectedNodeIds = new Set<string>();
  for (const edge of edges) {
    connectedNodeIds.add(edge.sourceNodeId);
    connectedNodeIds.add(edge.targetNodeId);
  }

  /**
   * Detects topology shapes that the deterministic request/event model cannot
   * safely interpret as a useful architecture. These rules deliberately flag
   * only structural contradictions; they never require a learner to reproduce
   * a reference solution.
   */
  function validateDistributedTopology(
    nodes: ArchitectureNode[],
    edges: ArchitectureEdge[],
    nodeById: Map<string, ArchitectureNode>,
    requestEdges: ArchitectureEdge[]
  ): ValidationIssue[] {
    const issues: ValidationIssue[] = [];

    const requestCycles = findCycles(requestEdges);
    for (const cycle of requestCycles) {
      const names = cycle.map((nodeId) => nodeById.get(nodeId)?.config.displayName ?? nodeId);
      issues.push({
        severity: "error",
        code: "request-routing-cycle",
        message: `Request routing contains a cycle (${names.join(" → ")}). Add a terminal path or move asynchronous work to event edges.`,
        nodeIds: cycle
      });
    }

    for (const edge of edges.filter((candidate) => candidate.kind === "replication")) {
      const source = nodeById.get(edge.sourceNodeId);
      const target = nodeById.get(edge.targetNodeId);
      if (!source || !target) continue;
      const dataNode = (node: ArchitectureNode): boolean =>
        ["relational-database", "read-replica", "nosql-database", "object-storage"].includes(node.type);
      if (!dataNode(source) || !dataNode(target)) {
        issues.push({
          severity: "error",
          code: "invalid-replication-path",
          message: `Replication edge "${source.config.displayName} → ${target.config.displayName}" must connect data components.`,
          nodeIds: [source.id, target.id],
          edgeIds: [edge.id]
        });
      }
    }

    for (const edge of edges.filter((candidate) => candidate.kind === "failover")) {
      const source = nodeById.get(edge.sourceNodeId);
      const target = nodeById.get(edge.targetNodeId);
      if (!source || !target) continue;
      const isRegionalFailover =
        source.config.region !== "local" || target.config.region !== "local";
      if (isRegionalFailover && source.type !== target.type) {
        issues.push({
          severity: "warning",
          code: "failover-role-mismatch",
          message: `Failover edge "${source.config.displayName} → ${target.config.displayName}" joins different component roles; verify that the target can take over this workload.`,
          nodeIds: [source.id, target.id],
          edgeIds: [edge.id]
        });
      }
      if (isRegionalFailover && source.config.region === target.config.region) {
        issues.push({
          severity: "warning",
          code: "same-region-failover",
          message: `Failover target "${target.config.displayName}" is in the same region as "${source.config.displayName}", so it cannot mitigate a regional outage.`,
          nodeIds: [source.id, target.id],
          edgeIds: [edge.id]
        });
      }
    }

    for (const queue of nodes.filter((node) => node.type === "message-queue" || node.type === "event-topic")) {
      const consumers = edges.filter(
        (edge) =>
          edge.sourceNodeId === queue.id &&
          edge.kind === "event" &&
          nodeById.get(edge.targetNodeId)?.type === "worker"
      );
      if (consumers.length > 1) {
        issues.push({
          severity: "warning",
          code: "consumer-semantics-simplified",
          message: `${queue.config.displayName} has ${consumers.length} worker consumers. The simulator models throughput but not consumer groups, ordering, or exactly-once delivery semantics.`,
          nodeIds: [queue.id, ...consumers.map((edge) => edge.targetNodeId)],
          edgeIds: consumers.map((edge) => edge.id)
        });
      }
    }

    const regions = new Set(nodes.map((node) => node.config.region).filter((region) => region !== "local"));
    const hasDnsFailoverPolicy = nodes.some(
      (node) =>
        node.type === "dns-traffic-manager" &&
        (node.config as Record<string, unknown>)["policy"] === "failover"
    );
    if (
      regions.size > 1 &&
      !edges.some((edge) => edge.kind === "failover") &&
      !hasDnsFailoverPolicy
    ) {
      issues.push({
        severity: "warning",
        code: "multi-region-no-failover",
        message: "The graph spans multiple regions but has no failover edge. A regional fault will not have an explicit recovery path.",
        nodeIds: nodes.filter((node) => node.config.region !== "local").map((node) => node.id)
      });
    }

    return issues;
  }

  function findCycles(edges: ArchitectureEdge[]): string[][] {
    const outgoing = new Map<string, string[]>();
    for (const edge of edges) {
      const list = outgoing.get(edge.sourceNodeId) ?? [];
      list.push(edge.targetNodeId);
      outgoing.set(edge.sourceNodeId, list);
    }
    const cycles: string[][] = [];
    const visiting = new Set<string>();
    const visited = new Set<string>();
    const path: string[] = [];

    function visit(nodeId: string): void {
      if (visiting.has(nodeId)) {
        const start = path.indexOf(nodeId);
        const cycle = path.slice(start);
        const canonical = [...cycle].sort().join("|");
        if (!cycles.some((existing) => [...existing].sort().join("|") === canonical)) cycles.push(cycle);
        return;
      }
      if (visited.has(nodeId)) return;
      visiting.add(nodeId);
      path.push(nodeId);
      for (const next of outgoing.get(nodeId) ?? []) visit(next);
      path.pop();
      visiting.delete(nodeId);
      visited.add(nodeId);
    }

    for (const nodeId of outgoing.keys()) visit(nodeId);
    return cycles;
  }
  for (const node of nodes) {
    if (!connectedNodeIds.has(node.id)) {
      issues.push({
        severity: "warning",
        code: "disconnected-node",
        message: `Node "${node.config.displayName}" is not connected to any edge.`,
        nodeIds: [node.id]
      });
    }
  }

  // Single point of failure: a request edge fan-in of >1 upstream node into one downstream
  // node with instanceCount 1 and no redundancy is flagged as a warning.
  const incomingCountByNode = new Map<string, number>();
  for (const edge of requestEdges) {
    incomingCountByNode.set(
      edge.targetNodeId,
      (incomingCountByNode.get(edge.targetNodeId) ?? 0) + 1
    );
  }
  for (const node of nodes) {
    if (node.config.instanceCount === 1 && (incomingCountByNode.get(node.id) ?? 0) > 0) {
      const isEntryOrCompute = node.type === "server" || node.type === "worker";
      if (isEntryOrCompute) {
        issues.push({
          severity: "warning",
          code: "single-point-of-failure",
          message: `Node "${node.config.displayName}" runs a single instance and has no redundancy.`,
          nodeIds: [node.id]
        });
      }
    }
  }

  return issues;
}

export function hasBlockingErrors(issues: ValidationIssue[]): boolean {
  return issues.some((issue) => issue.severity === "error");
}

/**
 * Validation rules for the Priority 1 catalog expansion, per
 * COMPONENT_CATALOG.md and TRD.md "Graph validation".
 */
function validateExpansionComponents(
  nodes: ArchitectureNode[],
  edges: ArchitectureEdge[],
  nodeById: Map<string, ArchitectureNode>,
  outgoingByNode: Map<string, ArchitectureEdge[]>
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  for (const node of nodes) {
    const config = node.config as Record<string, unknown>;
    const name = node.config.displayName;

    switch (node.type) {
      case "api-gateway": {
        const outgoing = outgoingByNode.get(node.id) ?? [];
        const routes = outgoing.filter(
          (edge) => nodeById.get(edge.targetNodeId)?.type !== "identity-auth-service"
        );
        if (routes.length === 0) {
          issues.push({
            severity: "error",
            code: "gateway-no-routes",
            message: `API gateway "${name}" has no route target.`,
            nodeIds: [node.id]
          });
        }
        if (config["authMode"] === "delegate") {
          const hasIdentity = outgoing.some(
            (edge) => nodeById.get(edge.targetNodeId)?.type === "identity-auth-service"
          );
          if (!hasIdentity) {
            issues.push({
              severity: "error",
              code: "auth-delegation-missing",
              message: `API gateway "${name}" delegates authentication but has no identity component target.`,
              nodeIds: [node.id]
            });
          }
        }
        break;
      }
      case "dns-traffic-manager": {
        if ((outgoingByNode.get(node.id) ?? []).length === 0) {
          issues.push({
            severity: "error",
            code: "dns-no-targets",
            message: `DNS component "${name}" has no resolvable target.`,
            nodeIds: [node.id]
          });
        }
        break;
      }
      case "event-topic": {
        const groups = edges.filter(
          (edge) =>
            edge.sourceNodeId === node.id &&
            (edge.kind === "event" || edge.kind === "request") &&
            nodeById.get(edge.targetNodeId)?.type === "worker"
        );
        if (groups.length === 0) {
          issues.push({
            severity: "error",
            code: "topic-no-subscribers",
            message: `Event topic "${name}" has no subscriber group; fan-out has no destination.`,
            nodeIds: [node.id]
          });
        }
        break;
      }
      case "nosql-database": {
        const lag = typeof config["replicationLagMs"] === "number" ? config["replicationLagMs"] : 0;
        if (config["consistency"] === "strong" && lag > 0) {
          issues.push({
            severity: "error",
            code: "nosql-invalid-consistency",
            message: `"${name}" requests strong consistency but declares ${lag} ms of replication lag.`,
            nodeIds: [node.id]
          });
        }
        break;
      }
      case "external-service": {
        const scaled = edges.some(
          (edge) =>
            edge.sourceNodeId === node.id &&
            nodeById.get(edge.targetNodeId)?.type === "autoscaler"
        );
        if (scaled) {
          issues.push({
            severity: "error",
            code: "external-service-not-scalable",
            message: `External service "${name}" cannot be autoscaled; a third-party dependency is outside your control.`,
            nodeIds: [node.id]
          });
        }
        const guarded = edges.some(
          (edge) =>
            edge.targetNodeId === node.id &&
            nodeById.get(edge.sourceNodeId)?.type === "circuit-breaker"
        );
        if (!guarded) {
          issues.push({
            severity: "warning",
            code: "external-service-no-circuit-breaker",
            message: `External service "${name}" has no circuit breaker protecting callers from provider failures.`,
            nodeIds: [node.id]
          });
        }
        break;
      }
      case "identity-auth-service": {
        const inboundCount = edges.filter(
          (edge) => edge.targetNodeId === node.id && edge.kind === "request"
        ).length;
        if (inboundCount > 0 && node.config.instanceCount === 1 && config["failMode"] !== "fail-open") {
          issues.push({
            severity: "warning",
            code: "auth-single-point-of-failure",
            message: `Identity component "${name}" is a fail-closed single instance in the critical path.`,
            nodeIds: [node.id]
          });
        }
        break;
      }
      default:
        break;
    }
  }

  return issues;
}
