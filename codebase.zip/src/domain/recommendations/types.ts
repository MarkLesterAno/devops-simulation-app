﻿import { z } from "zod";
import type {
  BaseComponentConfig,
  ComponentType
} from "@/domain/architecture/schema";
import type { ScenarioDifficulty, WorkloadShape } from "@/domain/scenarios/schema";
import type { DeploymentModel } from "@/domain/technology/schema";

/**
 * Technology recommendation contract, per
 * docs/SCENARIO_TUTORIAL_AND_RECOMMENDATION_PROMPT.md section 6.
 *
 * Recommendations are educational guidance derived from the existing
 * technology catalog only: the engine never invents a technology, never
 * contacts a network, and never applies anything on its own. It scores the
 * catalog entries already valid for a component type and returns a short,
 * explainable, deterministically ordered shortlist.
 */

export const recommendationPreferencesSchema = z.object({
  preferOpenSource: z.boolean().default(false),
  preferManagedServices: z.boolean().default(false),
  preferredProviders: z.array(z.string().min(1)).default([])
});
export type RecommendationPreferences = z.infer<typeof recommendationPreferencesSchema>;

export interface RecommendationContext {
  componentType: ComponentType;
  nodeConfiguration: BaseComponentConfig & Record<string, unknown>;
  workloadCharacteristics: WorkloadShape[];
  connectedNodeTypes: ComponentType[];
  scenarioDomain?: string;
  scenarioDifficulty?: ScenarioDifficulty;
  /** Technology ids already assigned elsewhere in the current graph. */
  existingTechnologyAssignments: string[];
  userPreferences: RecommendationPreferences;
}

export interface TechnologyRecommendation {
  technologyId: string;
  displayName: string;
  provider: string;
  /** 0-100, higher is a stronger contextual match. */
  matchScore: number;
  /** 1-based position in the returned, already-sorted list. */
  rank: number;
  rationale: string;
  strengths: string[];
  tradeOffs: string[];
  typicalUseCases: string[];
  deploymentModel: DeploymentModel[];
  hasSimulationPreset: boolean;
  warnings: string[];
}
