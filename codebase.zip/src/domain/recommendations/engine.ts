import {
  getAdvisoriesForRole,
  getCapabilitiesForRole,
  getTechnologiesForComponentType,
  getTechnologyById
} from "@/domain/technology/registry";
import type { TechnologyOption } from "@/domain/technology/schema";
import {
  DIFFICULTY_DEPLOYMENT_AFFINITY,
  MAX_POSSIBLE_SCORE,
  MAX_RECOMMENDATIONS,
  MIN_RECOMMENDATIONS,
  SCORING_WEIGHTS,
  WARNING_KEYWORDS,
  WORKLOAD_KEYWORDS
} from "@/domain/recommendations/rules";
import type {
  RecommendationContext,
  TechnologyRecommendation
} from "@/domain/recommendations/types";

const STATUS_LABEL: Record<string, string> = {
  legacy: "Legacy",
  deprecated: "Deprecated"
};

/** Clamps a fraction into the closed unit interval before it is weighted. */
function clampUnit(value: number): number {
  return Math.min(1, Math.max(0, value));
}

function humanize(token: string): string {
  return token.replace(/-/g, " ");
}

function firstSentence(text: string): string {
  const match = text.match(/^[^.]+\./);
  return (match ? match[0] : text).trim();
}

interface ScoredFactor {
  fraction: number;
  weight: number;
}

/**
 * Signal 2: alignment with the workload characteristics of the scenario,
 * judged by keyword presence in the candidate's role-scoped capabilities and
 * description. Neutral (0.5) when no workload characteristics are supplied,
 * since the caller genuinely has no signal to score against.
 */
function scoreWorkloadFit(
  searchableText: string,
  workloadCharacteristics: RecommendationContext["workloadCharacteristics"]
): { fraction: number; matchedShapes: string[] } {
  if (workloadCharacteristics.length === 0) return { fraction: 0.5, matchedShapes: [] };
  const matchedShapes = workloadCharacteristics.filter((shape) =>
    WORKLOAD_KEYWORDS[shape].some((keyword) => searchableText.includes(keyword))
  );
  return { fraction: matchedShapes.length / workloadCharacteristics.length, matchedShapes };
}

/**
 * Signal 3: consistency with technologies already assigned to connected
 * nodes, approximated by shared provider (e.g. favoring AWS ElastiCache next
 * to an existing AWS RDS assignment). Neutral when nothing is assigned yet.
 */
function scoreTopologyCoherence(
  option: TechnologyOption,
  existingTechnologyAssignments: string[]
): number {
  if (existingTechnologyAssignments.length === 0) return 0.5;
  const connectedProviders = existingTechnologyAssignments
    .map((id) => getTechnologyById(id)?.provider)
    .filter((provider): provider is string => Boolean(provider));
  if (connectedProviders.length === 0) return 0.5;
  return connectedProviders.includes(option.provider) ? 1 : 0.15;
}

/** Signal 4: soft keyword match against the scenario's stated problem domain. */
function scoreDomainRelevance(searchableText: string, scenarioDomain: string | undefined): number {
  if (!scenarioDomain) return 0.5;
  const words = scenarioDomain.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
  if (words.length === 0) return 0.5;
  return words.some((word) => searchableText.includes(word)) ? 1 : 0.3;
}

/** Signal 5: pedagogical fit between deployment model and difficulty tier. */
function scoreDifficultyAppropriateness(
  option: TechnologyOption,
  scenarioDifficulty: RecommendationContext["scenarioDifficulty"]
): number {
  if (!scenarioDifficulty) return 0.5;
  const affinity = DIFFICULTY_DEPLOYMENT_AFFINITY[scenarioDifficulty];
  const values = option.deploymentModel.map((model) => affinity[model] ?? 0);
  const average = values.reduce((sum, value) => sum + value, 0) / values.length;
  let fraction = clampUnit((average + 1) / 2);
  if (scenarioDifficulty === "beginner" && option.status !== "current") {
    fraction = clampUnit(fraction - 0.3);
  }
  return fraction;
}

/** Signal 6: respect for the user's local deployment-model preferences. */
function scoreDeploymentPreference(
  option: TechnologyOption,
  userPreferences: RecommendationContext["userPreferences"]
): number {
  let fraction = 0.5;
  if (userPreferences.preferOpenSource) {
    fraction += option.deploymentModel.includes("open-source") ? 0.25 : -0.15;
  }
  if (userPreferences.preferManagedServices) {
    const managed =
      option.deploymentModel.includes("managed-cloud") || option.deploymentModel.includes("saas");
    fraction += managed ? 0.25 : -0.15;
  }
  if (userPreferences.preferredProviders.length > 0) {
    const preferred = userPreferences.preferredProviders.some(
      (provider) => provider.toLowerCase() === option.provider.toLowerCase()
    );
    fraction += preferred ? 0.25 : -0.1;
  }
  return clampUnit(fraction);
}

/** Signal 7: favor catalog entries with a maintained simulation preset. */
function scorePresetAvailability(option: TechnologyOption): number {
  return option.simulationPreset ? 1 : 0.2;
}

function buildTradeOffs(option: TechnologyOption, roleAdvisories: string[]): string[] {
  if (roleAdvisories.length > 0) return roleAdvisories;
  const managed =
    option.deploymentModel.includes("managed-cloud") || option.deploymentModel.includes("saas");
  const selfManaged =
    option.deploymentModel.includes("self-managed") || option.deploymentModel.includes("on-premises");
  const tradeOffs: string[] = [];
  if (managed) {
    tradeOffs.push("Managed service: recurring cost and less low-level operational control.");
  }
  if (selfManaged) {
    tradeOffs.push("Self-managed: you own patching, capacity planning, and monitoring.");
  }
  if (tradeOffs.length === 0) {
    tradeOffs.push("Evaluate operational fit before committing; no vendor is universally correct.");
  }
  return tradeOffs;
}

function buildTypicalUseCases(option: TechnologyOption, matchedShapes: string[]): string[] {
  if (matchedShapes.length > 0) {
    return matchedShapes.map((shape) => `Well suited for ${humanize(shape)} workloads.`);
  }
  return [firstSentence(option.description)];
}

function buildWarnings(option: TechnologyOption, roleAdvisories: string[]): string[] {
  const warnings: string[] = [];
  if (option.status !== "current") {
    warnings.push(`${STATUS_LABEL[option.status] ?? option.status} technology.`);
  }
  for (const advisory of roleAdvisories) {
    const lower = advisory.toLowerCase();
    if (WARNING_KEYWORDS.some((keyword) => lower.includes(keyword))) {
      warnings.push(advisory);
    }
  }
  return warnings;
}

function buildRationale(
  option: TechnologyOption,
  matchedShapes: string[],
  topologyFraction: number
): string {
  const base = firstSentence(option.description);
  if (matchedShapes.length > 0) {
    return `${base} Matches ${matchedShapes.map(humanize).join(", ")} workload.`;
  }
  if (topologyFraction === 1) {
    return `${base} Consistent with ${option.provider} already used on a connected node.`;
  }
  return base;
}

/**
 * Scores and ranks the technology catalog for a single recommendation
 * request. Deterministic: identical `context` values always produce an
 * identically ordered result, since every signal is a pure function of the
 * catalog entry and the supplied context (no randomness, no wall-clock use,
 * ties broken by catalog display name).
 */
export function recommendTechnologies(context: RecommendationContext): TechnologyRecommendation[] {
  const candidates = getTechnologiesForComponentType(context.componentType);

  const scored = candidates.map((option) => {
    const roleCapabilities = getCapabilitiesForRole(option, context.componentType);
    const roleAdvisories = getAdvisoriesForRole(option, context.componentType).map(
      (advisory) => advisory.message
    );
    const searchableText = [option.description, ...option.capabilities, ...roleCapabilities]
      .join(" ")
      .toLowerCase();

    const workload = scoreWorkloadFit(searchableText, context.workloadCharacteristics);
    const topology = scoreTopologyCoherence(option, context.existingTechnologyAssignments);
    const domain = scoreDomainRelevance(searchableText, context.scenarioDomain);
    const difficulty = scoreDifficultyAppropriateness(option, context.scenarioDifficulty);
    const deployment = scoreDeploymentPreference(option, context.userPreferences);
    const preset = scorePresetAvailability(option);

    const factors: ScoredFactor[] = [
      { fraction: workload.fraction, weight: SCORING_WEIGHTS.workloadFit },
      { fraction: topology, weight: SCORING_WEIGHTS.topologyCoherence },
      { fraction: domain, weight: SCORING_WEIGHTS.domainRelevance },
      { fraction: difficulty, weight: SCORING_WEIGHTS.difficultyAppropriateness },
      { fraction: deployment, weight: SCORING_WEIGHTS.deploymentPreference },
      { fraction: preset, weight: SCORING_WEIGHTS.presetAvailability }
    ];
    const rawScore = factors.reduce((sum, factor) => sum + factor.fraction * factor.weight, 0);
    const matchScore = Math.round(clampUnit(rawScore / MAX_POSSIBLE_SCORE) * 100);

    const recommendation: Omit<TechnologyRecommendation, "rank"> = {
      technologyId: option.id,
      displayName: option.displayName,
      provider: option.provider,
      matchScore,
      rationale: buildRationale(option, workload.matchedShapes, topology),
      strengths: roleCapabilities.slice(0, 5).map(humanize),
      tradeOffs: buildTradeOffs(option, roleAdvisories),
      typicalUseCases: buildTypicalUseCases(option, workload.matchedShapes),
      deploymentModel: option.deploymentModel,
      hasSimulationPreset: option.simulationPreset !== undefined,
      warnings: buildWarnings(option, roleAdvisories)
    };
    return recommendation;
  });

  scored.sort((left, right) => {
    if (right.matchScore !== left.matchScore) return right.matchScore - left.matchScore;
    return left.displayName.localeCompare(right.displayName);
  });

  const boundedCount =
    scored.length <= MIN_RECOMMENDATIONS
      ? scored.length
      : Math.min(MAX_RECOMMENDATIONS, scored.length);

  return scored.slice(0, boundedCount).map((recommendation, index) => ({
    ...recommendation,
    rank: index + 1
  }));
}
