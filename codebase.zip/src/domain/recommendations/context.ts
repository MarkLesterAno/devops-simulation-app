﻿import type { ArchitectureNode, ComponentType } from "@/domain/architecture/schema";
import type { ProjectDocument } from "@/domain/architecture/projectDocument";

/**
 * Component types of every node directly connected (in either direction) to
 * `nodeId`, used as the "topology coherence" recommendation signal.
 */
export function getConnectedNodeTypes(
  document: Pick<ProjectDocument, "nodes" | "edges">,
  nodeId: string
): ComponentType[] {
  const nodesById = new Map(document.nodes.map((node) => [node.id, node]));
  const connectedIds = new Set<string>();
  for (const edge of document.edges) {
    if (edge.sourceNodeId === nodeId) connectedIds.add(edge.targetNodeId);
    if (edge.targetNodeId === nodeId) connectedIds.add(edge.sourceNodeId);
  }
  const types: ComponentType[] = [];
  for (const id of connectedIds) {
    const node = nodesById.get(id);
    if (node) types.push(node.type);
  }
  return types;
}

/**
 * Technology ids already assigned to other nodes in the graph, used to bias
 * recommendations toward a provider ecosystem already in use elsewhere.
 */
export function getExistingTechnologyAssignments(
  document: Pick<ProjectDocument, "nodes">,
  excludeNodeId?: string
): string[] {
  const ids: string[] = [];
  for (const node of document.nodes) {
    if (node.id === excludeNodeId) continue;
    const technology = (node as ArchitectureNode).config.technology;
    if (technology) ids.push(technology.id);
  }
  return ids;
}
