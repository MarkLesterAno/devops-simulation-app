﻿import type { WorkloadShape } from "@/domain/scenarios/schema";
import type { ScenarioDifficulty } from "@/domain/scenarios/schema";
import type { DeploymentModel } from "@/domain/technology/schema";

/**
 * Deterministic scoring weights. Kept as named constants (rather than magic
 * numbers inline in `engine.ts`) so the relative importance of each ranking
 * signal from the recommendation prompt is easy to audit and adjust.
 */
export const SCORING_WEIGHTS = {
  workloadFit: 34,
  topologyCoherence: 14,
  domainRelevance: 10,
  difficultyAppropriateness: 16,
  deploymentPreference: 16,
  presetAvailability: 10
} as const;

export const MAX_POSSIBLE_SCORE = Object.values(SCORING_WEIGHTS).reduce((a, b) => a + b, 0);

export const MIN_RECOMMENDATIONS = 3;
export const MAX_RECOMMENDATIONS = 7;

/**
 * Keywords searched (case-insensitively) across a candidate's capabilities,
 * role capabilities, and description to judge fit for a workload shape. This
 * reuses the existing catalog's free-text fields instead of requiring new
 * schema metadata on every technology entry.
 */
export const WORKLOAD_KEYWORDS: Record<WorkloadShape, string[]> = {
  "read-heavy": [
    "read-scaling",
    "read-replica",
    "cache",
    "caching",
    "in-memory",
    "hit-ratio",
    "cdn",
    "edge-caching",
    "eventual-consistency"
  ],
  "write-heavy": [
    "write",
    "sharding",
    "partitioning",
    "horizontal-sharding",
    "append-only",
    "log-structured",
    "durability",
    "wal",
    "high-throughput"
  ],
  "latency-sensitive": [
    "sub-millisecond",
    "low-latency",
    "in-memory",
    "multi-threaded",
    "edge",
    "in-memory-storage"
  ],
  "throughput-sensitive": [
    "horizontal-sharding",
    "partitioning",
    "streaming",
    "streams",
    "batch",
    "high-throughput",
    "multi-threaded",
    "autoscaling"
  ],
  "consistency-sensitive": [
    "acid",
    "sql-transactions",
    "strong-consistency",
    "linearizable",
    "quorum",
    "transactions"
  ],
  "availability-sensitive": [
    "multi-region",
    "failover",
    "high-availability",
    "replication",
    "active-active",
    "streaming-replication"
  ]
};

/**
 * Heuristic affinity of a deployment model to a difficulty tier: lower tiers
 * favor lower-operational-burden options, higher tiers favor options that
 * reward deeper operational understanding. This is pedagogical guidance, not a
 * claim about production suitability.
 */
export const DIFFICULTY_DEPLOYMENT_AFFINITY: Record<
  ScenarioDifficulty,
  Partial<Record<DeploymentModel, number>>
> = {
  beginner: { "managed-cloud": 1, saas: 1, "self-managed": -0.5, "on-premises": -1 },
  intermediate: { "managed-cloud": 0.5, saas: 0.5, "open-source": 0.5 },
  advanced: { "self-managed": 0.5, "open-source": 0.5, "managed-cloud": 0.25 },
  specialized: { "self-managed": 0.5, "open-source": 0.5, "on-premises": 0.25 }
};

/**
 * Free-text markers in advisories/capabilities/status that indicate a
 * technology deserves a role-mismatch or lifecycle warning independent of any
 * per-context score.
 */
export const WARNING_KEYWORDS = ["analytical", "non-relational", "legacy", "deprecated"];
