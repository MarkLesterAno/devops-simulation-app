import { z } from "zod";

/** Fault types supported by the MVP, per PRD.md fault injection requirements.
 *
 * Append-only: fault scenarios persist these values by string, so entries must
 * never be reordered, renamed, or removed.
 */
export const faultTypeSchema = z.enum([
  "node-outage",
  "degradation",
  "latency-increase",
  "error-rate-increase",
  "capacity-reduction",
  "network-failure",
  "traffic-spike",
  "cache-failure",
  "database-primary-failure",
  "queue-consumer-failure",
  "regional-outage",
  // Priority 1 catalog expansion.
  "quota-exhaustion",
  "stale-dns-record",
  "partition-hotspot",
  "subscriber-group-stall",
  "credential-store-unavailable",
  "provider-throttling"
]);
export type FaultType = z.infer<typeof faultTypeSchema>;

export const faultTargetSchema = z.object({
  nodeIds: z.array(z.string().min(1)).default([]),
  edgeIds: z.array(z.string().min(1)).default([]),
  region: z.string().optional()
});
export type FaultTarget = z.infer<typeof faultTargetSchema>;

export const scheduledFaultSchema = z.object({
  id: z.string().min(1),
  type: faultTypeSchema,
  target: faultTargetSchema,
  startMs: z.number().min(0),
  endMs: z.number().min(0).optional(),
  capacityMultiplier: z.number().min(0).max(1).optional(),
  additionalLatencyMs: z.number().min(0).optional(),
  additionalErrorRate: z.number().min(0).max(1).optional(),
  trafficMultiplier: z.number().min(0).optional()
});
export type ScheduledFault = z.infer<typeof scheduledFaultSchema>;

export const faultScenarioSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  faults: z.array(scheduledFaultSchema)
});
export type FaultScenario = z.infer<typeof faultScenarioSchema>;
