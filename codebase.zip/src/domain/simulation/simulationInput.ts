import { z } from "zod";
import { projectDocumentSchema } from "@/domain/architecture/projectDocument";
import { manualRequestDefinitionSchema } from "@/domain/simulation/manualRequest";

/**
 * SimulationInput and SimulationSettings, per SIMULATION_SPEC.md "Simulation input".
 * A run is always derived from an immutable snapshot plus a fixed seed.
 */
export const simulationSettingsSchema = z.object({
  metricIntervalMs: z.number().min(1).default(200),
  maxRecordedEvents: z.number().int().min(1).default(2000),
  maxEventsProcessed: z.number().int().min(1).default(500_000),
  maxHopCount: z.number().int().min(1).default(64),
  samplingRate: z.number().min(0).max(1).default(1)
});
export type SimulationSettings = z.infer<typeof simulationSettingsSchema>;

export const simulationInputSchema = z.object({
  projectSnapshot: projectDocumentSchema,
  trafficProfileId: z.string().min(1),
  faultScenarioIds: z.array(z.string()),
  durationMs: z.number().min(1),
  seed: z.number().int(),
  settings: simulationSettingsSchema,
  /**
   * User-initiated request batches dispatched alongside the traffic profile.
   * Optional so existing callers and saved projects are unaffected.
   */
  manualRequests: z.array(manualRequestDefinitionSchema).optional(),
  /**
   * Suppresses profile-generated traffic so a run contains only the manual
   * batches. Used by the request composer's "send just this batch" mode.
   */
  suppressProfileTraffic: z.boolean().optional()
});
export type SimulationInput = z.infer<typeof simulationInputSchema>;

export function defaultSimulationSettings(): SimulationSettings {
  return simulationSettingsSchema.parse({});
}
