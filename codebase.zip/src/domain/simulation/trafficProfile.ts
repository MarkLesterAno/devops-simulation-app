import { z } from "zod";

export const trafficScheduleKindSchema = z.enum(["constant", "step", "ramp", "burst"]);
export type TrafficScheduleKind = z.infer<typeof trafficScheduleKindSchema>;

/** A single interval within a traffic profile, per SIMULATION_SPEC.md traffic generation rules. */
export const trafficIntervalSchema = z.object({
  kind: trafficScheduleKindSchema,
  startMs: z.number().min(0),
  endMs: z.number().min(0),
  startRps: z.number().min(0),
  endRps: z.number().min(0)
});
export type TrafficInterval = z.infer<typeof trafficIntervalSchema>;

export const trafficProfileSchema = z
  .object({
    id: z.string().min(1),
    name: z.string().min(1),
    durationMs: z.number().min(1),
    intervals: z.array(trafficIntervalSchema).min(1),
    readRatio: z.number().min(0).max(1).default(0.8),
    concurrentUsers: z.number().int().min(1).default(100),
    requestSizeBytes: z.number().min(0).default(1024),
    responseSizeBytes: z.number().min(0).default(4096)
  })
  .superRefine((profile, ctx) => {
    for (const interval of profile.intervals) {
      if (interval.endMs <= interval.startMs) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Traffic interval endMs must be greater than startMs"
        });
      }
      if (interval.endMs > profile.durationMs) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Traffic interval cannot extend past profile durationMs"
        });
      }
    }
  });
export type TrafficProfile = z.infer<typeof trafficProfileSchema>;
