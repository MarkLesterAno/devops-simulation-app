import { z } from "zod";

/**
 * User-initiated request batches, per LIVE_PLAYBACK_AND_REQUEST_SIMULATION_PROMPT.md
 * section 5. A batch is purely logical input to the deterministic engine: it is
 * converted into request-arrival events exactly like a traffic profile is, and
 * never results in real network activity of any kind.
 */
export const httpMethodSchema = z.enum([
  "GET",
  "POST",
  "PUT",
  "PATCH",
  "DELETE",
  "HEAD",
  "OPTIONS"
]);
export type HttpMethod = z.infer<typeof httpMethodSchema>;

export const requestClassSchema = z.enum(["read", "write", "auth-required"]);
export type RequestClass = z.infer<typeof requestClassSchema>;

/** Methods that are treated as reads unless the batch overrides the class. */
const READ_METHODS: ReadonlySet<HttpMethod> = new Set<HttpMethod>([
  "GET",
  "HEAD",
  "OPTIONS"
]);

export const MAX_MANUAL_REQUEST_COUNT = 1_000_000;
export const MAX_MANUAL_DISPATCH_RPS = 1_000_000;

export const manualRequestDefinitionSchema = z.object({
  id: z.string().min(1),
  /** Client node the batch originates from. */
  sourceNodeId: z.string().min(1),
  method: httpMethodSchema,
  requestCount: z.number().int().min(1).max(MAX_MANUAL_REQUEST_COUNT),
  dispatchRateRps: z.number().min(0.001).max(MAX_MANUAL_DISPATCH_RPS),
  /** Logical time the batch begins dispatching, relative to run start. */
  startAtMs: z.number().min(0).default(0),
  path: z.string().optional(),
  requestClass: requestClassSchema.optional(),
  payloadSizeBytes: z.number().min(0).optional(),
  responseSizeBytes: z.number().min(0).optional(),
  timeoutMs: z.number().min(1).max(600_000).optional(),
  /** Overrides the run seed for this batch's own random draws only. */
  seed: z.number().int().optional(),
  /** Display label for presets and result traceability. */
  label: z.string().optional()
});
export type ManualRequestDefinition = z.infer<typeof manualRequestDefinitionSchema>;

/**
 * Resolves the effective class of a batch. An explicit class always wins;
 * otherwise the HTTP method decides, so a PUT batch is a write without the
 * user having to say so twice.
 */
export function effectiveRequestClass(definition: ManualRequestDefinition): RequestClass {
  if (definition.requestClass) return definition.requestClass;
  return READ_METHODS.has(definition.method) ? "read" : "write";
}

/** True when the batch should be counted as a read by the engine's read/write split. */
export function isReadRequestClass(
  method: HttpMethod,
  requestClass: RequestClass | undefined
): boolean {
  if (requestClass === "read") return true;
  if (requestClass === "write") return false;
  return READ_METHODS.has(method);
}

/**
 * Dispatch duration implied by a batch. Exposed so the composer can show the
 * user the logical time span their batch will occupy before they submit it.
 */
export function batchDurationMs(definition: ManualRequestDefinition): number {
  return (definition.requestCount / definition.dispatchRateRps) * 1000;
}

/**
 * Deterministic arrival timestamps for a manual batch.
 *
 * Arrivals are evenly spaced at `1000 / dispatchRateRps` milliseconds so that a
 * batch of 1,000 requests at 100 RPS occupies exactly 10 logical seconds and
 * produces exactly 1,000 arrivals. Spacing uses multiplication from the start
 * offset rather than repeated addition so floating-point error cannot
 * accumulate across large batches.
 */
export function generateManualArrivalTimestamps(
  definition: ManualRequestDefinition
): number[] {
  const intervalMs = 1000 / definition.dispatchRateRps;
  const arrivals: number[] = new Array<number>(definition.requestCount);
  for (let index = 0; index < definition.requestCount; index += 1) {
    arrivals[index] = definition.startAtMs + index * intervalMs;
  }
  return arrivals;
}
