import type { FlowClass, FlowTimeline } from "@/domain/metrics/flowTimeline";

/**
 * Live per-edge flow at one instant of visual playback.
 *
 * Everything here is derived by reading a finished run's recorded timeline.
 * Playback never writes back into simulation state, so scrubbing, pausing or
 * changing speed cannot alter a calculated outcome.
 */
export interface LiveEdgeFlow {
  edgeId: string;
  flowClass: FlowClass;
  /** Traversals recorded in the bucket covering this instant. */
  count: number;
  failureCount: number;
  retryCount: number;
  /** Volume relative to the busiest bucket in the run, 0..1. */
  intensity: number;
}

export interface PlaybackFrame {
  logicalTimeMs: number;
  edges: Map<string, LiveEdgeFlow>;
  /** Nodes receiving traffic at this instant, for the active-processing state. */
  activeNodeIds: Set<string>;
}

/** An empty frame, used before a run exists and when playback is reset. */
export const EMPTY_FRAME: PlaybackFrame = {
  logicalTimeMs: 0,
  edges: new Map(),
  activeNodeIds: new Set()
};

/**
 * Reads the flow state at a logical instant.
 *
 * Buckets are ordered, so the bucket covering an instant is found by binary
 * search rather than by scanning every sample. That keeps sampling cheap
 * enough to run on every animation frame regardless of run length.
 *
 * When several classes traverse the same edge in one bucket, the busiest class
 * wins the edge's visual treatment; its count still reports the edge total so
 * density stays truthful.
 */
export function sampleTimelineAt(
  timeline: FlowTimeline | undefined,
  logicalTimeMs: number,
  edgeTargets?: ReadonlyMap<string, string>
): PlaybackFrame {
  if (!timeline || timeline.buckets.length === 0) {
    return { logicalTimeMs, edges: new Map(), activeNodeIds: new Set() };
  }

  const bucketStart = Math.floor(logicalTimeMs / timeline.bucketMs) * timeline.bucketMs;
  const bucket = findBucket(timeline, bucketStart);
  const edges = new Map<string, LiveEdgeFlow>();
  const activeNodeIds = new Set<string>();
  if (!bucket) return { logicalTimeMs, edges, activeNodeIds };

  const peak = timeline.peakBucketCount || 1;
  for (const sample of bucket.samples) {
    const existing = edges.get(sample.edgeId);
    const count = (existing?.count ?? 0) + sample.count;
    const dominant = !existing || sample.count > existing.count;
    edges.set(sample.edgeId, {
      edgeId: sample.edgeId,
      flowClass: dominant ? sample.flowClass : existing!.flowClass,
      count,
      failureCount: (existing?.failureCount ?? 0) + sample.failureCount,
      retryCount: (existing?.retryCount ?? 0) + sample.retryCount,
      intensity: Math.min(1, count / peak)
    });
    const target = edgeTargets?.get(sample.edgeId);
    if (target) activeNodeIds.add(target);
  }

  return { logicalTimeMs, edges, activeNodeIds };
}

/**
 * Locates the bucket starting at `bucketStart`.
 *
 * Buckets are sparse — a quiet stretch of a run produces no bucket at all — so
 * the position of a bucket cannot be computed from its timestamp. Binary
 * search over the ascending bucket list keeps the lookup O(log n), which is
 * cheap enough to run on every animation frame.
 */
function findBucket(timeline: FlowTimeline, bucketStart: number) {
  let low = 0;
  let high = timeline.buckets.length - 1;
  while (low <= high) {
    const mid = (low + high) >> 1;
    const candidate = timeline.buckets[mid]!;
    if (candidate.timestampMs === bucketStart) return candidate;
    if (candidate.timestampMs < bucketStart) low = mid + 1;
    else high = mid - 1;
  }
  // No bucket for this instant means there genuinely was no traffic then.
  return undefined;
}

/**
 * Total logical time playback should cover. Uses the recorded duration so
 * playback keeps running through trailing quiet periods rather than stopping
 * at the last busy bucket.
 */
export function playbackDurationMs(timeline: FlowTimeline | undefined): number {
  if (!timeline) return 0;
  return Math.max(timeline.durationMs, 0);
}
