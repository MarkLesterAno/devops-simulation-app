import { create } from "zustand";
import {
  batchDurationMs,
  type ManualRequestDefinition
} from "@/domain/simulation/manualRequest";

interface RequestState {
  /** Batches that will be dispatched by the next run. */
  batches: ManualRequestDefinition[];
  /**
   * When true, the next run dispatches only the manual batches. Useful for
   * studying exactly what one burst of traffic does without background load
   * blurring the picture.
   */
  suppressProfileTraffic: boolean;

  addBatch(batch: ManualRequestDefinition): void;
  removeBatch(id: string): void;
  /** Clears session-only batches when switching to another project or template. */
  reset(): void;
  setSuppressProfileTraffic(value: boolean): void;
}

/**
 * User-initiated request batches, per
 * LIVE_PLAYBACK_AND_REQUEST_SIMULATION_PROMPT.md section 5.
 *
 * Held outside the project document: a batch is something the user dispatches
 * during a session, not a property of the architecture, so queueing one must
 * not mark the project dirty or enter undo history.
 */
export const useRequestStore = create<RequestState>((set) => ({
  batches: [],
  suppressProfileTraffic: false,

  addBatch(batch) {
    set((state) => ({ batches: [...state.batches, batch] }));
  },

  removeBatch(id) {
    set((state) => ({ batches: state.batches.filter((batch) => batch.id !== id) }));
  },

  reset() {
    set({ batches: [], suppressProfileTraffic: false });
  },

  setSuppressProfileTraffic(value) {
    set({ suppressProfileTraffic: value });
  }
}));

/**
 * Logical time a run must cover for every queued batch to finish dispatching.
 * The composer uses this to warn when a batch would be cut short by the
 * configured run duration.
 */
export function requiredDurationMs(batches: readonly ManualRequestDefinition[]): number {
  let required = 0;
  for (const batch of batches) {
    required = Math.max(required, batch.startAtMs + batchDurationMs(batch));
  }
  return required;
}
