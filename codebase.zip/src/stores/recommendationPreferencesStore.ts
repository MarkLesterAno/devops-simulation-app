﻿import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { RecommendationPreferences } from "@/domain/recommendations/types";

/**
 * Local, per-device technology recommendation preferences.
 *
 * Deliberately isolated from the project document (per
 * docs/SCENARIO_TUTORIAL_AND_RECOMMENDATION_PROMPT.md section 7): these are a
 * personal UI setting, not project data, so they persist across projects and
 * never round-trip through save/load or export.
 */
interface RecommendationPreferencesState extends RecommendationPreferences {
  setPreferOpenSource(value: boolean): void;
  setPreferManagedServices(value: boolean): void;
  addPreferredProvider(provider: string): void;
  removePreferredProvider(provider: string): void;
  reset(): void;
}

const defaults: RecommendationPreferences = {
  preferOpenSource: false,
  preferManagedServices: false,
  preferredProviders: []
};

export const useRecommendationPreferencesStore = create<RecommendationPreferencesState>()(
  persist(
    (set) => ({
      ...defaults,

      setPreferOpenSource(value) {
        set({ preferOpenSource: value });
      },

      setPreferManagedServices(value) {
        set({ preferManagedServices: value });
      },

      addPreferredProvider(provider) {
        const trimmed = provider.trim();
        if (!trimmed) return;
        set((state) =>
          state.preferredProviders.includes(trimmed)
            ? state
            : { preferredProviders: [...state.preferredProviders, trimmed] }
        );
      },

      removePreferredProvider(provider) {
        set((state) => ({
          preferredProviders: state.preferredProviders.filter((entry) => entry !== provider)
        }));
      },

      reset() {
        set(defaults);
      }
    }),
    {
      name: "system-design-simulator-recommendation-preferences",
      partialize: (state) => ({
        preferOpenSource: state.preferOpenSource,
        preferManagedServices: state.preferManagedServices,
        preferredProviders: state.preferredProviders
      })
    }
  )
);
