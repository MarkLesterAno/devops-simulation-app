import { create } from "zustand";

export type NodeModalTab = "implementation" | "inspector";
export type ContextPanelTab = "objectives" | "inspector" | "metrics" | "findings";
export type ScenarioMode = "guided-tour" | "build" | "challenge";

export interface ContextMenuTarget {
  nodeId: string;
  x: number;
  y: number;
}

interface UiState {
  /** Node whose configuration modal is open, if any. */
  configNodeId?: string;
  configTab: NodeModalTab;
  contextMenu?: ContextMenuTarget;
  metricsModalOpen: boolean;
  /**
   * Component the metrics modal should scroll to and highlight. Set when the
   * modal is opened from a finding so the user lands on the relevant numbers
   * rather than the top of the list.
   */
  metricsFocusNodeId?: string;
  requestComposerOpen: boolean;
  scenarioGalleryOpen: boolean;
  /** Scenario metadata to retain in the workspace after the gallery closes. */
  activeScenarioId?: string;
  activeScenarioMode: ScenarioMode;
  contextPanelOpen: boolean;
  contextPanelTab: ContextPanelTab;
  /** Preference. Kept in UI state because it never belongs in a project file. */
  flowAnimationEnabled: boolean;

  openNodeConfig(nodeId: string, tab?: NodeModalTab): void;
  closeNodeConfig(): void;
  setConfigTab(tab: NodeModalTab): void;
  openContextMenu(target: ContextMenuTarget): void;
  closeContextMenu(): void;
  openMetrics(focusNodeId?: string): void;
  closeMetrics(): void;
  openRequestComposer(): void;
  closeRequestComposer(): void;
  openScenarioGallery(): void;
  closeScenarioGallery(): void;
  setActiveScenario(scenarioId: string | undefined, mode?: ScenarioMode): void;
  openContextPanel(tab?: ContextPanelTab): void;
  closeContextPanel(): void;
  setContextPanelTab(tab: ContextPanelTab): void;
  setFlowAnimationEnabled(value: boolean): void;
}

/**
 * Ephemeral view state: which overlays are open, what they are pointed at, and
 * the user's presentation preferences.
 *
 * Deliberately separate from the project store. None of this is part of the
 * saved document, and keeping it out means opening a modal can never mark a
 * project dirty or enter undo history.
 */
export const useUiStore = create<UiState>((set) => ({
  configTab: "inspector",
  metricsModalOpen: false,
  requestComposerOpen: false,
  scenarioGalleryOpen: false,
  activeScenarioId: undefined,
  activeScenarioMode: "guided-tour",
  contextPanelOpen: true,
  contextPanelTab: "objectives",
  flowAnimationEnabled: true,

  // Opening a different node resets to Inspector; re-opening the same node
  // keeps whichever tab the user was last working in.
  openNodeConfig(nodeId, tab) {
    set((state) => ({
      configNodeId: nodeId,
      configTab: tab ?? (state.configNodeId === nodeId ? state.configTab : "inspector"),
      contextMenu: undefined
    }));
  },

  closeNodeConfig() {
    set({ configNodeId: undefined });
  },

  setConfigTab(tab) {
    set({ configTab: tab });
  },

  openContextMenu(target) {
    set({ contextMenu: target });
  },

  closeContextMenu() {
    set({ contextMenu: undefined });
  },

  openMetrics(focusNodeId) {
    set({ metricsModalOpen: true, metricsFocusNodeId: focusNodeId });
  },

  closeMetrics() {
    set({ metricsModalOpen: false, metricsFocusNodeId: undefined });
  },

  openRequestComposer() {
    set({ requestComposerOpen: true });
  },

  closeRequestComposer() {
    set({ requestComposerOpen: false });
  },

  openScenarioGallery() {
    set({ scenarioGalleryOpen: true });
  },

  closeScenarioGallery() {
    set({ scenarioGalleryOpen: false });
  },

  setActiveScenario(scenarioId, mode = "guided-tour") {
    set({ activeScenarioId: scenarioId, activeScenarioMode: mode });
  },

  openContextPanel(tab = "objectives") {
    set({ contextPanelOpen: true, contextPanelTab: tab });
  },

  closeContextPanel() {
    set({ contextPanelOpen: false });
  },

  setContextPanelTab(tab) {
    set({ contextPanelTab: tab });
  },

  setFlowAnimationEnabled(value) {
    set({ flowAnimationEnabled: value });
  }
}));
