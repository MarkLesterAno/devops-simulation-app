﻿import { create } from "zustand";
import type {
  ArchitectureEdge,
  ArchitectureNode,
  ConnectionKind,
  TechnologyAssignment
} from "@/domain/architecture/schema";
import type { ProjectDocument } from "@/domain/architecture/projectDocument";
import { createEmptyProject } from "@/domain/architecture/projectDocument";
import { trafficProfileSchema } from "@/domain/simulation/trafficProfile";
import { componentDefinitions, createNodeFromDefinition } from "@/domain/components/registry";
import type { ComponentType } from "@/domain/architecture/schema";
import { validateGraph, type ValidationIssue } from "@/domain/validation/graphValidation";
import { architectureSignature } from "@/domain/architecture/projectAnalysis";
import type { SimulationResult } from "@/domain/metrics/schema";

const DEFAULT_TRAFFIC_PROFILE_ID = "default-profile";

function defaultTrafficProfile() {
  return trafficProfileSchema.parse({
    id: DEFAULT_TRAFFIC_PROFILE_ID,
    name: "Constant 100 RPS",
    durationMs: 30_000,
    intervals: [{ kind: "constant", startMs: 0, endMs: 30_000, startRps: 100, endRps: 100 }]
  });
}

interface HistoryEntry {
  nodes: ArchitectureNode[];
  edges: ArchitectureEdge[];
}

interface ProjectState {
  document: ProjectDocument;
  filePath?: string;
  isDirty: boolean;
  selectedNodeId?: string;
  selectedEdgeId?: string;
  validationIssues: ValidationIssue[];
  lastResult?: SimulationResult;
  /** Architecture fingerprint captured when `lastResult` arrived. */
  lastResultSignature?: string;
  isSimulating: boolean;
  past: HistoryEntry[];
  future: HistoryEntry[];

  /** Returns the id of the created node so callers can select or wire it up. */
  addNode(type: ComponentType, position: { x: number; y: number }): string;
  duplicateNode(nodeId: string): string | undefined;
  updateNodeConfig(nodeId: string, patch: Record<string, unknown>): void;
  setNodeTechnology(nodeId: string, technology: TechnologyAssignment | undefined): void;
  moveNode(nodeId: string, position: { x: number; y: number }): void;
  removeNode(nodeId: string): void;
  addEdge(sourceNodeId: string, targetNodeId: string, kind: ConnectionKind): { ok: boolean; error?: string };
  removeEdge(edgeId: string): void;
  selectNode(nodeId: string | undefined): void;
  selectEdge(edgeId: string | undefined): void;
  undo(): void;
  redo(): void;
  revalidate(): void;
  setDocument(document: ProjectDocument, filePath?: string): void;
  restoreDocument(document: ProjectDocument, filePath: string | undefined, isDirty: boolean): void;
  setFilePath(filePath: string | undefined): void;
  markSaved(): void;
  setSimulating(isSimulating: boolean): void;
  setResult(result: SimulationResult): void;
  newProject(): void;
  loadTemplateDocument(document: ProjectDocument): void;
}

let nodeCounter = 0;
function generateNodeId(type: ComponentType): string {
  nodeCounter += 1;
  return `${type}-${nodeCounter}-${Date.now().toString(36)}`;
}
let edgeCounter = 0;
function generateEdgeId(): string {
  edgeCounter += 1;
  return `edge-${edgeCounter}-${Date.now().toString(36)}`;
}

function snapshot(document: ProjectDocument): HistoryEntry {
  return {
    nodes: structuredClone(document.nodes),
    edges: structuredClone(document.edges)
  };
}

const CONNECTION_RULES: Record<ConnectionKind, { requiresDefinitionSupport: boolean }> = {
  request: { requiresDefinitionSupport: true },
  response: { requiresDefinitionSupport: true },
  event: { requiresDefinitionSupport: true },
  replication: { requiresDefinitionSupport: true },
  failover: { requiresDefinitionSupport: true },
  observability: { requiresDefinitionSupport: true }
};

const initialDocument = seedInitialProject();

/** Canvas offset for duplicated nodes so the copy never hides the original. */
const DUPLICATE_OFFSET = 48;

export const useProjectStore = create<ProjectState>((set, get) => ({
  document: initialDocument,
  isDirty: false,
  // Validate the seed document up front so Run is correctly blocked before any edit occurs.
  validationIssues: validateGraph(initialDocument.nodes, initialDocument.edges),
  isSimulating: false,
  past: [],
  future: [],

  addNode(type, position) {
    const id = generateNodeId(type);
    const node = createNodeFromDefinition(type, id, position);
    set((state) => {
      const past = [...state.past, snapshot(state.document)];
      return {
        document: {
          ...state.document,
          nodes: [...state.document.nodes, node],
          updatedAt: new Date().toISOString()
        },
        past,
        future: [],
        isDirty: true,
        selectedNodeId: id
      };
    });
    get().revalidate();
    return id;
  },

  /**
   * Deep-copies a node with a fresh id and an offset position.
   *
   * Edges are intentionally not duplicated: a copied component almost never
   * wants the original's exact wiring, and silently cloning connections would
   * produce invalid topologies the user did not ask for.
   */
  duplicateNode(nodeId) {
    const source = get().document.nodes.find((node) => node.id === nodeId);
    if (!source) return undefined;
    const id = generateNodeId(source.type);
    const copy: ArchitectureNode = {
      ...structuredClone(source),
      id,
      position: { x: source.position.x + DUPLICATE_OFFSET, y: source.position.y + DUPLICATE_OFFSET },
      config: {
        ...structuredClone(source.config),
        displayName: `${source.config.displayName} copy`
      }
    };
    set((state) => ({
      document: {
        ...state.document,
        nodes: [...state.document.nodes, copy],
        updatedAt: new Date().toISOString()
      },
      past: [...state.past, snapshot(state.document)],
      future: [],
      isDirty: true,
      selectedNodeId: id
    }));
    get().revalidate();
    return id;
  },

  updateNodeConfig(nodeId, patch) {    set((state) => {
      const past = [...state.past, snapshot(state.document)];
      return {
        document: {
          ...state.document,
          nodes: state.document.nodes.map((node) =>
            node.id === nodeId ? { ...node, config: { ...node.config, ...patch } } : node
          ),
          updatedAt: new Date().toISOString()
        },
        past,
        future: [],
        isDirty: true
      };
    });
    get().revalidate();
  },

  /**
   * Assigns or clears a node's technology. Passing `undefined` resets the node to
   * Generic / Custom Implementation while deliberately leaving all simulation
   * values untouched, so user-tuned numbers are never lost by clearing a product.
   */
  setNodeTechnology(nodeId, technology) {
    set((state) => {
      const past = [...state.past, snapshot(state.document)];
      return {
        document: {
          ...state.document,
          nodes: state.document.nodes.map((node) => {
            if (node.id !== nodeId) return node;
            const nextConfig = { ...node.config };
            if (technology) {
              nextConfig.technology = technology;
            } else {
              delete nextConfig.technology;
            }
            return { ...node, config: nextConfig };
          }),
          updatedAt: new Date().toISOString()
        },
        past,
        future: [],
        isDirty: true
      };
    });
    get().revalidate();
  },

  moveNode(nodeId, position) {
    set((state) => ({
      document: {
        ...state.document,
        nodes: state.document.nodes.map((node) => (node.id === nodeId ? { ...node, position } : node))
      },
      isDirty: true
    }));
  },

  removeNode(nodeId) {
    set((state) => {
      const past = [...state.past, snapshot(state.document)];
      return {
        document: {
          ...state.document,
          nodes: state.document.nodes.filter((node) => node.id !== nodeId),
          edges: state.document.edges.filter(
            (edge) => edge.sourceNodeId !== nodeId && edge.targetNodeId !== nodeId
          ),
          updatedAt: new Date().toISOString()
        },
        past,
        future: [],
        isDirty: true,
        selectedNodeId: state.selectedNodeId === nodeId ? undefined : state.selectedNodeId
      };
    });
    get().revalidate();
  },

  addEdge(sourceNodeId, targetNodeId, kind) {
    const { document } = get();
    const sourceNode = document.nodes.find((node) => node.id === sourceNodeId);
    const targetNode = document.nodes.find((node) => node.id === targetNodeId);
    if (!sourceNode || !targetNode) return { ok: false, error: "Unknown source or target node." };
    const sourceDefinition = componentDefinitions[sourceNode.type];
    const targetDefinition = componentDefinitions[targetNode.type];
    if (CONNECTION_RULES[kind].requiresDefinitionSupport) {
      if (!sourceDefinition.allowedOutgoingConnections.includes(kind)) {
        return {
          ok: false,
          error: `${sourceDefinition.displayName} does not support outgoing "${kind}" connections.`
        };
      }
      if (!targetDefinition.allowedIncomingConnections.includes(kind)) {
        return {
          ok: false,
          error: `${targetDefinition.displayName} does not accept incoming "${kind}" connections.`
        };
      }
    }
    const edge: ArchitectureEdge = {
      id: generateEdgeId(),
      sourceNodeId,
      targetNodeId,
      kind,
      latencyMs: 5
    };
    set((state) => {
      const past = [...state.past, snapshot(state.document)];
      return {
        document: {
          ...state.document,
          edges: [...state.document.edges, edge],
          updatedAt: new Date().toISOString()
        },
        past,
        future: [],
        isDirty: true
      };
    });
    get().revalidate();
    return { ok: true };
  },

  removeEdge(edgeId) {
    set((state) => {
      const past = [...state.past, snapshot(state.document)];
      return {
        document: {
          ...state.document,
          edges: state.document.edges.filter((edge) => edge.id !== edgeId),
          updatedAt: new Date().toISOString()
        },
        past,
        future: [],
        isDirty: true,
        selectedEdgeId: state.selectedEdgeId === edgeId ? undefined : state.selectedEdgeId
      };
    });
    get().revalidate();
  },

  selectNode(nodeId) {
    set({ selectedNodeId: nodeId, selectedEdgeId: undefined });
  },

  selectEdge(edgeId) {
    set({ selectedEdgeId: edgeId, selectedNodeId: undefined });
  },

  undo() {
    set((state) => {
      if (state.past.length === 0) return state;
      const previous = state.past[state.past.length - 1]!;
      const future = [...state.future, snapshot(state.document)];
      return {
        document: { ...state.document, nodes: previous.nodes, edges: previous.edges },
        past: state.past.slice(0, -1),
        future,
        isDirty: true
      };
    });
    get().revalidate();
  },

  redo() {
    set((state) => {
      if (state.future.length === 0) return state;
      const next = state.future[state.future.length - 1]!;
      const past = [...state.past, snapshot(state.document)];
      return {
        document: { ...state.document, nodes: next.nodes, edges: next.edges },
        past,
        future: state.future.slice(0, -1),
        isDirty: true
      };
    });
    get().revalidate();
  },

  revalidate() {
    const { document } = get();
    set({ validationIssues: validateGraph(document.nodes, document.edges) });
  },

  setDocument(document, filePath) {
    set({ document, filePath, isDirty: false, past: [], future: [], selectedNodeId: undefined, selectedEdgeId: undefined });
    get().revalidate();
  },

  /**
   * Loads a recovered autosave draft. Unlike opening a file, the restored work
   * is marked dirty because it has never been written to a real project file.
   */
  restoreDocument(document, filePath, isDirty) {
    set({
      document,
      filePath,
      isDirty,
      past: [],
      future: [],
      selectedNodeId: undefined,
      selectedEdgeId: undefined,
      lastResult: undefined,
      lastResultSignature: undefined
    });
    get().revalidate();
  },

  setFilePath(filePath) {
    set({ filePath });
  },

  markSaved() {
    set({ isDirty: false });
  },

  setSimulating(isSimulating) {
    set({ isSimulating });
  },

  setResult(result) {
    set((state) => ({
      lastResult: result,
      lastResultSignature: architectureSignature(state.document),
      isSimulating: false
    }));
  },

  newProject() {
    set({
      document: seedInitialProject(),
      filePath: undefined,
      isDirty: false,
      past: [],
      future: [],
      selectedNodeId: undefined,
      selectedEdgeId: undefined,
      lastResult: undefined,
      lastResultSignature: undefined
    });
    get().revalidate();
  },

  /**
   * Opens a scenario template as a fresh, unsaved project. It is deliberately
   * marked dirty and given no file path: the learner has a working copy, and
   * saving it can never overwrite the shipped template.
   */
  loadTemplateDocument(document) {
    set({
      document,
      filePath: undefined,
      isDirty: true,
      past: [],
      future: [],
      selectedNodeId: undefined,
      selectedEdgeId: undefined,
      lastResult: undefined,
      lastResultSignature: undefined
    });
    get().revalidate();
  }
}));

function seedInitialProject(): ProjectDocument {
  const document = createEmptyProject("Untitled Architecture");
  document.trafficProfiles = [defaultTrafficProfile()];
  return document;
}
