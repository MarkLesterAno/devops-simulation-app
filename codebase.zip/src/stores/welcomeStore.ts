import { create } from "zustand";
import { persist } from "zustand/middleware";

interface WelcomeState {
  hasSeenWelcome: boolean;
  isOpen: boolean;
  open(): void;
  dismiss(): void;
}

/**
 * Local onboarding state. It is intentionally separate from ProjectDocument:
 * completing the welcome flow must not dirty, save, or export a project.
 */
export const useWelcomeStore = create<WelcomeState>()(
  persist(
    (set) => ({
      hasSeenWelcome: false,
      isOpen: false,

      open() {
        set({ isOpen: true });
      },

      dismiss() {
        set({ hasSeenWelcome: true, isOpen: false });
      }
    }),
    {
      name: "system-design-simulator-welcome",
      partialize: (state) => ({ hasSeenWelcome: state.hasSeenWelcome })
    }
  )
);
