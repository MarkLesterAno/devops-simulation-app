import { create } from "zustand";
import type { FlowTimeline } from "@/domain/metrics/flowTimeline";
import { playbackDurationMs } from "@/domain/flow/playbackFrame";

export type PlaybackStatus = "idle" | "running" | "paused" | "completed" | "cancelled";

export const PLAYBACK_SPEEDS = [0.25, 0.5, 1, 2, 4, 8] as const;
export type PlaybackSpeed = (typeof PLAYBACK_SPEEDS)[number];

/**
 * Shortest wall-clock time a playback is allowed to take. A run whose logical
 * duration is tiny would otherwise finish animating before the user's eye could
 * follow it, so short runs are stretched. This changes only how long the
 * visualization takes to watch; logical timestamps and results are untouched.
 */
export const MIN_PLAYBACK_WALL_MS = 4000;

interface PlaybackState {
  status: PlaybackStatus;
  speed: PlaybackSpeed;
  /** Position within the run's logical timeline. */
  currentLogicalTimeMs: number;
  timeline?: FlowTimeline;
  /** Logical ms consumed per wall-clock ms at 1x, before the speed multiplier. */
  logicalPerWallMs: number;

  /** Loads a finished run's telemetry and begins playing it. */
  start(timeline: FlowTimeline | undefined): void;
  pause(): void;
  resume(): void;
  restart(): void;
  reset(): void;
  cancel(): void;
  /** Jumps to the end, for users who want the final state immediately. */
  skipToEnd(): void;
  /** Moves within finished telemetry without changing any simulation result. */
  seek(logicalTimeMs: number): void;
  setSpeed(speed: PlaybackSpeed): void;
  /** Advances playback by a wall-clock delta. Driven by the animation loop. */
  advance(deltaWallMs: number): void;
}

/**
 * Visual playback state, per LIVE_PLAYBACK_AND_REQUEST_SIMULATION_PROMPT.md
 * section 6.
 *
 * Strictly separate from the simulation engine: the engine calculates a whole
 * run as fast as it can in a worker, and this store then replays the recorded
 * telemetry over visible time. Because playback only ever reads a finished
 * result, no playback control can influence a simulated outcome.
 */
export const usePlaybackStore = create<PlaybackState>((set, get) => ({
  status: "idle",
  speed: 1,
  currentLogicalTimeMs: 0,
  logicalPerWallMs: 1,

  start(timeline) {
    const durationMs = playbackDurationMs(timeline);
    if (!timeline || durationMs <= 0) {
      set({ status: "completed", timeline, currentLogicalTimeMs: 0 });
      return;
    }
    // Stretch short runs so they stay watchable, but never compress long ones:
    // a 5-minute run should still play in 5 minutes at 1x.
    const logicalPerWallMs = Math.min(1, durationMs / MIN_PLAYBACK_WALL_MS);
    set({
      status: "running",
      timeline,
      currentLogicalTimeMs: 0,
      logicalPerWallMs
    });
  },

  pause() {
    if (get().status === "running") set({ status: "paused" });
  },

  resume() {
    if (get().status === "paused") set({ status: "running" });
  },

  restart() {
    if (!get().timeline) return;
    set({ status: "running", currentLogicalTimeMs: 0 });
  },

  reset() {
    set({
      status: "idle",
      currentLogicalTimeMs: 0,
      timeline: undefined
    });
  },

  cancel() {
    set({ status: "cancelled" });
  },

  skipToEnd() {
    const { timeline } = get();
    set({
      status: "completed",
      currentLogicalTimeMs: playbackDurationMs(timeline)
    });
  },

  seek(logicalTimeMs) {
    const { timeline } = get();
    if (!timeline) return;
    const durationMs = playbackDurationMs(timeline);
    const currentLogicalTimeMs = Math.max(0, Math.min(logicalTimeMs, durationMs));
    set({
      currentLogicalTimeMs,
      // A direct seek should leave the learner on the evidence they selected,
      // rather than immediately advancing it beneath their cursor.
      status: currentLogicalTimeMs >= durationMs ? "completed" : "paused"
    });
  },

  setSpeed(speed) {
    set({ speed });
  },

  advance(deltaWallMs) {
    const state = get();
    if (state.status !== "running" || !state.timeline) return;
    const durationMs = playbackDurationMs(state.timeline);
    const nextLogical =
      state.currentLogicalTimeMs + deltaWallMs * state.logicalPerWallMs * state.speed;
    if (nextLogical >= durationMs) {
      set({ status: "completed", currentLogicalTimeMs: durationMs });
      return;
    }
    set({ currentLogicalTimeMs: nextLogical });
  }
}));
