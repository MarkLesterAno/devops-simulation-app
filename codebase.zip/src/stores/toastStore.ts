import { create } from "zustand";
import type { Finding, FindingSeverity } from "@/domain/metrics/schema";

export type ToastSeverity = FindingSeverity | "recommendation";
export type AppNotificationSeverity = "error" | "warning" | "info" | "success";

export interface AppNotification {
  id: string;
  severity: AppNotificationSeverity;
  title: string;
  detail?: string;
  createdAt: number;
}

export interface FindingToast {
  /** Stable identity for this toast instance. */
  id: string;
  /**
   * Identity of the *condition* being reported, independent of the run. Two
   * findings with the same key describe the same problem on the same
   * component, so the newer one replaces rather than stacks.
   */
  dedupeKey: string;
  severity: ToastSeverity;
  title: string;
  detail: string;
  /** Component or connection the finding concerns, when it names one. */
  subjectLabel?: string;
  metricSummary?: string;
  suggestedAction?: string;
  focusNodeId?: string;
  findingId: string;
  createdAt: number;
  /** How many times this condition has recurred while the toast was visible. */
  repeatCount: number;
}

/** Most toasts on screen at once; the rest queue behind them. */
export const MAX_VISIBLE_TOASTS = 3;

const SEVERITY_RANK: Record<ToastSeverity, number> = {
  critical: 0,
  warning: 1,
  info: 2,
  recommendation: 3
};

interface ToastState {
  visible: FindingToast[];
  queued: FindingToast[];
  /** Everything raised this session, so dismissed findings remain reviewable. */
  history: FindingToast[];
  notificationCentreOpen: boolean;
  appNotifications: AppNotification[];

  publish(toasts: FindingToast[]): void;
  dismiss(id: string): void;
  dismissAll(): void;
  openNotificationCentre(): void;
  closeNotificationCentre(): void;
  clearHistory(): void;
  notify(notification: Omit<AppNotification, "id" | "createdAt">): void;
  dismissAppNotification(id: string): void;
}

/**
 * Findings toast queue, per LIVE_PLAYBACK_AND_REQUEST_SIMULATION_PROMPT.md
 * section 2.
 *
 * Presentation only: dismissing a toast never removes the underlying finding,
 * which stays in the run result. Toast state is deliberately not persisted as
 * project data.
 */
export const useToastStore = create<ToastState>((set, get) => ({
  visible: [],
  queued: [],
  history: [],
  notificationCentreOpen: false,
  appNotifications: [],

  publish(incoming) {
    if (incoming.length === 0) return;
    const state = get();
    const byKey = new Map<string, FindingToast>();
    for (const toast of [...state.visible, ...state.queued]) byKey.set(toast.dedupeKey, toast);

    const fresh: FindingToast[] = [];
    const repeated = new Set<string>();
    for (const toast of incoming) {
      if (byKey.has(toast.dedupeKey)) {
        // Same condition, already on screen: count the recurrence instead of
        // stacking another copy of the same message.
        repeated.add(toast.dedupeKey);
        continue;
      }
      byKey.set(toast.dedupeKey, toast);
      fresh.push(toast);
    }

    const carried = [...state.visible, ...state.queued].map((toast) =>
      repeated.has(toast.dedupeKey) ? { ...toast, repeatCount: toast.repeatCount + 1 } : toast
    );
    const all = [...carried, ...fresh].sort(
      (a, b) => SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity]
    );

    set({
      // Critical findings outrank informational ones for screen space, so a
      // newly raised critical can displace a queued recommendation.
      visible: all.slice(0, MAX_VISIBLE_TOASTS),
      queued: all.slice(MAX_VISIBLE_TOASTS),
      history: [...fresh, ...state.history].slice(0, 200)
    });
  },

  dismiss(id) {
    set((state) => {
      const visible = state.visible.filter((toast) => toast.id !== id);
      const queued = [...state.queued];
      while (visible.length < MAX_VISIBLE_TOASTS && queued.length > 0) {
        visible.push(queued.shift()!);
      }
      return { visible, queued };
    });
  },

  dismissAll() {
    set({ visible: [], queued: [] });
  },

  openNotificationCentre() {
    set({ notificationCentreOpen: true });
  },

  closeNotificationCentre() {
    set({ notificationCentreOpen: false });
  },

  clearHistory() {
    set({ history: [] });
  },

  notify(notification) {
    const createdAt = Date.now();
    set((state) => ({
      appNotifications: [
        ...state.appNotifications,
        { ...notification, id: crypto.randomUUID(), createdAt }
      ].slice(-MAX_VISIBLE_TOASTS)
    }));
  },

  dismissAppNotification(id) {
    set((state) => ({
      appNotifications: state.appNotifications.filter((notification) => notification.id !== id)
    }));
  }
}));

/**
 * Converts a run's findings into toast descriptors.
 *
 * The dedupe key is built from the finding's identity and the components it
 * concerns rather than from the run, so re-running an unchanged architecture
 * re-reports the same condition as a repeat instead of a new alert.
 */
export function findingsToToasts(
  findings: readonly Finding[],
  labelForNode: (nodeId: string) => string | undefined,
  now: number = Date.now()
): FindingToast[] {
  return findings.map((finding, index) => {
    const focusNodeId = finding.relatedNodeIds[0];
    const subjectLabel = focusNodeId ? labelForNode(focusNodeId) : undefined;
    return {
      id: `${finding.id}-${now}-${index}`,
      dedupeKey: `${finding.id}|${finding.relatedNodeIds.join(",")}|${finding.relatedEdgeIds.join(",")}`,
      severity: severityFor(finding),
      title: finding.title,
      detail: finding.detail,
      subjectLabel,
      metricSummary: finding.evidence[0],
      suggestedAction: finding.suggestedAction,
      focusNodeId,
      findingId: finding.id,
      createdAt: now,
      repeatCount: 0
    };
  });
}

/**
 * Recommendations are surfaced as their own toast severity even though the
 * engine records them at info level, because "you could improve this" and
 * "here is a fact about your run" warrant different visual weight.
 */
function severityFor(finding: Finding): ToastSeverity {
  if (finding.source === "recommendation" && finding.severity === "info") return "recommendation";
  return finding.severity;
}
