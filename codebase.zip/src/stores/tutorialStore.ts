import { create } from "zustand";
import { persist } from "zustand/middleware";
import { getTutorial } from "@/domain/tutorials/registry";

export interface TutorialProgress {
  currentStepIndex: number;
  acknowledgedStepIds: string[];
  completed: boolean;
  revealedHintCount: number;
}

interface TutorialState {
  activeTutorialId?: string;
  progressByTutorial: Record<string, TutorialProgress>;
  start(tutorialId: string): void;
  acknowledge(stepId: string, acknowledged: boolean): void;
  next(): void;
  back(): void;
  restart(): void;
  exit(): void;
  revealHint(): void;
}

const initialProgress = (): TutorialProgress => ({
  currentStepIndex: 0,
  acknowledgedStepIds: [],
  completed: false,
  revealedHintCount: 0
});

export const useTutorialStore = create<TutorialState>()(
  persist(
    (set) => ({
      activeTutorialId: undefined,
      progressByTutorial: {},

      start(tutorialId) {
        if (!getTutorial(tutorialId)) throw new Error(`Unknown tutorial "${tutorialId}".`);
        set((state) => ({
          activeTutorialId: tutorialId,
          progressByTutorial: state.progressByTutorial[tutorialId]
            ? state.progressByTutorial
            : { ...state.progressByTutorial, [tutorialId]: initialProgress() }
        }));
      },

      acknowledge(stepId, acknowledged) {
        set((state) => {
          const tutorialId = state.activeTutorialId;
          if (!tutorialId) return state;
          const progress = state.progressByTutorial[tutorialId] ?? initialProgress();
          const ids = new Set(progress.acknowledgedStepIds);
          if (acknowledged) ids.add(stepId);
          else ids.delete(stepId);
          return {
            progressByTutorial: {
              ...state.progressByTutorial,
              [tutorialId]: { ...progress, acknowledgedStepIds: [...ids] }
            }
          };
        });
      },

      next() {
        set((state) => {
          const tutorialId = state.activeTutorialId;
          const tutorial = tutorialId ? getTutorial(tutorialId) : undefined;
          if (!tutorialId || !tutorial) return state;
          const progress = state.progressByTutorial[tutorialId] ?? initialProgress();
          const isLast = progress.currentStepIndex >= tutorial.steps.length - 1;
          return {
            progressByTutorial: {
              ...state.progressByTutorial,
              [tutorialId]: {
                ...progress,
                currentStepIndex: isLast
                  ? progress.currentStepIndex
                  : progress.currentStepIndex + 1,
                completed: isLast
              }
            },
            activeTutorialId: isLast ? undefined : tutorialId
          };
        });
      },

      back() {
        set((state) => {
          const tutorialId = state.activeTutorialId;
          if (!tutorialId) return state;
          const progress = state.progressByTutorial[tutorialId] ?? initialProgress();
          return {
            progressByTutorial: {
              ...state.progressByTutorial,
              [tutorialId]: {
                ...progress,
                currentStepIndex: Math.max(0, progress.currentStepIndex - 1)
              }
            }
          };
        });
      },

      restart() {
        set((state) => {
          const tutorialId = state.activeTutorialId;
          if (!tutorialId) return state;
          return {
            progressByTutorial: {
              ...state.progressByTutorial,
              [tutorialId]: initialProgress()
            }
          };
        });
      },

      exit() {
        set({ activeTutorialId: undefined });
      },

      revealHint() {
        set((state) => {
          const tutorialId = state.activeTutorialId;
          if (!tutorialId) return state;
          const progress = state.progressByTutorial[tutorialId] ?? initialProgress();
          return {
            progressByTutorial: {
              ...state.progressByTutorial,
              [tutorialId]: {
                ...progress,
                revealedHintCount: progress.revealedHintCount + 1
              }
            }
          };
        });
      }
    }),
    {
      name: "system-design-simulator-tutorials",
      partialize: (state) => ({ progressByTutorial: state.progressByTutorial })
    }
  )
);
