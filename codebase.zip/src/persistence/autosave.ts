import { z } from "zod";
import {
  parseProjectDocument,
  type ProjectDocument
} from "@/domain/architecture/projectDocument";

export const AUTOSAVE_VERSION = 1;

/** Browser-fallback storage key, used only when the Electron bridge is absent. */
const AUTOSAVE_STORAGE_KEY = "sds:autosave-draft";

/**
 * localStorage ceiling. Browsers typically cap the whole origin near 5 MB, so
 * we refuse oversized drafts rather than throwing a QuotaExceededError mid-edit.
 */
const MAX_BROWSER_AUTOSAVE_BYTES = 4 * 1024 * 1024;

const autosaveEnvelopeSchema = z.object({
  version: z.literal(AUTOSAVE_VERSION),
  savedAt: z.string().min(1),
  filePath: z.string().min(1).optional(),
  isDirty: z.boolean().default(true),
  document: z.unknown()
});

export interface AutosaveRecord {
  version: typeof AUTOSAVE_VERSION;
  savedAt: string;
  filePath?: string;
  /** Whether the work had unwritten changes, so recovery can report accurately. */
  isDirty: boolean;
  document: ProjectDocument;
}

function bridge() {
  return typeof window !== "undefined" ? window.simulator : undefined;
}

export function buildAutosaveRecord(
  document: ProjectDocument,
  filePath: string | undefined,
  isDirty: boolean
): AutosaveRecord {
  return {
    version: AUTOSAVE_VERSION,
    savedAt: new Date().toISOString(),
    ...(filePath ? { filePath } : {}),
    isDirty,
    document
  };
}

/**
 * Persists a recovery draft. Autosave is strictly best-effort: a failure here
 * must never interrupt editing, so every path resolves rather than throws.
 */
export async function writeAutosave(
  document: ProjectDocument,
  filePath: string | undefined,
  isDirty: boolean
): Promise<boolean> {
  const record = buildAutosaveRecord(document, filePath, isDirty);
  const api = bridge();
  if (api) {
    try {
      const result = await api.autosave.write({ record });
      return result.ok;
    } catch {
      return false;
    }
  }
  try {
    const serialized = JSON.stringify(record);
    if (serialized.length > MAX_BROWSER_AUTOSAVE_BYTES) return false;
    window.localStorage.setItem(AUTOSAVE_STORAGE_KEY, serialized);
    return true;
  } catch {
    return false;
  }
}

/**
 * Reads a recovery draft, validating it through the same schema as any opened
 * project file. A corrupt or outdated draft is discarded, never surfaced as an
 * error and never allowed to block startup.
 */
export async function readAutosave(): Promise<AutosaveRecord | undefined> {
  let raw: unknown;
  const api = bridge();
  if (api) {
    try {
      const result = await api.autosave.read();
      if (!result.ok || result.data === undefined) return undefined;
      raw = result.data;
    } catch {
      return undefined;
    }
  } else {
    try {
      const stored = window.localStorage.getItem(AUTOSAVE_STORAGE_KEY);
      if (!stored) return undefined;
      raw = JSON.parse(stored);
    } catch {
      return undefined;
    }
  }

  const envelope = autosaveEnvelopeSchema.safeParse(raw);
  if (!envelope.success) return undefined;
  const parsed = parseProjectDocument(envelope.data.document);
  if (!parsed.ok || !parsed.document) return undefined;

  return {
    version: AUTOSAVE_VERSION,
    savedAt: envelope.data.savedAt,
    ...(envelope.data.filePath ? { filePath: envelope.data.filePath } : {}),
    isDirty: envelope.data.isDirty,
    document: parsed.document
  };
}

export async function clearAutosave(): Promise<void> {
  const api = bridge();
  if (api) {
    try {
      await api.autosave.clear();
    } catch {
      // Best-effort: a stale draft is harmless because restore is user-confirmed.
    }
    return;
  }
  try {
    window.localStorage.removeItem(AUTOSAVE_STORAGE_KEY);
  } catch {
    // Ignore storage failures (private mode, disabled storage).
  }
}

/**
 * A draft is only worth keeping if it holds actual design work. This keeps the
 * pristine seed project from producing a recovery prompt on every launch.
 */
export function isRestorableDraft(document: ProjectDocument): boolean {
  return document.nodes.length > 0 || document.edges.length > 0;
}
