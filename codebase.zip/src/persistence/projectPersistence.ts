import { parseProjectDocument, type ProjectDocument } from "@/domain/architecture/projectDocument";

export interface PersistenceResult {
  ok: boolean;
  error?: string;
  filePath?: string;
  document?: ProjectDocument;
}

function bridge() {
  return typeof window !== "undefined" ? window.simulator : undefined;
}

/**
 * Opens a project through the native file dialog (Electron) when available.
 * In a plain browser dev context (no Electron bridge), falls back to the
 * browser's file picker so `npm run dev` remains usable without Electron.
 */
export async function openProject(): Promise<PersistenceResult> {
  const api = bridge();
  if (api) {
    const result = await api.project.open();
    if (!result.ok || result.data === undefined) return { ok: false, error: result.error };
    const parsed = parseProjectDocument(result.data);
    if (!parsed.ok) return { ok: false, error: parsed.error };
    return { ok: true, filePath: result.filePath, document: parsed.document };
  }
  return openProjectViaBrowserPicker();
}

export async function saveProject(
  document: ProjectDocument,
  filePath: string | undefined
): Promise<PersistenceResult> {
  const api = bridge();
  if (api) {
    const result = await api.project.save({ filePath, document });
    return { ok: result.ok, error: result.error, filePath: result.filePath };
  }
  return saveProjectViaBrowserDownload(document);
}

export async function exportProjectJson(document: ProjectDocument): Promise<PersistenceResult> {
  const api = bridge();
  if (api) {
    const result = await api.project.exportJson({ document });
    return { ok: result.ok, error: result.error };
  }
  return saveProjectViaBrowserDownload(document);
}

async function openProjectViaBrowserPicker(): Promise<PersistenceResult> {
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json";
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) {
        resolve({ ok: false, error: "cancelled" });
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const parsed = parseProjectDocument(JSON.parse(String(reader.result)));
          if (!parsed.ok) {
            resolve({ ok: false, error: parsed.error });
          } else {
            resolve({ ok: true, document: parsed.document, filePath: file.name });
          }
        } catch {
          resolve({ ok: false, error: "read-or-parse-failed" });
        }
      };
      reader.readAsText(file);
    };
    input.click();
  });
}

function saveProjectViaBrowserDownload(projectDocument: ProjectDocument): PersistenceResult {
  const filename = `${safeFileName(projectDocument.name)}.json`;
  const blob = new Blob([JSON.stringify(projectDocument, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
  return { ok: true, filePath: filename };
}

function safeFileName(name: string): string {
  const sanitized = Array.from(name.trim())
    .map((character) =>
      character.charCodeAt(0) < 32 || '<>:"/\\|?*'.includes(character) ? "-" : character
    )
    .join("");
  return sanitized || "project";
}
