import { useEffect, useRef, useState } from "react";
import { useProjectStore } from "@/stores/projectStore";
import {
  clearAutosave,
  isRestorableDraft,
  readAutosave,
  writeAutosave
} from "@/persistence/autosave";

/** Debounce window: long enough to coalesce rapid edits, short enough to survive a crash. */
const AUTOSAVE_DEBOUNCE_MS = 1000;

export type AutosaveStatus = "idle" | "saving" | "saved" | "error";

export interface RecoveredDraft {
  savedAt: string;
}

export interface AutosaveController {
  status: AutosaveStatus;
  lastSavedAt?: string;
  /** Set once a draft has been restored, until the user dismisses the notice. */
  recovered?: RecoveredDraft;
  dismissRecovery(): void;
  discardRecovery(): void;
}

/**
 * Drives crash/refresh recovery: restores any draft on mount, then continuously
 * autosaves the working document to application-owned storage.
 *
 * Autosave is deliberately independent of explicit Save — it never writes to the
 * user's project file and never changes `isDirty`.
 */
export function useAutosave(): AutosaveController {
  const document = useProjectStore((state) => state.document);
  const filePath = useProjectStore((state) => state.filePath);
  const isDirty = useProjectStore((state) => state.isDirty);
  const restoreDocument = useProjectStore((state) => state.restoreDocument);

  const [status, setStatus] = useState<AutosaveStatus>("idle");
  const [lastSavedAt, setLastSavedAt] = useState<string>();
  const [recovered, setRecovered] = useState<RecoveredDraft>();

  // Restore must complete before the first autosave write, otherwise the empty
  // seed document would immediately overwrite the draft we are trying to recover.
  const hydratedRef = useRef(false);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const draft = await readAutosave();
      if (cancelled) return;
      if (draft && isRestorableDraft(draft.document)) {
        restoreDocument(draft.document, draft.filePath, draft.isDirty);
        // Only announce recovery for work that was never written to a file;
        // silently reloading already-saved work needs no user decision.
        if (draft.isDirty) {
          setRecovered({ savedAt: draft.savedAt });
        }
        setLastSavedAt(draft.savedAt);
      }
      hydratedRef.current = true;
      setHydrated(true);
    })();
    return () => {
      cancelled = true;
    };
  }, [restoreDocument]);

  useEffect(() => {
    if (!hydrated) return;

    if (!isRestorableDraft(document)) {
      // An emptied canvas should clear the draft rather than resurrect old work.
      void clearAutosave();
      setStatus("idle");
      return;
    }

    setStatus("saving");
    const timer = window.setTimeout(() => {
      void (async () => {
        const ok = await writeAutosave(document, filePath, isDirty);
        if (!hydratedRef.current) return;
        if (ok) {
          setStatus("saved");
          setLastSavedAt(new Date().toISOString());
        } else {
          setStatus("error");
        }
      })();
    }, AUTOSAVE_DEBOUNCE_MS);

    return () => window.clearTimeout(timer);
  }, [document, filePath, isDirty, hydrated]);

  useEffect(() => {
    return () => {
      hydratedRef.current = false;
    };
  }, []);

  return {
    status,
    lastSavedAt,
    recovered,
    dismissRecovery: () => setRecovered(undefined),
    discardRecovery: () => {
      setRecovered(undefined);
      void clearAutosave();
      useProjectStore.getState().newProject();
    }
  };
}
