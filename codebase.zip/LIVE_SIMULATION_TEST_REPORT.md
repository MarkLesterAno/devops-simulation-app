# Ultimate System Design Simulator

## Live Simulation Technical Test Report

**Application URL:** http://localhost:5173/  
**Application title:** Ultimate System Design Simulator  
**Test date:** 2026-09-28  
**Test type:** Browser-based end-to-end functional validation  
**Test perspective:** System-design simulation effectiveness and AI-agent readiness  
**Environment:** Local Vite/web application accessed through a Chromium browser  
**Overall status:** Core simulation effective; export remediation implemented after review

---

## 1. Executive summary

The live application was tested through its primary architecture-design and simulation workflows. The core product behavior is effective:

- The application loads and renders the architecture canvas and component palette.
- Scenarios can be selected from the scenario library and instantiated as editable projects.
- Traffic profiles and fault scenarios are applied to a deterministic simulation.
- Request-flow playback visualizes traffic moving through the architecture.
- Metrics provide request totals, success/failure counts, error rate, latency percentiles, availability, per-component telemetry, and an event timeline.
- Findings identify architectural weaknesses such as single points of failure and disconnected nodes.
- Manual request batches can be queued and included in a subsequent simulation.
- Unsaved work is recovered after page reload and can be retained or discarded.

The application is therefore effective as an interactive system-design learning and analysis tool. It is not yet fully release-ready because the export surface is incomplete:

1. PNG export failed with a Content Security Policy violation involving a generated `blob:` image URL.
2. Save and JSON export previously produced no observable completion feedback during testing.

### Post-review remediation

- The image CSP now permits the app's locally generated `blob:` URLs, allowing the PNG renderer to load its intermediate SVG image without permitting external image origins.
- Browser save and JSON-export paths now return the generated filename, and Save, JSON export, and PNG export each emit a clear in-app success notification.
- The browser test harness may still not expose downloads as files; the new completion feedback makes the browser action observable to users and agents.

These export issues do not invalidate the simulation engine, but they limit reportability, portability, and downstream AI-agent workflows that depend on machine-readable architecture artifacts.

---

## 2. Scope and test objectives

### 2.1 In scope

- Initial application load and baseline state
- Component palette and canvas interaction
- Scenario library and scenario instantiation
- Architecture validation and findings
- Traffic profile selection
- Fault scenario execution
- Deterministic simulation execution
- Playback controls and request-flow visualization
- Simulation metrics and event timeline
- Manual request-batch composition and execution
- Findings history and repeated findings
- Recovery of unsaved work after reload
- Save, JSON export, and PNG export surfaces
- Browser console/page-error observations during tested flows

### 2.2 Out of scope

- Source-code inspection
- Backend/API integration testing
- Multi-user collaboration
- Performance testing under browser/device load
- Accessibility conformance certification
- Cross-browser compatibility
- Security penetration testing
- Validation of downloaded file contents, because Save and JSON export did not emit observable downloads in the browser test harness

### 2.3 Test objectives

The test sought to determine whether an AI agent can use the application to:

1. Construct or load a distributed architecture.
2. Apply workload and failure conditions.
3. Execute a simulation.
4. Interpret architectural findings and quantitative telemetry.
5. Execute targeted manual requests.
6. Recover from a reload without silently losing work.
7. Export the resulting architecture or evidence for downstream processing.

---

## 3. Test environment and observability

### 3.1 Browser-observable surfaces

The application exposed accessible controls for:

- New, Templates, Open, Save
- Export JSON and Export PNG
- Undo and Redo
- Traffic profile, fault scenario, seed, and duration
- Run
- Send requests
- View Metrics
- Findings
- Flow animation
- Playback pause, replay, skip, and speed controls

The application also exposed semantic labels for the canvas, nodes, utilization progress bars, dialogs, tables, alerts, and status messages. This is favorable for AI-agent operation because controls can be addressed by stable roles and labels rather than visual coordinates.

### 3.2 Determinism

The simulation accepted a numeric seed. The tested scenario used seed `42`, which allowed repeatable execution and consistent findings:

- Application-server outage
- 30,000 ms run duration
- Steady traffic at 100 RPS

Deterministic inputs are important for an AI agent because they allow before/after architecture comparisons and regression assertions.

---

## 4. Detailed test matrix

| ID | Test area | Procedure | Expected result | Observed result | Status |
|---|---|---|---|---|---|
| T01 | Initial load | Navigate to `http://localhost:5173/` | App renders without blocking error | Title and main toolbar rendered; Run initially disabled because the architecture was empty | PASS |
| T02 | Scenario library | Open Templates | Scenario dialog shows searchable/filterable scenario catalog | 16 scenarios displayed with difficulty, duration, tags, objectives, and documentation metadata | PASS |
| T03 | Scenario instantiation | Open Basic Web Application | Canvas receives template nodes and edges | 5 components and 4 connections loaded | PASS |
| T04 | Architecture guidance | Inspect validation panel | Guidance reports known structural risks | Reported single application-server instance with no redundancy | PASS |
| T05 | Component addition | Add Server from palette | New node is added and validation updates | Server node added; disconnected-node finding appeared | PASS |
| T06 | Fault simulation | Run with application server outage | Playback and findings reflect outage | Run completed; availability dropped to 39.97% | PASS |
| T07 | Playback | Pause, skip, replay, change speed | Playback controls update state and position | Pause/skip controls worked; playback reached 30.0/30.0 s | PASS |
| T08 | Metrics | Open View Metrics after run | Metrics dialog exposes aggregate and component telemetry | Requests, latency, availability, methods, component table, timeline, and assumptions displayed | PASS |
| T09 | Findings | Open Findings | Finding history is visible and actionable | Critical and warning findings shown with severity, description, count, and actions | PASS |
| T10 | Manual requests | Queue 10 GET requests at 10 req/s | Batch appears in queue and is included in next run | Batch displayed as `GET /api/test ×10 · 10 req/s · 1.00 s` | PASS |
| T11 | Manual request execution | Run queued-only batch | Batch completes with correct metrics | 10 total, 10 successful, 0 failed, 100.00% availability | PASS |
| T12 | Reload recovery | Reload after unsaved changes | Recovery prompt appears | Recovered unsaved work prompt appeared with Keep and Discard actions | PASS |
| T13 | Recovery discard | Choose Discard and confirm | App returns to clean project | Empty initial state restored; Run disabled | PASS |
| T14 | Save | Click Save | Project file download/dialog/confirmation occurs | No observable download or completion feedback | FAIL |
| T15 | JSON export | Click Export JSON | JSON file download occurs | No observable download or completion feedback | FAIL |
| T16 | PNG export | Click Export PNG | PNG file download occurs | Export failed; app displayed “Could not export diagram” | FAIL |
| T17 | Runtime errors | Monitor console/page errors during normal flows | No unhandled runtime failures | Normal flows were clean; PNG export emitted a CSP error | CONDITIONAL |

---

## 5. Simulation evidence

### 5.1 Faulted architecture run

The Basic Web Application scenario was loaded with a single application server and a single relational database. The application-server outage fault was then executed.

Observed aggregate metrics:

| Metric | Value |
|---|---:|
| Total requests | 3,000 |
| Successful requests | 1,199 |
| Failed requests | 1,801 |
| Requests per second | 100.0 |
| Error rate | 60.0% |
| p50 latency | 2 ms |
| p95 latency | 73 ms |
| p99 latency | 75 ms |
| Observed availability | 39.97% |

Observed failure timeline entries included:

- `node-unavailable`
- `no-healthy-target`

The result is technically useful: it demonstrates that the simulator propagates a component outage through a synchronous request path and exposes the resulting availability degradation.

### 5.2 Manual request-batch run

A manual batch was configured as follows:

| Input | Value |
|---|---|
| Origin | Browser Client |
| Method | GET |
| Path | `/api/test` |
| Number of requests | 10 |
| Dispatch rate | 10 req/s |
| Start time | 0 ms |
| Request class | Infer from method |
| Traffic profile load | Suppressed |

The batch was queued and then executed.

Observed metrics:

| Metric | Value |
|---|---:|
| Total requests | 10 |
| Successful requests | 10 |
| Failed requests | 0 |
| Requests per second | 0.3 aggregate over the 30-second run |
| Error rate | 0.0% |
| p50 latency | 70 ms |
| p95 latency | 89 ms |
| p99 latency | 89 ms |
| Observed availability | 100.00% |

The metrics dialog explicitly identified the user-triggered manual batch, confirming that manual traffic is retained as separate simulation evidence.

---

## 6. Functional assessment by capability

### 6.1 Architecture modeling

**Assessment: Effective.**

The application provides a useful palette of conceptual, behavioral, and advanced components, including clients, DNS, load balancers, servers, caches, databases, queues, topics, autoscalers, circuit breakers, and identity services. Scenario templates accelerate setup while still allowing edits.

The architecture validation panel provides immediate feedback when a node is disconnected or lacks redundancy. This is especially useful for an AI agent because the validation output is explicit, semantic, and actionable.

### 6.2 Simulation engine

**Assessment: Effective for educational and comparative simulation.**

The engine models deterministic request flow, per-hop latency, component availability, capacity effects, fault scenarios, request methods, and manual request batches. The outage test generated plausible and internally consistent failure telemetry.

The application also states assumptions in the metrics dialog, including:

- Capacity is modeled as concurrent in-flight request slots rather than literal RPS ceilings.
- CDN and load balancer nodes are near-zero-overhead forwarders in the MVP.
- Retries are bounded by node configuration and the shared request deadline.
- Queue consumption uses configured throughput per worker instance.
- Manual request batches are logical arrivals only and generate no external network traffic.
- Playback replays recorded telemetry and does not recalculate results.

These assumptions are valuable for preventing an AI agent from over-interpreting results as production capacity measurements.

### 6.3 Diagnostics and learning feedback

**Assessment: Strong.**

Findings were presented with severity, title, affected component, explanation, repetition count, and actions such as View Metrics and Focus component. This gives an AI agent both a diagnosis and a navigation target for remediation.

The tested findings included:

- **Critical:** Observed availability below 99%
- **Warning:** Single point of failure — Application Server
- **Warning:** Disconnected node — Server

### 6.4 Evidence and reporting

**Assessment: Partially effective.**

The metrics and event timeline provide strong in-app evidence. However, inability to export JSON and PNG reduces the ability to preserve, compare, or hand off results to another tool or AI agent.

### 6.5 Persistence and recovery

**Assessment: Recovery works; explicit project export is unresolved.**

Reload recovery correctly detected unsaved work and presented Keep/Discard choices. Discarding required confirmation and returned the application to a clean state.

The Save action did not produce an observable file download or confirmation in the test harness. This should be treated as a separate issue from recovery persistence: recovery persistence worked, while explicit project persistence was not verified.

---

## 7. Defects and technical diagnosis

### DEF-001 — PNG export blocked by Content Security Policy

**Severity:** High  
**Category:** Export / browser security policy  
**Reproducibility:** Reproduced during live testing  

#### Reproduction

1. Load the application.
2. Load the Basic Web Application scenario.
3. Click **Export PNG**.

#### Observed behavior

The application displayed:

> Could not export diagram  
> Could not render the diagram for export.

The browser also reported:

> Loading the image `blob:http://localhost:5173/...` violates the following Content Security Policy directive: `img-src 'self' data:`.

The request for the generated blob URL failed with reason `csp`.

#### Likely root cause

The PNG export implementation creates or consumes a `blob:` URL for an intermediate image, but the active Content Security Policy only allows images from `'self'` and `data:`. The CSP therefore blocks the image before the diagram can be rendered or downloaded.

#### Recommended remediation

Choose one consistent strategy:

1. Add `blob:` to the appropriate `img-src` directive if the blob workflow is intentional and acceptable:

   ```text
   img-src 'self' data: blob:
   ```

2. Preferably, avoid an intermediate blob image where possible by rendering directly to a canvas/data URL or by using an export library compatible with the deployed CSP.
3. Add an automated browser test that asserts:
   - Export PNG produces a download.
   - No CSP console error is emitted.
   - The downloaded file has a PNG MIME type and non-zero size.
4. Preserve the existing user-facing error notification, but include diagnostic logging that identifies the export stage that failed.

### DEF-002 — Save action has no observable completion

**Severity:** Medium  
**Category:** Persistence / UX feedback  
**Reproducibility:** Observed during live testing  

#### Observed behavior

Clicking **Save** did not produce an observable browser download, file chooser, dialog, toast, or error in the browser test harness.

#### Risk

An AI agent cannot reliably determine whether the project was persisted. This creates ambiguity between:

- a successful file save that the browser did not expose to the harness,
- an unimplemented action,
- a blocked download,
- or a silent failure.

#### Recommended remediation

- Emit a success notification containing the saved filename.
- Emit an error notification when serialization or download initiation fails.
- Make the download filename deterministic and document its schema.
- Add a browser test that captures the download event and validates file contents.

### DEF-003 — JSON export has no observable completion

**Severity:** Medium  
**Category:** Interoperability / export  
**Reproducibility:** Observed during live testing  

#### Observed behavior

Clicking **Export JSON** did not produce an observable download or success/error feedback.

#### Risk

JSON export is the most important interoperability path for an AI agent. Without a verified artifact, an agent cannot reliably:

- persist an architecture as structured input,
- compare architecture versions,
- run external validation,
- attach simulation evidence to a generated report,
- or restore a project in another session.

#### Recommended remediation

- Define and document a versioned JSON schema.
- Emit a successful download notification with filename and byte size.
- Validate the serialized document before download.
- Add a round-trip test: export JSON, import/open JSON, and assert node, edge, configuration, and scenario equivalence.
- Add a browser test asserting a non-empty `.json` download and valid JSON parsing.

---

## 8. AI-agent readiness assessment

### Strengths

1. **Accessible control model:** Controls expose semantic names and roles suitable for browser automation.
2. **Deterministic execution:** Seed, traffic, duration, and fault inputs support reproducibility.
3. **Structured findings:** Diagnostic output is explicit and machine-readable in the accessibility tree.
4. **Quantitative evidence:** Metrics are presented as labeled values and tables rather than only visual charts.
5. **Actionable navigation:** Findings can open metrics or focus a component.
6. **Clear assumptions:** The metrics dialog documents model limitations.
7. **No external request side effects:** Manual requests are explicitly simulated inside the engine.

### Gaps

1. **Artifact extraction:** JSON export is not currently verifiable.
2. **Visual artifact extraction:** PNG export is broken under the current CSP.
3. **Completion signaling:** Save/export actions lack reliable success/failure states.
4. **Semantic identifiers:** The application would benefit from stable IDs exposed through data attributes for nodes, edges, findings, and run IDs.
5. **Machine-readable run contract:** A documented schema for inputs, outputs, assumptions, and findings would simplify autonomous evaluation.

### Recommended AI-agent contract

For reliable autonomous use, expose or document the following:

```text
Architecture input:
  nodes[]
  edges[]
  node configuration
  traffic profile
  fault scenario
  seed
  duration_ms
  manual request batches[]

Simulation output:
  run_id
  total_requests
  successful_requests
  failed_requests
  error_rate
  latency_p50_ms
  latency_p95_ms
  latency_p99_ms
  observed_availability
  per_component_metrics[]
  event_timeline[]
  findings[]
  assumptions[]
```

An AI agent should also be able to distinguish:

- architecture validation findings before a run,
- runtime findings generated by a run,
- repeated findings aggregated from history,
- and export/persistence failures.

---

## 9. Release recommendation

### Current recommendation

**Accept for internal use, demonstrations, and system-design learning. Do not declare fully production-ready until export behavior is fixed and covered by automated tests.**

### Exit criteria for release readiness

- [ ] PNG export succeeds without CSP errors.
- [ ] JSON export produces a valid, non-empty, versioned JSON file.
- [ ] Save produces a valid project file and explicit success feedback.
- [ ] Export failures produce actionable error messages.
- [ ] Browser tests cover all three export actions.
- [ ] JSON round-trip preserves architecture and simulation configuration.
- [ ] A machine-readable run-result contract is documented.
- [ ] Regression tests verify deterministic metrics for a fixed seed and scenario.

---

## 10. Final conclusion

The Ultimate System Design Simulator is effective as a core simulation and architecture-analysis tool. Its strongest capabilities are deterministic fault simulation, request-flow playback, quantitative metrics, and actionable architectural findings. The test demonstrated both degraded behavior under an application-server outage and successful handling of a targeted manual request batch.

The primary remaining weakness is not the simulation engine; it is evidence portability. Until Save, JSON export, and PNG export reliably produce artifacts with explicit completion states, an AI agent can analyze results inside the application but cannot dependably preserve or transfer those results to downstream workflows.
